# Pizza.py script to viz E Coli particles

d = dump("dump.ecoli")
g = gl(d)
g.arad(0,0.01)
v = vcr(g)
