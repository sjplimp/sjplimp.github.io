/* Dummy defs for MPI C stubs */

#define MPI_Comm int
#define MPI_Request int
#define MPI_Status int
#define MPI_Datatype int
#define MPI_Op int

#define MPI_INT 1
#define MPI_FLOAT 2
#define MPI_DOUBLE 3
#define MPI_BYTE 4

#define MPI_SUM 1
#define MPI_MAX 2
#define MPI_MIN 3
