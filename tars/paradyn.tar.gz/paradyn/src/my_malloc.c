/* 

c ParaDyn - Parallel DYNAMO - molecular dynamics with EAM potentials
c 
c Authored by Steve Plimpton
c   (505) 845-7873, sjplimp@cs.sandia.gov
c   Dept 9221, MS 1111, Sandia National Labs, Albuquerque, NM  87185-1111
c
c Based on the serial DYNAMO code authored by
c   Stephen Foiles (foiles@ca.sandia.gov), Sandia National Labs, Livermore, CA
c   Murray Daw (daw@hubcap.clemson.edu), Clemson University
c
c See the README file for more information
c

*/

/* Robust versions of malloc, free, realloc
   allow for 0-length requests and NULL ptrs */

#include "stdio.h"

/* ------------------------------------------------------------------------ */
/* Malloc with error checking */

char *my_malloc(int n)

{
  char *ptr;

  if (n == 0) return NULL;

  ptr = (char *) malloc(n);

  if (ptr == NULL) {
    printf("ERROR: Could not malloc %d bytes\n",n);
    exit(0);
  }

  return ptr;
}

/* ------------------------------------------------------------------------ */
/* Free with error checking */

void my_free(char *ptr)

{
  if (ptr == NULL) return;

  free(ptr);
}

/* ------------------------------------------------------------------------ */
/* Realloc with error checking */

char *my_realloc(char *ptr, int n)

{
  if (n == 0) {
    if (ptr != NULL) free(ptr);
    return NULL;
  }

  if (ptr == NULL)
    ptr = (char *) malloc(n);
  else
    ptr = (char *) realloc(ptr,n);

  if (ptr == NULL) {
    printf("ERROR: Could not realloc %d bytes\n",n);
    exit(0);
  }

  return ptr;
}
