c ParaDyn - Parallel DYNAMO - molecular dynamics with EAM potentials
c 
c Authored by Steve Plimpton
c   (505) 845-7873, sjplimp@cs.sandia.gov
c   Dept 9221, MS 1111, Sandia National Labs, Albuquerque, NM  87185-1111
c
c Based on the serial DYNAMO code authored by
c   Stephen Foiles (foiles@ca.sandia.gov), Sandia National Labs, Livermore, CA
c   Murray Daw (daw@hubcap.clemson.edu), Clemson University
c
c See the README file for more information
c

      implicit real*8 (a-h,o-z)

c Static array bounds

      parameter (maxtype=3)
      parameter (maxgridin=1010)
      parameter (maxgridout=1010)
      parameter (maxtmp=10)
      parameter (maxfix=10)
      parameter (maxbin=10000)

c Dynamic or static array bounds

#ifdef DYNAMIC
      parameter (extra_neigh=1.5)
      integer maxlocal,maxrow,maxcol,maxnsmall,maxnlarge
      common /blk00/ maxlocal,maxrow,maxcol,maxnsmall,maxnlarge
#else
      parameter (maxlocal=500)
      parameter (maxrow=500)
      parameter (maxcol=500)
      parameter (maxnsmall=50)
      parameter (maxnlarge=80)
#endif

c Clear routine

      common /blk01/ node,nprocs,logflag,limitflag
      common /blk02/ boltz,conmas,time_limit

c Input settings

      integer pmeth,idynper(3)
      real*8 dstress(3)

      common /blk11/ dt,dradn,dpress,dstress
      common /blk12/ nmeth,ibdtyp,ithermo,idump,idumpvel,idumpstrs
      common /blk13/ idynper,pmeth,newton

c Temperature controls

      integer tmpkind(maxtmp)
      integer tmpflag(maxtmp),tmpnum(0:maxtmp),tmpiwork(0:maxtmp)
      real*8 tmpstart(maxtmp),tmpend(maxtmp),tmpq(maxtmp)
      real*8 drag(maxtmp),tmpreg(2,3,maxtmp),tmpnow(0:maxtmp)
      real*8 target(maxtmp),tmpvec(3,maxtmp),tmpwork(0:maxtmp)

      common /blk21/ ntemps,langseed,tmpkind
      common /blk22/ tmpflag,tmpnum,tmpiwork
      common /blk23/ tmpstart,tmpend,tmpq,drag,tmpreg
      common /blk24/ tmpnow,target,tmpvec,tmpwork

#ifdef DYNAMIC
      integer tmptag(1),tmpseed(1)
      pointer (tmptag_ptr,tmptag),(tmpseed_ptr,tmpseed)
      common /blk29/ tmptag_ptr,tmpseed_ptr
#else
      integer tmptag(maxlocal),tmpseed(maxlocal)
      common /blk29/ tmptag,tmpseed
#endif

c Constraints

      integer fixkind(maxfix)
      real*8 fixreg(2,3,maxfix),fixvec(3,maxfix)

      common /blk31/ nfixes
      common /blk38/ fixkind
      common /blk39/ fixreg,fixvec

#ifdef DYNAMIC
      integer fixtag(1)
      pointer (fixtag_ptr,fixtag)
      common /blk39/ fixtag_ptr
#else
      integer fixtag(maxlocal)
      common /blk39/ fixtag
#endif

c Read potential

      character*80 potfile
      integer nrhoin(maxtype),nrin(maxtype),ielement(maxtype)
      real*8 amass(maxtype),alat(maxtype),drhoin(maxtype)
      real*8 drin(maxtype),rcut(maxtype)
      real*8 frhoin(maxgridin,maxtype),rhorin(maxgridin,maxtype)
      real*8 zrin(maxgridin,maxtype)
      real*8 frho(maxgridin,maxtype),rhor(maxgridin,maxtype)
      real*8 z2r(maxgridin,maxtype,maxtype)

      common /blk41/ potfile
      common /blk42/ npots,ipot,nrhoin,nrin,ielement,nrho,nr
      common /blk43/ amass,alat,drhoin,drin,rcut,drho,dr,rcutmax
      common /blk44/ rdrar,rdrhoar
      common /blk45/ frhoin,rhorin,zrin
      common /blk46/ frho,rhor,z2r

c Interpolate potential

      real*8 zrtemp(maxgridin,maxtype)
      real*8 frhoar(maxgridout,maxtype),frhoar1(maxgridout,maxtype)
      real*8 frhoar2(maxgridout,maxtype),frhoar3(maxgridout,maxtype)
      real*8 frhoar4(maxgridout,maxtype),frhoar5(maxgridout,maxtype)
      real*8 frhoar6(maxgridout,maxtype)
      real*8 rhorar(maxgridout,maxtype),rhorar1(maxgridout,maxtype)
      real*8 rhorar2(maxgridout,maxtype),rhorar3(maxgridout,maxtype)
      real*8 rhorar4(maxgridout,maxtype),rhorar5(maxgridout,maxtype)
      real*8 rhorar6(maxgridout,maxtype)
      real*8 z2rar(maxgridout,maxtype,maxtype)
      real*8 z2rar1(maxgridout,maxtype,maxtype)
      real*8 z2rar2(maxgridout,maxtype,maxtype)
      real*8 z2rar3(maxgridout,maxtype,maxtype)
      real*8 z2rar4(maxgridout,maxtype,maxtype)
      real*8 z2rar5(maxgridout,maxtype,maxtype)
      real*8 z2rar6(maxgridout,maxtype,maxtype)

      common /blk51/ ninterp,nrhoar,nrar
      common /blk52/ cutsq1,cutsq2,trigger,drhoar,drar
      common /blk53/ zrtemp
      common /blk54/ rhorar,rhorar1,rhorar2,rhorar3
      common /blk55/ rhorar4,rhorar5,rhorar6
      common /blk56/ z2rar,z2rar1,z2rar2,z2rar3,z2rar4,z2rar5,z2rar6
      common /blk57/ frhoar,frhoar1,frhoar2,frhoar3
      common /blk58/ frhoar4,frhoar5,frhoar6

c Read and Create and Scale atoms

      character*80 atomfile
      character*3 lattype
      real*8 perlb(3),perub(3),latconst
      integer row_comm,col_comm
      real*8 plan_row,plan_row3,plan_row6
      real*8 plan_col,plan_col3,plan_col6
      integer xlat,ylat,zlat,ilatseed
      real*8 xscale,yscale,zscale

      common /blk61/ atomfile,lattype
      common /blk62/ natoms,ntypes,xlat,ylat,zlat,ilatseed
      common /blk63/ nstart,nend,nlocal,nrow,ncol
      common /blk64/ time_stamp,perlb,perub,latconst
      common /blk65/ row_comm,col_comm
      common /blk66/ plan_row,plan_row3,plan_row6,
     $     plan_col,plan_col3,plan_col6
      common /blk67/ xscale,yscale,zscale

#ifdef DYNAMIC
      integer tag(1),tagtmp(1)
      integer tagrow(1),tagcol(1)
      integer itype(1),itypetmp(1)
      integer ityperow(1),itypecol(1)
      real*8 x(3,1),xtmp(3,1)
      real*8 xrow(3,1),xcol(3,1)

      pointer (tag_ptr,tag),(tagtmp_ptr,tagtmp)
      pointer (tagrow_ptr,tagrow),(tagcol_ptr,tagcol)
      pointer (itype_ptr,itype),(itypetmp_ptr,itypetmp)
      pointer (ityperow_ptr,ityperow),(itypecol_ptr,itypecol)
      pointer (x_ptr,x),(xtmp_ptr,xtmp)
      pointer (xrow_ptr,xrow),(xcol_ptr,xcol)

      common /blk68/ tag_ptr,tagtmp_ptr,tagrow_ptr,tagcol_ptr
      common /blk69/ itype_ptr,itypetmp_ptr,ityperow_ptr,itypecol_ptr
      common /blk69a/ x_ptr,xtmp_ptr,xrow_ptr,xcol_ptr
#else
      integer tag(maxlocal),tagtmp(maxlocal)
      integer tagrow(maxrow),tagcol(maxcol)
      integer itype(maxlocal),itypetmp(maxlocal)
      integer ityperow(maxrow),itypecol(maxcol)
      real*8 x(3,maxlocal),xtmp(3,maxlocal)
      real*8 xrow(3,maxrow),xcol(3,maxcol)

      common /blk68/ tag,tagtmp,tagrow,tagcol
      common /blk69/ itype,itypetmp,ityperow,itypecol
      common /blk69a/ x,xtmp,xrow,xcol
#endif

c Dump atoms

      character*80 dumpfile,dumpvelfile,dumpstrsfile

      common /blk71/ dumpfile,dumpvelfile,dumpstrsfile
      common /blk72/ idumpflag,idumpvelflag,idumpstrsflag

c Read and Create and Scale velocities

      character*80 velfile

      common /blk81/ velfile
      common /blk82/ nvelocities,iseed
      common /blk83/ t_request

#ifdef DYNAMIC
      real*8 v(3,1)
      pointer (v_ptr,v)
      common /blk89/ v_ptr
#else
      real*8 v(3,maxlocal)
      common /blk89/ v
#endif

c Minimize routines

      common /blk91/ tolerance,maxstep

c Dynamics routines

      real*8 perlen(3),bnddrg(3),bndvel(3),bndmas(3)
      real*8 stress(6),stresstmp(6)

      common /blk101/ ntimes,ndegfr
      common /blk102/ time_mark,c0,c1,c2,c3,c4,c5,perlen
      common /blk103/ stress,stresstmp
      common /blk104/ bnddrg,bndvel,bndmas

#ifdef DYNAMIC
      integer parity(3,1)
      real*8 u1(3,1),u2(3,1),u3(3,1),u4(3,1),u5(3,1)
      real*8 y(6,1),acc(3,1)
      real*8 e(1),etmp(1),erow(1),ecol(1)
      real*8 rho(1),rhotmp(1),rhorow(1),rhocol(1)
      real*8 f(3,1),ftmp(3,1),frow(3,1),fcol(3,1)
      real*8 fp(1),fprow(1),fpcol(1)

      pointer (parity_ptr,parity)
      pointer (u1_ptr,u1),(u2_ptr,u2),(u3_ptr,u3)
      pointer (u4_ptr,u4),(u5_ptr,u5)
      pointer (y_ptr,y),(acc_ptr,acc)
      pointer (e_ptr,e),(etmp_ptr,etmp)
      pointer (erow_ptr,erow),(ecol_ptr,ecol)
      pointer (rho_ptr,rho),(rhotmp_ptr,rhotmp)
      pointer (rhorow_ptr,rhorow),(rhocol_ptr,rhocol)
      pointer (f_ptr,f),(ftmp_ptr,ftmp)
      pointer (frow_ptr,frow),(fcol_ptr,fcol)
      pointer (fp_ptr,fp),(fprow_ptr,fprow),(fpcol_ptr,fpcol)

      common /blk100/ parity_ptr
      common /blk100/ u1_ptr,u2_ptr,u3_ptr,u4_ptr,u5_ptr,y_ptr,acc_ptr
      common /blk100/ e_ptr,etmp_ptr,erow_ptr,ecol_ptr,
     $     rho_ptr,rhotmp_ptr,rhorow_ptr,rhocol_ptr
      common /blk100/ f_ptr,ftmp_ptr,frow_ptr,fcol_ptr,
     $     fp_ptr,fprow_ptr,fpcol_ptr

#ifdef STRESS
      real*8 strs(6,1),strstmp(6,1),strsrow(6,1),strscol(6,1)
      pointer (strs_ptr,strs),(strstmp_ptr,strstmp)
      pointer (strsrow_ptr,strsrow),(strscol_ptr,strscol)
      common /blk109/ strs_ptr,strstmp_ptr,strsrow_ptr,strscol_ptr
#endif

#else
      integer parity(3,maxlocal)
      real*8 u1(3,maxlocal+1),u2(3,maxlocal+1),u3(3,maxlocal+1)
      real*8 u4(3,maxlocal+1),u5(3,maxlocal+1)
      real*8 y(6,maxlocal+1)
      real*8 acc(3,maxlocal+1)
      real*8 e(maxlocal+1),etmp(maxlocal)
      real*8 erow(maxrow),ecol(maxcol)
      real*8 rho(maxlocal),rhotmp(maxlocal)
      real*8 rhorow(maxrow),rhocol(maxcol)
      real*8 f(3,maxlocal+1),ftmp(3,maxlocal)
      real*8 frow(3,maxrow),fcol(3,maxcol)
      real*8 fp(maxlocal),fprow(maxrow),fpcol(maxcol)

      common /blk105/ parity
      common /blk106/ u1,u2,u3,u4,u5,y,acc
      common /blk107/ e,etmp,erow,ecol,rho,rhotmp,rhorow,rhocol
      common /blk108/ f,ftmp,frow,fcol,fp,fprow,fpcol

#ifdef STRESS
      real*8 strs(6,maxlocal),strstmp(6,maxlocal)
      real*8 strsrow(6,maxrow),strscol(6,maxcol)
      common /blk109/ strs,strstmp,strsrow,strscol
#endif

#endif

c Neighbor routines

      real*8 actbuf(6),actlb(3),actlen(3)
      integer binpnt(maxbin)

      common /blk111/ actbuf,actlb,actlen
      common /blk112/ binsizex,binsizey,binsizez
      common /blk113/ nbinx,nbiny,nbinz
      common /blk114/ binpnt

#ifdef DYNAMIC
      integer nsmall_pt(0:1),nlarge_pt(0:1)
      integer jneigh(1)
      real*8 dneigh(3,1),rneigh(1)
      integer nlarge_lst(1)
      integer bin(1)
      real*8 xold(3,1)

      pointer (nsmall_pt_ptr,nsmall_pt),(nlarge_pt_ptr,nlarge_pt)
      pointer (jneigh_ptr,jneigh)
      pointer (dneigh_ptr,dneigh),(rneigh_ptr,rneigh)
      pointer (nlarge_lst_ptr,nlarge_lst)
      pointer (bin_ptr,bin)
      pointer (xold_ptr,xold)

      common /blk115/ nsmall_pt_ptr,nlarge_pt_ptr,jneigh_ptr
      common /blk116/ dneigh_ptr,rneigh_ptr
      common /blk117/ nlarge_lst_ptr
      common /blk118/ bin_ptr
      common /blk119/ xold_ptr
#else
      integer nsmall_pt(0:maxrow),nlarge_pt(0:maxrow)
      integer jneigh(maxnsmall*maxlocal+1000)
      real*8 dneigh(3,maxnsmall*maxlocal+1000)
      real*8 rneigh(maxnsmall*maxlocal+1000)
      integer nlarge_lst(maxnlarge*maxlocal+1000)
      integer bin(maxcol)
      real*8 xold(3,maxlocal)

      common /blk115/ nsmall_pt,nlarge_pt,jneigh
      common /blk116/ dneigh,rneigh
      common /blk117/ nlarge_lst
      common /blk118/ bin
      common /blk119/ xold
#endif

c Statistics

      real*8 avstrs(6)
      character*80 diagfile,version

      common /blk121/ avke,avpe,avpres,avtemp,avvol,avstrs
      common /blk122/ nforce,nneigh,newlst
      common /blk123/ mxnsmall,mxnlarge,nave
      common /blk124/ avensmall,avenlarge,eold,demax
      common /blk125/ ekin1,ekin2,etot1,etot2,epot1,epot2,volint,volfin
      common /blk126/ time_force,time_neigh,time_comm,time_io
      common /blk127/ time_start,time_runstart,time_runend
      common /blk128/ diagfile,version
      common /blk129/ diag1,diag2,diag3,diag4,diag5,idiag,ndiag
      common /blk130/ user1,user2,user3,user4,user5,iuser
