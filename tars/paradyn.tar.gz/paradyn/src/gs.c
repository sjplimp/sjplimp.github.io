/* 

c ParaDyn - Parallel DYNAMO - molecular dynamics with EAM potentials
c 
c Authored by Steve Plimpton
c   (505) 845-7873, sjplimp@cs.sandia.gov
c   Dept 9221, MS 1111, Sandia National Labs, Albuquerque, NM  87185-1111
c
c Based on the serial DYNAMO code authored by
c   Stephen Foiles (foiles@ca.sandia.gov), Sandia National Labs, Livermore, CA
c   Murray Daw (daw@hubcap.clemson.edu), Clemson University
c
c See the README file for more information
c

*/

/* Gather and Scatter routines
     to replace MPI_Allgatherv and MPI_Reduce_scatter which are often slow

   Compiler and Precision options:

     default is recursive gather/scatter
     compile with -DGS_MPI to call standard MPI gather/scatter

     default is synchronous (blocking) MPI send/recv which can be faster
       depending on the size of messages and the machine, but can also
       hang if the MPI implementation has insufficient buffer space
     compile with -DGS_IRECV to do asyncronous MPI_Irecv

     default for scatter is simple addition loop
     compile with -DGS_AXPY if you have a BLAS routine for this operation
       must check syntax of AXPY call to see that it's correct for your machine

     to change type of datums being gathered or scattered:
       set DATA to appropriate type
       set MPI_MINE to appropriate MPI Datatype
*/

#include "stdio.h"
#include "mpi.h"

typedef double DATA;
#define MPI_MINE MPI_DOUBLE

#ifdef T3E_KLUDGE

#define gather_ GATHER
#define scatter_ SCATTER
#define plan_gather_scatter_ PLAN_GATHER_SCATTER

#endif

#ifdef LINUX_KLUDGE

#define plan_gather_scatter_ plan_gather_scatter__

#endif

/* ----------------------------------------------------------------------- */
/* gather-scatter plan */

struct gs_plan {
  int me,nprocs,n;               /* n = # of datums on this proc */
  int *displs,*counts;           /* displs = offsets into full vec */
  DATA *tmpbuf;                  /* extra memory for scatter recv */
  MPI_Comm comm;                 /* perform these ops in isolated MPI_Comm */
};

/* ----------------------------------------------------------------------- */
/* function prototypes including F77 wrappers */

struct gs_plan *plan_gather_scatter(int, int, MPI_Comm);
void plan_gather_scatter_(int *, int *, MPI_Comm *, struct gs_plan **);
void unplan_gather_scatter(struct gs_plan *);
void unplan_gather_scatter_(struct gs_plan **);

void gather(DATA *, DATA *, struct gs_plan *);
void gather_(DATA *, DATA *, struct gs_plan **);
void recursive_gather(DATA *, int *, int, int, int, MPI_Comm);
void scatter(DATA *, DATA *, struct gs_plan *);
void scatter_(DATA *, DATA *, struct gs_plan **);
void recursive_scatter(DATA *, DATA *, int *, int, int, int, MPI_Comm);

/* ----------------------------------------------------------------------- */
/* create a plan for gather or scatter
   flag = 0 for a gather
   flag = 1 for a scatter (requires additional memory) 
   n = # of datums on this proc
   orig_comm = MPI Communicator of all procs who will participate
   returns gs_plan pointer to use in future gather/scatter calls */

struct gs_plan *plan_gather_scatter(int flag, int n, MPI_Comm orig_comm)

{
  int i,me,nprocs;
  int pmid,sizelo,sizehi,nsize;
  struct gs_plan *plan;
  int *counts,*displs;
  MPI_Comm comm;

/* new communicator for collective operation */

  MPI_Comm_dup(orig_comm,&comm);
  MPI_Comm_rank(comm,&me);
  MPI_Comm_size(comm,&nprocs);

/* allocate memory for plan */

  plan = (struct gs_plan *) malloc(sizeof(struct gs_plan));

/* accumulate per-processor counts and displacements */

  counts = (int *) my_malloc(nprocs*sizeof(int));
  displs = (int *) my_malloc((nprocs+1)*sizeof(int));

  MPI_Allgather(&n,1,MPI_INT,counts,1,MPI_INT,comm);

  displs[0] = 0;
  for (i = 1; i <= nprocs; i++) displs[i] = displs[i-1] + counts[i-1];

/* initialize plan */

  plan->me = me;
  plan->nprocs = nprocs;
  plan->n = n;
  plan->displs = displs;
  plan->counts = counts;
  plan->comm = comm;

/* add temporary recv buf for scatter */

  if (flag) {
    pmid = (nprocs + 1) / 2;
    sizelo = displs[pmid] - displs[0];
    sizehi = displs[nprocs] - displs[pmid];
    nsize = (sizelo > sizehi) ? sizelo : sizehi;
    plan->tmpbuf = (DATA *) my_malloc(nsize*sizeof(DATA));
  }
  else
    plan->tmpbuf = NULL;

  return plan;
}

/* ----------------------------------------------------------------------- */
/* F77 wrapper on plan_gather_scatter */

void plan_gather_scatter_(int *flag, int *n, 
			  MPI_Comm *comm, struct gs_plan **plan)

{
  *plan = plan_gather_scatter(*flag,*n,*comm);
}


/* ----------------------------------------------------------------------- */
/* destroy a plan for gather or scatter */

void unplan_gather_scatter(struct gs_plan *plan)

{
/* free MPI communicator */

  MPI_Comm_free(&plan->comm);

/* free internal arrays */

  my_free(plan->displs);
  my_free(plan->counts);
  my_free(plan->tmpbuf);

/* free plan itself */

  my_free(plan);
}

/* ----------------------------------------------------------------------- */
/* F77 wrapper on unplan_gather_scatter */

void unplan_gather_scatter_(struct gs_plan **plan)

{
  unplan_gather_scatter(*plan);
}

/* ----------------------------------------------------------------------- */
/* C version of gather */

void gather(DATA *sbuf, DATA *rbuf, struct gs_plan *plan)

{
  int me,nprocs,i,n,noffset;

  me = plan->me;
  nprocs = plan->nprocs;

  n = plan->n;
  noffset = plan->displs[me];

#ifdef GS_MPI
  MPI_Allgatherv(sbuf,n,MPI_MINE,
		 rbuf,plan->counts,plan->displs,MPI_MINE,plan->comm);
#else
  for (i = 0; i < n; i++) rbuf[noffset++] = sbuf[i];
  recursive_gather(rbuf,plan->displs,me,0,nprocs-1,plan->comm);
#endif
}

/* ----------------------------------------------------------------------- */
/* F77 version of gather */

void gather_(DATA *sbuf, DATA *rbuf, struct gs_plan **pplan)

{
  int me,nprocs,i,n,noffset;
  struct gs_plan *plan;

  plan = *pplan;
  me = plan->me;
  nprocs = plan->nprocs;

  n = plan->n;
  noffset = plan->displs[me];

#ifdef GS_MPI
  MPI_Allgatherv(sbuf,n,MPI_MINE,
		 rbuf,plan->counts,plan->displs,MPI_MINE,plan->comm);
#else
  for (i = 0; i < n; i++) rbuf[noffset++] = sbuf[i];
  recursive_gather(rbuf,plan->displs,me,0,nprocs-1,plan->comm);
#endif
}

/* -------------------------------------------------------------------- */
/* recursive gather */

void recursive_gather(DATA *buf, int *displs, int me, int plo, int phi,
		      MPI_Comm comm)

{
  int pmid,nplo,nphi,pcut;
  MPI_Status status;
  MPI_Request request;

/* down to one proc -> all done */

  if (plo == phi) return;

/* pmid = 1st proc in upper half
   upper half is larger partition */

  pmid = (plo + phi + 1) / 2;
  nplo = pmid - plo;
  nphi = phi - pmid + 1;
  
/* 1st do a gather within each half */

  if (me < pmid)
    recursive_gather(buf,displs,me,plo,pmid-1,comm);
  else
    recursive_gather(buf,displs,me,pmid,phi,comm);

/* data exchange to finish gather for this partition */

  if (me < pmid) {
    if (nplo == nphi) {
#ifndef GS_IRECV
      MPI_Send(&buf[displs[plo]],displs[pmid]-displs[plo],
	       MPI_MINE,me+nplo,0,comm);
      MPI_Recv(&buf[displs[pmid]],displs[phi+1]-displs[pmid],
	       MPI_MINE,me+nplo,0,comm,&status);
#else
      MPI_Irecv(&buf[displs[pmid]],displs[phi+1]-displs[pmid],
		MPI_MINE,me+nplo,0,comm,&request);
      MPI_Send(&buf[displs[plo]],displs[pmid]-displs[plo],
	       MPI_MINE,me+nplo,0,comm);
      MPI_Wait(&request,&status);
#endif
    }
    else {
#ifndef GS_IRECV
      if (me == pmid-1)
	MPI_Send(&buf[displs[plo]],displs[pmid]-displs[plo],
		 MPI_MINE,phi,0,comm);
      MPI_Send(&buf[displs[plo]],displs[pmid]-displs[plo],
	       MPI_MINE,me+nplo,0,comm);
      MPI_Recv(&buf[displs[pmid]],displs[phi+1]-displs[pmid],
	       MPI_MINE,me+nplo,0,comm,&status);
#else
      MPI_Irecv(&buf[displs[pmid]],displs[phi+1]-displs[pmid],
		MPI_MINE,me+nplo,0,comm,&request);
      if (me == pmid-1)
	MPI_Send(&buf[displs[plo]],displs[pmid]-displs[plo],
		 MPI_MINE,phi,0,comm);
      MPI_Send(&buf[displs[plo]],displs[pmid]-displs[plo],
	       MPI_MINE,me+nplo,0,comm);
      MPI_Wait(&request,&status);
#endif
    }
  }
  else {
    if (nplo == nphi) {
#ifndef GS_IRECV
      MPI_Send(&buf[displs[pmid]],displs[phi+1]-displs[pmid],
	       MPI_MINE,me-nplo,0,comm);
      MPI_Recv(&buf[displs[plo]],displs[pmid]-displs[plo],
	       MPI_MINE,me-nplo,0,comm,&status);
#else
      MPI_Irecv(&buf[displs[plo]],displs[pmid]-displs[plo],
		MPI_MINE,me-nplo,0,comm,&request);
      MPI_Send(&buf[displs[pmid]],displs[phi+1]-displs[pmid],
	       MPI_MINE,me-nplo,0,comm);
      MPI_Wait(&request,&status);
#endif
    }
    else {
#ifndef GS_IRECV
      if (me == phi)
	MPI_Recv(&buf[displs[plo]],displs[pmid]-displs[plo],
		 MPI_MINE,pmid-1,0,comm,&status);
      else {
	MPI_Send(&buf[displs[pmid]],displs[phi+1]-displs[pmid],
		 MPI_MINE,me-nplo,0,comm);
	MPI_Recv(&buf[displs[plo]],displs[pmid]-displs[plo],
		 MPI_MINE,me-nplo,0,comm,&status);
      }
#else
      if (me == phi) {
	MPI_Irecv(&buf[displs[plo]],displs[pmid]-displs[plo],
		  MPI_MINE,pmid-1,0,comm,&request);
	MPI_Wait(&request,&status);
      }
      else {
	MPI_Irecv(&buf[displs[plo]],displs[pmid]-displs[plo],
		  MPI_MINE,me-nplo,0,comm,&request);
	MPI_Send(&buf[displs[pmid]],displs[phi+1]-displs[pmid],
		 MPI_MINE,me-nplo,0,comm);
	MPI_Wait(&request,&status);
      }
#endif
    }
  }

}

/* ----------------------------------------------------------------------- */
/* C version of scatter */

void scatter(DATA *sbuf, DATA *rbuf, struct gs_plan *plan)

{
  int me,nprocs,i,n,noffset;

  me = plan->me;
  nprocs = plan->nprocs;

#ifdef GS_MPI
  MPI_Reduce_scatter(sbuf,rbuf,plan->counts,MPI_MINE,MPI_SUM,plan->comm);
#else
  recursive_scatter(sbuf,plan->tmpbuf,plan->displs,me,0,nprocs-1,plan->comm);

  n = plan->n;
  noffset = plan->displs[me];
  for (i = 0; i < n; i++) rbuf[i] = sbuf[noffset++];
#endif
}

/* ----------------------------------------------------------------------- */
/* F77 version of scatter */

void scatter_(DATA *sbuf, DATA *rbuf, struct gs_plan **pplan)

{
  int me,nprocs,i,n,noffset;
  struct gs_plan *plan;

  plan = *pplan;
  me = plan->me;
  nprocs = plan->nprocs;

#ifdef GS_MPI
  MPI_Reduce_scatter(sbuf,rbuf,plan->counts,MPI_MINE,MPI_SUM,plan->comm);
#else
  recursive_scatter(sbuf,plan->tmpbuf,plan->displs,me,0,nprocs-1,plan->comm);

  n = plan->n;
  noffset = plan->displs[me];
  for (i = 0; i < n; i++) rbuf[i] = sbuf[noffset++];
#endif
}


/* -------------------------------------------------------------------- */
/* recursive scatter */

void recursive_scatter(DATA *buf, DATA *tmpbuf,
		       int *displs, int me, int plo, int phi, MPI_Comm comm)
  
{
  int i,n,noffset;
  int pmid,nplo,nphi,pcut;
  int one_i = 1;
  double one_d = 1.0;
  MPI_Status status;
  MPI_Request request;

/* down to one proc -> all done */

  if (plo == phi) return;

/* pmid = 1st proc in upper half
   upper half is larger partition */

  pmid = (plo + phi + 1) / 2;
  nplo = pmid - plo;
  nphi = phi - pmid + 1;

/* data exchange to begin scatter for this partition */

  if (me < pmid) {
    if (nplo == nphi) {
#ifndef GS_IRECV
      MPI_Send(&buf[displs[pmid]],displs[phi+1]-displs[pmid],
	       MPI_MINE,me+nplo,0,comm);
      n = displs[pmid]-displs[plo];
      MPI_Recv(tmpbuf,n,MPI_MINE,me+nplo,0,comm,&status);
      noffset = displs[plo];
#ifndef GS_AXPY
      for (i = 0; i < n; i++) buf[noffset++] += tmpbuf[i];
#else
      daxpy_(&n,&one_d,tmpbuf,&one_i,&buf[noffset],&one_i);
#endif
#else
      n = displs[pmid]-displs[plo];
      MPI_Irecv(tmpbuf,n,MPI_MINE,me+nplo,0,comm,&request);
      MPI_Send(&buf[displs[pmid]],displs[phi+1]-displs[pmid],
	       MPI_MINE,me+nplo,0,comm);
      MPI_Wait(&request,&status);
      noffset = displs[plo];
#ifndef GS_AXPY
      for (i = 0; i < n; i++) buf[noffset++] += tmpbuf[i];
#else
      daxpy_(&n,&one_d,tmpbuf,&one_i,&buf[noffset],&one_i);
#endif
#endif
    }
    else {
#ifndef GS_IRECV
      MPI_Send(&buf[displs[pmid]],displs[phi+1]-displs[pmid],
	       MPI_MINE,me+nplo,0,comm);
      n = displs[pmid]-displs[plo];
      MPI_Recv(tmpbuf,n,MPI_MINE,me+nplo,0,comm,&status);
      noffset = displs[plo];
#ifndef GS_AXPY
      for (i = 0; i < n; i++) buf[noffset++] += tmpbuf[i];
#else
      daxpy_(&n,&one_d,tmpbuf,&one_i,&buf[noffset],&one_i);
#endif
      if (me == pmid-1) {
	MPI_Recv(tmpbuf,n,MPI_MINE,phi,0,comm,&status);
	noffset = displs[plo];
#ifndef GS_AXPY
	for (i = 0; i < n; i++) buf[noffset++] += tmpbuf[i];
#else
	daxpy_(&n,&one_d,tmpbuf,&one_i,&buf[noffset],&one_i);
#endif
      }
#else
      n = displs[pmid]-displs[plo];
      MPI_Irecv(tmpbuf,n,MPI_MINE,me+nplo,0,comm,&request);
      MPI_Send(&buf[displs[pmid]],displs[phi+1]-displs[pmid],
	       MPI_MINE,me+nplo,0,comm);
      MPI_Wait(&request,&status);
      noffset = displs[plo];
#ifndef GS_AXPY
      for (i = 0; i < n; i++) buf[noffset++] += tmpbuf[i];
#else
      daxpy_(&n,&one_d,tmpbuf,&one_i,&buf[noffset],&one_i);
#endif
      if (me == pmid-1) {
	MPI_Irecv(tmpbuf,n,MPI_MINE,phi,0,comm,&request);
	MPI_Wait(&request,&status);
	noffset = displs[plo];
#ifndef GS_AXPY
	for (i = 0; i < n; i++) buf[noffset++] += tmpbuf[i];
#else
	daxpy_(&n,&one_d,tmpbuf,&one_i,&buf[noffset],&one_i);
#endif
      }
#endif
    }
  }
  else {
    if (nplo == nphi) {
#ifndef GS_IRECV
      MPI_Send(&buf[displs[plo]],displs[pmid]-displs[plo],
	       MPI_MINE,me-nplo,0,comm);
      n = displs[phi+1]-displs[pmid];
      MPI_Recv(tmpbuf,n,MPI_MINE,me-nplo,0,comm,&status);
      noffset = displs[pmid];
#ifndef GS_AXPY
      for (i = 0; i < n; i++) buf[noffset++] += tmpbuf[i];
#else
      daxpy_(&n,&one_d,tmpbuf,&one_i,&buf[noffset],&one_i);
#endif
#else
      n = displs[phi+1]-displs[pmid];
      MPI_Irecv(tmpbuf,n,MPI_MINE,me-nplo,0,comm,&request);
      MPI_Send(&buf[displs[plo]],displs[pmid]-displs[plo],
	       MPI_MINE,me-nplo,0,comm);
      MPI_Wait(&request,&status);
      noffset = displs[pmid];
#ifndef GS_AXPY
      for (i = 0; i < n; i++) buf[noffset++] += tmpbuf[i];
#else
      daxpy_(&n,&one_d,tmpbuf,&one_i,&buf[noffset],&one_i);
#endif
#endif
    }
    else {
#ifndef GS_IRECV
      if (me < phi) {
	MPI_Send(&buf[displs[plo]],displs[pmid]-displs[plo],
		 MPI_MINE,me-nplo,0,comm);
	n = displs[phi+1]-displs[pmid];
	MPI_Recv(tmpbuf,n,MPI_MINE,me-nplo,0,comm,&status);
	noffset = displs[pmid];
#ifndef GS_AXPY
	for (i = 0; i < n; i++) buf[noffset++] += tmpbuf[i];
#else
	daxpy_(&n,&one_d,tmpbuf,&one_i,&buf[noffset],&one_i);
#endif
      }
      else
	MPI_Send(&buf[displs[plo]],displs[pmid]-displs[plo],
		 MPI_MINE,pmid-1,0,comm);
#else
      if (me < phi) {
	n = displs[phi+1]-displs[pmid];
	MPI_Irecv(tmpbuf,n,MPI_MINE,me-nplo,0,comm,&request);
	MPI_Send(&buf[displs[plo]],displs[pmid]-displs[plo],
		 MPI_MINE,me-nplo,0,comm);
	MPI_Wait(&request,&status);
	noffset = displs[pmid];
#ifndef GS_AXPY
	for (i = 0; i < n; i++) buf[noffset++] += tmpbuf[i];
#else
	daxpy_(&n,&one_d,tmpbuf,&one_i,&buf[noffset],&one_i);
#endif
      }
      else
	MPI_Send(&buf[displs[plo]],displs[pmid]-displs[plo],
		 MPI_MINE,pmid-1,0,comm);
#endif
    }
  }

/* finally do a scatter within each half */

  if (me < pmid)
    recursive_scatter(buf,tmpbuf,displs,me,plo,pmid-1,comm);
  else
    recursive_scatter(buf,tmpbuf,displs,me,pmid,phi,comm);

}
