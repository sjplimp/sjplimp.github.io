def truncate(x):
  return int(x)
