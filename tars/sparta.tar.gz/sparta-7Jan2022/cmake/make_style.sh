#!/bin/bash
cd $1
sh $2/Make.sh style
