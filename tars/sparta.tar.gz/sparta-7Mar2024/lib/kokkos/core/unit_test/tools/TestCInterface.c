#include <impl/Kokkos_Profiling_C_Interface.h>
int main() {}
