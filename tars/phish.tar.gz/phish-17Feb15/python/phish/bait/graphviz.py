import sys
sys.modules["phish.bait"].backend("graphviz")
