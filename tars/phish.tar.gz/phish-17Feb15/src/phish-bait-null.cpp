#include "phish-bait.h"
#include "phish-bait-common.h"

extern "C"
{

int phish_bait_start()
{
  return 0;
}

} // extern "C"
