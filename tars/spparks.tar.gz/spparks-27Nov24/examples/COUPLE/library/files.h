#ifndef FILES_H
#define FILES_H
void replace(char *, char *, int, char **);
void extract(char *, char *, int, char **);
#endif
