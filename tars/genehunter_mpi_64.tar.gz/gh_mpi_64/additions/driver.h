#ifndef ___DRIVER_H___
#define ___DRIVER_H___
void Insert_ST(double key, int val);
void initialize_ST();
int Retrieve_ST(double key);
int Retrieve_Global_ST(double key);
void cleanup_ST();
#endif
