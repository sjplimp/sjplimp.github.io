

#ifndef ___BST_H___
#define ___BST_H___

#define INC_LIB
#include "npl.h"


/*Two structs that define a very simple binary search tree
  BSTNode implements the nodes of the tree, with pointers
  to stored data and the 2 children
  BinarySearchTree  implements the 3 basic functions: Insert, Delete and Retrieve */

struct BinSearchNode {
  struct BinSearchNode *children[2];
  double key;
  int val;
};

typedef struct BinSearchNode BSTNode;

void new_node(BSTNode *newnd);
  
struct BSTree {
 
  BSTNode  *Root, *successor_to_loc, *hole_loc;

 
};
 

typedef struct BSTree BinarySearchTree;


/*Function descriptions in source file BST.c*/ 

BSTNode* find_key_loc(double key, BSTNode *start, int *success);

int delete_loc(BinarySearchTree *tree, double key, BSTNode *current);

void bottom_up_delete_tree(BSTNode *current);

void initialize_tree(BinarySearchTree *tree);

void delete_tree(BinarySearchTree *tree);

/*Insert returns a int for success/failure.  Failure means that the item
  already exists in the tree*/
int Insert (BinarySearchTree *tree, double key, int val);

/*Retrieve returns a pointer to the item with key == key
  if the return value==0, the key was not found in the tree*/
int Retrieve(BinarySearchTree *tree, double key);

/*Delete returns a bool for success/failure.  Failure means that the item 
  was not found in the tree*/
int Delete (BinarySearchTree *tree, double key);

#endif


