
#include "BST.h"
#include <stdlib.h>
#include <stdio.h>

void new_node(BSTNode *newnd) 
{
  newnd->children[0]=newnd->children[1]=0; newnd->key=0; newnd->val=0;
}

void initialize_tree(BinarySearchTree *tree) 
{
  tree->Root=0; 
  tree->successor_to_loc=0; 
  tree->hole_loc=0;
}

void delete_tree(BinarySearchTree *tree) 
{
  if (tree->Root != 0) {
    if ((tree->Root->children[0] !=0)  || (tree->Root->children[1] !=0))
      bottom_up_delete_tree(tree->Root);
  
 
    free(tree->Root);
  }
}
  


int Insert (BinarySearchTree *tree, double key, int val)
     /*(Implements the Insert routine by first using the function
       find_key_loc to locate the place the new item should go.
       If the item is already there, find_key_loc sets matches to true
       and the function returns false
       Otherwise, it inserts the item at the appropriate location
       to the left or right of the insertloc node returned by
       find_key_loc*/
{
  int matches;
  BSTNode *insertloc;

  if (tree->Root!=0)
    {
      insertloc=tree->Root;
      insertloc=find_key_loc(key, insertloc, &matches);
      if (matches==FALSE)
	{
	  if (key<insertloc->key)
	    {
	      insertloc->children[0]=(BSTNode *) malloc(sizeof(BSTNode));
	      new_node(insertloc->children[0]);
	      insertloc->children[0]->key=key;
	      insertloc->children[0]->val=val;
	    }
	  else
	    {
	      insertloc->children[1]=(BSTNode *) malloc(sizeof(BSTNode));
	      new_node(insertloc->children[1]);
	      insertloc->children[1]->key=key;
	      insertloc->children[1]->val=val;
	    }
	  return(TRUE);
	}
      else
	return(TRUE);
    }
  else
    {
      tree->Root=(BSTNode *) malloc(sizeof(BSTNode));
      new_node(tree->Root);
      tree->Root->key=key;
      tree->Root->val=val;
      return(TRUE);
    }
}  /*Insert*/




int Retrieve(BinarySearchTree *tree, double key)
     /*Retrieve also uses the function find_key_loc.  If the matches 
       variable is returned as true, the loc variable is returned 
       (i.e. the key was found).  Otherwise the function returns -1
       (the key was not found)--since this application is looking up
       memory addresses, -1 should never be valid*/
{
  int matches;
  BSTNode *loc;

  if (tree->Root == 0)
    return(-1);
  else
    {
      loc=tree->Root;
      
      loc=find_key_loc(key, loc, &matches);
      
      if (matches==TRUE)
	return(loc->val);
      else
	return(-1);
    }
} /*End Retrieve*/




int Delete (BinarySearchTree *tree, double key)
     /*Front-end for Deletion performed by delete_loc*/
{
  BSTNode *deleting_loc;
  if (tree->Root!=0)
    {
      deleting_loc=tree->Root;
      return(delete_loc(tree, key, deleting_loc));
    }
  else
    return(FALSE);
}  /*End  Delete*/




BSTNode* find_key_loc(double key, BSTNode *start, int *success)
     /*Generic function for finding locations in the tree.  If an
       exact match to key is found, the function returns the node where the match
       was found and sets success=true.  Otherwise the function returns the node
       that would be the parent of key on an insert and sets success=false*/
{
 
  (*success)=FALSE;

  if (start->key==key)
    {
      (*success)=TRUE;
      return(start);
    }   
  else if (key<start->key)
    {
      if (start->children[0]!=0)
	  return(find_key_loc(key, start->children[0], success));
      else
	return(start);
    }
  else
    {
      if (start->children[1]!=0)
	return(find_key_loc(key, start->children[1], success));
      else
	return(start);
    }
}  /*End BinarySearchTree::find_key_loc*/




int delete_loc(BinarySearchTree *tree, double key, BSTNode *current)
     /*Proceeds down the tree building up a parent recursive stack
       If the key is found in a non-leaf node (two non-null children, the class 
       variable successor_to_loc marks the location of the key, and the recursion
       contiunes to find the in-order successor by travelling first right
       and then completely left.  Once the successor is found at a leaf, it is 
       swapped with successor_to_loc and the deletion is as usual.
       Once the node to be deleted is at a leaf (i.e. has at least one null child),
       one of two things may happen.  If the node has two null children it is 
       marked with hole_loc and passed up to it's parent.  At that point it is deleted
       and the parent's appropriate child set to 0.  Otherwise, the single child of the
       node to be deleted is passed up the tree with hole_loc and a decision is made
       to put it to the left or right of it's grandparent.  This completes the deletion. */
{
  int ret_val;
  int found_pos=-1;
  double tempkey;
  int tempval;

  if (tree->successor_to_loc!=0)                                                   /*If we find the key not at a leaf*/
    {                                                                         /*we flag it and move to the in-order*/
      if (current->children[0]!=0)                                            /*successor*/
        ret_val=delete_loc(tree, key, current->children[0]);
      else
	{
	  found_pos=0;
	  tempval=tree->successor_to_loc->val;
	  tempkey=tree->successor_to_loc->key;
	  tree->successor_to_loc->key=current->key;
	  tree->successor_to_loc->val=current->val;
	  current->val=tempval;
	  current->key=tempkey;
	  tree->successor_to_loc=0;
	}
    }

  else                                                                        /*Still looking for key*/
    {
      if (current->key==key) 
	  found_pos=0;
      else if (key<current->key)
	    {
	      if (current->children[0]!=0)
		  ret_val=delete_loc(tree, key, current->children[0]);
	      else
		  return(FALSE);
	    }
      else
	{
	  if (current->children[1]!=0)
	    ret_val=delete_loc(tree, key, current->children[1]);
	  else
	      return(FALSE);
	}
    }      
    
      
  
  if (found_pos!=-1)
    {
      if (current->children[0]!=0 && current->children[1]!=0)               /*Two non-null children--*/
	{                                                                   /*look for successor*/
	  tree->successor_to_loc=current;
	  ret_val=delete_loc(tree, key, current->children[1]);
	}
      else
	{
	  if (current->children[0]==0 && current->children[1]!=0)          /*Node to delete has right child*/
	    {	 
	      if (current!=tree->Root)
		  tree->hole_loc=current->children[1];
	      else                                                         /*Child is passed up w/ hole_loc*/
		{
		  tree->hole_loc=tree->Root;
		  tree->Root=current->children[1];
		  free(tree->hole_loc);
		  tree->hole_loc=0;
		}
	    }
	  else if (current->children[0]!=0 && current->children[1]==0)     /*Node to delete has left child*/
	    {	 
	      if (current!=tree->Root)
		tree->hole_loc=current->children[0];
	      else                                                        /*Child is passed up w/ hole_loc*/
		{
		  tree->hole_loc=tree->Root;
		  tree->Root=current->children[0];
		  free(tree->hole_loc);
		  tree->hole_loc=0;
		}
	    }
	  else                                                           /*Removed node is marked for parent*/
	    tree->hole_loc=current;

	  return(TRUE);
	}
    }
     
  if (tree->hole_loc!=0)                                                      /*Fixes parents of deleted nodes*/
    {
      if (tree->hole_loc==current->children[0])                               /*Node w/o children deleted--fixing parent*/
	{
	  current->children[0]=0;
	  free(tree->hole_loc);
	}
      else if (tree->hole_loc==current->children[1])                         /*Node w/o children deleted--fixing parent*/ 
	{
	  current->children[1]=0;
	  free(tree->hole_loc);
	}
      else                                                             /*Node w/ child deleted--assigning it to*/
	{                                                              /*grandparent*/
	  if (tree->hole_loc->key<current->key)
	    current->children[0]=tree->hole_loc;
	  else
	    current->children[1]=tree->hole_loc;
	}
      tree->hole_loc=0;          
    }
  return(ret_val);
}  /*End delete_loc*/




void bottom_up_delete_tree(BSTNode *current)
     /*Used by the destructor to delete the tree*/
{
 
  if (current->children[0]!=0) {
    if (current->children[0]->children[0]!=0  || current->children[0]->children[1]!=0)
      bottom_up_delete_tree(current->children[0]);
    
    free(current->children[0]);
  }
  if (current->children[1]!=0) {
    if (current->children[1]->children[0]!=0  || current->children[1]->children[1]!=0)
      bottom_up_delete_tree(current->children[1]);
    
    
    free(current->children[1]);
  }
}











