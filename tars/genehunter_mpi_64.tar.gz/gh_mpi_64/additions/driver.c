#include "BST.h"
#include "driver.h"
#include "timing.h"



long gct_prerun, gct_postrun, gct_pre, gct_post,
  gct_pre_graphmarkers, gct_post_graphmarkers, gct_total_graphmarkers,
  gct_pre_graphdisease, gct_post_graphdisease, gct_total_graphdisease,
  gct_pre_graphtotal, gct_post_graphtotal, gct_pre_graphstartup, gct_post_graphstartup, 
  gct_total_graphstartup, gct_pre_graphnpl, gct_post_graphnpl, gct_total_graphnpl,
gct_pre_TSC, gct_post_TSC, gct_total_TSC, gct_pre_TBAD, gct_post_TBAD, gct_total_TBAD,
  gct_pre_fft, gct_post_fft, gct_total_fft, gct_pre_onmarker, gct_post_onmarker, gct_total_onmarker, gct_pregather, gct_postgather, gct_totalgather, gct_pre_collect, gct_post_collect, gct_pre_output, gct_post_output, gct_pre_markcomm, gct_post_markcomm, gct_total_markcomm, gct_pre_red,
gct_post_red, gct_total_red, gct_pre_scoreassm, gct_post_scoreassm;

BinarySearchTree *score_tree, *global_score_tree;

void initialize_ST()
{
  score_tree=(BinarySearchTree*)malloc(sizeof(BinarySearchTree));
  initialize_tree(score_tree);
}


void Insert_ST(double key, int val)
{
  Insert(score_tree, key, val);
}


int Retrieve_ST(double key)
{
  return(Retrieve(score_tree, key));
}



int Retrieve_Global_ST(double key)
{
  return(Retrieve(global_score_tree, key));
}


void cleanup_ST()
{
  delete_tree(score_tree);
  delete_tree(global_score_tree);
}

unsigned long gct_RunTime()
{
    struct rusage r;
    long sec, usec;

    getrusage(RUSAGE_SELF, &r);   /* constant defined in include files */ 
    sec = r.ru_utime.tv_sec;      /* whole seconds */
    usec = r.ru_utime.tv_usec;    /* microseconds */

    return((sec * 1000) + (usec / 1000));

} /* RunTime*/


unsigned long gct_quickTime()
{
  struct rusage r;
  long sec, usec;

  getrusage(RUSAGE_SELF, &r);   /* constant defined in include files */ 
  sec = r.ru_utime.tv_sec;      /* whole seconds */
  usec = r.ru_utime.tv_usec;    /* microseconds */
  
  return((sec * 100000) + (usec / 10));

}


/*End GC Timing function*/

