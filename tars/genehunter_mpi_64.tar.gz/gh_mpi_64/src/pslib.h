/* GENEHUNTER - Kruglyak, Daly, Reeve-Daly, and Lander
   Whitehead Institute for Biomedical Research, Copyright 1996 */
void draw_rect(FILE*,double,double,double,double,double);
void draw_labeled_rect(FILE*,double,double,double,double,double,double,char*);
void draw_centered_rect(FILE*,double,double,double,double,double,char*,int);
void draw_circle (FILE*,double,double,double,double,char*,int);
void draw_pie_chart(FILE*,char*,char**,double*,int);
void draw_axes(FILE*,int,double*,char**,int,double*,char**,char*,char*, 
	       double,double,double,int);
void draw_x(FILE*);
void ps_file_start(FILE*);
void ps_file_end(FILE*);
void ps_page_start(FILE*,int);
void ps_page_end(FILE*,int);
void do_bezier(FILE*,double*,double*,int,double,double,char*,double,double);

void print_poster(FILE*);
char* line_choice(int);

#define XZERO 0.0
#define YZERO 0.0

#define SOLID_LINE    ""
#define THICK_LINE    "2 LW"
#define THIN_LINE     ".5 LW"
#define EVEN_DASH     "[4 4] 0 setdash"
#define BIG_DASH      "[6 2] 0 setdash"
#define SMALL_DASH    "[2 6] 0 setdash"
#define DOTTED2       "[2 2] 0 setdash"
#define DOTTED1       "[1 1] 0 setdash"
#define DASH42        "[4 2] 0 setdash"
#define DASH24        "[2 4] 0 setdash"



/* Postscript fill colors --
 */
#define BLACK        0.0
#define DRK_GRAY     0.75
#define GRAY         0.5
#define LGT_GRAY     0.25
#define WHITE        1.0


