/* GENEHUNTER - Kruglyak, Daly, Reeve-Daly, and Lander
   Whitehead Institure for Biomedical Research, Copyright 1996 */
#define INC_LIB
#define INC_SHELL
#include "npl.h"

#define MAXITS 600    /* Maximum number of iterations in fisher */
#define EPS1 1.0e-8   /* Constants for measuring convergence */
#define EPS2 1.0e-9     /* of parameter values */
#define REPEATS 8     /* Required number of iterations without significant parameter */
                      /* change before iteration ceases */
#define TOLF 1.0e-8

/* extern */
int start_values;     /* Flag indicating whether start values are entered manually */
bool means_by_sex;    /* Flag indicating whether to estimate separate male and female means */

/* static */
static int num_means;      /* Number of means estimated: two (one for each sex) or one */
static int num_null_vars;  /* Number of variance components in null model */
static int num_QTL_vars;   /* Number of additional QTL variance components in ML model */
static int num_fixed;      /* Number of means and covariates in model */
static int num_vars;       /* Number of variance components in model */
static double mMean;       /* Mean trait value of males, or of all phenotypes if not */
                             /* estimating sexes separately */
static double fMean;       /* Mean trait value of females */
static double varP;        /* Total variance of trait values */

static int *num_phenotyped;        /* Number of phenotyped members in each pedigree */
static int **phenotyped_members;   /* Indices of the phenotyped members in each pedigree, */
                                     /* for reading from externs in pair_prep.c */
static int *pedigree_IDs;          /* Indices of pedigrees containing phenotyped members, */
                                     /* for reading from externs in pair_prep.c */
static int num_peds;               /* Number of pedigrees containing phenotyped members */
static double ***dev_matrix;       /* Matrix and transpose of */
static double ***dev_transpose;      /* phenotype deviations from mean */
static double ***variance;         /* Covariance matrices for each pedigree */
static double ****deriv;           /* Derivatives of covariance matrices, with respect */
                                     /* to each variance component */
static double ****fixed_derivs;    /* Derivatives of means and covariance coefficients */
static double ****fixed_derivs_transpose;
static double ***inverse;          /* Inverses of covariance matrices */
static double *det;                /* Determinants of covariance matrices */
static double **temp1, **temp2;    /* Temporary storage for matrix multiplications */
static double **temp3, **temp4; 

/* Internal methods */
void max_likelihood(FILE *varcomfp, FILE *corrfp, FILE *lodfpps, FILE *varfpps, int pheno_index, char **param_names, char **headings);
bool fisher (double x[], double corrs[], double vars[], int n, double *f, int pheno_index, int pos);
int sweep_next (double **in_matrix, bool *already_swept, int n);
double fmax(double x[], int pheno_index);
void step_half(int n, int pheno_index, double xold[], double fold, double p[], double x[], double *f);
void get_fixed_score(double *fixed_param, int paramID);
void get_variance_score(int component, double *var);
void finfo(int n, double **jac);
void fdjac(int n, double **q);
void pheno_mean_and_variance(int pheno_index);
void transpose(double **in_matrix, int r, int c, double **out_matrix);
void dot_product(double **pre_matrix, double **post_matrix, int r, int in, int c, double **out_matrix);
double trace(double **in_matrix, int n);
void partial_sweep(double **in_matrix, int r, int c, int k);
void ludcmp(double **a, int n, int *indx, double *d);
void lubksb(double **a, int n, int *indx, double *b);
double enter_start_value(char *component_name);
double binomial_coeff(int n, int k);
double factln (int n);
double gammaln(double xx);


void var_com_switch(void)
{
  bool valid;
  int i, j, n, ped, pheno_index;
  char *tmp, *default_file, **names, **headings;
  FILE *varcomfp, *corrfp, *lodfpps, *varfpps;

  /**** Check for the correct starting conditions ****/
  if (num_phenotypes == 0)
    error("no phenotype data loaded for this session\n");
  if (!scan_done)
    error("no scan done for the current map, pair, and pedigree settings\n");

  /* Find out which phenotype to look at */
  valid=FALSE;
  while (!valid) {
    if (num_phenotypes > 1) {
      sf(ps,"which phenotype do you want to analyze? (1-%d): ",
	 num_phenotypes);
      tmp = get_temp_string();
      input(ps,tmp,TEMP_STRING_LEN);
      itoken(&tmp,iREQUIRED,&pheno_index);
      if (pheno_index < 1 || pheno_index > num_phenotypes) {
	sf(ps,"phenotype '%d' does not exist\n",pheno_index);
	print(ps);
      } else {
	pheno_index--;
	valid=TRUE;
      }
    } else { pheno_index = 0; valid = TRUE; }
  }

  /* Make list of phenotyped members of each pedigree */
  array(num_phenotyped, num_pedigrees, int);
  matrix(phenotyped_members, num_pedigrees, MAX_INDIVIDUALS, int);
  array(pedigree_IDs, num_pedigrees, int);
  num_peds = 0;
  for (ped=0; ped<num_pedigrees; ped++) {
    n = 0;
    for (i=0; i<pedigree_size[ped]; i++) {
      if (pheno[ped][i][pheno_index] != MISSING_PHENO) {
	phenotyped_members[num_peds][n] = i;
	n++;
      } 
    }
    if (n > 1) {
      num_phenotyped[num_peds] = n;
      pedigree_IDs[num_peds] = ped;
      num_peds++;
    }
  }

  /* Include polygenic dominance variance? */
  num_null_vars = 3; /* Additive, dominance, environmental */
  sf(ps,"include polygenic dominance variance component? y/n [y]: ");
  tmp = get_temp_string();
  input(ps,tmp,TEMP_STRING_LEN);
  if (tmp[0] == 'n' || tmp[0] == 'N')
    num_null_vars = 2; /* Additive and environmental */

  /* Include QTL dominance variance? */
  num_QTL_vars = 2; /* QTL additive and QTL dominance */
  sf(ps,"include QTL dominance variance component? y/n [y]: ");
  tmp = get_temp_string();
  input(ps,tmp,TEMP_STRING_LEN);
  if (tmp[0] == 'n' || tmp[0] == 'N')
    num_QTL_vars = 1; /* QTL additive */
 
  /* Determine phenotypic means and variance */
  num_means = means_by_sex ? 2 : 1;
  pheno_mean_and_variance(pheno_index);

  /* Write parameter names and column headings for output */
  matrix(names, MAX_COVARIATES+10, MAX_NAME_SIZE, char);
  matrix(headings, MAX_COVARIATES+10, MAX_NAME_SIZE, char);
  if (num_means == 1) {
    strcpy(names[0], "Mean trait value");
    strcpy(headings[0], "Mean        ");
  }
  else {
    strcpy(names[0], "Mean trait value for males");
    strcpy(names[1], "Mean trait value for females");
    strcpy(headings[0], "Mean (M)");
    strcpy(headings[1], "Mean (F)");
  }
  for(i=num_means; i<num_means+num_covs; i++) {
    sf(ps,"Covariate coefficient %d", i-num_means+1);
    strcpy(names[i], ps);
    sf(ps,"Covariate %d", i-num_means+1);
    strcpy(headings[i], ps);
  }
  if (num_null_vars == 2) {
    strcpy(names[num_means+num_covs], "Polygenic additive variance");
    strcpy(names[num_means+num_covs+1], "Environmental variance");
    strcpy(headings[num_means+num_covs], "Additive (P)");
    strcpy(headings[num_means+num_covs+1], "Environmental");
    strcpy(names[num_means+num_covs+num_null_vars+num_QTL_vars], "Null polygenic additive variance");
    strcpy(names[num_means+num_covs+num_null_vars+num_QTL_vars+1], "Null environmental variance");
  }
  else {
    strcpy(names[num_means+num_covs], "Polygenic additive variance");
    strcpy(names[num_means+num_covs+1], "Polygenic dominance variance");
    strcpy(names[num_means+num_covs+2], "Environmental variance");
    strcpy(headings[num_means+num_covs], "Additive (P)");
    strcpy(headings[num_means+num_covs+1], "Dominance (P)");
    strcpy(headings[num_means+num_covs+2], "Environmental");
    strcpy(names[num_means+num_covs+num_null_vars+num_QTL_vars], "Null polygenic additive variance");
    strcpy(names[num_means+num_covs+num_null_vars+num_QTL_vars+1], "Null polygenic dominance variance");
    strcpy(names[num_means+num_covs+num_null_vars+num_QTL_vars+2], "Null environmental variance");
  }
  if (num_QTL_vars == 1) {
    strcpy(names[num_means+num_covs+num_null_vars], "QTL additive variance");
    strcpy(headings[num_means+num_covs+num_null_vars], "Additive (QTL)");
  }
  else {
    strcpy(names[num_means+num_covs+num_null_vars], "QTL additive variance");
    strcpy(names[num_means+num_covs+num_null_vars+1], "QTL dominance variance");
    strcpy(headings[num_means+num_covs+num_null_vars], "Additive (QTL)");
    strcpy(headings[num_means+num_covs+num_null_vars+1], "Dominance (QTL)");
  }
   
  /* Open output file */
  array(default_file,MAX_FILE_NAME_LEN,char);
  nstrcpy(default_file,"vc.out",MAX_FILE_NAME_LEN);
  varcomfp = open_out_file(default_file, "variance components");
 
  /* Open parameter correlations file */
  nstrcpy(default_file,"corr.out",MAX_FILE_NAME_LEN);
  corrfp = open_out_file(default_file, "parameter correlations");

  /* Open lod score postscript file */
  if (num_in_map_order > 1 && postscript_output && !single_point_mode) {
    nstrcpy(default_file,"vc_lod.ps",MAX_FILE_NAME_LEN);
    lodfpps = open_postscript_file(default_file, "LOD");
  }

  /* Open variance components postscript file */
  if (num_in_map_order > 1 && postscript_output && !single_point_mode) {
    nstrcpy(default_file,"vc_var.ps",MAX_FILE_NAME_LEN);
    varfpps = open_postscript_file(default_file, "variance components");
  }
  unarray(default_file, char);

  /* Write headings for variance components output file */
  if (single_point_mode)
    fprintf(varcomfp,"marker\tLOD\t\t");
  else
    fprintf(varcomfp,"pos   \tLOD\t\t");
  for (i=0; i<num_means+num_covs+num_null_vars+num_QTL_vars; i++)
    fprintf(varcomfp, "%-18s\t", headings[i]);
  fprintf(varcomfp, "Converged?\n");

  /* Write headings for correlations file */
  fprintf(corrfp, "      \t");
  for (i=0; i<num_means+num_covs; i++)
    for (j=i+1; j<num_means+num_covs; j++)
      fprintf(corrfp, "%s,\t", headings[i]);
  for (i=num_means+num_covs; i<num_means+num_covs+num_QTL_vars+num_null_vars; i++)
    for (j=i+1; j<num_means+num_covs+num_QTL_vars+num_null_vars; j++)
      fprintf(corrfp, "%s,\t", headings[i]);
  fprintf(corrfp, "\n");
  if (single_point_mode)
    fprintf(corrfp,"marker\t");
  else
    fprintf(corrfp,"pos   \t");
  for (i=0; i<num_means+num_covs; i++)
    for (j=i+1; j<num_means+num_covs; j++)
      fprintf(corrfp, "%s\t", headings[j]);
  for (i=num_means+num_covs; i<num_means+num_covs+num_QTL_vars+num_null_vars; i++)
    for (j=i+1; j<num_means+num_covs+num_QTL_vars+num_null_vars; j++)
      fprintf(corrfp, "%s\t", headings[j]);
  fprintf(corrfp, "\n");
 
  max_likelihood(varcomfp, corrfp, lodfpps, varfpps, pheno_index, names, headings);

  unarray(num_phenotyped, int);
  unmatrix(phenotyped_members, num_pedigrees, int);
  unarray(pedigree_IDs, int);
  unmatrix(names, MAX_COVARIATES+10, char);
  unmatrix(headings, MAX_COVARIATES+10, char);
}


void max_likelihood(FILE *varcomfp, FILE *corrfp, FILE *lodfpps, FILE *varfpps, int pheno_index, char **param_names, char **headings)
/* Implements Fisher's scoring method to find maximum likelihood values for the mean and variance */
/* components of the QTL at each scan position. The method follows that outlined by Lange, Westlake, */
/* and Spence (1976), Ann Hum Genet 39:485-491; Jennrich and Sampson (1976), Technometrics 18:11-17; */
/* and Jennrich and Sampson (1968), Technometrics 10:63-72. */
{
  int num_params, num_correlations, num_null_correlations, ped, pid, i, j, k, r, c, pos, vc;
  double *params, *corrs, *vars, total_var, logML, val;
  double *start_vals, **ML_estimates, **ML_correlations, **ML_variances;
  double *null_estimates, *null_correlations, *null_variances;
  double logNull, *loglike, *lod, **relvar;
  char **legend_str, *tmp, heading_str[50];
  bool converged, *pos_converged, manual_enter;

  /* Allocate storage */
  num_params = num_means+num_covs+num_null_vars+num_QTL_vars;
  num_vars = num_null_vars+num_QTL_vars;
  num_fixed = num_means+num_covs;
  num_correlations = binomial_coeff(num_fixed, 2) + binomial_coeff(num_vars, 2);
  num_null_correlations = binomial_coeff(num_fixed, 2) + binomial_coeff(num_null_vars, 2);
  array(params, num_params, double); 
  array(corrs, num_correlations, double);
  array(vars, num_params, double);
  array(start_vals, num_params+num_null_vars, double);
  matrix(ML_estimates, num_params, num_w_pos, double);
  matrix(ML_correlations, num_correlations, num_w_pos, double);
  matrix(ML_variances, num_params, num_w_pos, double);
  array(null_estimates, num_params, double);
  array(null_correlations, num_null_correlations, double);
  array(null_variances, num_params, double);
  array(det, num_peds, double);
  array(variance, num_peds, double**);
  array(inverse, num_peds, double**);
  array(dev_matrix, num_peds, double**);
  array(dev_transpose, num_peds, double**);
  for (i=0; i<num_peds; i++) {
    matrix (variance[i], MAX_INDIVIDUALS, MAX_INDIVIDUALS, double);
    matrix (inverse[i], MAX_INDIVIDUALS, MAX_INDIVIDUALS, double);
    matrix(dev_matrix[i], MAX_INDIVIDUALS, 1, double);
    matrix(dev_transpose[i], 1, MAX_INDIVIDUALS, double);
  }
  matrix(deriv, num_vars, num_peds, double**);
  matrix(fixed_derivs, num_peds, num_fixed, double**);
  matrix(fixed_derivs_transpose, num_peds, num_fixed, double**);
  for(i=0; i<num_vars; i++)
    for(j=0; j<num_peds; j++)
      matrix(deriv[i][j], MAX_INDIVIDUALS, MAX_INDIVIDUALS, double);
  for(i=0; i<num_peds; i++)
    for(j=0; j<num_fixed; j++) {
      matrix(fixed_derivs[i][j], MAX_INDIVIDUALS, 1, double);
      matrix(fixed_derivs_transpose[i][j], 1, MAX_INDIVIDUALS, double);
    }
  matrix(temp1, MAX_INDIVIDUALS, MAX_INDIVIDUALS, double);
  matrix(temp2, MAX_INDIVIDUALS, MAX_INDIVIDUALS, double);
  matrix(temp3, MAX_INDIVIDUALS, MAX_INDIVIDUALS, double);
  matrix(temp4, MAX_INDIVIDUALS, MAX_INDIVIDUALS, double);
  array(loglike, num_w_pos, double);
  array(lod, num_w_pos, double);
  matrix(relvar, num_vars, num_w_pos, double);
  array(pos_converged, num_w_pos, bool);

 /* Enter starting values manually? */
  manual_enter = TRUE;     
  sf(ps,"Manually enter starting values for means and variances? y/n [y]: ");
  tmp = get_temp_string();
  input(ps,tmp,TEMP_STRING_LEN);
  if (tmp[0] == 'n' || tmp[0] == 'N')
    manual_enter = FALSE;

  if (manual_enter) {
    sf(ps,"The total phenotypic variance = %f\n", varP);
    print(ps);
    if (num_means == 1) {
      sf(ps,"The mean trait value = %f\n", mMean);
      print(ps);
    }
    else {
      sf(ps,"The mean male trait value = %f\nThe mean female trait value = %f\n", mMean, fMean);
      print(ps);
    }
    for (i=0; i<num_params+num_null_vars; i++)
      start_vals[i] = enter_start_value(param_names[i]);
  }
  else {   /* Set covariate coefficients to zero, and divide total variance equally among components */
    start_vals[0] = mMean;                    /* Mean(s) */
    if (num_means == 2)
      start_vals[1] = fMean;
    for (i=num_means; i<num_fixed; i++)       /* Covariates */
      start_vals[i] = 0.0;
    for (; i<num_fixed+num_vars; i++)         /* Variances for ML model*/
      start_vals[i] = varP/(num_vars);
    for (; i<num_params+num_null_vars; i++)   /* Variances for null model */
      start_vals[i] = varP/num_null_vars;
  }
 
  /* Fill parts of derivative matrices which do not depend on position */
  for (ped=0; ped<num_peds; ped++) {
    pid = pedigree_IDs[ped];
    for (i=0; i<num_phenotyped[ped]; i++) {
      r = phenotyped_members[ped][i];
      for (j=0; j<=i; j++) {
	c = phenotyped_members[ped][j];
	if (i>j) {
	  vc = 0;
	  deriv[vc][ped][i][j] = deriv[vc][ped][j][i] =
	    prior_wmatrix[pid][r][c][1]/2 + prior_wmatrix[pid][r][c][2];  /* Polygenic additive var. */
	  vc++;
	  if (num_null_vars == 3) {
	    deriv[vc][ped][i][j] = deriv[vc][ped][j][i] = 
	      prior_wmatrix[pid][r][c][2];                    /* Polygenic dominance variance */
	    vc++;
	  }
	  deriv[vc][ped][i][j] = deriv[vc][ped][j][i] = 0;    /*Environmental variance */
	}
	else {
	  for (vc=0; vc<num_vars; vc++)
	  deriv[vc][ped][i][j] = 1;
	}
      }   
    }
  }

  for (ped=0; ped<num_peds; ped++) {
    pid = pedigree_IDs[ped];
    for (i=0; i<num_phenotyped[ped]; i++) {
      r = phenotyped_members[ped][i];
      if (num_means == 2) {
	if (sex[pid][r] == 1) {  /* male */
	  fixed_derivs[ped][0][i][0] = fixed_derivs_transpose[ped][0][0][i] = 1;
	  fixed_derivs[ped][1][i][0] = fixed_derivs_transpose[ped][1][0][i] = 0;
	}
	else {  /* female */
	  fixed_derivs[ped][0][i][0] = fixed_derivs_transpose[ped][0][0][i] = 0;
	  fixed_derivs[ped][1][i][0] = fixed_derivs_transpose[ped][1][0][i] = 1;
	}
      }
      else   /* Means not calculated separately for each sex */
	fixed_derivs[ped][0][i][0] = fixed_derivs_transpose[ped][0][0][i] = 1;
    }
    for (c=0; c<num_covs; c++)
      for (i=0; i<num_phenotyped[ped]; i++) {
	r = phenotyped_members[ped][i];
	fixed_derivs[ped][c+num_means][i][0] = fixed_derivs_transpose[ped][c+num_means][0][i] =
	  covariates[pid][r][c];
      }
  }

  for (pos=0; pos<num_w_pos; pos++) {  /* loop over scan positions */
    /* Fill derivative matrices */
    for (ped=0; ped<num_peds; ped++) {
      pid = pedigree_IDs[ped];
      for (i=0; i<num_phenotyped[ped]; i++) {
	r = phenotyped_members[ped][i];
	for (j=0; j<=i; j++) {
	  c = phenotyped_members[ped][j];
	  if (i>j) {
	    deriv[num_null_vars][ped][i][j] = deriv[num_null_vars][ped][j][i] =
	      wmatrix[pid][pos][r][c][1]/4 + wmatrix[pid][pos][r][c][2]/4;     /* QTL additive var. */
	    if (num_QTL_vars == 2)
	      deriv[num_null_vars+1][ped][i][j] = deriv[num_null_vars+1][ped][j][i] =
		wmatrix[pid][pos][r][c][2]/4;                                  /* QTL dominance var. */
	  }
	}
      }
    }
   
    /* Find constrained maximum likelihood estimates under null hypothesis */
    /* Do this only for the first scan position, since the estimates are the same for all positions */
    if (pos == 0) {
      /* Find and store maximum likelihood estimates, under the constraint that varA and varD = zero */
      for (i=0; i<num_fixed; i++)   /* Set means and covariate coefficients to start values */
	params[i] = start_vals[i];
      for (; i<num_fixed+num_null_vars; i++)   /* Set variance comps. of null model to start values */
	params[i] = start_vals[i+num_vars];
      for (; i<num_vars; i++)   /* Set QTL variance comps. to zero */
	params[i] = 0.0;
      converged = fisher (params, corrs, vars, num_params-num_QTL_vars, &logNull, pheno_index, pos);
      if (converged) {
	for (i=0; i<num_fixed+num_null_vars; i++) {
	  null_estimates[i] = params[i];
	  null_variances[i] = vars[i];
	}
	for (i=0; i<num_null_correlations; i++)
	  null_correlations[i] = corrs[i];
	logNull *= LOG10E;

	/* Reinitialize the parameters for use as the starting values for the ML solution */
	for (i=0; i<num_params; i++)
	  params[i] = start_vals[i];
      }
      else   /* Convergence failed: abort analysis */
	error("MAXITS exceeded in fisher while calculating likelihood of null hypothesis");
    }

    /* Find and store maximum likelihood estimates of mean and variances */
    if (start_values == CONSTANT)      /* I.e., not using ML estimates from previous position */
      for (i=0; i<num_params; i++)
	params[i] = start_vals[i];

    converged = fisher (params, corrs, vars, num_params, &logML, pheno_index, pos);
    if (converged) {
      for (i=0; i<num_params; i++) {
	ML_estimates[i][pos] = params[i];
	ML_variances[i][pos] = vars[i];
      }
      for (i=0; i<num_correlations; i++)
	ML_correlations[i][pos] = corrs[i];
      loglike[pos] = LOG10E*logML;
      pos_converged[pos] = TRUE;
    }
    else if (pos > 0) {   /* Convergence failed: set estimates to those at previous position */
      for (i=0; i<num_params; i++) {
	ML_estimates[i][pos] = ML_estimates[i][pos-1];
	ML_variances[i][pos] = ML_variances[i][pos-1];
      }
      for (i=0; i<num_correlations; i++)
	ML_correlations[i][pos] = ML_correlations[i][pos-1];
      loglike[pos] = loglike[pos-1];
      pos_converged[pos] = FALSE;
    }
    else {   /* Convergence failed: set all estimates to zero and loglikelihood to logNull */
      for (i=0; i<num_params; i++) {
	ML_estimates[i][pos] = 0.0;
	ML_variances[i][pos] = 0.0;
      }
      for (i=0; i<num_correlations; i++)
	ML_correlations[i][pos] = 0.0;
      loglike[pos] = logNull;
      pos_converged[pos] = FALSE;
    }
     
    lod[pos] = loglike[pos] - logNull;
    total_var = 0.0;
    for (i=num_fixed; i<num_params; i++)
      total_var += ML_estimates[i][pos];
    for (i=num_fixed; i<num_params; i++)
      relvar[i-num_fixed][pos] = ML_estimates[i][pos]/total_var;
  }
 
  /* Report lod scores and maximum likelihood estimates */
  for (pos=0; pos<num_w_pos; pos++) {
    fprintf(varcomfp,"%.3lf\t%f\t",wpos[pos], lod[pos]);
    for (i=0; i<num_params; i++)
      fprintf(varcomfp,"%f (%f)\t", ML_estimates[i][pos], sqrt(ML_variances[i][pos]));
    fprintf(varcomfp, "\t%s\n", pos_converged[pos] ? "Y" : "N");
  }

  /* Report correlations among parameter estimates */
  for (pos=0; pos<num_w_pos; pos++) {
    fprintf(corrfp, "%.3lf\t", wpos[pos]);
    for (i=0; i<num_correlations; i++)
      fprintf(corrfp, "%f\t", ML_correlations[i][pos]);
    fprintf(corrfp, "\n");
  }

  /* Report parameter estimates under null hypothesis */
  fprintf(varcomfp, "\nParameter estimates under null hypothesis:\n");
  for (i=0; i<num_params-num_QTL_vars; i++)
    fprintf(varcomfp, "%28s = %f (%f)\n", param_names[i], null_estimates[i], sqrt(null_variances[i]));

  /* Report correlations among null parameter estimates */
  fprintf(corrfp, "\nCorrelations among null parameter estimates:\n");
  k = 0;
  for (i=0; i<num_fixed; i++)
    for (j=i+1; j<num_fixed; j++) {
      sprintf(heading_str, "%s, %s", headings[i], headings[j]);
      fprintf(corrfp, "%32s = %f\n", heading_str, null_correlations[k]);
      k++;
    }
  for (i=num_fixed; i<num_fixed+num_null_vars; i++)
    for (j=i+1; j<num_fixed+num_null_vars; j++) {
      sprintf(heading_str, "%s, %s", headings[i], headings[j]);
      fprintf(corrfp, "%32s = %f\n", heading_str, null_correlations[k]);
      k++;
    }

  /* Postscript output */
  matrix(legend_str, num_vars, 50, char);
  if (num_in_map_order > 1 && postscript_output && !single_point_mode) {
    draw_graph(lodfpps,wpos,lod,num_w_pos,"Maximum likelihood variance components estimation","LOD");
    for (i=0; i<num_vars; i++)
      sprintf(legend_str[i], param_names[i+num_fixed]);
    draw_mult_y_plots(varfpps,wpos,relvar,num_w_pos,num_vars,"Variance components",legend_str,"Proportion of total variance");
  }
  unmatrix(legend_str, 4, char);

  if (num_in_map_order > 1 && postscript_output && !single_point_mode)
    print("\nAnalysis complete\ntext and drawing output files successfully written\n");
  else
    print("\nAnalysis complete\ntext output file successfully written\n");

  /* Clean up */
  unarray(params, double);
  unarray(corrs, double);
  unarray(vars, double);
  unarray(start_vals, double);
  unmatrix(ML_estimates, num_params, double);
  unmatrix(ML_correlations, num_correlations, double);
  unmatrix(ML_variances, num_params, double);
  unarray(null_estimates, double);
  unarray(null_correlations, double);
  unarray(null_variances, double);
  unarray(det, double);
  for (i=0; i<num_peds; i++) {
    unmatrix(variance[i], MAX_INDIVIDUALS, double);
    unmatrix(inverse[i], MAX_INDIVIDUALS, double);
    unmatrix(dev_matrix[i], MAX_INDIVIDUALS, double);
    unmatrix(dev_transpose[i], 1, double);
  }
  unarray(variance, double**);
  unarray(inverse, double**);
  unarray(dev_matrix, double**);
  unarray(dev_transpose, double**);
  for (i=0; i<num_vars; i++)
    for (j=0; j<num_peds; j++)
      unmatrix(deriv[i][j], MAX_INDIVIDUALS, double);
  unmatrix(deriv, num_vars, double**);
  for (i=0; i<num_peds; i++)
    for (j=0; j<num_fixed; j++) {
      unmatrix(fixed_derivs[i][j], MAX_INDIVIDUALS, double);
      unmatrix(fixed_derivs_transpose[i][j], 1, double);
    }
  unmatrix(fixed_derivs, num_peds, double**);
  unmatrix(fixed_derivs_transpose, num_peds, double**);
  unmatrix(temp1, MAX_INDIVIDUALS, double);
  unmatrix(temp2, MAX_INDIVIDUALS, double);
  unmatrix(temp3, MAX_INDIVIDUALS, double);
  unmatrix(temp4, MAX_INDIVIDUALS, double);
  unarray(loglike, double);
  unarray(lod, double);
  unmatrix(relvar, num_vars, double);
  unarray(pos_converged, bool);
   
  close_file(varcomfp);
  close_file(corrfp);
  if (num_in_map_order > 1 && postscript_output && !single_point_mode)
    close_file(varfpps);	
}


#define FREERETURN {unarray(fvec, double); unarray(xold, double); unarray(p, double);\
		      unmatrix(q, n, double); unarray(drop, bool); unarray(diagonal, double);\
		      unmatrix(q_inverse, n, double); unarray(col, double); unarray(ind, int); return TRUE;}
bool fisher (double x[], double corrs[], double vars[], int n, double *f, int pheno_index, int pos)
/* Loosely based on function newt from Press et al. (1992) Numerical Recipes in C, pp. 386-388 */
/* This function uses Fisher's scoring method, rather than the Newton-Raphson method, to find the */
/* parameter values which maximize the loglikelihood of the data for the phenotype given by */
/* pheno_index, at scan position pos. The starting estimates of the n parameters are passed in x, */
/* which holds the maximum likelihood values at the end. The loglikelihood of the final estimates */
/* is stored in f. */
{
  int c, its, i, j, k, ped, size, index, count, pivot, *ind;
  double fold, test, next_test, **q, *p, *xold, *fvec, old, max_step, *col, **q_inverse;
  bool done, *drop, *swept, divide, found;
  double a, *diagonal;

  array(drop, n, bool);
  array(swept, n, bool);
  array(diagonal, n, double);
  matrix(q, n, n+1, double);
  matrix(q_inverse, n, n+1, double);
  array(p, n, double);
  array(xold, n, double);
  array(fvec, n, double);
  array(col, n, double);
  array(ind, n, int);

  count = 0;

  /* Determine loglikelihood of starting values. As side effect, also calculate variance matrices, */
  /* their inverses, and other structures needed below to calculate the score vector and */
  /* information matrix */
  *f = fmax(x, pheno_index);
  for (its = 1; its<MAXITS; its++) {   /* Iterate until convergence on max likelihood values */
    /* Determine score vector (fvec) and information matrix (q) */
    for (i=0; i<num_fixed; i++)
      get_fixed_score(&fvec[i], i);
    for (i=0; i<num_vars; i++)
      get_variance_score(i, &fvec[i+num_fixed]);
    finfo(n, q);

    /* Append scores to information matrix in preparation for partial sweeping to determine */
    /* step direction */
    for (i=0; i<n; i++) {
      q[i][n] = fvec[i];
      drop[i] = FALSE;     /* At first, sweep entire matrix */
      diagonal[i] = q[i][i];  /* Used below in determining when to drop rows and columns */
    }                         /* from matrix to avoid singularity */
   
    /* Sweep all diagonal elements whose tolerance (Jennrich & Sampson (1968), p. 67) exceeds 0.001 */
    for (i=0; i<n; i++)
      swept[i] = FALSE;
    for (i=0; i<n; i++) {
      pivot = sweep_next(q, swept, n);
      if ((q[pivot][pivot] == 0) || (fabs(q[pivot][pivot] / diagonal[pivot])) < 0.001)
	drop[pivot] = TRUE;
      else
	partial_sweep(q, n, n+1, pivot);
      swept[pivot] = TRUE;
    }
   
    /* Store the calculated parameter steps in p; set p to zero for any element not swept above */
    for (i=0; i<n; i++) {
      p[i] = q[i][n];
      if (drop[i])
	p[i] = 0;
    }

    /* Drop from the analysis any variances which are currently at zero and have a */
    /* negative step value */
    done = FALSE;
    while (!done) {   
      /* If any variance already equals zero and has a negative step value, drop it. */
      found = FALSE;
      i=num_covs+num_means;
      while (!found && i<n)
	if ((x[i] == 0) && (p[i] < 0))
	  found = TRUE;
	else
	  i++;
      if (i<n) {
	partial_sweep(q, n, n+1, i);     /* This reverses the effect of the previous */
	drop[i] = TRUE;                  /*pivot on this element */          
	for (j=0; j<n; j++) {
	  p[j] = q[j][n];
	  if (drop[j])
	    p[j] = 0;
	}
      }
      else
	done = TRUE;
    }

    /* Scale the step size until none of the new variance estimates are negative. */
    a = 1.0;
    index = 0;
    for (i=num_covs+num_means; i<n; i++)
      if ((x[i] + p[i]) < 0) 
	if (-x[i]/p[i] < a) {
	  a = -x[i]/p[i];
	  index = i;
	}
    for (i=0; i<n; i++)
      p[i] *= a;
    if (index > 0)
      p[index] = -x[index];   /* in case of rounding error */

    /* Store current parameter values and their loglikelihood in xold and fold */
    for (i=0; i<n; i++)
      xold[i] = x[i];
    fold = *f;

    /* Scale the step size to avoid any decrease in loglikelihood, and update the parameter values. */
    step_half(n, pheno_index, xold, fold, p, x, f);

    /* Find the parameter whose value has changed the most */
    test = fabs(x[0]-xold[0]);
    old = xold[0];
    for (i=1; i<n; i++) {
      next_test = fabs(x[i]-xold[i]);
      if (next_test > test) {
	test = next_test;
	old = xold[i];
      }
    }

    /* If the largest parameter value change is less than a threshold value, augment count */
    if (test <= EPS1*(fabs(old) + EPS2))
      count++;
    else
      count = 0;  /* Otherwise, reset count to zero */

    /* If a sufficient number of consecutive subthreshold parameter changes has occurred, and the */
    /* most recent loglikelihood increase is also below a threshold value, stop iterating */
    /* This termination rule is from references cited in Searle et al. (1992), Variance Components, p. 296 */
    if ((count > REPEATS) && (fabs(*f-fold) < TOLF)) {   /* Convergence */
      /* Invert information matrix */
      finfo(n, q);
      ludcmp(q, n, ind, &old); /* old is a dummy */
      for (j=0; j<n; j++) {
	for (i=0; i<n; i++)
	  col[i] = 0.0;
	col[j] = 1.0;
	lubksb(q, n, ind, col);
	for (i=0; i<n; i++)
	  q_inverse[i][j] = col[i];
      }

      /* Read correlations and variances from inverted information matrix */
      k = 0;
      for (i=0; i<n; i++)
	vars[i] = q_inverse[i][i];
      for (i=0; i<num_fixed; i++)
	for (j=i+1; j<num_fixed; j++) {
	  corrs[k] = q_inverse[i][j]/sqrt(vars[i]*vars[j]);
	  k++;
	}
      for (i=num_fixed; i<n; i++)
	for (j=i+1; j<n; j++) {
	  corrs[k] = q_inverse[i][j]/sqrt(vars[i]*vars[j]);
	  k++;
	}
      FREERETURN  
    }
  }
  return FALSE;  /* Convergence failed: exceeded max number of iterations (MAXITS) */
}


int sweep_next(double **in_matrix, bool *already_swept, int n)
{
  int next;
  bool found = FALSE;
 
  while (!found) {
    next = randnum() * n;
    if (!already_swept[next]) {
      found = TRUE;
      return next;
    }
  }
}


double fmax(double x[], int pheno_index)
/* Determine the loglikelihood of the parameter values given in x */
{
  int i, j, r, c, vc, ped, pid, size, *indx;
  double sum, logl, *col, var;

  array(indx, MAX_INDIVIDUALS, int);
  array(col, MAX_INDIVIDUALS, double);

  for (ped=0; ped<num_peds; ped++) {
    pid = pedigree_IDs[ped];
    /* Fill variance and derivative matrices */
    for (i=0; i<(size=num_phenotyped[ped]); i++)
      for (j=0; j<i+1; j++) {
	var = 0.0;
	for (vc=0; vc<num_vars; vc++)
	  var += deriv[vc][ped][i][j]*x[num_fixed+vc];
	variance[ped][i][j] = variance[ped][j][i] = var;
      }

    /* Get determinants and inverses of variance matrices */
    ludcmp(variance[ped], size, indx, &det[ped]);
    for (i=0; i<size; i++)
      det[ped] *= variance[ped][i][i];
    for (j=0; j<size; j++) {
      for (i=0; i<size; i++)
	col[i] = 0.0;
      col[j] = 1.0;
      lubksb(variance[ped], size, indx, col);
      for (i=0; i<size; i++)
	inverse[ped][i][j] = col[i];
    }
   
    /* Fill deviation matrices */
    for (i=0; i<size; i++) {
      r = phenotyped_members[ped][i];
      dev_matrix[ped][i][0] = pheno[pid][r][pheno_index];
      for (c=0; c<num_covs+num_means; c++)
	dev_matrix[ped][i][0] -= fixed_derivs[ped][c][i][0]*x[c];
    }
    transpose(dev_matrix[ped], size, 1, dev_transpose[ped]);
  }

  /* Calculate loglikelihood */
  logl = 0.0;
  for (ped=0; ped<num_peds; ped++) {
    logl -= log(det[ped])/2;
    dot_product(dev_transpose[ped], inverse[ped], 1, num_phenotyped[ped], num_phenotyped[ped], temp1);
    dot_product(temp1, dev_matrix[ped], 1, num_phenotyped[ped], 1, temp2);
    logl -= **temp2/2;
  }
  unarray(col, double);
  unarray(indx, int);
  return logl;
}


void step_half(int n, int pheno_index, double xold[], double fold, double p[], double x[], double *f)
/* Employ step-halving to determine a new set of n parameter values which do not yield a decrease */
/* in the loglikelihood (f) from its previous value (fold). Begin by adding step values in p to xold. */
/* Iteratively halve p, as necessary, until a step is found which does not reduce the loglikelihood. */
/* Report the new parameter values in x */
{
  int i;
  double a;
 
  a = 1.0;
  *f = fold - 1;
  while (*f < fold) {
    for (i=0; i<n; i++)
      x[i] = xold[i] + a*p[i];
    *f = fmax(x, pheno_index);
    a /= 2;
    if ((a == 0) && (*f < fold))
      error("Decrease in likelihood during search for maximum likelihood values. Try running again with different start values.\n");
  }
}


void get_fixed_score(double *fixed_param, int paramID)
/* Find the derivative of the loglikelihood with respect to the indicated fixed parameter */
/* (mean or covariate regression coefficient). Calculating formula from Lange et al (1976) */
{
  int ped, size;

  *fixed_param = 0.0;
  for (ped=0; ped<num_peds; ped++) {  /* loop over pedigrees */
    size = num_phenotyped[ped];
    dot_product(fixed_derivs_transpose[ped][paramID], inverse[ped], 1, size, size, temp1);
    dot_product(temp1, dev_matrix[ped], 1, size, 1, temp2);
    *fixed_param += **temp2;
  }
}

void get_variance_score(int component, double *var)
/* Find the derivative of the loglikelihood with respect to the indicated variance component */
/* Calculating formula from Lange et al (1976) */
{
  int ped, size;

  *var = 0; 
  for (ped=0; ped<num_peds; ped++) {  /* loop over pedigrees */
    size = num_phenotyped[ped];
    dot_product(inverse[ped], deriv[component][ped], size, size, size, temp1);
    *var += -trace(temp1, size)/2;
    dot_product(dev_transpose[ped], inverse[ped], 1, size, size, temp1);
    dot_product(temp1, deriv[component][ped], 1, size, size, temp2);
    dot_product(temp2, inverse[ped], 1, size, size, temp1);
    dot_product(temp1, dev_matrix[ped], 1, size, 1, temp2);
    *var += (**temp2)/2;
  }
} 


void finfo(int n, double **info)
/* Calculate the information matrix: the expectations of the negatives of the second partial */
/* derivatives of the loglikelihood with respect to the n parameters (mean, covariate regression */
/* coefficients, and variance components). Calculating formula based on Lange et al (1976) */
{
  int i, j, r, c, size, ped;

  for (i=0; i<n; i++)
    for (j=0; j<n; j++)
      info[i][j] = 0;
  for (ped=0; ped<num_peds; ped++) {  /* loop over pedigrees */
    size = num_phenotyped[ped];
    for (r=0; r<num_covs+num_means; r++)
      for (c=0; c<num_covs+num_means; c++) {
	dot_product(fixed_derivs_transpose[ped][r], inverse[ped], 1, size, size, temp1);
	dot_product(temp1, fixed_derivs[ped][c], 1, size, 1, temp2);
	info[r][c] += **temp2;
      }
    for(i=num_covs+num_means; i<n; i++) {
      dot_product(inverse[ped], deriv[i-num_means-num_covs][ped], size, size, size, temp1);
      dot_product(temp1, inverse[ped], size, size, size, temp2);
      for(j=num_covs+num_means; j<n; j++) {
	dot_product(temp2, deriv[j-num_means-num_covs][ped], size, size, size, temp1);
	info[i][j] += trace(temp1, size)/2;
      }
    }
  }
}

    
void matrix_sum(double **a, double **b, int r, int c, double **sum)
{
  int i, j;

  for (i=0; i<r; i++)
    for (j=0; j<c; j++)
      sum[i][j] = a[i][j] + b[i][j];
}


void fdjac(int n, double **q)
{
  int i, j, size, ped;

  for (i=0; i<n; i++)
    for (j=0; j<n; j++)
      q[i][j] = 0;
  for (ped=0; ped<num_peds; ped++) {  /* loop over pedigrees */
    size = num_phenotyped[ped];
     
    /* Increment q matrix elements */
    for (i=0; i<size; i++)
      for (j=0; j<size; j++)
	q[0][0] += inverse[ped][i][j];
    for (i=1; i<n; i++) {
      dot_product(temp1, deriv[i-1][ped], 1, size, size, temp2);
      dot_product(temp2, inverse[ped], 1, size, size, temp1);
      dot_product(temp1, dev_matrix[ped], 1, size, 1, temp2);
      q[i][0] += **temp2;
      q[0][i] += **temp2;
    }
    for(i=1; i<n; i++)
      for(j=1; j<n; j++) {
	dot_product(inverse[ped], deriv[i-1][ped], size, size, size, temp1);
	dot_product(temp1, inverse[ped], size, size, size, temp2);
	dot_product(temp2, deriv[j-1][ped], size, size, size, temp1);
	q[i][j] -= trace(temp1, size)/2;
	dot_product(dev_transpose[ped],inverse[ped], 1, size, size, temp1);
	dot_product(deriv[i-1][ped], inverse[ped], size, size, size, temp2);
	dot_product(temp2, deriv[j-1][ped], size, size, size, temp3);
	dot_product(deriv[j-1][ped], inverse[ped], size, size, size, temp2);
	dot_product(temp2, deriv[i-1][ped], size, size, size, temp4);
	matrix_sum(temp3, temp4, size, size, temp2);
	dot_product(temp1, temp2, 1, size, size, temp3);
	dot_product(temp3, inverse[ped], 1, size, size, temp1);
	dot_product(temp1, dev_matrix[ped], 1, size, 1, temp2);
	q[i][j] += **temp2/2;
      }
  }
}


void pheno_mean_and_variance(int pheno_index)
/* Report the mean and variance of the phenotype given by pheno_index, across all phenotyped individuals */
{
  int i, j, r, c, pid, ped, n_means, mN=0, fN=0;
  double ep=0.0, mSum=0.0, fSum=0.0, s, p;

  mMean = 0.0;
  fMean = 0.0;
  for(ped=0; ped<num_peds; ped++) {
    pid = pedigree_IDs[ped];
    for(i=0; i<num_phenotyped[ped]; i++) {
      r = phenotyped_members[ped][i];
      if (sex[pid][r] == 1) {  /* 1 = male */
	mN++;
	mSum+=pheno[pid][r][pheno_index];
      }
      else {
	fN++;
	fSum+=pheno[pid][r][pheno_index];
      }
    }
  }

  n_means = num_means;
  if ((num_means == 2) && (mN == 0)) {
    print("Male mean cannot be estimated because there are no phenotyped males\n");
    n_means--;
  }
  if ((num_means == 2) && (fN == 0)) {
    print("Female mean cannot be estimated because there are no phenotyped females\n");
    n_means--;
  }
  if (n_means < 1)
    error("analysis cannot be completed becuase there are no phenotyped individuals");
  num_means = n_means;

  if (num_means == 1)
    mMean=(mSum+fSum)/(mN+fN);
  else {
    mMean=mSum/mN;
    fMean=fSum/fN;
  }

  varP=0.0;
  for(ped=0; ped<num_peds; ped++) {
    pid = pedigree_IDs[ped];
    for(i=0; i<num_phenotyped[ped]; i++) {
      r = phenotyped_members[ped][i];
      s = pheno[pid][r][pheno_index];
      if (num_means == 2)
	s -= sex[pid][r] == 1 ? mMean : fMean;
      else
	s -= mMean;
      varP += s*s;
    }
  }
  varP = (varP-ep*ep/(mN+fN))/(mN+fN-1);   /* ep term corrects roundoff error: see Press */
}                                          /* et al (1992), Numerical Recipes in C, p. 613 */


void transpose(double **in_matrix, int r, int c, double **out_matrix)
/* Report transpose of r by c matrix in_matrix in out_matrix */
{
  int i, j;

  for(i=0; i<r; i++)
    for(j=0; j<c; j++)
      out_matrix[j][i] = in_matrix[i][j];
}


void dot_product(double **pre_matrix, double **post_matrix, int r, int in, int c, double **out_matrix)
/* Place in out_matrix the dot product of rXin matrix pre_matrix and inXc matrix post_matrix */
{
  int i, j, k;

  for(i=0; i<r; i++)
    for(j=0; j<c; j++) {
      out_matrix[i][j] = 0;
      for(k=0; k<in; k++)
	out_matrix[i][j] += pre_matrix[i][k] * post_matrix[k][j];
    }
}


double trace(double **in_matrix, int n)
/* Return trace of size n matrix in_matrix */
{
  int i;
  double result=0.0;

  for(i=0; i<n; i++)
    result += in_matrix[i][i];

  return result;
}


#define TINY 1.0e-20
void ludcmp(double **a, int n, int *indx, double *d)
/* Perform LU decomposition of size n matrix a. From Press et al (1992), */
/* Numerical Recipes in C, pp. 46-47. */
{
  int i, imax, j, k;
  double big, dum, sum, temp;
  double *vv;

  array(vv, n, double);
  *d = 1.0;
  for (i=0; i<n; i++) {
    big = 0.0;
    for (j=0; j<n; j++)
      if ((temp = fabs(a[i][j])) > big)
	big = temp;
    if (big == 0.0) 
      error("singular matrix in routine ludcmp");
    vv[i] = 1.0/big;
  }
  for (j=0; j<n; j++) {
    for (i=0; i<j; i++) {
      sum = a[i][j];
      for (k=0; k<i; k++)
	sum -= a[i][k]*a[k][j];
      a[i][j]=sum;
    }
    big = 0.0;
    for (i=j; i<n; i++) {
      sum = a[i][j];
      for (k=0; k<j; k++)
	sum -= a[i][k]*a[k][j];
      a[i][j] = sum;
      if ((dum = vv[i]*fabs(sum)) >= big) {
	big = dum;
	imax = i;
      }
    }
    if (j != imax) {
      for (k=0; k<n; k++) {
	dum = a[imax][k];
	a[imax][k] = a[j][k];
	a[j][k] = dum;
      }
      *d = -(*d);
      vv[imax] = vv[j];
    }
    indx[j] = imax;
    if (a[j][j] == 0.0) a[j][j] = TINY;
    if (j != n-1) {
      dum = 1.0/(a[j][j]);
      for (i=j+1; i<n; i++) a[i][j] *= dum;
    }
  }
  unarray(vv, double);
}
#undef TINY


void lubksb(double **a, int n, int *indx, double *b)
/* Perform backsubstitution of size n LU-decomposed matrix a. */
/* From Press et al (1992), Numerical Recipes in C, pp. 47-48. */
{
  int i, ii=0, ip, j;
  double sum;

  for (i=0; i<n; i++) {
    ip = indx[i];
    sum = b[ip];
    b[ip] = b[i];
    if (ii > -1)
      for (j=ii; j<=i-1; j++)
	sum -= a[i][j]*b[j];
    else if (sum)
      ii = i;
    b[i] = sum;
  }
  for (i=n-1; i>=0; i--) {
    sum = b[i];
    for (j=i+1; j<n; j++)
      sum -= a[i][j]*b[j];
    b[i] = sum/a[i][i];
  }
}


void partial_sweep(double **in_matrix, int r, int c, int k)
/* Perform a Gauss-Jordan pivot on th kth diagonal element of the rXc matrix in_matrix */
/* See Jennrich and Sampson (1968), p. 66 */
{
  int i, j;
  double **a;

  matrix(a, r, c, double);

  for (i=0; i<r; i++)
    for (j=0; j<c; j++)
      a[i][j] = in_matrix[i][j];

  for (i=0; i<r; i++)
    for (j=0; j<c; j++)
      if ((i != k) && (j != k))
	in_matrix[i][j] = a[i][j] - a[i][k]*a[k][j]/a[k][k];
      else if ((i != k) && (j == k))
	in_matrix[i][j] = -a[i][k]/a[k][k];
      else if ((i == k) && (j != k))
	in_matrix[i][j] = a[k][j]/a[k][k];
      else
	in_matrix[i][j] = 1/a[k][k];

  unmatrix(a, r, double);
}


void set_num_means(void)
{
  char *tmp;
  int tmp_int,a,b,real_count,i;
  bool valid;

  sf(ps,"\nGenehunter currently "); pr();
  switch (means_by_sex) {
  case FALSE:
    print("estimates a single mean for all pedigree members.\n");
    break;
  case TRUE:
    print("estimates male and female means separately.\n");
    break;
  }
  print("\n");
  print("   1. Estimate a single mean\n");
  print("   2. Estimate male and female means separately\n");

  valid = FALSE;
  i = means_by_sex ? 2 : 1;
  while(!valid) {
    sf(ps,"Enter the index of the option you want to use [%d]: ", i);
    tmp = get_temp_string();
    input(ps,tmp,TEMP_STRING_LEN);
    if (nullstr(tmp)) valid = TRUE;
    else if (itoken(&tmp,iREQUIRED,&tmp_int)) {
      if (tmp_int > 0 && tmp_int < 3) {
	valid=TRUE;
	means_by_sex = (tmp_int == 2) ? TRUE : FALSE;
      }
      else {
	print("invalid index entered, please try again\n");
      }
    }
  }
}


void set_start_values (void)
{
  char *tmp;
  int tmp_int,a,b,real_count,i;
  bool valid;

  sf(ps,"\nGenehunter currently "); pr();
  switch (start_values) {
  case 1:
    print("uses ML estimate from adjacent position.\n");
    break;
  case 2:
    print("uses a constant fraction of total phenotypic variance.\n");
    break;
  }
  print("\n");
  print("  Possible starting values: \n");
  print("   1. ML estimate from adjacent position\n");
  print("   2. Constant fraction of total phenotypic variance\n");

  valid = FALSE;
  while(!valid) {
    sf(ps,"Enter the index of the start values you want to use [%d]: ",
       start_values);
    tmp = get_temp_string();
    input(ps,tmp,TEMP_STRING_LEN);
    if (nullstr(tmp)) valid = TRUE;
    else if (itoken(&tmp,iREQUIRED,&tmp_int)) {
      if (tmp_int > 0 && tmp_int < 3) {
	valid=TRUE;
	start_values = tmp_int;
      }
      else {
	print("invalid index entered, please try again\n");
      }
    }
  }
}


double enter_start_value(char *component_name)
{
  double val;
  char *tmp;

  sf(ps,"Enter starting value for %s: ", component_name);
  tmp = get_temp_string();
  input(ps,tmp,TEMP_STRING_LEN);
  if (!rtoken(&tmp,rREQUIRED,&val)) {
    print("bad value, try again\n");
  } else {
    return val;
  }
}


double binomial_coeff(int n, int k)
{
  if (n<k)
    return 0.0;
  else
    return floor(0.5+exp(factln(n)-factln(k)-factln(n-k)));
}


double factln(int n)
{
  static double a[101];

  if (n<0) error("Negative factorial in routine factln");
  if (n<=1) return 0.0;
  if (n<=100)
    return a[n] ? a[n] : (a[n]=gammaln(n+1.0));
  else
    return gammaln(n+1.0);
}


double gammaln(double xx)
{
  double x, y, tmp, ser;
  static double cof[6] = {76.18009172947146, -86.50532032941677, 24.01409824083091, -1.231739572450155, 0.1208650973866179e-2, -0.5395239384953e-5};
  int j;

  y = x = xx;
  tmp = x+5.5;
  tmp -= (x+0.5)*log(tmp);
  ser = 1.000000000190015;
  for (j=0; j<=5; j++)
    ser += cof[j]/++y;
  return -tmp+log(2.5066282746310005*ser/x);
}

