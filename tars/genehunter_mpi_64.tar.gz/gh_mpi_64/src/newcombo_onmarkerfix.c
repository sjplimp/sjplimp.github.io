/* GENEHUNTER - Kruglyak, Daly, Reeve-Daly, and Lander
   Whitehead Institute for Biomedical Research, Copyright 1996 */

/*G. Conant added mpi includes*/
#include "mpi_info.h"


/*G. Conant added INC_SHELL for c++ compile*/
#define INC_SHELL

#define INC_LIB
#include "npl.h"

/*G. Conant added function declars for included c++ functions and timing funcs*/
#include "driver.h"
#include "timing.h"

/*Genehunter originally had a score size of 100000 hard coded.  G. Conant changed 
  for larger problems*/
#define SCORE_SIZE 500000

/*#define TEST_COMM*/
#define ON_MARKER_DEBUG
/*#define DEBUG64*/


void compute_haplotype(int);
/* Katz, Aug, 2000, this was in newcombo.h in ghk version */
#define real_eq(x,y) (fabs((x)-(y))<1e-10)

/* externs */
double **apm_stat,**raw_stat,**p_value,**apm_info,**apm_entropy,**pvec_entropy;
double *wpos, *null_variance;
int num_w_pos;
double *total_lod;
double **sub_lods;

double *total_recs;

/* exact p-value computation */
double **prior_pscore, **pscore_list, ***post_pscore;
int *num_pscores;

/* local */
static double *map_position;
static double **lvector, **rvector, **aux, *tempvector, *newp; 
static int n, rn, *padded_vec;
static long long int N, bigN;
static double theta[MAXLOCI];
static double **pvector;
static double *apm_score;
static double expscore, expscore_2;
static int *best_pvector, **saved_partner;
static long long int uninf_mask, *flip_mask;
int *row_partner;
int *bit_count, *real_bit_count;

static int lbtc8mask=0xff, mod8[64], lbtc8[256];
static long long int lbtc8mask_l=0xff;
static long long int    **maskTest;
static int    *nz_bits;
static long long int *nz_pointer;
static double *par_score, *pvct, *lvct, *rvct;

/*Hold information about how to redistribute the marker vectors for the step 3
  calculations--G. Conant*/
static PBvct_blocks left_prob_blocks, right_prob_blocks, indep_prob_blocks;
static MPI_Status *mpistat;
/*End G. Conant additions*/
static int f_num_in_map_order, *f_uninformative, *f_map_order;
static long long int score_mask_rdc;

int num_mapped_loci;


/*G. Conant added founder_sim_masks to speed up TransBetweenAndDot*/
typedef struct {
  int p_bitc;
  long long int n_size;
  long long int n_pntf;
  long long int n_pntl;
  int nffs;
  int nMaskShift;
  long long int p_address0;
  long long int p_mask_v_bits;
  long long int p_legal;
  double l_theta[65];
  double l_ctheta[65]; 
  long long int p_v_flip_mask[64];
  long long int p_f_flip_mask[64];
  double *tempvct;
  int    *bit_cnt;
  long long int **maskShift; 
  long long int *founder_sim_mask;
  long long int *founder_sim_mask1;
  long long int *founder_sim_mask2;
  int *hamming_dist;
} TRANSSTRUCT;

typedef struct {
  double maxlike;
  double minlike;
  double lodlike;
  double like;
  double statval; 
  double varsum;
  double un_normalized_entropy;
} TRDOTSTRUCT;



/* internal procedures */
/*G. Conant changed likelihood parameters to allow a single gather op*/

double likelihood(int, int, int,  double, double, int, int *, double *, double *, 
		  double *, int, double *, double *, double *,
		  int, double *, double *);
double left(double*,int), right(double*,int);
void reduce(int,int,int), makerec(double,double*), new_reduce(int,int,int);
void exciting_reduce(int,int), haplo_reduce(int,int);
void speedy_reduce(double,double*);
void convolve_fft(double,double*), convolve_count_fft(double,double*);
void fft(double*);

void Setup_flip_masks(long long int, int *, long long int *, int *, long long int *, PBvct_blocks *);
void convolve_fft_2(int, double, int *, double *);
void Setup_MaskShift(int, long long int, long long int, long long int, TRANSSTRUCT *);
void Setup_legal_vectors(int, long long int *, int, long long int *, int, long long int *);
void   Allocate_MCh_vars(int);
void   Free_MCh_vars(void);
void   Load_pvct(void);
double Compute_lr_vectors(void);

/*Note--G. Conant reallocated the apm_score to be of the same size
 as the disease vector.  As a result, the Get_apm_score function can
 be replaced with a simple array element lookup*/
double Get_apm_score(int);
double Get_apm_score_mpi(long long int);
long long int Get_apm_offset_mpi(long long int, long long int);
void TransSetupConvolve(double, int, int, double *, TRANSSTRUCT *, PBvct_blocks *);
void TransSetupConvolve_Parallel(double, int, int, double *, TRANSSTRUCT *, PBvct_blocks *);
void TransAndMap(TRANSSTRUCT *, double *, int);
void TransAndMap_ParallelNonParallel(TRANSSTRUCT *, double *, int, PBvct_blocks *prob_blocks);
void TransAndMap_ParallelParallel(TRANSSTRUCT *, double *, int, PBvct_blocks *prob_blocks);
void TransBetweenAndDot(TRANSSTRUCT *tsleft, TRANSSTRUCT *tsright,
								double *score_list, int num_scores, double *p_score, 
								int pos_in_scan, TRDOTSTRUCT *tdot, double *tmpdot,
								double *tmp3, double *tmp4);
void TransFree(TRANSSTRUCT *, PBvct_blocks *);
void Check_results_01(int ,int, int , int, int, int, double *, double *);


/*G. Conant added function to do founder sim masks*/
void Setup_founder_sim_masks(TRANSSTRUCT *ts);

void scan_pedigree(int *nz_bits_s, long long int *nz_pointer_s, double *pvct_s,
	      double *par_score_s,
	      int f_num_in_map_order_s, int *f_uninformative_s, int *f_map_order_s,
          int real_num_bits, double *score, long long int score_mask_rdc_s,
	      double exp, double exp2, int pednum, 
	      int originals, int *best_pv, int num_bits, 
	      long long int u_mask, long long int *f_mask, long long int **maskT)
{
    void setup_lodscores(void);
    void calc_apm_scores(int,double*,int,double,int,double*,double**);
    int i,j,k,padi,andmask,bits_on,num_scores,*score_count, this_score,old_num_w_pos;
	double score_npl_val;
	double *score_list,tempmax,tempmin, default_entropy,this_prob,*lod;
    void allocate_apm_storage(void), free_apm_storage(int);
    static int previously_allocated_apm=FALSE;
    long long int ii;
   
    nz_bits    = nz_bits_s;
	nz_pointer = nz_pointer_s;
	pvct       = pvct_s;
	par_score  = par_score_s;
    f_num_in_map_order = f_num_in_map_order_s;
	f_uninformative    = f_uninformative_s;
	f_map_order        = f_map_order_s;
	
    apm_score = score;
	score_mask_rdc = score_mask_rdc_s;
    expscore = exp;
    expscore_2 = exp2;
    best_pvector = best_pv;
    uninf_mask = u_mask;
    flip_mask = f_mask;

    /*Initializations for struct that holds marker comm data--
      prevents "freeing" of unallocated arrays--G. Conant*/
    setup_prob_blocks(&right_prob_blocks);
    setup_prob_blocks(&left_prob_blocks);
    setup_prob_blocks(&indep_prob_blocks);
  
    
    /*Creates the BST for storing unique NPL scores*/
    initialize_ST(); 
  

    n = num_bits;
    rn = real_num_bits;
    N = pow2[rn];
    bigN = pow2[n];

	/* fill bitcount lookup table */
	for(i=0; i<64; i++) mod8[i] = i/8;
	for(i=0; i<(int)pow2[8]; i++) {
		lbtc8[i] = 0;
		for(j=0; j<8; j++) lbtc8[i] += ((i & (int)pow2[j]) ? 1:0);
	}
    /*r-full-alloc  allocate_lod_vars(real_num_bits); */
	
	maskTest = maskT;
	
	Allocate_MCh_vars(real_num_bits);

	/* Load_pvct(); */
	
    /*r-old-alloc  array(row_partner, N, int); for *reduce */
    /*r-full-alloc array(bit_count, N, int);
    /*r-full-alloc array(real_bit_count, N, int);
    /*r-old-alloc matrix(saved_partner, n, N, int); for speedy_reduce 
    for (j=0; j<n; j++) for (i=0; i<N; i++) saved_partner[j][i]=-1; */

	/* define bit count for each vector */
    /*r-full-alloc  removed computation for real_bit_count, bit_count */

    if (pednum==0) {
        old_num_w_pos = num_w_pos;

	
        setup_lodscores(); /* only call setup the first time */
		modify_setup_lodscores();
	/* Allocate the apm_stat array  - free first if necessary */
		
	if (previously_allocated_apm) free_apm_storage(old_num_w_pos);
	allocate_apm_storage();
	
	pedigrees_calculated=0;
	previously_allocated_apm=TRUE;
	array(total_recs, num_in_map_order, double);
	for (i=0; i<num_in_map_order; i++) total_recs[i]=0.0;
    }
    
    /**********
       compute the list of possible scores for 2 purposes:
       1) so we can compute Shannon's entropy for score function 
          in our likelihood function
       2) so we can keep a running probability distribution of
          the sum of raw scores for a p-value over all pedigrees 
    **********/
   
    array(score_list, SCORE_SIZE, double);
    array(score_count, SCORE_SIZE, int); 
#ifdef GC_TIME
    gct_pre_scoreassm=gct_RunTime();
#endif  

    num_scores=0; tempmax=0.0; tempmin=1.0;
    for (ii=mpi_interface.vec_offset; 
	 ii<=mpi_interface.vec_end; ii++) {
      score_npl_val = Get_apm_score_mpi(ii);
      if (score_npl_val > tempmax) tempmax = score_npl_val;
      if (score_npl_val < tempmin) tempmin = score_npl_val;
      /*G. Conant replaced with BST*/
      /*for (j=0; j<num_scores; j++)
	if (score_npl_val == score_list[j]) { score_count[j]++; break; }*/

      j=Retrieve_ST(score_npl_val);
      
      if (j == -1) {
	/* this one not in list */
	  score_list[num_scores] = score_npl_val;
	  Insert_ST(score_npl_val, num_scores);
	  score_count[num_scores] = 1;
	  num_scores++;
      }
      else
	score_count[j]++;
    }
   
    if (j>=SCORE_SIZE) {
      error("Overwrote score_list[], score_count[]");
      MPI_Abort(MPI_COMM_WORLD, 1);
    }

    mpi_interface.local_scores=(double*)malloc(sizeof(double)*num_scores);
    mpi_interface.local_score_count=(int*)malloc(sizeof(int)*num_scores);
    mpi_interface.pednum=pednum;
    
    if ((mpi_interface.local_scores == NULL) || (mpi_interface.local_score_count == NULL))
      {
	printf("Error on processor %d: Insufficient memory for local score_arrays\n", mpi_interface.rank);
	MPI_Abort(MPI_COMM_WORLD, 1);
      }

    for(i=0; i<num_scores; i++)
      {
	mpi_interface.local_scores[i]=score_list[i];
	mpi_interface.local_score_count[i]=score_count[i];
      }
    
    unarray(score_count, int);
    unarray(score_list, double);

    score_list=mpi_interface.local_scores;
    score_count=mpi_interface.local_score_count;

     array(lod, num_w_pos, double);
    


#ifdef GC_TIME
    gct_post_scoreassm=gct_RunTime();
    if (mpi_interface.rank == 0)
      printf("Proc %d runtime for doing proc score arrays: %d, num scores: %d\n", mpi_interface.rank,
	     gct_post_scoreassm-gct_pre_scoreassm, num_scores);
    gct_pre_scoreassm=gct_RunTime();
#endif
 
   
    /*	printf("num_scores = %d \n", num_scores);
     */
   
  
    prior_pscore[pednum]=0;
    pscore_list[pednum]=0;
    post_pscore[pednum]=0;
    
    post_pscore[pednum]=(double**)malloc(sizeof(double*)*num_w_pos);
    
    for (i=0; i<num_w_pos; i++)
      post_pscore[pednum][i]=(double*)malloc(sizeof(double)*num_scores);
    
    /*matrix(post_pscore[pednum], num_w_pos, num_scores, double);*/
    if(post_pscore[pednum]==0) {
      printf("Proc %d: Error: Insufficient memory for post_pscore array\n", mpi_interface.rank);
     MPI_Abort(MPI_COMM_WORLD, 1);
   }
      
#ifdef GC_TIME
      MPI_Barrier(MPI_COMM_WORLD);
      gct_post=gct_RunTime();
      if (mpi_interface.rank == 0)
      printf("Proc %d runtime between step 1 and call to calc_apm_scores: %d (Total time to this point: %d)\n", mpi_interface.rank,
	     gct_post-gct_pre, gct_post-gct_prerun);
#endif
    calc_apm_scores(pednum,score_list,num_scores, default_entropy,
		    originals,lod,post_pscore[pednum]);

   
 

   
    /*We do this assignment again because num_scores is passed by value to calc_apm_scores and should now be the
      number of *unique* scores on this processor  (See mpi_calculate_entropy).
      We also reassign the arrays, since they may have been malloced in the entropy calc.--G. Conant*/
    num_scores=mpi_interface.num_local_scores;

    if (num_scores > 0) {
      score_list=mpi_interface.local_scores;
      score_count=mpi_interface.local_score_count;
    }
    else {
      score_list=0;
      score_count=0;
    }
   
    /*G. Conant moved these allocs for more efficient memory use*/
    if (num_scores > 0) {
      prior_pscore[pednum]=(double*)malloc(sizeof(double)*num_scores);
      pscore_list[pednum]=(double*)malloc(sizeof(double)*num_scores);
      
      
      if((prior_pscore[pednum] == 0) || (pscore_list[pednum]==0)) {
	printf("Proc %d: Error: Insufficient memory for pscore arrays -Entropy and NPL p-values will be incorrect--continuing\n", mpi_interface.rank);
      }
    }
    else {
      prior_pscore[pednum]=0;
      pscore_list[pednum]=0;
    }

    null_variance[pednum] = expscore_2 - (expscore*expscore);

    for (i=0; i<num_w_pos; i++) {
        total_lod[i] += lod[i]; sub_lods[pednum][i] = lod[i];
    }
    unarray(lod, double);


    /***** debugging output
    sf(ps,"this max = %.4lf, this min = %.4lf, num different scores = %d\n",
       tempmax,tempmin,num_scores); pr();
    *****/

 
    for (i=0; i<num_scores; i++) {
      pscore_list[pednum][i]= score_list[i];
      prior_pscore[pednum][i]= (double) score_count[i] / (double) N;
      /***** debugging output OFF *****/
      /*****
      sf(ps,"score=%.4lf, prior=%.6lf, post=%.6lf\n",
	 score_list[i], prior_pscore[pednum][i], post_pscore[pednum][0][i]);
      pr();
      *****/
    }
    num_pscores[pednum]= num_scores;
        
    pedigrees_calculated++;

   
   /*G. Conant--removed in mpi struct
     unarray(score_count, int);
     unarray(score_list, double);*/

    /*r-old-alloc unmatrix(saved_partner, n, int); */
    /*r-old-alloc narray(row_partner,int); */
    /*r-full-alloc  unarray(bit_count,int); */
    /*r-full-alloc  unarray(real_bit_count,int); */

    
    Free_MCh_vars();

    /*r-full-alloc  free_lod_vars(real_num_bits); */
}

void allocate_apm_storage(void)
{
    int i;

    matrix (apm_stat, MAX_PEDIGREES, num_w_pos, double);
    matrix (raw_stat, MAX_PEDIGREES, num_w_pos, double);
    matrix (p_value, MAX_PEDIGREES, num_w_pos, double);
    matrix (apm_info, MAX_PEDIGREES, num_w_pos, double);
    matrix (apm_entropy, MAX_PEDIGREES, num_w_pos, double);
    matrix (pvec_entropy, MAX_PEDIGREES, num_w_pos, double);

    array(prior_pscore, MAX_PEDIGREES, double*);
    array(pscore_list, MAX_PEDIGREES, double*);
    post_pscore=(double***)malloc(sizeof(double**)*MAX_PEDIGREES);
    array(num_pscores, MAX_PEDIGREES, int);

    array(total_lod, num_w_pos, double);
    for (i=0; i<num_w_pos; i++) total_lod[i]=0.0;
    matrix (sub_lods, MAX_PEDIGREES, num_w_pos, double);

    array(null_variance, MAX_PEDIGREES, double);
}

void free_apm_storage(int old_num_w_pos)
{
    int i, j;
    /***** print("freeing memory\n"); *****/
    unmatrix (apm_stat, MAX_PEDIGREES, double);
    unmatrix (raw_stat, MAX_PEDIGREES, double);
    unmatrix (p_value, MAX_PEDIGREES, double);
    unmatrix (apm_info, MAX_PEDIGREES, double);
    unmatrix (apm_entropy, MAX_PEDIGREES, double);
    unmatrix (pvec_entropy, MAX_PEDIGREES, double);

    for (i=0; i<pedigrees_calculated; i++) {
      if (num_pscores[i]>0) {
	for(j=0; j<old_num_w_pos; j++)
	  free(post_pscore[i][j]);
	free(post_pscore[i]);
	
	unarray(pscore_list[i], double);
	unarray(prior_pscore[i], double);
      }
    }
    
    unarray(prior_pscore, double*);
    unarray(pscore_list,  double*);
    free(post_pscore);
    unarray(num_pscores, int);

    unarray(total_lod, double);
    unmatrix(sub_lods, MAX_PEDIGREES, double);

    unarray(null_variance, double);
}

void Allocate_MCh_vars(int num_bits)
{
	int  iMarker, ibit; 
    long amount_to_alloc;

    /*Alloc enough memory to hold each processor's piece of the vectors--G. Conant*/
    
      amount_to_alloc = (int)mpi_interface.marker_memory_offset[f_num_in_map_order];

    
      run {
	
	 array(lvct, amount_to_alloc, double);
	
	 array(rvct, amount_to_alloc, double);
	
      } except_when (NOMEMORY) {
	Free_MCh_vars();
	printf("Proc %d: Can't get enough memory for this scan (l/rvct)\n", mpi_interface.rank);
	flush();
	error("Can't get enough memory for this scan (l/rvct)\n");
	MPI_Abort(MPI_COMM_WORLD,1);
      }
}


void Free_MCh_vars(void)
{
	unarray(lvct, double);
	unarray(rvct, double);
}

void allocate_lod_vars(int num_bits)
{
    int i;
    long amount_to_alloc;

    amount_to_alloc=pow2[num_bits];

    run {

      matrix (lvector, num_in_map_order+2,  amount_to_alloc, double);
      matrix (rvector, num_in_map_order+2,  amount_to_alloc, double);
      /*r-old-alloc matrix (aux, amount_to_alloc, 30, double); for *reduce */
      array (tempvector, amount_to_alloc, double);
      /*r-old-alloc array (newp, amount_to_alloc, double); for speedy_reduce */
      /*r-old-alloc array (padded_vec, amount_to_alloc, int); for speedy_reduce */
      /*r-old-alloc for (i=0; i<amount_to_alloc; i++) padded_vec[i] = pad_inhvec(i); for speedy_reduce */

    } except_when (NOMEMORY) {

      print("Can't get enough memory for this scan\n");
      free_lod_vars(num_bits);
      
    }
}

void free_lod_vars(int num_bits) 
{
   int i;
    long amount_to_free;

    amount_to_free=pow2[num_bits];

    /*r-old-alloc unarray (padded_vec, int); for speedy_reduce */
    /*r-old-alloc unarray (newp, double); for speedy_reduce */
    unarray (tempvector, double);
    /* unmatrix(aux, amount_to_free, double);  for *reduce */
    unmatrix(rvector,num_in_map_order+2,double);
    unmatrix(lvector,num_in_map_order+2,double);
}

void setup_lodscores(void)
{
  int i, j, num_pos;
  double lod, total;
  double pos, start_position, end_position, this_dist;
  int interval;
  double increment;

  array(wpos, MAX_POSITIONS, double);
  array (map_position, num_markers+2, double);

  if (single_point_mode) {
      num_w_pos = num_markers;
      return;
  }

  /* Set up the map information needed */
  num_mapped_loci = f_num_in_map_order;
  total = 0.0;
  j=0;
  for (i=0; i<num_mapped_loci-1; i++) {
    map_position[i]=total;
    while(map_distance[j] == 0.) j++;
	this_dist = map_distance[j];
	j++;
    total += this_dist;
    theta[i] = dist_to_rec(this_dist);
/*	printf(" ilocus, theta, map_position, total %2d  %12.4e  %12.4e  %12.4e \n",
	i, theta[i], map_position[i], total);
*/	}
  map_position[i] = total;
  theta[i] = .5; /* for mapping disease locus at infinity */
  
  /* Currently only acceptable setting scan_steps = 1 
	if(scan_steps != 1) {
		scan_steps = 1;
		printf("******* Warning **********************************\n");
		printf("Currently only acceptable setting scan_steps = 1\n");
		printf("scan_steps set to default = 1 \n");
		printf("**************************************************\n");
	}
  */
  /* Tally the number of positions and save their position, so
     that we can correctly allocate the apm_stat array */
  num_pos=0;
  if (scan_steps > 0) {
    /* Calculate a set number of positions between each pair of markers */
    for (interval=0; interval<num_mapped_loci+1; interval++) {
      /* Deal with first and last intervals */
      if (interval==0) 
	start_position=(-1.0)*off_end_dist;
      else
	start_position=map_position[interval-1];
      if (interval==num_mapped_loci)
	end_position=map_position[num_mapped_loci-1]+off_end_dist;
      else
	end_position=map_position[interval];
      /* Calculate the increment size for the interval */
      increment = (end_position-start_position)/(double)scan_steps;
      /* so that the final step is taken and to prevent 
	 rounding problems in summations */
      if (interval==num_mapped_loci) 
	end_position+=increment/4.0;
      else
	end_position-=increment/4.0;
      /* if off_end==0 have to get the last point */
      if (interval==num_mapped_loci && increment==0.00) {
	end_position += 0.5;
	increment = 1.0;
      }
      /* Now we're ready to actually count and store the positions
	 for the interval */
      for (pos=start_position; pos<end_position; pos+=increment) {
	wpos[num_pos]=pos;
	num_pos++;
      }
    }
  } else {
    /* Move down the map at a set distance interval */
    start_position = (-1.0)*off_end_dist;
    end_position = map_position[num_mapped_loci-1]+off_end_dist;
    for (pos=start_position; pos<end_position; pos+=scan_increment) {
      wpos[num_pos] = pos;
      num_pos++;
    }
  }

  if (num_pos > MAX_POSITIONS) {
    sf(ps,"Number of positions to be calculated exceeds the max of %d\n",
       MAX_POSITIONS);
    error(ps);
  }
    
  num_w_pos = num_pos;
} 


void modify_setup_lodscores(void)
{
	int i, j;
	int pos_a, pos_b;

	pos_a = 0; 
	pos_b = num_w_pos;
	for(i=0; i<=(pos_b-pos_a); i++) {
		wpos[i] = wpos[i+pos_a];
	}
	num_w_pos = pos_b - pos_a;
	return;
}



void calc_apm_scores(int ped_num, double *score_list, int num_scores, 
		     double default_entropy, int originals, double *saved_lod,
		     double **p_score)
{
  /*G. Conant made count and count_r arrays*/
  int i, j, pos, left_i, *count, *count_r;
  long long int ii;
  /*G. Conant added last_locus_l and last_locus_r to do communication only when needed
   and nn_locus to find non-null locus*/
  int ilocus, locus_l, locus_r, nn_locus, locus_haplo, last_locus_l=-10, last_locus_r=-10;
  double varnull,extra_p_value, *entropy, this_prob;
  /*G. Conant replaced apmstat, like and lodlike with arrays indexed over markers
    and added apmstat_r, lodlike_r, and like_r as a receive buffer  and added maxlike, minlike, 
    statval, un_normalized_entropy, and varsum as arrays and maxlike_r, minlike_r, statval_r  
    un_normalized_entropy_r and varsum_r as receive buffers*/

  double thetal, thetar, pventropy, variance, apmstat, *like, *like_r, *lodlike, *lodlike_r, 
    this_lod, our_total, *statval, *statval_r, *varsum, *varsum_r, *maxlike, *maxlike_r, *minlike,
    *minlike_r, *un_normalized_entropy, *un_normalized_entropy_r;
  /*G. Conant added unlinked_s as an MPI send buffer*/
  double unlinked, unlinked_s, dum, observed_recs[MAXLOCI], real_map_sum, our_map_sum;
  int    haplo_viterbi;
  
  int     alloc_bit_cnt, k, bits_on, pnt;
  int     nvfs, nffs, im;
  long long int p_v_flip_mask[64], p_f_flip_mask[64], andmask;
  int     *bit_cnt;
  double  p, l_theta, obs_recs;
  double  score_npl_val;
  void Setup_flip_masks(long long int, int *, long long int *, int *, long long int *, PBvct_blocks *);

int count_total=0;

  /*G. Conant--allocations for score arrays*/
  array(entropy, num_w_pos, double);
  array(count, num_w_pos, int);
  array(count_r, num_w_pos, int);
  array(lodlike, num_w_pos, double);
  array(lodlike_r, num_w_pos, double);
  array(un_normalized_entropy, num_w_pos, double);
  array(un_normalized_entropy_r, num_w_pos, double);
  array(like, num_w_pos, double);
  array(like_r, num_w_pos, double);
  array(statval, num_w_pos, double);
  array(statval_r, num_w_pos, double);
  array(varsum, num_w_pos, double);
  array(varsum_r, num_w_pos, double);
  array(maxlike, num_w_pos, double);
  array(maxlike_r, num_w_pos, double);
  array(minlike, num_w_pos, double);
  array(minlike_r, num_w_pos, double);
/*  printf("----compute_sharing = %1d \n", compute_sharing);
*/

  if ((entropy == 0) || (count == 0) || (count_r == 0) || (lodlike == 0) || (lodlike_r == 0) ||
      (un_normalized_entropy == 0) || (un_normalized_entropy_r == 0) || (like == 0) || (like_r == 0) ||
      (statval == 0) || (statval_r == 0) || (varsum == 0) || (varsum_r == 0) || (maxlike == 0) || (maxlike_r == 0)
      || (minlike == 0) || (minlike_r == 0))
    {
      printf("Error on processor %d: not enough memory for send/receive buffers: calc_apm_scores\n", mpi_interface.rank);
      MPI_Abort(MPI_COMM_WORLD, 1);
    }
 

  if(compute_sharing) init_sharing_probs(N, n);
  if (!single_point_mode) {
    num_mapped_loci = f_num_in_map_order;

    /*	printf("compute l/r vectors \n");
     */
    /*compute left vectors*/
    /*r-full-alloc  unlinked = left(theta, num_mapped_loci); */
    /*compute right vectors*/
    /*r-full-alloc  dum = right(theta, num_mapped_loci-1); */


#ifdef GC_TIME
    gct_total_TSC=gct_total_fft=gct_total_TBAD=gct_total_onmarker=gct_totalgather=0;
    gct_pre=gct_RunTime();
#endif   
    unlinked=1.0;
    unlinked = Compute_lr_vectors();
    
#ifdef GC_TIME
    MPI_Barrier(MPI_COMM_WORLD);
    gct_post=gct_RunTime();
    if (mpi_interface.rank == 0) {
    printf("Compute_lr_vectors: Time spent in TSC: %d\n", gct_total_TSC);
    printf("Compute_lr_vectors: Time spent in TAM: %d\n", gct_total_TBAD);
    printf("Compute_lr_vectors: Time spent on communication: %d\n", gct_totalgather);
    printf("Compute_lr_vectors: Time spent strictly in fft: %d\n", gct_total_fft);
    printf("Runtime for proc %d for Compute_lr_vectors (Step 2): %d (Total: %d)\n",
	   mpi_interface.rank, gct_post-gct_pre, gct_post-gct_prerun);
    }
#endif   


    /*	printf("unlinked=%12.4e \n", unlinked);
     */
    /*	printf("search_vector \n");
	search_vector();    /* search p/l/rvector for unique values */
   	  

    
    if (display_scores) {
      if (analysis_type == NPL_ANALYSIS) 
	print("position  NPL score  p-value    information\n");
      else if (analysis_type == LOD_ANALYSIS) 
	print("position  LOD score    information\n");
      else /* BOTH */
	print("position  LOD score    NPL score  p-value    information\n");
    }

    /* prepare bitcount for fft */
    j = 0;
    for(i=0; i<num_mapped_loci; i++)
      if(!f_uninformative[i]) j++;
    /* if any one of the loci is uninformative we need bit_cnt[] */
    if(!show_expected_recs){
      
      array(bit_cnt, 1, int);
      alloc_bit_cnt = TRUE;
    } else {
      run {
	array(bit_cnt, (int)N, int);
	alloc_bit_cnt = TRUE;
      } except_when (NOMEMORY) {
	unarray(bit_cnt, int);
	alloc_bit_cnt = FALSE;
	error("Can't get enough memory to store bit_cnt\n");
	printf("Proc %d has insufficient memory for bit cnts\n", mpi_interface.rank);
	MPI_Abort(MPI_COMM_WORLD, 1);
      }
      /* make all flip masks "fully enclosed" */
     
      Setup_flip_masks(0, &nvfs, p_v_flip_mask,
		       &nffs, p_f_flip_mask, &left_prob_blocks);
      for(ii=0; ii<N; ii++) {
	bit_cnt[i] = 0;
	for(j=0; j<=mod8[rn]; j++) {
	  bit_cnt[i] += lbtc8[ (i >> (8*j)) & lbtc8mask ];
	}
	for(im=0; im<nvfs; im++) {
	  andmask = i & p_v_flip_mask[im];
	  bits_on = 0;
	  for(k=0; k<=mod8[rn]; k++) 
	    bits_on += lbtc8[ (andmask >> (8*k)) & lbtc8mask ];
	  bit_cnt[i] += bits_on & 1;
	}
      }
    }

    MPI_Barrier(MPI_COMM_WORLD);
#ifdef GC_TIME
    gct_total_TSC=gct_total_TBAD=gct_total_onmarker=gct_total_red=gct_totalgather=0;
    gct_total_fft=0;
    gct_pre=gct_RunTime();
   
#endif
    
   
    for (pos=0; pos<num_w_pos; pos++) {	
    
      /* find nearest informative marker left/right.  
	 Here locus_l/locus_r = -1 means that left/right vector is not used.*/
      /* left */

#if 1
      MPI_Barrier(MPI_COMM_WORLD);
      if (mpi_interface.rank == 0)
	printf("Proc 0 working on pos %d: runtime to this point: %d\n", pos, gct_RunTime());
#endif

      ilocus = 0;  locus_l = -1;  thetal = -1;
      while (ilocus < num_mapped_loci && map_position[ilocus] <= wpos[pos]) {
	if(!f_uninformative[ilocus]) locus_l = ilocus;
	ilocus++;
      }
      if(locus_l != -1) 
	thetal = dist_to_rec(wpos[pos]-map_position[locus_l]);
      if(locus_l == 0  && thetal == 0.) locus_l = -1;
      
      /* right */
      ilocus = num_mapped_loci-1;  locus_r = -1;  thetar = -1;
      while (ilocus >=0 && map_position[ilocus] >= wpos[pos]) {
	if(!f_uninformative[ilocus]) locus_r = ilocus;
	ilocus--;
      }
      if(locus_r != -1) 
	thetar = dist_to_rec(map_position[locus_r]-wpos[pos]);
      if(locus_r == num_mapped_loci-1  && thetar == 0.  &&  locus_l !=-1) locus_r = -1;
      

      /* find if at locus stated in marker data file.
	 If so we might need to find haplotype */
      locus_haplo = -1;
      for(ilocus=0; ilocus<num_mapped_loci; ilocus++)
	if(wpos[pos] == map_position[ilocus]) locus_haplo = ilocus;
      
      
      if(locus_l==-1  &&  locus_r==-1) {
	printf(" ******Error in calc_apm_scores() did not find any informative markers *******\n");
	exit (1);
      }
      
      
      /* p_score filled in in apm_likelihood with the probability of
	 each score in the score_list (of which there are num_scores) */

    
      like[pos] = likelihood(locus_haplo,locus_l,locus_r,
			     thetal,thetar,num_mapped_loci,
			     bit_cnt,
			     &statval[pos],&varsum[pos],score_list,num_scores,
			     p_score[pos], &un_normalized_entropy[pos],&lodlike[pos],pos, 
			     &maxlike[pos], &minlike[pos]);
#ifdef TEST_COMM
      MPI_Barrier(MPI_COMM_WORLD);
      if (mpi_interface.rank == 0)
	printf("Proc 0 done with loop for pos %d\n", pos);
#endif
    } /*G. Conant Split into calculation loop and printing loop to prevent reduces after
	each step*/

    /*Gather increment results for calculations*/
#ifdef GC_TIME
   
    gct_pre_collect=gct_RunTime();
#endif
  
#ifdef TEST_COMM
    MPI_Barrier(MPI_COMM_WORLD);
    if (mpi_interface.rank==0)
      printf ("Proc 0 done with position loop: about to enter reduces\n");
#endif
  
    MPI_Allreduce(lodlike, lodlike_r, num_w_pos, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(like, like_r, num_w_pos, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(statval, statval_r, num_w_pos, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
  
  
    /*G. Conant--This is ugly, but we need to be able to reduce count in a single step instead
     of at every marker.  This duplicates the calculation of apmstat, but that is not a serious
    computational burden*/

    for (pos=0; pos<num_w_pos; pos++) {
      /*Code moved from likelihood to allow a single reduction step--G. Conant*/
      if (like_r[pos] < 1e-280)
	apmstat=expscore; /* NPL = 0.0 */
      else 
	apmstat = statval_r[pos]/like_r[pos];
      count[pos]=count_r[pos]=0; 
      for (ii=mpi_interface.vec_offset; ii<=mpi_interface.vec_end; ii++) {
	score_npl_val = Get_apm_score_mpi(ii);
	if (apmstat < score_npl_val) count[pos]++;
	else if (real_eq(apmstat,score_npl_val)) count[pos]++;
      }
    }
  

    MPI_Allreduce(count, count_r, num_w_pos, MPI_INT, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(varsum, varsum_r, num_w_pos, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    MPI_Allreduce(maxlike, maxlike_r, num_w_pos, MPI_DOUBLE, MPI_MAX, MPI_COMM_WORLD);
    MPI_Allreduce(minlike, minlike_r, num_w_pos, MPI_DOUBLE, MPI_MIN, MPI_COMM_WORLD);
    MPI_Allreduce(un_normalized_entropy, un_normalized_entropy_r, num_w_pos, MPI_DOUBLE, 
		  MPI_SUM, MPI_COMM_WORLD);


  

    /*G. Conant moved the score reduction to this point for more efficient memory use*/
#ifdef GC_TIME 
    gct_pre_scoreassm=gct_RunTime();
#endif

#if 1
    MPI_Barrier(MPI_COMM_WORLD);
    if (mpi_interface.rank==0)
      printf ("Proc 0 about to reduce entropy\n");
#endif 

    default_entropy=mpi_calculate_entropy(num_scores, pow2, num_w_pos, post_pscore, like_r, entropy, N);

#if 1
    MPI_Barrier(MPI_COMM_WORLD);
    if (mpi_interface.rank==0)
      printf ("Proc 0 done with entropy\n");
#endif  

  num_scores=mpi_interface.num_local_scores;
   
   
    
#ifdef GC_TIME
  gct_post_collect=gct_RunTime();
  gct_pre_output=gct_post_collect;
#endif		
  
  for (pos=0; pos<num_w_pos; pos++) {
    /*Code moved from likelihood to allow a single reduction step--G. Conant*/
    
    if (like_r[pos] < 1e-280) {
      if (pos == 0) {
	print("WARNING: map likelihood=0.0 - this usually indicates that there is\n");
	print("an obligate recombinant between markers separated by 0.0 recombination\n");
	print("In cases where more than 50 markers are in use it is possible that\n");
	print("this error condition indicates that the map probability is smaller than\n");
	print("the smallest number supported by this architecture - try a subset of\n");
	print("the markers and see if the problem persists.\n");
      }
      apmstat=expscore; /* NPL = 0.0 */
      variance=0.0;
      /*for (j=0; j<num_scores; j++) p_score[pos][j]=0.0;*/
      
      } else {
	apmstat = statval_r[pos]/like_r[pos];
	variance = varsum_r[pos]/like_r[pos] - (apmstat*apmstat);
	pventropy = un_normalized_entropy_r[pos]/like_r[pos] + log(like_r[pos]);
	
	if(compute_sharing) norm_sharing_probs(pos, like_r[pos]); /*** new - FIX 6/99 ***/
      }
    

    
    if (lodlike_r[pos] <= 0.0) this_lod=-10000.0;
    else this_lod = log10(lodlike_r[pos]/unlinked);
    saved_lod[pos] = this_lod;
   
    
    
    p_value[ped_num][pos] = (double)count_r[pos] / (double)N;
    raw_stat[ped_num][pos] = apmstat;
      
      varnull = expscore_2 - (expscore*expscore);
      if (real_eq(varnull,0.0)) { 
	apm_stat[ped_num][pos]=0.0;
	apm_info[ped_num][pos]=0.0;
	  apm_entropy[ped_num][pos] = 0.0;
      } else {
	apm_stat[ped_num][pos] = (apmstat-expscore)/sqrt(varnull);
	apm_info[ped_num][pos] = 1.0 - variance/varnull;
	apm_entropy[ped_num][pos] = 1.0 - entropy[pos]/default_entropy;
      }
    
      /* pventropy -= (originals*log(2)); */
      /*pvec_entropy[ped_num][pos] = 1.0 - pventropy/((n-originals)*log(2));*/
      
      pvec_entropy[ped_num][pos] = 1.0 - pventropy/(rn*log(2));
      
      extra_p_value = 0.5 * (1.0 - erf(apm_stat[ped_num][pos]/sqrt(2)));
      
    
      if (mpi_interface.rank==0){
	if (display_scores) 
	  if (analysis_type == NPL_ANALYSIS) {
	    sf(ps,"%7.2lf  %9.6lf %9.6lf    %9.6lf\n",
	       wpos[pos], apm_stat[ped_num][pos],
	       p_value[ped_num][pos], pvec_entropy[ped_num][pos]);
	    pr_1proc();
	  } else if (analysis_type == LOD_ANALYSIS) {
	    sf(ps,"%7.2lf  %10.6lf    %9.6lf\n",
	       wpos[pos], saved_lod[pos], pvec_entropy[ped_num][pos]);
	    pr_1proc();
	  } else { /* BOTH */
	    sf(ps,"%7.2lf  %10.6lf    %9.6lf %9.6lf   %9.6lf\n",
	       wpos[pos], saved_lod[pos], apm_stat[ped_num][pos],
	       p_value[ped_num][pos], pvec_entropy[ped_num][pos]);
	    pr_1proc();
	  }
      }
  }
  
#ifdef GC_TIME
  gct_post_output=gct_RunTime();
  
  gct_post=gct_RunTime();
  printf("Proc %d Increment analysis: Time spent in TSC: %d\n",
	 mpi_interface.rank, gct_total_TSC);
  printf("Proc %d Increment analysis: Time spent in TBAD: %d\n",
	 mpi_interface.rank,gct_total_TBAD);
  printf("Proc %d Increment analysis: Time spent on marker analysis: %d\n", 
	 mpi_interface.rank,gct_total_onmarker);
  printf("Proc %d Increment analysis: Time spent collected scores: %d\n",
	 mpi_interface.rank, gct_post_collect-gct_pre_collect);
  printf("Proc %d Increment analysis: Time spent reporting results: %d\n",
	 mpi_interface.rank, gct_post_output-gct_pre_output);
  printf("Proc %d time spent strictly in parallel fft: %d\n", mpi_interface.rank,
	 gct_total_fft);
  printf("Proc %d Increment analysis: Time spend on comminucation: %d\n", mpi_interface.rank, gct_totalgather);
  printf("Runtime for proc %d for Step 3 excluding gathers: %d\n", mpi_interface.rank, gct_post-gct_pre-gct_totalgather);
  printf("Runtime for proc %d for Step 3 (analysis of increments): %d\n",
	 mpi_interface.rank, gct_post-gct_pre);
  
#endif
  
  
  if (display_scores) nl();
     
  if (show_expected_recs && num_mapped_loci > 1) {
    print("OBSERVED RECOMBINATION:\n");
    real_map_sum = our_map_sum = our_total = 0.0;
    /*    count_recs(num_mapped_loci,like,observed_recs); */
    count_recs_2(num_mapped_loci, like_r[pos], bit_cnt, observed_recs);
    print("interval   theta   observed \n");
    j=0;
    for (i=0; i<num_in_map_order-1; i++) {
      if(map_distance[i] != 0.) {
	obs_recs = observed_recs[j];
	l_theta  = theta[j];
	j++;
      } else {
	obs_recs = l_theta = 0.;
      }
      sf(ps,"%4d-%-4d %7.4lf  %7.4lf (%.4lf/%d)\n",map_order[i]+1,
	 map_order[i+1]+1,l_theta,obs_recs/n,obs_recs, n);
      pr();
      
      real_map_sum += rec_to_dist(l_theta);
      our_map_sum += rec_to_dist(obs_recs/(double)n);
      our_total += obs_recs;
      total_recs[i] += obs_recs;
    }
    sf(ps,"real map = %.2lf, observed map = %.2lf, total recs = %.2lf\n",real_map_sum,our_map_sum, our_total);
    pr();
  }
  haplo_viterbi = (haplo_method == 0);
  if (haplotype_output && haplo_viterbi) {
    printf("haplotype using viterbi\n");
    /* haplo_prob(num_mapped_loci); */
    compute_haplotype(num_mapped_loci);
  }
  
  if(alloc_bit_cnt) unarray(bit_cnt, int);
  alloc_bit_cnt = FALSE;
  
} else { /*** if SINGLE_POINT_MODE ***/

    if (analysis_type == NPL_ANALYSIS) 
      print("position   NPL score  p-value   information\n");    
    else if (analysis_type == LOD_ANALYSIS)
      print("position   LOD score    information\n");    
    else
      print("position   LOD score    NPL score   p-value   information\n");    

	if(analysis_type != NPL_ANALYSIS) {
	  /*G. Conant modified for distributed par_score*/
		unlinked=unlinked_s=0.0;
		for (i=0; i<mpi_interface.vecs_per_proc; i++) {
		  unlinked_s += par_score[i] / (double)N;
		}
		MPI_Allreduce(&unlinked_s, &unlinked, 1, MPI_INT, MPI_SUM, MPI_COMM_WORLD);
	} else {
		unlinked = 1.;
	}

	
    for (pos=0; pos<num_markers; pos++) {
      apmstat=0.0; variance=0.0; pventropy=0.0; lodlike[pos]=0.0;
      for (j=0; j<num_scores; j++) { p_score[pos][j]=0.0; }

      pnt = nz_pointer[pos];
	  for (ii=0; ii<N; ii++) {
	    if(!f_uninformative[pos]) {
	      if((ii & maskTest[pos][0]) != maskTest[pos][1]) {
		p = 0;
	      } else {
		p = pvct[pnt++];
	      }
	    } else {
	      p = 1 / (double)N;
	    }
	    if((compute_sharing) && (p != 0.)) 
		find_sharing_probs(pos, n, ii, p); /*** new - FIX 6/99 ***/	
	    
	    if(analysis_type != NPL_ANALYSIS) 
	      /*G. Conant modified for distributed par_score array*/
	      if (ii>=mpi_interface.vec_offset && ii<mpi_interface.vec_end)
		lodlike[pos] += p*par_score[i-mpi_interface.vec_offset];
	    score_npl_val = Get_apm_score(ii);
	    apmstat += p*score_npl_val;
	    variance += p*score_npl_val*score_npl_val;
	    for (j=0; j<num_scores; j++) {
	      if (score_npl_val==score_list[j]) {
		p_score[pos][j]+=p; break;
	      }
	    }
	    if (p > 0.0) 
	      pventropy += (-1.0)*p*log(p);
	  }
	  
	  //Collects lodlike on all processors--G. Conant*/
	  MPI_Allreduce(&lodlike[pos], &lodlike_r[pos], 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
	  variance -= (apmstat*apmstat);
	  
      if (lodlike[pos] <= 0.0) this_lod=-10000.0;
      else this_lod = log10(lodlike[pos]/unlinked);
      saved_lod[pos] = this_lod;

      entropy[pos]=0.0;
      for (i=0; i<num_scores; i++) {
        if (p_score[pos][i]==0.0) entropy[pos] += 0.0;
	else entropy[pos] += (-1.0)*p_score[pos][i]*log(p_score[pos][i]);
      }
    
      count[pos]=0; 
      for (i=0; i<N; i++) {
	score_npl_val = Get_apm_score(i);
	if (apmstat < score_npl_val) count[pos]++;
	else if (real_eq(apmstat,score_npl_val)) count[pos]++;
      }

      p_value[ped_num][pos] = (double)count[pos] / (double)N;
      
      raw_stat[ped_num][pos] = apmstat;

      varnull = expscore_2 - (expscore*expscore);
      if (real_eq(varnull,0.0)) { 
        apm_stat[ped_num][pos]=0.0;
	apm_info[ped_num][pos]=0.0;
	apm_entropy[ped_num][pos] = 0.0;
      } else {
        apm_stat[ped_num][pos] = (apmstat-expscore)/sqrt(varnull);
	apm_info[ped_num][pos] = 1.0 - variance/varnull;
	apm_entropy[ped_num][pos] = 1.0 - entropy[pos]/default_entropy;
      }
      /* pventropy -= (originals*log(2)); */
      pvec_entropy[ped_num][pos] = 1.0 - pventropy/(rn*log(2));

      /* extra_p_value = 0.5 * (1.0 - erf(apm_stat[ped_num][pos]/sqrt(2))); */

      if (analysis_type == NPL_ANALYSIS) {
	sf(ps,"%-9s %9.6lf %9.6lf   %9.6lf\n",
	   locus[pos].name, apm_stat[ped_num][pos],
	   p_value[ped_num][pos], pvec_entropy[ped_num][pos]);
	pr();
      } else if (analysis_type == LOD_ANALYSIS) {
	sf(ps,"%-9s %10.6lf    %9.6lf\n",
	   locus[pos].name, saved_lod[pos], pvec_entropy[ped_num][pos]);
	pr();
      } else {
	sf(ps,"%-9s %10.6lf    %9.6lf %9.6lf   %9.6lf\n",
	   locus[pos].name, saved_lod[pos], apm_stat[ped_num][pos],
	   p_value[ped_num][pos], pvec_entropy[ped_num][pos]);
	pr();
      }
    }
  }
/*G. Conant--allocations for score arrays*/
unarray(count, int);
unarray(count_r, int);
unarray(lodlike, double);
unarray(lodlike_r, double);
unarray(un_normalized_entropy, double);
unarray(un_normalized_entropy_r, double);
unarray(like,  double);
unarray(like_r, double);
unarray(statval, double);
unarray(statval_r, double);
unarray(varsum, double);
unarray(varsum_r, double);
unarray(maxlike,  double);
unarray(maxlike_r, double);
unarray(minlike, double);
unarray(minlike_r, double);
unarray(entropy, double);
}

/*===============================================================*/

void count_recs_2(int num_loci, double like, int *bit_cnt, double *observed_recs)
{
	int i, loc, lloc, rloc, no_info;
	double t[MAXLOCI],rectotal, l_theta;
	double *p_l, *p_r;
	void copy_vector(double *, int, double *);
	void convolve_fft_2(int, double, int *, double *);
	void convolve_count_fft_2(int, double, int *, double *);

	run { 
		array(p_l, N, double); 
		array(p_r, N, double); 
	} except_when (NOMEMORY) {
		unarray(p_r, double);
		unarray(p_l, double);
		error("Can't get enough memory to store p_l[], p_r[] in count_recs\n");
	}
	
	for (loc=0; loc < num_loci-1; loc++) {
	
		no_info = FALSE;
		
		/* Compute left vectoror in interval */
		if(!f_uninformative[loc]) {
			copy_vector(lvct, loc, p_l);
		} else {
			for(lloc=loc-1; lloc>=0; lloc--)
				if(!f_uninformative[lloc]) break;
			if(lloc>=0) {
				l_theta = dist_to_rec(map_position[loc] - map_position[lloc]);
				copy_vector(lvct, lloc, p_l);
				convolve_fft_2(rn, l_theta, bit_cnt, p_l);
			} else {
				no_info = TRUE;
			}
		}
		
		/* convolve_count left vectoror in interval */
		convolve_count_fft_2(rn, theta[loc], bit_cnt, p_l);
		
		/* Compute right vectoror in interval */
		if(!f_uninformative[loc+1]) {
			copy_vector(rvct, loc+1, p_r);
		} else {
			for(rloc=loc+1; rloc<num_loci; rloc++)
				if(!f_uninformative[rloc]) break;
			if(rloc<num_loci) {
				copy_vector(rvct, rloc, p_r);
				l_theta = dist_to_rec(map_position[rloc] - map_position[loc+1]);
				convolve_fft_2(rn, l_theta, bit_cnt, p_r);
			} else {
				no_info = TRUE;
			}
		}
		
		rectotal=0.0;
		if(no_info) {
			observed_recs[loc] = theta[loc] * n;
		} else {
			for(i=0; i<N; i++)
				rectotal += p_l[i] * p_r[i];
			observed_recs[loc] = rectotal/like;
		}
	}
	unarray(p_r, double);
	unarray(p_l, double);
}

void copy_vector(double *vct, int loc, double *pv)
{
	int i, pnt;

	pnt = nz_pointer[loc];
	for(i=0; i<N; i++) {
		if((i & maskTest[loc][0]) == maskTest[loc][1]) 
			{ pv[i] = vct[pnt++]; } else { pv[i] = 0; }
	}
}

void convolve_count_fft_2(int nbits, double theta, int *bit_cnt, double *pv)
{
	int i, Nstates;
	double trans[100], factor;
	void fft_2(int, double *);

	Nstates = pow2[nbits];
	trans[0] = 1.0;
	factor = 1.0 - 2.0*theta;
	for (i=1; i<100; ++i)
		trans[i] = trans[i-1]*factor;

	fft_2(nbits, pv);
	for(i=0; i<Nstates; i++)
    	pv[i] *= (theta*(n-bit_cnt[i])*trans[bit_cnt[i]] -
		theta*bit_cnt[i]*
		trans[((bit_cnt[i]-1)>=0) ? (bit_cnt[i]-1) : 0]);
	fft_2(nbits, pv);
	for(i=0; i<Nstates; i++)
		pv[i] /= Nstates;
}

/*===============================================================*/

void count_recs(int num_loci, double like, double *observed_recs)
{
    int i,j,k,loc;
    double t[MAXLOCI],rectotal;

    for (loc=0; loc < num_loci-1; loc++) {

        rectotal=0.0;

        for (i=0; i<N; ++i)
	  tempvector[i] = lvector[loc][i];

	convolve_count_fft(theta[loc], tempvector);

	for (i=0; i<N; ++i) rectotal += rvector[loc+1][i]*tempvector[i];

	observed_recs[loc] = rectotal/like;
    }
}

int **aux_index;

void compute_haplotype(int num_loci)
{
    int i, j, k, loc, **path_matrix, max_i, vec, height, temp, bit;
    double t[MAXLOCI], *p, max_p;
    FILE *fp;
    char *binary_output(int);
    int num_steps, best_mask, tmp_max_i, last_max_i, reverse_mask(int,int);
	int pnt;

    array(p, N, double);
    matrix (path_matrix, num_loci, N, int);
    matrix (aux_index, N, 30, int);
	matrix(aux, N, 30, double);
	array(row_partner, N, int);

/*    for (i=0; i<N; i++) p[i]=pvector[0][i];
*/
/*	printf(" Computing Viterbi, num_loci = %d\n", num_loci); */
	pnt = nz_pointer[0];
	for(i=0; i<N; i++) {
		if(f_uninformative[0]) {
			p[i] = 1 / (double)N;
		} else {
			if((i & maskTest[0][0]) != maskTest[0][1]) {
				p[i] = 0;
			} else {
				p[i] = pvct[pnt++];
			}
		}
	}

    for (loc=1; loc<num_loci; loc++) {
		makerec(theta[loc-1],t);
	
	for (i=0; i<N; i++) 
	  for (j=0; j<n+1; j++) {
	    aux[i][j] = p[i]*t[j];
	    aux_index[i][j] = -1;
	  }
	
	haplo_reduce(bigN,n+1);

	pnt = nz_pointer[loc];
	for (i=0; i<N; i++) {
/*	    p[i] = aux[i][0]*pvector[loc][i];
*/		
		if(f_uninformative[loc]) {
			p[i] = aux[i][0] * (1/(double)N);
		} else {
			if((i & maskTest[loc][0]) != maskTest[loc][1]) {
				p[i] = 0;
			} else {
				p[i] = aux[i][0] * pvct[pnt++];
			}
		}
	    /* path_matrix[loc][i] = aux_index[i][0]; */

	    height=1;  temp=aux_index[i][0];
	    vec=pad_inhvec(i);
	    for (j=0; j<n; j++) {
	      bit = temp%2;
	      temp >>= 1;
	      height *= 2;
	      if (bit) {
		  vec = height*(vec/height) + (height-1) - (vec%height);
		  /* vec = lookup_mask(vec); */
	      }
	    }
	    path_matrix[loc][i]=vec;
	}
    }

    /* get largest at end */
    /* fp = open_file("newvectors.out","w"); */
    /* sf(ps,"MAXIMUM LIKELIHOOD HAPLOTYPE:\n"); fpr(fp); */
    max_p=0.0; max_i=-1;
    for (i=0; i<N; i++) {
      if (p[i] > max_p) { max_p=p[i]; max_i=i; }
    }

    max_i = pad_inhvec(max_i); /* the critical missing link */

    /* sf(ps,"max p[%d] = %.10g\n",max_i,max_p); fpr(fp); */

    /* walk back from largest through maximal path */

    for (loc=num_loci-1; loc>=0; loc--) {
      best_pvector[loc] = max_i;
      last_max_i = max_i;
      tmp_max_i = lookup_mask(max_i);
      max_i = path_matrix[loc][tmp_max_i];
      max_i = reverse_mask(max_i, last_max_i);
    }

/*    sf(ps,"marker %d: %s\n",map_order[0]+1,binary_output(best_pvector[0])); 
      fpr(fp);  */

/**********
    for (loc=1; loc<num_loci; loc++) {
      num_steps = min_diff_bits(best_pvector[loc],best_pvector[loc-1],
				&best_mask);
      sf(ps,"marker %d: %s  (%d recs)\n", map_order[loc]+1,
	 binary_output(best_pvector[loc]), num_steps);
      fpr(fp);
      diff_bits(best_pvector[loc],best_pvector[loc-1]));
    }
**********/

/*     close_file(fp); */

    unarray(row_partner, int);
	unmatrix(aux, N, double);
    unmatrix(aux_index, N, int);
    unmatrix(path_matrix, num_loci, int);
    unarray(p, double);

}    

void haplo_prob(int num_loci)
{
    int i, j, num_recs, loc;
    double t[MAXLOCI], total_prob;
    char *binary_output(int);
    FILE *fp;

    fp = open_file("newvectors.out","w");
    
    sf(ps,"BEST p[i], MINIMUM RECS HAPLOTYPE:\n"); fpr(fp);
    sf(ps,"marker %d: %s\n",f_map_order[0]+1,binary_output(best_pvector[0])); 
    fpr(fp);

    total_prob=pvector[0][best_pvector[0]];

    for (loc=1; loc<num_loci; loc++) {
        makerec(theta[loc-1],t);
	num_recs = diff_bits(best_pvector[loc-1], best_pvector[loc]);
	total_prob *= t[num_recs];
	total_prob *= pvector[loc][best_pvector[loc]];
	sf(ps,"marker %d: %s  (%d recs)\n", f_map_order[loc]+1,
	 binary_output(best_pvector[loc]), num_recs);
	fpr(fp);
    }
    sf(ps,"total prob = %.10g\n",total_prob); fpr(fp);

    close_file(fp);
}



int running_bestrecs[MAXLOCI], running_secondrecs[MAXLOCI];
int secondbest_pvector[MAXLOCI];


/*G. Conant changed parameters variance, pvec_entropy, and apmstat to varsum, unnormalized_entropy
  and statval to allow a single reduction at the end of the code.  Also added maxlike and minlike as
  parameters*/
double likelihood(int locus_haplo, int locus_l, int locus_r, 
		  double thetal, double thetar, int loci, 
		  int     *bit_cnt,
		  double *statval, double *varsum, 
		  double *score_list, int num_scores, 
		  double *p_score, double *un_normalized_entropy, double *lodlike,
		  int pos_in_scan, double *maxlike, double *minlike)
{
  /*G. Conant added ii as mpi counter*/
  int i,ii, l, j, num_maxlike, best_new_choice, best_num_steps, num_steps, proc_on;
  long long int iii;
  double p, plod, totlike, *pass_lvct, *pass_rvct, *pass_pvct;
  int breakpoint, num1, num2;
  double t[MAXLOCI];
  /*G. Conant removed variable entropy to avoid confusion*/
  double like;
  
  static FILE *fp;
  static int like_fp_open=TRUE;
  static int choice;
  static int second_choice;
  static double first_prob, second_prob;
  char *binary_output(int);
  /*	int skip_this_haplo_code = TRUE, best_mask, m1, m2, best_i;
	km for checking alt. haplo code */
  int skip_this_haplo_code = FALSE, best_mask, m1, m2, best_i; 
  int ilocus;
  long long int pnt;
  double pvct_max, pvct_value;
  double score_npl_val;
  int    at_informative_marker;
  double *tmpdot;
  TRANSSTRUCT tsleft, tsright;
  TRDOTSTRUCT tdot;

 
	if (like_fp_open && !skip_this_haplo_code) {
	  fp=open_file("vectors.out","w"); like_fp_open=FALSE;
	}
	
	like = *lodlike = 0.0; *statval = 0.0; *varsum = 0.0;
	for (j=0; j<num_scores; j++) p_score[j]=0.0;
	*maxlike=0.0; 
	*minlike=1.0;
	*un_normalized_entropy = 0;
	at_informative_marker = (thetal == 0.0) || (thetar == 0.0);
	tmpdot = (double *) 0;
	
	if ( !at_informative_marker ) {
	  /* need transition away from informative marker */
	  /* compute prob. per inheritance vector and store in tmp1[] */
	  
	  /* for Haplotyping between markers, but slows things down */
	  if (haplotype_output && (locus_haplo != -1) && (haplo_method == 1)) {
	    run {
	      array(tmpdot, (int)N, double);
	    } except_when (NOMEMORY) {
	      unarray(tmpdot, double);
	      tmpdot = (double *) 0;
	      error("Can't get enough memory to compute haplotypes between markers\n");
	    }
	  }
	
	  /* off end, only one transition necessary */
		if((locus_l == -1) || (locus_r == -1)){

		  if (locus_r == -1) {
#ifdef GC_TIME
		    gct_pre_TSC=gct_RunTime(); 
		   
#endif		   
#ifdef TEST_COMM
		    MPI_Barrier(MPI_COMM_WORLD);
		    if (mpi_interface.rank == 0)
		      printf ("Proc 0 entering TSC: parallel: %d\n", mpi_interface.do_marker_in_parallel[locus_l]);
#endif
		    if (mpi_interface.do_marker_in_parallel[locus_l]==0)
		      TransSetupConvolve(thetal, locus_l, -1, &lvct[0], &tsleft, &left_prob_blocks);
		    else
		       TransSetupConvolve_Parallel(thetal, locus_l, -1, &lvct[0], &tsleft, &left_prob_blocks);
#ifdef GC_TIME
		    gct_post_TSC=gct_RunTime();
		    gct_total_TSC+=gct_post_TSC-gct_pre_TSC;
		    gct_pre_TBAD=gct_RunTime();
#endif		
#ifdef TEST_COMM
		    /*crash_mem();*/
		    if (mpi_interface.rank == 0)
		      printf ("Proc 0 entering TBAD\n");
#endif
		    TransBetweenAndDot(&tsleft, (TRANSSTRUCT *)NULL, score_list, 
				       num_scores, p_score, pos_in_scan,
				       &tdot, tmpdot, 0, 0);
#ifdef GC_TIME
		    gct_post_TBAD=gct_RunTime();
		    gct_total_TBAD+=gct_post_TBAD-gct_pre_TBAD;
#endif
		    TransFree(&tsleft, &left_prob_blocks);

	 
		  }

		  if (locus_l == -1) {
		   
#ifdef GC_TIME
		    gct_pre_TSC=gct_RunTime();
#endif
#ifdef TEST_COMM
		    MPI_Barrier(MPI_COMM_WORLD);
		    if (mpi_interface.rank == 0)
		      printf ("Proc 0 entering TSC: parallel: %d\n", mpi_interface.do_marker_in_parallel[locus_r]);
#endif
		     if (mpi_interface.do_marker_in_parallel[locus_r]==0)
		       TransSetupConvolve(thetar, locus_r, -1, &rvct[0], &tsright, &right_prob_blocks);
		     else
		       TransSetupConvolve_Parallel(thetar, locus_r, -1, &rvct[0], &tsright, &right_prob_blocks);
		       
#ifdef GC_TIME
		    gct_post_TSC=gct_RunTime();
		    gct_total_TSC+=gct_post_TSC-gct_pre_TSC;
		    gct_pre_TBAD=gct_RunTime();
#endif	
#ifdef TEST_COMM
		    /*crash_mem();*/
		    if (mpi_interface.rank == 0)
		      printf ("Proc 0 entering TBAD\n");
#endif
		    TransBetweenAndDot((TRANSSTRUCT *)NULL, &tsright, score_list, 
				       num_scores, p_score, pos_in_scan, &tdot, 
				       tmpdot, 0, 0);
#ifdef GC_TIME
		    gct_post_TBAD=gct_RunTime();
		    gct_total_TBAD+=gct_post_TBAD-gct_pre_TBAD;
#endif
			TransFree(&tsright, &right_prob_blocks);
		
		  }

		}  /* if not at informative marker and off one end */

		else {
		  
		 
#ifdef GC_TIME
		  gct_pre_TSC=gct_RunTime();
#endif
		 
#ifdef TEST_COMM
#ifdef CRASH_MEM
		  crash_mem();
#endif
		    MPI_Barrier(MPI_COMM_WORLD);
		    if (mpi_interface.rank == 0)
		      printf ("Proc 0 entering TSC (2): parallel: %d, parallel: %d \n", mpi_interface.do_marker_in_parallel[locus_l],
			mpi_interface.do_marker_in_parallel[locus_r]);
#endif
		  if (mpi_interface.do_marker_in_parallel[locus_l]==0)
		    TransSetupConvolve(thetal, locus_l, -1, &lvct[0], &tsleft, &left_prob_blocks);
		  else
		    TransSetupConvolve_Parallel(thetal, locus_l, -1, &lvct[0], &tsleft, &left_prob_blocks);

		 

#ifdef GC_TIME
		  gct_post_TSC=gct_RunTime();
		  gct_total_TSC+=gct_post_TSC-gct_pre_TSC;
		  gct_pre_TSC=gct_RunTime();
#endif
#ifdef TEST_COMM
#ifdef CRASH_MEM
		  crash_mem();
#endif
		    MPI_Barrier(MPI_COMM_WORLD);
		    if (mpi_interface.rank == 0)
		      printf ("Proc 0 entering second TSC: parallel: %d, parallel: %d \n", mpi_interface.do_marker_in_parallel[locus_l],
			mpi_interface.do_marker_in_parallel[locus_r]);
#endif	  
		  if (mpi_interface.do_marker_in_parallel[locus_r]==0) 
		    TransSetupConvolve(thetar, locus_r, -1, &rvct[0], &tsright, &right_prob_blocks);
		  else
		    TransSetupConvolve_Parallel(thetar, locus_r, -1, &rvct[0], &tsright, &right_prob_blocks);

		 

#ifdef GC_TIME
		  gct_post_TSC=gct_RunTime();
		  gct_total_TSC+=gct_post_TSC-gct_pre_TSC;
		  gct_pre_TBAD=gct_RunTime();
		 
#endif		
#ifdef TEST_COMM
#ifdef CRASH_MEM
		  crash_mem();
#endif
		  MPI_Barrier(MPI_COMM_WORLD);
		  if (mpi_interface.rank == 0)
		      printf ("Proc 0 entering TBAD\n");
#endif		 



		  TransBetweenAndDot(&tsleft, &tsright, score_list, num_scores,
				     p_score, pos_in_scan, &tdot, tmpdot, 0, 0);
		  
#ifdef TEST_COMM
#ifdef CRASH_MEM
		  crash_mem();
#endif
		  MPI_Barrier(MPI_COMM_WORLD);
		    if (mpi_interface.rank == 0)
		      printf ("Proc 0 done with TBAD\n");
#endif		 
#ifdef GC_TIME
		  
		  gct_post_TBAD=gct_RunTime();
		  gct_total_TBAD+=gct_post_TBAD-gct_pre_TBAD;
#endif
		 
		 
		  TransFree(&tsleft, &left_prob_blocks);
		  TransFree(&tsright, &right_prob_blocks);
#ifdef TEST_COMM
#ifdef CRASH_MEM
		  crash_mem();
#endif
	  MPI_Barrier(MPI_COMM_WORLD);
	    if (mpi_interface.rank ==0 )
	      printf("Proc 0 done with cleanup\n");
#endif

		} /* if NOT off one end and not informative marker */

		*maxlike=tdot.maxlike;
		*minlike=tdot.minlike;
		*lodlike=tdot.lodlike;
		like=tdot.like;
		*statval=tdot.statval;
		*varsum=tdot.varsum;
		*un_normalized_entropy=tdot.un_normalized_entropy;
		
  } /* if !informative marker */  


	else {

#ifdef GC_TIME
	  gct_pre_onmarker=gct_RunTime();
#endif
	  
	 
	  if(locus_l >= 0) { ilocus = locus_l; } else { ilocus = locus_r; }
	  /*MPI interface struct stores the starting location in lvct/rvct for
	    each marker--G. Conant*/	 
	 
	 
	  /*G. Conant modified for MPI and distributed
				par_score*/	 
	  if (mpi_interface.do_marker_in_parallel[ilocus]==1) {
	    pnt=0;

#ifdef ON_MARKER_DEBUG
	    MPI_Barrier(MPI_COMM_WORLD);
	    if (mpi_interface.rank == 0)
	      printf("Proc 0 about to reorg blocks for on-marker\n");
#endif
	    if ((locus_l != -1) && (locus_r != -1)){ 
#ifdef GC_TIME
	      gct_pregather=gct_RunTime();
#endif     

	      pass_lvct=(double*)malloc(sizeof(double)*(int)pow2[nz_bits[ilocus]-mpi_interface.log2procs]);
	      pass_rvct=(double*)malloc(sizeof(double)*(int)pow2[nz_bits[ilocus]-mpi_interface.log2procs]);
	      pass_pvct=(double*)malloc(sizeof(double)*(int)pow2[nz_bits[ilocus]-mpi_interface.log2procs]);
	      for(i=0; i<(int)pow2[nz_bits[ilocus]-mpi_interface.log2procs]; i++)
		{
		  pass_lvct[i]=lvct[mpi_interface.marker_memory_offset[ilocus]+i];
		  pass_rvct[i]=rvct[mpi_interface.marker_memory_offset[ilocus]+i];
		  pass_pvct[i]=pvct[mpi_interface.marker_memory_offset[ilocus]+i];
		}

	      mpi_redistribution_for_on_marker(nz_bits[ilocus], maskTest[ilocus][0], maskTest[ilocus][1], 
					       pass_rvct, &right_prob_blocks);
		
	      mpi_redistribution_for_on_marker(nz_bits[ilocus], maskTest[ilocus][0], maskTest[ilocus][1], 
					       pass_lvct, &left_prob_blocks);  
	      
	      mpi_redistribution_for_on_marker(nz_bits[ilocus], maskTest[ilocus][0], maskTest[ilocus][1], 
					       pass_pvct, &indep_prob_blocks);  
#ifdef GC_TIME
	      gct_postgather=gct_RunTime();
	      gct_totalgather+=gct_postgather-gct_pregather;
#endif	     
	    }
	    else if (locus_l == -1) 
	      {
#ifdef GC_TIME
		gct_pregather=gct_RunTime();
#endif    
		pass_rvct=(double*)malloc(sizeof(double)*(int)pow2[nz_bits[ilocus]-mpi_interface.log2procs]); 
		for(i=0; i<(int)pow2[nz_bits[ilocus]-mpi_interface.log2procs]; i++)
		  pass_rvct[i]=rvct[mpi_interface.marker_memory_offset[ilocus]+i];
		mpi_redistribution_for_on_marker(nz_bits[ilocus], maskTest[ilocus][0], maskTest[ilocus][1], 
					       pass_rvct, &right_prob_blocks);
#ifdef GC_TIME
		gct_postgather=gct_RunTime();
		gct_totalgather+=gct_postgather-gct_pregather;
#endif      
	      }
	    else if (locus_r == -1) { 
#ifdef GC_TIME
	      gct_pregather=gct_RunTime();
#endif
	      pass_lvct=(double*)malloc(sizeof(double)*(int)pow2[nz_bits[ilocus]-mpi_interface.log2procs]); 
	      for(i=0; i<(int)pow2[nz_bits[ilocus]-mpi_interface.log2procs]; i++)
		  pass_lvct[i]=lvct[mpi_interface.marker_memory_offset[ilocus]+i];
	      mpi_redistribution_for_on_marker(nz_bits[ilocus], maskTest[ilocus][0], maskTest[ilocus][1], 
					       pass_lvct, &left_prob_blocks); 	
#ifdef GC_TIME
	      gct_postgather=gct_RunTime();
	      gct_totalgather+=gct_postgather-gct_pregather;
#endif	     
	    }
	    
	    if (locus_r != -1)
	      proc_on=right_prob_blocks.proc_on_onmarker;
	    else
	      proc_on=left_prob_blocks.proc_on_onmarker;
	    
				       
	    iii=mpi_interface.vec_offset-1;
	    /*Modified by G. Conant for MPI*/
#ifdef ON_MARKER_DEBUG
	    MPI_Barrier(MPI_COMM_WORLD);
	    if (mpi_interface.rank == 0)
	      printf("Proc 0 about to start onmarker calc\n");
#endif  


	    if (proc_on != 0) {
	      for(ii=0; ii < mpi_interface.vecs_per_proc; ii++) {
		iii++;	 
		

		score_npl_val = Get_apm_score_mpi(iii);
		
		if((iii & maskTest[ilocus][0]) != maskTest[ilocus][1]) continue;
		
		/*G. Conant changed to pass_vcts for distribution of markers data*/
		
		if(locus_l == -1) {
		  p   =  right_prob_blocks.local_block[(int)(pnt)];
		  
		} else if(locus_r == -1) { 
		  p    = left_prob_blocks.local_block[(int)(pnt)];
		} else {
		  
		  if((indep_prob_blocks.local_block[(int)(pnt)] != 0.) &&
		     (right_prob_blocks.local_block[(int)(pnt)] != 0.)) {
		    p    = left_prob_blocks.local_block[(int)(pnt)] * 
		      (right_prob_blocks.local_block[(int)(pnt)]/
		       indep_prob_blocks.local_block[(int)(pnt)]);
		    
		  } else {
		    p    = 0.;
		  }
		}
		pnt++;
		
		if(analysis_type != NPL_ANALYSIS) { 
		  
		  plod = p * par_score[ii]; } 
		else                              { plod = p;                }
		if (p > *maxlike) *maxlike=p;
		if (p < *minlike && p > 0.0) *minlike = p;
		*lodlike += plod;
		like += p;
		*statval += (p*score_npl_val);
		*varsum  += (p*score_npl_val*score_npl_val);
		
		/*G. Conant replaced with BST
		  for (j=0; j<num_scores; j++) {
		  if (score_npl_val == score_list[j]) { p_score_s[j]+=p; break; }
		  } 
		  if (j==num_scores) 
		  error("can't find apm_score in list in entropy computation");*/
		
		p_score[Retrieve_ST(score_npl_val)]+=p;
		/* SUM(-(p[i]/like)*log(p[i]/like) = 
		   (1/like)*SUM(-p[i]*log(p[i])) + log(like)  */
		if(p > 0) *un_normalized_entropy += (-1.0) * p * log(p);
		
		if(compute_sharing) find_sharing_probs(pos_in_scan, n, iii, p); /*** new - FIX 6/99 ***/
		
	      }
	    }

	   
#ifdef ON_MARKER_DEBUG
	    MPI_Barrier(MPI_COMM_WORLD);
	    if (mpi_interface.rank ==0 )
	      printf("Proc 0 done with on-marker loop\n");
#ifdef CRASH_MEM
	    
	    crash_mem();
#endif
#endif
	    if ((locus_l != -1) && (locus_r != -1)){ 
	      cleanup_onmarker_PBvct_struct(&right_prob_blocks);
	      cleanup_onmarker_PBvct_struct(&left_prob_blocks);
	      cleanup_onmarker_PBvct_struct(&indep_prob_blocks);
	     }
	    else if (locus_l == -1){
	      cleanup_onmarker_PBvct_struct(&right_prob_blocks);
	     }
	    else if (locus_r == -1 ) {
	      cleanup_onmarker_PBvct_struct(&left_prob_blocks);
	      }
#ifdef ON_MARKER_DEBUG
	  MPI_Barrier(MPI_COMM_WORLD);
	    if (mpi_interface.rank ==0 )
	      printf("Proc 0 done with on-marker cleanup\n");
#endif
	  }

	  else {          /*This marker is serial--G. Conant*/
	   
	   
	    pnt=mpi_interface.marker_full_vec_start[ilocus]+(long long int)mpi_interface.marker_memory_offset[ilocus];

	    for(iii=mpi_interface.vec_offset; iii<=mpi_interface.vec_end; iii++) {
	     
	      score_npl_val = Get_apm_score_mpi(iii);
	      if((iii & maskTest[ilocus][0]) != maskTest[ilocus][1]) continue;
	      
	      if(locus_l == -1) {
		p    = rvct[(int)pnt];
	      } else if(locus_r == -1) {
		p    = lvct[(int)pnt];
	      } else {
		if((rvct[pnt] != 0.) && (pvct[(int)pnt] != 0.)) {
		  p    = lvct[(int)pnt] * (rvct[(int)pnt]/pvct[(int)pnt]);
		} else {
		  p    = 0.;
		}
	      }
	      pnt++;
	      
	      if(analysis_type != NPL_ANALYSIS) { plod = p * par_score[(int)(iii-mpi_interface.vec_offset)]; } 
	      else                              { plod = p;                }
	      if (p > *maxlike) *maxlike=p;
	      if (p < *minlike && p > 0.0) *minlike = p;
	      *lodlike += plod;
	      like += p;
	      *statval += (p*score_npl_val);
	      *varsum  += (p*score_npl_val*score_npl_val);
	      
	      /*G. Conant replaced with BST
	       for (j=0; j<num_scores; j++) {
	       if (score_npl_val == score_list[j]) { p_score[j]+=p; break; }
	       }
	       if (j==num_scores) 
	       error("can't find apm_score in list in entropy computation");
	     */
	      j=Retrieve_ST(score_npl_val);
	     
	      p_score[Retrieve_ST(score_npl_val)]+=p; 
	      
	      /* SUM(-(p[i]/like)*log(p[i]/like) = 
		 (1/like)*SUM(-p[i]*log(p[i])) + log(like)  */
	      if(p > 0) *un_normalized_entropy += (-1.0) * p * log(p);
	      
	      if(compute_sharing) find_sharing_probs(pos_in_scan, n, iii, p); /*** new - FIX 6/99 ***/
	    
	    }
	    

	  }
#ifdef GC_TIME
	  gct_post_onmarker=gct_RunTime();
#ifdef GC_FINE_TIME
			printf("On marker calculation: locus: %d bits %d: Time: %d\n", ilocus, nz_bits[ilocus], gct_post_onmarker-
			       gct_pre_onmarker);
#endif
			gct_total_onmarker+=gct_post_onmarker-gct_pre_onmarker;
#endif
			
	}


	
	/* output for haplotyping code */
	skip_this_haplo_code = (haplo_method != 1);
	if (haplotype_output && (locus_haplo != -1) && !skip_this_haplo_code) {
		if (locus_haplo == 0) {
/*			printf("haplotype using maximum probability path\n");
*/			sf(ps,"haplo_ratio = %.4lf\n",haplo_ratio); fpr(fp);
			first_prob = second_prob = 1.0;
		}
		best_new_choice=-1; best_num_steps=n+1;
		/* we're at a marker, do the haplotyping stuff */
		sf(ps,"at marker %d\n",f_map_order[locus_haplo]+1); fpr(fp);
		*maxlike /= like;
		num_maxlike=0;
		
		if(at_informative_marker) { pnt = nz_pointer[locus_haplo];
		} else                    { pvct_value = 1/pow2[rn]; }
		
		for(i=0; i<N; i++) {
			if(at_informative_marker) {
				if((i & maskTest[ilocus][0]) != maskTest[ilocus][1]) continue;
				if(locus_l == -1) {
					p    = rvct[pnt];
				} else if(locus_r == -1) {
					p    = lvct[pnt];
				} else {
					if(rvct[pnt] != 0.) {
						p    = lvct[pnt] * (rvct[pnt]/pvct[pnt]);
					} else {
						p = 0.;
					}
				}
				pvct_value = pvct[pnt];
				pnt++;
			} else {
			  if (tmpdot != (double *) 0)   /* for safety, should always be */
				 p=tmpdot[i];
			  else {
				 error("Internal error: Null tmp pointer in compute haplotype between markers\n");
				 p=0;
			  }
			}
			if (real_eq(p/like,*maxlike)) { 
				sf(ps,"p[%s] = %.15lf\n",binary_output(i),p/like); fpr(fp);
				num_maxlike++;
				if (locus_haplo > 0) {
					/* see if this is a good step */
					num_steps = min_diff_bits(pad_inhvec(i),choice,&best_mask);
					if (num_steps < best_num_steps) {
						best_new_choice = best_mask;
						best_num_steps  = num_steps;
						best_i          = i;
						pvct_max        = pvct_value;
					}
				} else {
					/* first locus, doesn't matter which one we take */
					if (best_new_choice == -1) {
						best_new_choice = pad_inhvec(i);
						best_i          = i;
						pvct_max        = pvct_value;
					}
				}
			}
		}
		choice = best_new_choice;
		totlike = (double)num_maxlike * *maxlike;
		sf(ps,"num_max_pvectors = %d, amounting to %.6lf of total prob\n",
		num_maxlike, totlike); fpr(fp);
		if (locus_haplo==0) { 
			sf(ps,"CHOICE = %s\n\n",binary_output(choice)); 
			running_bestrecs[locus_haplo]=0;
			first_prob = pvct_max;
		} else { 
			sf(ps,"CHOICE = %s  (implying %d recs)\n\n",
			binary_output(choice), best_num_steps); 
			running_bestrecs[locus_haplo] = running_bestrecs[locus_haplo-1]+best_num_steps;
			first_prob *= pvct_max;
			first_prob *= pow(theta[locus_haplo-1], (double) best_num_steps);
			first_prob *= pow(1.0-theta[locus_haplo-1], (double)(n-best_num_steps));
		}
		fpr(fp);
		best_pvector[locus_haplo] = choice; /* to be returned to pedprep */

		fflush(fp);
		/* if (index == loci) fclose(fp); */
	}
	
	if (tmpdot != (double *) 0){
	  unarray(tmpdot, double);
	  tmpdot = (double *) 0;  /* just in case */
	}

	/*Nnte that marker calculations of likelihood, variance, entropy, etc. are deferred until
	  end of loop to allow a single reduce, and the code to perform these operations has
	  moved to calc_apm_scores*/

	
return(like);
	
}



char *binary_output(int num)
{
    char *tempret;
    int i;

    tempret = get_temp_string();
    strcpy(tempret,"");
    for (i=n-1; i>=0; i--) {
      sf(ps,"%d",(num>>i)%2);
      strcat(tempret,ps);
    }
    return(tempret);
}

int diff_bits(int a, int b)
{
    int xor, i, ones;

    xor = a^b;
    /* now count the 1's */
    ones=0;
    for (i=n-1; i>=0; i--) {
      if (((xor>>i)%2) == 1) ones++;
    }
    return(ones);
}

int min_diff_bits(int newb, int old, int *new_vec)
{
    int xor, i, j, ones, newxor, newones;
    int best_recs, best_vec;

    xor = newb^old;
    /* now count the 1's */
    ones=0;
    for (i=n-1; i>=0; i--) {
      if (((xor>>i)%2) == 1) ones++;
    }
    if (ones < 2) { *new_vec=newb; return(ones); }
    
    /* else try each mask and see if it improves the recombination count */
    best_recs=ones; best_vec=newb;

    for (i=0; i<n; i++) {
      if (flip_mask[i] > 0) {
	newxor = xor^flip_mask[i];
	newones=0;
	for (j=n-1; j>=0; j--) { if (((newxor>>j)%2) == 1) newones++; }
	if (newones < ones) {
	  /* accept this flip */
	  best_vec = (best_vec^flip_mask[i]);
	}
      }
    }

    xor = old^best_vec;
    ones=0;
    for (i=n-1; i>=0; i--) {
      if (((xor>>i)%2) == 1) ones++;
    }

    *new_vec=best_vec;
    return(ones);
}

double left(double *theta, int loci)
{

	int i, l, j;
	double t[MAXLOCI];
	double like;
	for (i=0; i<N; ++i) lvector[0][i] = pvector[0][i];

	for (l=0; l<loci; ++l)
	{
		for (i=0; i<N; ++i)
		  tempvector[i] = lvector[l][i];

		convolve_fft(theta[l], tempvector);

		for (i=0; i<N; ++i) 
		  lvector[l+1][i]=pvector[l+1][i]*tempvector[i];
	}

	like = 0.;
	for (i=0; i<N; ++i) like += lvector[loci][i];
	return(like);
}

double right(double *theta, int loci)
{

	int i, l, j;
	double t[MAXLOCI];
	double like;
	for (i=0; i<N; ++i) rvector[loci][i] = pvector[loci][i];

	for (l=loci; l>0; --l)
	{
	    for (i=0; i<N; i++) 
	      tempvector[i]=rvector[l][i];
	    convolve_fft(theta[l-1], tempvector);
	    for (i=0; i<N; ++i) 
	      rvector[l-1][i]=tempvector[i]*pvector[l-1][i];
	}

	like = 0.;
	for (i=0; i<N; ++i) like += rvector[0][i];
	return(like);
}

/* compute the transition probabilities for 0,1,...,n recombinations */
void makerec(double theta, double *t)
{
	int i;
	double ctheta, rat;

	ctheta = 1.-theta;
	rat = theta/ctheta;
	t[0] = 1.;
	for (i=0; i<n; ++i) t[0]*=ctheta;
	for (i=1; i<n+1; ++i) t[i] = t[i-1]*rat;
}

/* recursively compute the vector-matrix product */
void reduce(int tc, int h, int w)
{
	int i, j, half;

	if (w>1) {
	half = h/2;
	for (i=0; i<half; ++i)
	for (j=0; j<w; ++j)
		aux[tc+i][j] += aux[tc+h-i-1][w-j-1];

	for (i=tc+half; i<tc+h; ++i)
	for (j=0; j<w-1; ++j)
		aux[i][j] = aux[i-half][j+1];

	reduce(tc,half,w-1);
	reduce(tc+half,half,w-1);
	} /* if */
} /* end reduce */

void convolve_fft(double theta, double *pv)
{
    int i,j;
    double trans[100], factor;

    trans[0] = 1.0;
    factor = 1.0 - 2.0*theta;
    for (j=1; j<=n; ++j)
      trans[j] = trans[j-1]*factor;

    fft(pv);

    for (i=0; i<N; i++) {

      /*****
      sf(ps,"%d\t%d\t%d\t%f\n",i,real_bit_count[i],bit_count[i],pv[i]);
      pr();
      *****/

      pv[i] *= trans[bit_count[i]];

      /* zero out all higher order components */
      /*
      if (real_bit_count[i] > 1)
        pv[i] = 0;
      */
    }

    fft(pv);  /* should I divide by N = 2^rn here to normalize? */

    for (i=0; i<N; i++)
      pv[i] /= N;
}


void convolve_count_fft(double theta, double *pv)
{
    int i,j;
    double trans[100], factor;

    trans[0] = 1.0;
    factor = 1.0 - 2.0*theta;
    for (j=1; j<=n; ++j)
      trans[j] = trans[j-1]*factor;

    fft(pv);

    for (i=0; i<N; i++) {

      /*****
      sf(ps,"%d\t%d\t%d\t%f\n",i,real_bit_count[i],bit_count[i],pv[i]);
      pr();
      *****/

      pv[i] *= (theta*(n-bit_count[i])*trans[bit_count[i]] -
		theta*bit_count[i]*
		trans[((bit_count[i]-1)>=0) ? (bit_count[i]-1) : 0]);

      /* zero out all higher order components */
      /*
      if (real_bit_count[i] > 1)
        pv[i] = 0;
      */
    }

    fft(pv);  /* should I divide by N = 2^rn here to normalize? */

    for (i=0; i<N; i++)
      pv[i] /= N;
}


void fft(double *pv)
{
    int i,j,ej,flipi;
    double temp;

    for (j=0; j<rn; j++) {

      ej = pow2[j];

      for (i=0; i<N; i++) {

        if ((i & ej) == 0) {

	  flipi = i ^ ej; /* should this by "+" instead of "^" ? */
	  temp = pv[i];
	  pv[i] = temp + pv[flipi];
	  pv[flipi] = temp - pv[flipi];

	}
      }
    }
}

void speedy_reduce(double theta, double *pv)
{
    int i,j,ej;
    int virtual_i, virtual_partner, partner;
    double ctheta, xtheta, thetan;

    ctheta=1.0-theta;

    for (j=0; j<n; j++) {

      for (i=0; i<N; i++) {

	if (saved_partner[j][i] >= 0) {
	  partner = saved_partner[j][i];
	  newp[i] = pv[i]*ctheta + pv[partner]*theta;
	} else {
	 
	  ej = pow2[j];
	  /* expand me to full size */
	  /* virtual_i = pad_inhvec(i); */
	  virtual_i = padded_vec[i];

	  /* find partner with bit j flipped */
	  virtual_partner = virtual_i ^ ej;
	  partner = lookup_mask(virtual_partner);

	  newp[i] = pv[i]*ctheta + pv[partner]*theta;
	  saved_partner[j][partner]=i;
	  saved_partner[j][i]=partner;
	}
      }

      for (i=0; i<N; i++) pv[i] = newp[i];
    }
}



void exciting_reduce(int height, int width)
{
    int i,j,half,row,col,partner,virtual_partner,virtual_row;
    int lookup_mask(int), pad_inhvec(int);

    if (width > 1) {
      /* row_partner is now globally allocated */
      for (row=0; row<N; row++) row_partner[row]=-1;

      for (row=0; row<N; row++) {
      
        if ((partner=row_partner[row]) >= 0 ) {
	  for (col=0; col<width; col++) 
	    aux[row][col] = aux[partner][width-col-1];
	  
	} else {
	  virtual_row = pad_inhvec(row);
	  virtual_partner=  height*(virtual_row/height) + 
	    (height-1) - virtual_row%height;
	  partner = lookup_mask(virtual_partner);
	  if (partner == row) {
	    /* partner with itself */
	    half = (width+1)/2;
	    for (col=0; col<half; col++) 
	      aux[row][col] += aux[row][width-col-1];
	    for (col=half; col<width; col++) 
	      aux[row][col] = aux[row][width-col-1];
	  } else {
	    /* partner with another row */
	    row_partner[partner]=row;
	    for (col=0; col<width; col++)
	      aux[row][col] += aux[partner][width-col-1];
	  }
	}
      }
      exciting_reduce(height/2, width-1);
    }
}

int lookup_mask(int vec)
{
    int andmask,newvec,count,i,fmask,realcount;

    andmask = vec&uninf_mask;
    
    for (i=0; i<n; i++) {
      if ((andmask&(pow2[i])) > 0) { 
	fmask = flip_mask[i];
	newvec = vec^fmask; 
	vec = newvec; 
      }
    }
    /* now we have the original vector flipped such that all uninformative
       positions now have 0's in them - now we must return the value of 
       this vector with those bits taken out entirely */
    newvec=0; realcount=0;
    for (i=0; i<n; i++) {
      if ((uninf_mask&pow2[i]) > 0) {
	/* bit to be ignored */
      } else {
	if ((vec&pow2[i]) > 0) {
	  newvec += pow2[realcount];
	}
	realcount++;
      }
    }
    return(newvec);
}



int reverse_mask(int vec1, int vec2)
{
    int andmask,newvec,count,i,fmask,realcount,newvec1;

    andmask = vec2&uninf_mask;
    
    for (i=0; i<n; i++) {
      if ((andmask&(pow2[i])) > 0) { 
	fmask = flip_mask[i];

	newvec = vec2^fmask; 
	vec2 = newvec;

	newvec1 = vec1^fmask;
	vec1 = newvec1;
      }
    }
    return(vec1);
}


int pad_inhvec(int vec)
{
    int i, newvec, count, realcount;

    newvec=0; realcount=0;
    for (i=0; i<n; i++) {
      if ((uninf_mask&pow2[i]) > 0) {
	/* bit inserted here */
      } else {
	if ((vec&pow2[realcount]) > 0) {
	  newvec += pow2[i];
	}
	realcount++;
      }
    }
    return(newvec);
}

void haplo_reduce(int height, int width)
{
    int i,j,half,row,col,partner,virtual_partner,virtual_row;
    int lookup_mask(int), pad_inhvec(int), vpp, pp, this_bit, tmpvec;

    if (width > 1) {
      for (row=0; row<N; row++) row_partner[row]=-1;

      for (row=0; row<N; row++) {
      
        if ((partner=row_partner[row]) >= 0 ) {

	  for (col=0; col<width; col++) {
	    aux[row][col] = aux[partner][width-col-1];
	    this_bit = aux_index[partner][width-col-1] % 2; 

	    if (this_bit) {
	      if (aux_index[row][col] >= 0) {
		tmpvec = aux_index[row][col];
		aux_index[row][col] = tmpvec << 1;
	      } else {
		aux_index[row][col] = 0;
	      }
	    } else {
	      if (aux_index[row][col] >= 0) {
		aux_index[row][col] = aux_index[partner][width-col-1];
		aux_index[row][col] += 1;
		/* tmpvec = aux_index[partner][width-col-1];
		   aux_index[row][col] = tmpvec << 1; already shifted */
	      } else {
		aux_index[row][col] = 1;
	      }
	    }
	    /* aux_index[row][col] = aux_index[partner][width-col-1];  */
	  }

	} else {
	  virtual_row = pad_inhvec(row);
	  virtual_partner=  height*(virtual_row/height) + 
	    (height-1) - virtual_row%height;
	  partner = lookup_mask(virtual_partner);
	  if (partner == row) {

	    /* partner with itself */
	    half = (width+1)/2;
	    for (col=0; col<half; col++) {
	      if (aux[row][col] < aux[row][width-col-1]) {
		aux[row][col] = aux[row][width-col-1];
		/* aux_index[row][col] = virtual_partner; */
		if (aux_index[row][width-col-1] >= 0) {
		  tmpvec = aux_index[row][width-col-1];
		  aux_index[row][col] = tmpvec << 1;
		  aux_index[row][col] += 1;
		} else {
		  aux_index[row][col]=1;
		}
	      } else {
		if (aux_index[row][col] >= 0) {
		  tmpvec = aux_index[row][col];
		  aux_index[row][col] = tmpvec << 1;
		} else {
		  aux_index[row][col] = 0;
		}
	      }
	    }

	    for (col=half; col<width; col++) {
	      aux[row][col] = aux[row][width-col-1];
	      this_bit = aux_index[row][width-col-1] % 2; 

	      if (this_bit) {
		if (aux_index[row][col] >= 0) {
		  tmpvec = aux_index[row][col];
		  aux_index[row][col] = tmpvec << 1;
		} else {
		  aux_index[row][col] = 0;
		}
	      } else {
		if (aux_index[row][col] >= 0) {
		  aux_index[row][col] = aux_index[row][width-col-1];
		  aux_index[row][col] += 1;
		} else {
		  aux_index[row][col] = 1;
		}
	      }
	    }

	  } else {
	    /* partner with another row */
	    row_partner[partner]=row;
	    pp = pad_inhvec(partner);
	    vpp = height*(pp/height) + (height-1) - pp%height;

	    for (col=0; col<width; col++)
	      if (aux[row][col] < aux[partner][width-col-1]) {
		aux[row][col] = aux[partner][width-col-1];
		if (aux_index[row][col] >= 0) {
		  tmpvec = aux_index[partner][width-col-1];
		  aux_index[row][col] = tmpvec << 1;
		  aux_index[row][col] += 1;
		} else {
		  aux_index[row][col] = 1;
		}
	      } else {
		aux[partner][width-col-1] = aux[row][col];
		if (aux_index[row][col] >= 0) {
		  tmpvec = aux_index[row][col];
		  aux_index[row][col] = tmpvec << 1;
		} else {
		  aux_index[row][col] = 0;
		}
	      }
	  }
	}
      }
      haplo_reduce(height/2, width-1);
    }
}

/* recursively compute the vector-matrix product */
void new_reduce(int tc, int h, int w)
{
	int i, j, half;

	if (w>1) {
	  half = h/2;
	  for (i=0; i<half; ++i)
	    for (j=0; j<w; ++j)

	      if (aux[tc+i][j] < aux[tc+h-i-1][w-j-1]) {
		aux[tc+i][j] = aux[tc+h-i-1][w-j-1];
		aux_index[tc+i][j] = aux_index[tc+h-i-1][w-j-1];
	      }

	  for (i=tc+half; i<tc+h; ++i)
	    for (j=0; j<w-1; ++j) {
	      aux[i][j] = aux[i-half][j+1];
	      aux_index[i][j] = aux_index[i-half][j+1];
	    }
	  new_reduce(tc,half,w-1);
	  new_reduce(tc+half,half,w-1);
	} /* if */
} /* end new_reduce */


/* Extras from HOMOZ */

double rec_to_dist(double rec_frac)
{
    /* returns value in cM */

    if (rec_frac > .4999) return(999.9); /* unlinked value */

    if (map_function == KOSAMBI) {
        return(25.0 * log ((1.0+(2.0*rec_frac)) / (1.0-(2.0*rec_frac))));
    } else if (map_function == HALDANE) {
        return(-50.0 * log (1.0-(2.0*rec_frac)));
    } else {
        error("map function undefined");
    }
}

double dist_to_rec(double distance)
{
    /* cM to recombination fraction */

    if (map_function == KOSAMBI) {
        return (0.5 * tanh(.02*distance));
    } else if (map_function == HALDANE) {
        return (0.5 * (1.0-exp(-.02*distance)));
    } else {
        error("map function undefined");
    }
}



/***** CONVOLUTION CODE *****/

double *temp_pval, *temp_pval_r;;
int saved_max;

void init_convolution(double max)
{
    /* set precision for entire set of convolutions */

    if (max > 100000.0) pval_precision=1;
    else if (max > 10000.0) pval_precision=10;
    else if (max > 1000.0) pval_precision=100;
    else if (max > 100.0) pval_precision=1000;
    else pval_precision=10000;

    saved_max= (int)(max*pval_precision)+10;
    array(temp_pval, saved_max, double);
    array(temp_pval_r, saved_max, double);
}



void convolve(double *pval_func, double *newpval, 
	      double *newscore, int num_scores)
{
    int i,j,this_score;
    

    /* convolve the two probability distributions */
    for (i=0; i<saved_max; i++) temp_pval[i]=temp_pval_r[i]=0.0;
  

    for (i=0; i<saved_max; i++) {
        if (pval_func[i] == 0.0) continue;
	for (j=0; j<num_scores; j++) {
	    /* add .5 to do proper rounding */
	    this_score = (int) ((newscore[j]*pval_precision)+.5) + i;
	    temp_pval[this_score] += pval_func[i]*newpval[j];
	}
    }

    MPI_Allreduce(temp_pval, temp_pval_r, saved_max, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
   

    for (i=0; i<saved_max; i++) {
      pval_func[i]=temp_pval_r[i];
    }
}

void free_convolution(void)
{
    unarray(temp_pval, double);
    unarray(temp_pval_r, double);
}

int search_vector(void)
{
#define real_eq_100(x,y) (fabs((x)-(y))<1e-100)
#define real_eq_50(x,y)  (fabs((x)-(y))<1e-50)
#define real_eq_10(x,y)  (fabs((x)-(y))<1e-10)
#define real_eq_06(x,y)  (fabs((x)-(y))<1e-06)
#define MAX_SAMPLE   1000  
#define SVECTOR     lvector
#define DETAIL_OUT    0
	int      ibit, ilocus, ibit_padded;
	int      i, j, iclass, ips[2], ipsa, address, found;
	int      lgc[10], sum;
	double   value[2][MAX_SAMPLE], value_all[MAX_SAMPLE], temp;
	char     *binary_output(int);

	printf("\n");
	for(ilocus=0; ilocus<num_mapped_loci; ilocus++){
		printf("ilocus=%d \t",ilocus);
/*		printf("\n",ilocus);
*/		
		/* distinct values */
		for(i=0; i<MAX_SAMPLE; i++) { value_all[i]=-1; }
		ipsa = -1;
		for(i=0; i<N; i++) {
			temp = SVECTOR[ilocus][i];
			if( ipsa < MAX_SAMPLE-1 ) {
				found=FALSE;
				for(j=0; j<=ipsa; j++){
					if( real_eq_100(temp,value_all[j]) ) { 
						found = TRUE;
						break; 
					}
				}
				if( !found ) { value_all[++ipsa]=temp; }
			}
		}
		printf("(%d)\t",ipsa);
		
		/* bit pattern */
		ibit_padded=n-1;
		for(ibit=rn-1; ibit>=0; ibit--) {
			address = pow2[ibit];
			for(iclass=0; iclass<=1; iclass++) {
				for(i=0; i<MAX_SAMPLE; i++) { value[iclass][i]=-1; }
			}
			ips[0] = ips[1] = -1;
			for(i=0; i<N; i++) {
				temp = SVECTOR[ilocus][i];
				/* distinct by class */
				if((address & i) == address) { iclass=1;
				} else {                       iclass=0; }
				if( ips[iclass] < MAX_SAMPLE-1 ) { 
					found=FALSE;
					for(j=0; j<=ips[iclass]; j++){
						if( real_eq_100(temp,value[iclass][j]) ) { 
							found = TRUE;
							break; 
						}
					}
					if( !found ) {
						ips[iclass]++;
						j = ips[iclass];
						value[iclass][j]=temp;
					}
				}
				if( (ips[0] == MAX_SAMPLE-1) && (ips[1] == MAX_SAMPLE-1) ) { break; } 
			}

			if(DETAIL_OUT) {
				if(ibit==0) printf("\n");
				printf("    ibit=%d",ibit); 
				printf("\t ips[0/1]=%d %d",ips[0], ips[1]);
				printf("\n");

				for(iclass=0; iclass<=1; iclass++){
					printf("             value[%d][i]=(%d total)",iclass,ips[iclass]);
					for(i=0; i<5; i++) printf(" %12.4e",value[iclass][i]);
					printf("\n");
				}
			} else {
				while((pow2[ibit_padded] & uninf_mask) != 0) {
					if((ibit_padded & 1) == 1) printf("  ");
					printf("_");
					ibit_padded--;
				}
				if((ibit_padded & 1) == 1) printf("  ");

				lgc[0] = ips[0]==0 && real_eq_100(value[0][0],0.0);
				lgc[1] = ips[1]==0 && real_eq_100(value[1][0],0.0);
				lgc[2] = ips[0]==0 && ips[1]==0 && real_eq_100(value[0][0],value[1][0]);
				sum = lgc[0] + lgc[1] + lgc[2];
				if( sum > 1 ) {
					printf("?");
				} else if( sum==1 ) {
/*old convention */
/*					if(lgc[0])  printf("0");  
					if(lgc[1])  printf("1");
					if(lgc[2])  printf("e");
*/
/*new convention */
					if(lgc[0])  printf("1");
					if(lgc[1])  printf("0");
					if(lgc[2])  printf("e");
				} else {
					printf("x");
				}
				ibit_padded--;
			}

		}  /* ------------ end ibit loop -----*/
		printf("\n");
	}/* ------------ end ilcus loop -----*/
	printf("\n n=%d rn=%d \n", n, rn);		
	printf("uninf_mask=%x (hex),  %s (bin)\n", uninf_mask, binary_output(uninf_mask));
}
				/* eventually replace block if with an assignment outside the loop */
/*				if(       vector_flag & pow2(0)) { temp = lvector[ilocus][i];
				} else if(vector_flag & pow2(1)) { temp = pvector[ilocus][i];
				} else if(vector_flag & pow2(2)) { temp = rvector[ilocus][i]; }
*/



/*G. Conant--never called?*/
void  Load_pvct(void){
	int  i, iMarker, ipvct; 
	ipvct=0;
	for(iMarker=0; iMarker<num_in_map_order; iMarker++) {
		for(i=0; i<N; i++) {
			if((i & maskTest[iMarker][0]) == maskTest[iMarker][1])
				pvct[ipvct++] = pvector[iMarker][i];
		}
		if(ipvct != nz_pointer[iMarker+1]) {
			printf(
			"*** Error *** iMarker=%3d  ipvct=%10d  nz_pointer[iMarker+1]=%10d\n",
			iMarker, ipvct, nz_pointer[iMarker+1]);
			exit (1);
		}
	}
}

double Compute_lr_vectors(void)
{
	int i, l, p_bitc, p_size, p_marker, n_marker, n_pntf, n_bitc;
	int found_first_informative;
	/*G. Conant added to find nearest inf. marker for transfer*/
	int next_inf, temp;
	/*G. Conant added sum_s as send buffer*/
	double sum_s, sum, unlinked, ltheta;
	TRANSSTRUCT ts;




	/* left vector ------------------------ */
	found_first_informative = FALSE;
	for(l=0; l<num_mapped_loci; l++) {
	 
	  if(f_uninformative[l]) continue;
	  
	  if(!found_first_informative) {
	    found_first_informative = TRUE;
	 
	      for(i=mpi_interface.marker_memory_offset[l]; 
		  i<mpi_interface.marker_memory_offset[l+1]; i++) 
		lvct[i] = pvct[i];
	   
	    
	      p_marker = l;
	      n_marker = l; /* just in case there is a single informative marker (compute unlinked) */
	      continue;
	  }
	  n_marker = l;
	  
	  ltheta = dist_to_rec(map_position[n_marker] - map_position[p_marker]);
#ifdef GC_TIME
	    gct_pre_TSC=gct_RunTime();
#endif
#if 0
	    if (mpi_interface.rank==0)
	      printf("Proc 0 doing marker %d\n", l);
#endif

	    if (mpi_interface.do_marker_in_parallel[p_marker]==0)
	      TransSetupConvolve(ltheta, p_marker, n_marker, &lvct[0], &ts, &left_prob_blocks);
	    else
	      TransSetupConvolve_Parallel(ltheta, p_marker, n_marker, &lvct[0], &ts, &left_prob_blocks);
#ifdef GC_TIME
	    gct_post_TSC=gct_RunTime();
	    gct_total_TSC+=gct_post_TSC-gct_pre_TSC;
	    gct_pre_TBAD=gct_RunTime();
#endif
	    if (mpi_interface.do_marker_in_parallel[p_marker] == 1 &&
		mpi_interface.do_marker_in_parallel[n_marker] == 0) {

#ifdef GC_TIME
	      gct_pregather=gct_RunTime();
#endif	
	      mpi_redistribute_step2_marker_nonparallel_target(nz_bits[p_marker], maskTest[p_marker][0], nz_bits[n_marker], rn, 
							       maskTest[n_marker][0], maskTest[n_marker][1], 
							       ts.nffs,  pow2, ts.tempvct,  &left_prob_blocks);
#ifdef GC_TIME
	      gct_postgather=gct_RunTime();
	      gct_totalgather+=gct_postgather-gct_pregather;
#endif
	      TransAndMap_ParallelNonParallel(&ts, &lvct[0], n_marker, &left_prob_blocks);
	      
	    }
	    else if (mpi_interface.do_marker_in_parallel[p_marker] == 1 &&
		     mpi_interface.do_marker_in_parallel[n_marker] == 1) {  

#ifdef GC_TIME
	      gct_pregather=gct_RunTime();
#endif	
	      mpi_redistribute_step2_marker_bothparallel(nz_bits[p_marker], maskTest[p_marker][0], nz_bits[n_marker], 
							 maskTest[n_marker][0], maskTest[n_marker][1], rn, ts.nffs, pow2,
							 ts.tempvct, &left_prob_blocks);
#ifdef GC_TIME
	      gct_postgather=gct_RunTime();
	      gct_totalgather+=gct_postgather-gct_pregather;
#endif
	     
	      TransAndMap_ParallelParallel(&ts, &lvct[0], n_marker, &left_prob_blocks);
#if 0
	      if (mpi_interface.rank == 0)
		printf("Proc %d leaving TAM:PP: %d\n", mpi_interface.rank, n_marker);
#endif	    
}
	    else {
	      TransAndMap(&ts, &lvct[0], n_marker);
#if 0
	      if (mpi_interface.rank == 0)
		printf("Proc %d leaving TAM:Serial: %d\n", mpi_interface.rank, n_marker);
#endif	    
	    }
#ifdef GC_TIME
	    gct_post_TBAD=gct_RunTime();
	    gct_total_TBAD+=gct_post_TBAD-gct_pre_TBAD;
#endif
	    TransFree(&ts, &left_prob_blocks);
	  
	    p_marker = n_marker;	  
	}
	

	sum=sum_s=0;


	  for(i=mpi_interface.marker_memory_offset[n_marker]; 
	      i<mpi_interface.marker_memory_offset[n_marker+1]; i++)
	      sum_s += lvct[i];
	  
	 
	  if (mpi_interface.do_marker_in_parallel[n_marker] == 1) 
	    MPI_Allreduce(&sum_s, &sum, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
	  else
	    sum=sum_s;

	for(i=0; i<rn; i++) sum *= 0.5;
	unlinked = sum;

	
	/* right vector ------------------------ */


	found_first_informative = FALSE;
 
	for(l=num_mapped_loci-1; l>=0; l--) {
	  if(f_uninformative[l]) continue;
	 
	  if(!found_first_informative) {
	    found_first_informative = TRUE;
	     
	    for(i=mpi_interface.marker_memory_offset[l]; 
		i<mpi_interface.marker_memory_offset[l+1]; i++) 
	      rvct[i] = pvct[i];
	   
	     
	    p_marker = l;
	    n_marker = l; /* just in case there is a single informative marker (compute unlinked) */
	    continue;
	  }
	  n_marker = l;
	  
	  ltheta = dist_to_rec(map_position[p_marker] - map_position[n_marker]);
	  
	
#ifdef GC_TIME
	  gct_pre_TSC=gct_RunTime();
#endif 
	  if (mpi_interface.do_marker_in_parallel[p_marker]==0)
	    TransSetupConvolve(ltheta, p_marker, n_marker, &rvct[0], &ts, &right_prob_blocks);
	  else
	    TransSetupConvolve_Parallel(ltheta, p_marker, n_marker, &rvct[0], &ts, &right_prob_blocks);
#ifdef GC_TIME
	  gct_post_TSC=gct_RunTime();
	  gct_total_TSC+=gct_post_TSC-gct_pre_TSC;
	  gct_pre_TBAD=gct_RunTime();
#endif
	  if (mpi_interface.do_marker_in_parallel[p_marker] == 1 &&
	      mpi_interface.do_marker_in_parallel[n_marker] == 0) { 


#ifdef GC_TIME
	    gct_pregather=gct_RunTime();
#endif	
	    mpi_redistribute_step2_marker_nonparallel_target(nz_bits[p_marker], maskTest[p_marker][0], nz_bits[n_marker], rn, 
							     maskTest[n_marker][0], maskTest[n_marker][1], 
							     ts.nffs,  pow2, ts.tempvct,  &right_prob_blocks);
#ifdef GC_TIME
	    gct_postgather=gct_RunTime();
	    gct_totalgather+=gct_postgather-gct_pregather;
#endif
	    TransAndMap_ParallelNonParallel(&ts, &rvct[0], n_marker, &right_prob_blocks);
	  }
	  else if (mpi_interface.do_marker_in_parallel[p_marker] == 1 &&
		   mpi_interface.do_marker_in_parallel[n_marker] == 1) {

#ifdef GC_TIME
	   gct_pregather=gct_RunTime();
#endif	
	   mpi_redistribute_step2_marker_bothparallel(nz_bits[p_marker], maskTest[p_marker][0], nz_bits[n_marker], 
						      maskTest[n_marker][0], maskTest[n_marker][1], rn, ts.nffs, pow2,
						      ts.tempvct, &right_prob_blocks);
#ifdef GC_TIME
	   gct_postgather=gct_RunTime();
	   gct_totalgather+=gct_postgather-gct_pregather;
#endif
	 
	   TransAndMap_ParallelParallel(&ts, &rvct[0], n_marker, &right_prob_blocks);

	  }
	  else 
	    TransAndMap(&ts, &rvct[0], n_marker);
#ifdef GC_TIME
	  gct_post_TBAD=gct_RunTime();
	  gct_total_TBAD+=gct_post_TBAD-gct_pre_TBAD;
#endif
	  TransFree(&ts, &right_prob_blocks);


	  p_marker = n_marker;
	
	}
	
	
	/* right vector ------------------------ */


	return(unlinked);
}

/* Katz, Tue Jun 20 12:28:08 2000, Break up Transition() into
 * TransSetup(), TransAndMap(), and TransFree() so that can also use
 * between markers.
 */

/* Katz, Thu Jun 22 14:24:16 2000
 *  For use with destination between markers, set n_marker to -1 
 *  If n_marker is -1, it means no restrictions on destination.
 */

void TransSetupConvolve(double theta, int p_marker, int n_marker, 
			double lr_vct[], TRANSSTRUCT *ts, PBvct_blocks *prob_blocks)
{
	int i, j, k, xor, im;
	long long int ii;
	int p_pntf, n_bitc;   
	long long int p_size, p_pntl;
	int nvfs, bits_on, nerrors;
	long long int n_legal;
	long long int andmask;
	double tmpl;
	int ioffset;
	long long int iarg3;
	

	ts->p_bitc = nz_bits[p_marker];
	
	
	p_size = pow2[ ts->p_bitc ];
	p_pntf = mpi_interface.marker_memory_offset[p_marker];
	p_pntl = p_pntf + p_size;
	
	if (n_marker >= 0){     /* Normal case, marker to marker transition */
	  n_bitc = nz_bits[n_marker];
	  ts->n_size = pow2[n_bitc];
	  ts->n_pntf = mpi_interface.marker_memory_offset[n_marker];
	  ts->n_pntl = ts->n_pntf + ts->n_size;
	}
	else {            /* Transition to between markers, these are not used */
	  ts->n_size = 0; /*  (n_marker = -1) */
	  ts->n_pntf = 0;
	  ts->n_pntl = 0;
	}

	ts->l_theta[0]  = ts->l_ctheta[0] = 1.;
	ts->l_theta[1]  = theta;  ts->l_ctheta[1] = 1. - ts->l_theta[1];
	for(i=2; i<=n; i++) {
		ts->l_theta[i]  = ts->l_theta[i-1]  * ts->l_theta[1];
		ts->l_ctheta[i] = ts->l_ctheta[i-1] * ts->l_ctheta[1];
	}

	run {
		array(ts->bit_cnt, (int)p_size,  int);
		array(ts->tempvct, (int)p_size, double);
		matrix(ts->maskShift, 128, 2, long long int);
	} except_when (NOMEMORY) {
		unmatrix(ts->maskShift, 128, long long int);
		unarray(ts->tempvct, double);
		unarray(ts->bit_cnt, int);
		error("Can't get enough memory for this scan (local vars)\n");
		printf("Proc %d: Error: not enough memory for TransSetupConvolve\n", mpi_interface.rank); 
		MPI_Abort(MPI_COMM_WORLD, 1);
	}

	


	Setup_flip_masks(maskTest[p_marker][0], &nvfs, ts->p_v_flip_mask,
		                                    &(ts->nffs), ts->p_f_flip_mask, prob_blocks);

	Setup_legal_vectors(ts->p_bitc, &(ts->p_mask_v_bits), p_marker, 
							  &(ts->p_legal), 
							  n_marker, &n_legal);
	
	       
	Setup_founder_sim_masks(ts);

	


	if (n_marker >= 0)
	  n_legal = n_legal << n_bitc;

	/* prepare bitcount for fft */
	for(ii=0; ii<p_size; ii++) {
		ts->bit_cnt[(int)ii] = 0;
		for(j=0; j<=mod8[ts->p_bitc]; j++) {
			ts->bit_cnt[(int)ii] += lbtc8[(int)((ii >> (8*j)) & lbtc8mask_l) ];
		}
		for(im=0; im<nvfs; im++) {
			andmask = ii & ts->p_v_flip_mask[im];
			bits_on = 0;
			for(k=0; k<=mod8[ts->p_bitc]; k++) 
				bits_on += lbtc8[(int)((andmask >> (8*k)) & lbtc8mask_l) ];
			ts->bit_cnt[(int)ii] += bits_on & 1;
		}
	}

	for(ii=0; ii<p_size; ii++) 
	  ts->tempvct[(int)ii] = lr_vct[mpi_interface.marker_memory_offset[p_marker]+(int)ii];




	convolve_fft_2(ts->p_bitc, theta, ts->bit_cnt, ts->tempvct);

/*	printf("l=%2d  p_bitc=%2d p_size=%10d  nvfs/nffs=%2d %2d\n", 
		    p_marker, p_bitc, p_size, nvfs, nffs);
*/

   if (n_marker >= 0)
	  iarg3 = maskTest[n_marker][0];
	else
	  iarg3 = 0;

   Setup_MaskShift(rn, maskTest[p_marker][0], iarg3, n_legal, ts);

}

/*G. Conant added parallel version*/
void TransSetupConvolve_Parallel(double theta, int p_marker, int n_marker, 
			double lr_vct[], TRANSSTRUCT *ts, PBvct_blocks *prob_blocks)
{
	int i, j, k, xor, im;
	long long int ii;
	int  n_bitc;
	long long int p_size, p_pntf, p_pntl;
	int nvfs, bits_on, nerrors;
	long long int n_legal, andmask;
	double tmpl, dummy_sum;
	int ioffset;
	long long int iarg3;


	/*Full size for marker, but each processor holds only 
	  marker_size/num_procs elements*/
	ts->p_bitc = nz_bits[p_marker];
      	

	p_size = pow2[ ts->p_bitc ];
	p_pntf = mpi_interface.marker_memory_offset[p_marker];
	p_pntl = p_pntf + p_size;
	
	if (n_marker >= 0){     /* Normal case, marker to marker transition */
	  /*Each processor holds only marker_size/num_procs elements*/
	  n_bitc = nz_bits[n_marker];
	  ts->n_size = pow2[n_bitc];
	  ts->n_pntf = mpi_interface.marker_memory_offset[n_marker];
	  ts->n_pntl = ts->n_pntf + ts->n_size;
	}
	else {            /* Transition to between markers, these are not used */
	  ts->n_size = 0; /*  (n_marker = -1) */
	  ts->n_pntf = 0;
	  ts->n_pntl = 0;
	}

	ts->l_theta[0]  = ts->l_ctheta[0] = 1.;
	ts->l_theta[1]  = theta;  ts->l_ctheta[1] = 1. - ts->l_theta[1];
	for(i=2; i<=n; i++) {
		ts->l_theta[i]  = ts->l_theta[i-1]  * ts->l_theta[1];
		ts->l_ctheta[i] = ts->l_ctheta[i-1] * ts->l_ctheta[1];
	}

	run {
	  /*Bit_cnt is only size of local vector piece*/
	  array(ts->bit_cnt, (int)pow2[ts->p_bitc-mpi_interface.log2procs], int);
	  array(ts->tempvct, (int)pow2[ts->p_bitc-mpi_interface.log2procs], double);
	  matrix(ts->maskShift, 128, 2, long long int);
	} except_when (NOMEMORY) {
		unmatrix(ts->maskShift, 128, long long int);
		unarray(ts->tempvct, double);
		unarray(ts->bit_cnt, int);
		error("Can't get enough memory for this scan (local vars)\n");
		printf("Proc %d: Error: not enough memory for TransSetupConvolve_Parallel\n", mpi_interface.rank);
		MPI_Abort(MPI_COMM_WORLD, 1);
	}
	if (ts->tempvct == 0)
	  {
	    printf("Proc %d: Error: not enough memory for TransSetupConvolve_Parallel\n", mpi_interface.rank);
		MPI_Abort(MPI_COMM_WORLD, 1);

	  }


	Setup_flip_masks(maskTest[p_marker][0], &nvfs, ts->p_v_flip_mask,
		                                    &(ts->nffs), ts->p_f_flip_mask, prob_blocks);

	Setup_legal_vectors(ts->p_bitc, &(ts->p_mask_v_bits), p_marker, 
							  &(ts->p_legal), 
							  n_marker, &n_legal);


	Setup_founder_sim_masks(ts);

	
	if (n_marker >= 0)
	  n_legal = n_legal << n_bitc;

	/* prepare bitcount for fft--Modified for parallel execution
	 bit_cnt is indexed by local size, ii scales up for full marker rep. */
	for(ii=mpi_interface.marker_vec_start[p_marker]; ii<=mpi_interface.marker_vec_end[p_marker]; ii++) {
		ts->bit_cnt[(int)(ii-mpi_interface.marker_vec_start[p_marker])] = 0;
		for(j=0; j<=mod8[ts->p_bitc]; j++) {
			ts->bit_cnt[(int)(ii-mpi_interface.marker_vec_start[p_marker])]
			  += lbtc8[(int)((ii >> (8*j)) & lbtc8mask_l) ];
		}
		for(im=0; im<nvfs; im++) {
			andmask = ii & ts->p_v_flip_mask[im];
			bits_on = 0;
			for(k=0; k<=mod8[ts->p_bitc]; k++) 
				bits_on += lbtc8[(int)((andmask >> (8*k)) & lbtc8mask_l) ];
			ts->bit_cnt[(int)(ii-mpi_interface.marker_vec_start[p_marker])] += bits_on & 1;
		}
	}



	for(i=0; i<(int)pow2[nz_bits[p_marker]-mpi_interface.log2procs]; i++)
	   ts->tempvct[i] = lr_vct[mpi_interface.marker_memory_offset[p_marker]+i];
	
#ifdef GC_TIME
	gct_pre_fft=gct_RunTime();
#endif
	
#ifdef TEST_COMM
#ifdef CRASH_MEM
		  crash_mem();
#endif
	MPI_Barrier(MPI_COMM_WORLD);
	if (mpi_interface.rank == 0)
	  printf("Proc 0 about to enter FFT\n");
#endif
	parallel_convolve_fft_2(ts->p_bitc, theta, ts->bit_cnt, ts->tempvct, 
				mpi_interface.rank, mpi_interface.num_procs);
	
#ifdef TEST_COMM
#ifdef CRASH_MEM
		  crash_mem();
#endif
	MPI_Barrier(MPI_COMM_WORLD);
	if (mpi_interface.rank == 0)
	  printf("Proc 0 about to enter Setup Mask shift\n");
#endif
	
#ifdef GC_TIME
	gct_post_fft=gct_RunTime();
	gct_total_fft+=gct_post_fft-gct_pre_fft;
#endif	
	
	if (n_marker >= 0)
	  iarg3 = maskTest[n_marker][0];
	else
	  iarg3 = 0;

	
	
	Setup_MaskShift(rn, maskTest[p_marker][0], iarg3, n_legal, ts);
	
#ifdef TEST_COMM
	MPI_Barrier(MPI_COMM_WORLD);
	if (mpi_interface.rank == 0)
	  printf("Proc 0 done with Setup Mask shift\n");
#endif

	if (n_marker == -1) {              /*In step 3*/
#ifdef GC_TIME
	  gct_pregather=gct_RunTime();
#endif	
	  /*This marker is parallel, so we store the original location of tempvct so that
	  we use it, but remember *not* delete it later--G. Conant*/
	  prob_blocks->local_block=ts->tempvct;
#ifdef COMM_DEBUG
#ifdef CRASH_MEM
		  crash_mem();
#endif	  
#endif
	  mpi_redistribute_marker(p_marker, nz_bits[p_marker], maskTest[p_marker][0], ts->p_mask_v_bits, rn, pow2, prob_blocks);	  
	  
#ifdef COMM_DEBUG  
#ifdef CRASH_MEM
		  crash_mem();
#endif
#endif
	  mpi_distrib_founder_sim_markers (ts->nffs, rn, maskTest[p_marker][0], ts->founder_sim_mask1, 
					    pow2, prob_blocks);

#ifdef COMM_DEBUG
#ifdef CRASH_MEM
		  crash_mem();
#endif
#endif
#ifdef GC_TIME
	  gct_postgather=gct_RunTime();
	  gct_totalgather+=gct_postgather-gct_pregather;
#endif
	}

	
	
	
/*	printf("l=%2d  p_bitc=%2d p_size=%10d  nvfs/nffs=%2d %2d\n", 
		    p_marker, p_bitc, p_size, nvfs, nffs);
*/
				
	

	

}


/*G. Conant added n_marker parameter*/
void TransAndMap(TRANSSTRUCT *ts, double lr_vct[], int n_marker)
{
  int flag_vec=0;
  int i,j,k;
  long long int ii;
  int ifs, r_size, n_ptr, hd_max, hd;
  long long int  p_address, p_varbl, p_fixed;
  int p_fix_bitc, im;
  long long int mask, mask1, mask2;
  double x0;

	hd_max     = rn - ts->p_bitc + ts->nffs;
	p_fix_bitc = rn - ts->p_bitc;
	r_size     = (int)pow2[ts->nffs];
	n_ptr      = ts->n_pntf;

	
	for(ii=0; ii < ts->n_size; ii++) {
	 
	  flag_vec=0;
	  if (mpi_interface.do_marker_in_parallel[n_marker]==0)
	    flag_vec=1;
	  else if ((ii>=mpi_interface.marker_vec_start[n_marker]) && (ii<=mpi_interface.marker_vec_end[n_marker]))
	    flag_vec=1;
	  if (flag_vec==1)
	    {
	      p_address = ts->p_address0;
	      for(j=0; j<ts->nMaskShift; j++) {
		if(ts->maskShift[j][1] >= 0) {
		  p_address |= (ii & ts->maskShift[j][0]) <<  (int)ts->maskShift[j][1];
		} else {
		  p_address |= (ii & ts->maskShift[j][0]) >> - (int)ts->maskShift[j][1];
		}
	      }
	      p_varbl = p_address & ts->p_mask_v_bits;
	      p_fixed = p_address >> ts->p_bitc;
	      
	      lr_vct[n_ptr] = 0;
		for(ifs=0; ifs<r_size; ifs++) {
		  x0    = ts->tempvct[(int)(p_varbl ^ ts->founder_sim_mask1[ifs])];
		  /* contr. vector fixed bits */
		  mask2 = ts->founder_sim_mask2[ifs] ^ p_fixed;        /* fixed bits distance to p_address */
		  hd=ts->hamming_dist[ifs];
		  for(j=0; j<=mod8[p_fix_bitc]; j++)
		    hd += lbtc8[(int)((mask2 >> (8*j)) & lbtc8mask_l)];
		  lr_vct[n_ptr] += x0 * ts->l_theta[hd] * ts->l_ctheta[hd_max - hd];
		}
	    
		n_ptr++;
		
	    }	
	}
	
	
	for(i=mpi_interface.marker_memory_offset[n_marker]; 
	    i<mpi_interface.marker_memory_offset[n_marker+1]; i++) { lr_vct[i] *= pvct[i];}
	

	
}


void TransAndMap_ParallelNonParallel(TRANSSTRUCT *ts, double lr_vct[], int n_marker, PBvct_blocks *prob_blocks)
{
  int i,j,k;
  long long int ii;
  int ifs, r_size, hd_max, hd;
  long long int p_address, p_varbl, new_p_varbl, p_fixed, n_ptr;
  int im;
  long long int p_fix_bitc, mask, mask1, mask2;
  double x0;

	hd_max     = rn - ts->p_bitc + ts->nffs;
	p_fix_bitc = rn - ts->p_bitc;
	r_size     = (int)pow2[ts->nffs];
	n_ptr      = ts->n_pntf;

	
	for(ii=0; ii < ts->n_size; ii++) {
	 
	      p_address = ts->p_address0;
	      for(j=0; j<ts->nMaskShift; j++) {
		if(ts->maskShift[j][1] >= 0) {
		  p_address |= (ii & ts->maskShift[j][0]) <<  (int)ts->maskShift[j][1];
		} else {
		  p_address |= (ii & ts->maskShift[j][0]) >> - (int)ts->maskShift[j][1];
		}
	      }
	    
	      p_fixed = p_address >> ts->p_bitc;
	      
	      new_p_varbl = 0;
	      for(j=0; j<rn; j++) {
		if (prob_blocks->maskshift[j][0] != 0)
		  new_p_varbl |= (ii & prob_blocks->maskshift[j][0]) >>(int)prob_blocks->maskshift[j][1];
	      }
	      
	      lr_vct[(int)n_ptr] = 0;
		for(ifs=0; ifs<r_size; ifs++) {
		  x0    = prob_blocks->needed_blocks[prob_blocks->founder_sim_blocks[ifs]][(int)(new_p_varbl ^ prob_blocks->new_founder_sim_mask1[ifs])];
		
		   /* contr. vector fixed bits */
		   mask2 = ts->founder_sim_mask2[ifs] ^ p_fixed;        /* fixed bits distance to p_address */
		   hd=ts->hamming_dist[ifs];
		   for(j=0; j<=mod8[p_fix_bitc]; j++)
		     hd += lbtc8[(int)( (mask2 >> (8*j)) & lbtc8mask_l) ];
		   lr_vct[(int)n_ptr] += x0 * ts->l_theta[hd] * ts->l_ctheta[hd_max - hd];
		}
		
		n_ptr++;
		
	    	
	}
	
	
	for(i=mpi_interface.marker_memory_offset[n_marker]; 
	    i<mpi_interface.marker_memory_offset[n_marker+1]; i++) { lr_vct[i] *= pvct[i];}
	

	
}



void TransAndMap_ParallelParallel(TRANSSTRUCT *ts, double lr_vct[], int n_marker, PBvct_blocks *prob_blocks)
{
  int i, j,k;
  long long int ii;
  int ifs, r_size, hd_max, hd;
  long long int  p_address, p_varbl, new_p_varbl, p_fixed, n_ptr;
  int im;
  long long int p_fix_bitc, mask, mask1, mask2;
  double x0;

	hd_max     = rn - ts->p_bitc + ts->nffs;
	p_fix_bitc = rn - ts->p_bitc;
	r_size     = (int)pow2[ts->nffs];
	n_ptr      = ts->n_pntf;
	
	ts->n_size=pow2[mpi_interface.marker_bits[n_marker]];

	ii=mpi_interface.marker_vec_start[n_marker]-1;
	
	for(i=0; i < (int)ts->n_size; i++) {
	  ii++;
	  p_address = ts->p_address0;
	  for(j=0; j<ts->nMaskShift; j++) {
	    if(ts->maskShift[j][1] >= 0) {
	      p_address |= (ii & ts->maskShift[j][0]) <<  (int)ts->maskShift[j][1];
	    } else {
	      p_address |= (ii & ts->maskShift[j][0]) >> - (int)ts->maskShift[j][1];
	    }
	  }
	
	  p_fixed = p_address >> ts->p_bitc;
	  
	
	  new_p_varbl = 0;
	  for(j=0; j<rn; j++) {
	    if (prob_blocks->maskshift[j][0] != 0)
	      new_p_varbl |= (ii & prob_blocks->maskshift[j][0]) >>(int)prob_blocks->maskshift[j][1];
	  }

	 
	  lr_vct[(int)n_ptr] = 0;
	  for(ifs=0; ifs<r_size; ifs++) {
	   
	    x0    = prob_blocks->needed_blocks[prob_blocks->founder_sim_blocks[ifs]][
		  (int)(new_p_varbl ^ prob_blocks->new_founder_sim_mask1[ifs])];
	    
	      /* contr. vector fixed bits */
	      mask2 = ts->founder_sim_mask2[ifs] ^ p_fixed;        /* fixed bits distance to p_address */
	      hd=ts->hamming_dist[ifs];
	      for(j=0; j<=mod8[p_fix_bitc]; j++)
		hd += lbtc8[(int)( (mask2 >> (8*j)) & lbtc8mask_l)];
	      lr_vct[n_ptr] += x0 * ts->l_theta[hd] * ts->l_ctheta[hd_max - hd];
	  }
	    
	    n_ptr++;
	    
	   
	}
	  
	  for(i=mpi_interface.marker_memory_offset[n_marker]; 
	      i<mpi_interface.marker_memory_offset[n_marker+1]; i++) { lr_vct[i] *= pvct[i];}
	

	
}

/* Katz, Thu Jun 22 14:21:37 2000, Used reduced FFT for between markers 
 *  This routine takes two TRANSSTRUCT's set up above for the transition
 *  from left and right to a position between markers and calculates
 *  the dot product between them, Lod Scores, etc.  Uses only the 
 *  (two) reduced space vectors.
 *
 *  (if either of these struct ptrs are NULL, it means we are off
 *   the end and should only calculate the other transition)
 *
 */



void TransBetweenAndDot(TRANSSTRUCT *tsleft, TRANSSTRUCT *tsright, 
								double *score_list, int num_scores, double *p_score, 
								int pos_in_scan, TRDOTSTRUCT *tdot, double *tmpdot,
								double *tmp3, double *tmp4)

/* Note: for debugging, if tmp3, tmp4 non-zero, returns the full dim
 * representation of left and right transitions in them.  In normal use
 * tmp3 and tmp4 should be 0 
 *
 * If tmpdot non-zero, return the dot product of what would be in 
 * tmp3 and tmp4 in it.  This is used for haplotyping between markers.
 *    
 */



{
  /*G. Conant changed temp internals to long double to test underflow probs*/
  int im;
  long long int  mask, mask1, mask2;
  double  myx0;
  /*froml_vct, fromr_vct;*/
  /*G. Conant added ii as dummy counting variable*/
  int i,j;
  long long int ii;
  int ifs, hd;

 
  int r_size_left;
  int hd_max_left, p_fix_bitc_left;
  int r_size_right;
  int hd_max_right, p_fix_bitc_right;
  long long int p_addr_left, p_varbl_left, p_fixed_left, p_addr_right,
    p_varbl_right, p_fixed_right;


  double score_npl_val;
  /*double p, plod;*/
  double p, plod, fromr_vct, froml_vct;


  if (tsleft != NULL) {
	 hd_max_left         = rn - tsleft->p_bitc + tsleft->nffs;
	 p_fix_bitc_left = rn - tsleft->p_bitc;
	 r_size_left         = (int)pow2[tsleft->nffs];
  }

  if (tsright != NULL) {
	 hd_max_right         = rn - tsright->p_bitc + tsright->nffs;
	 p_fix_bitc_right = rn - tsright->p_bitc;
	 r_size_right         = (int)pow2[tsright->nffs];
  }

  /*G. Conant added initializations for MPI*/
  tdot->like = tdot->lodlike = 0.0; 
  tdot->statval = 0.0; tdot->varsum = 0.0;
  for (j=0; j<num_scores; j++) 
    p_score[j]=0.0;

  tdot->maxlike=0.0;
  tdot->minlike=1.0;
  tdot->un_normalized_entropy = 0;

  ii=mpi_interface.vec_offset-1;


 
  /*Modified by G. Conant for MPI*/
  for(i=0; i < mpi_interface.vecs_per_proc; i++) {
    ii++;
	 if (tsleft != NULL) {
		p_addr_left = tsleft->p_address0;
		for(j=0; j<tsleft->nMaskShift; j++) {
		  if(tsleft->maskShift[j][1] >= 0) {
			 p_addr_left |= (ii & tsleft->maskShift[j][0]) 
				<<  (int)tsleft->maskShift[j][1];
		  } else {
			 p_addr_left |= (ii & tsleft->maskShift[j][0]) 
				>> - (int)tsleft->maskShift[j][1];
		  }
		}
		p_varbl_left = p_addr_left & tsleft->p_mask_v_bits;
		p_fixed_left = p_addr_left >> tsleft->p_bitc;
	 
		froml_vct = 0.0;

		for(ifs=0; ifs<r_size_left; ifs++) { 
		  if ( left_prob_blocks.local_block != 0)
		    myx0    = left_prob_blocks.needed_blocks[left_prob_blocks.founder_sim_blocks[ifs]]
		      [(int)((p_varbl_left & left_prob_blocks.new_p_mask_v_bits) ^  left_prob_blocks.new_founder_sim_mask1[ifs])];
		  else
		    myx0    = tsleft->tempvct[(int)(p_varbl_left ^ 
					     tsleft->founder_sim_mask1[ifs])];


		  mask2 = tsleft->founder_sim_mask2[ifs] ^ p_fixed_left;    /* fixed bits distance to p_address */
		  hd=tsleft->hamming_dist[ifs];
		  for(j=0; j<=mod8[p_fix_bitc_left]; j++)
		       hd += lbtc8[(int)( (mask2 >> (8*j)) & lbtc8mask_l) ];
		  froml_vct += 
			 (long double)myx0 * (long double)tsleft->l_theta[hd] * (long double)tsleft->l_ctheta[hd_max_left - hd];
		}
	 }   /* if tsleft not NULL */ 

	 if (tsright != NULL) {
		p_addr_right = tsright->p_address0;
		for(j=0; j<tsright->nMaskShift; j++) {
		  if(tsright->maskShift[j][1] >= 0) {
			 p_addr_right |= (ii & tsright->maskShift[j][0]) 
				<<  (int)tsright->maskShift[j][1];
		  } else {
			 p_addr_right |= (ii & tsright->maskShift[j][0]) 
				>> - (int)tsright->maskShift[j][1];
		  }
		}
		p_varbl_right = p_addr_right & tsright->p_mask_v_bits;
		p_fixed_right = p_addr_right >> tsright->p_bitc;
	 
		fromr_vct = 0.0;
		for(ifs=0; ifs<r_size_right; ifs++) { 
		  if ( right_prob_blocks.local_block != 0)
		    myx0    = right_prob_blocks.needed_blocks[right_prob_blocks.founder_sim_blocks[ifs]]
		      [(int)((p_varbl_right & right_prob_blocks.new_p_mask_v_bits) ^ right_prob_blocks.new_founder_sim_mask1[ifs])];
		  else
		    myx0    = tsright->tempvct[(int)(p_varbl_right ^ 
					      tsright->founder_sim_mask1[ifs])];

	       

		 
		  mask2 = tsright->founder_sim_mask2[ifs] ^ p_fixed_right;   /* fixed bits distance to p_address */
		  hd=tsright->hamming_dist[ifs];
		  for(j=0; j<=mod8[p_fix_bitc_right]; j++)
		    hd += lbtc8[(int)( (mask2 >> (8*j)) & lbtc8mask_l)];
		  fromr_vct += 
			 (long double)myx0 * (long double)tsright->l_theta[hd] * (long double)tsright->l_ctheta[hd_max_right - hd];
		}

  } /* if tsright not NULL */

  if ((tmp3 != (double *)0) && (tsleft != NULL))
		tmp3[i] = (double)froml_vct;
  if ((tmp4 != (double *)0) && (tsright != NULL))
		tmp4[i] = (double)fromr_vct;

	 /*Now that we have found the i'th bit in the full representation for
		both transitions from right and left, dot them here and calc Lod, etc
		so never have to store full vectors */

	 score_npl_val = Get_apm_score_mpi(ii);
	
	 if (tsleft == NULL)
		p = fromr_vct;
	 else if (tsright == NULL)
		p = froml_vct;
	 else
		p = (froml_vct * fromr_vct);

	 
	 /* Need this if haplotyping between markers, but it slows things down alot */
	 if (tmpdot != (double *)0)
		tmpdot[i]=(double)p;


	 /* printf("Proc %d at index %d has p: %8.7e, par: %8.7e, lod_like: %8.7e\n", mpi_interface.rank, i, p, par_score[i], tdot->lodlike );*/
	 /* par_score is indexed by local vector size--G. Conant*/
	 if(analysis_type != NPL_ANALYSIS) 
		plod = p * par_score[i];
	 else    
		plod = p;

	 /*G. Conant removed tdot members and used local MPI send buffers*/
	 if ((double)p > tdot->maxlike) tdot->maxlike=(double)p;
	 if ((double)p < tdot->minlike && p > 0.0) tdot->minlike = (double)p;
	 tdot->lodlike += (double)plod;
	 tdot->like += (double)p;
	 tdot->statval += ((double)p*score_npl_val);
	 tdot->varsum  += ((double)p*score_npl_val*score_npl_val);
	 /*G. Conant replaced with BST
	   for (j=0; j<num_scores; j++) {
	   if (score_npl_val == score_list[j]) {
	   p_score_s[j]+=(double)p; 
	   break;
	   }
	   }
	  
	   if (j==num_scores) 
	   error("can't find apm_score in list in entropy computation");*/
	
	 p_score[Retrieve_ST(score_npl_val)]+=(double)p;
	 /* SUM(-(p[i]/tdot->like)*log(p[i]/tdot->like) = 
	    (1/tdot->like)*SUM(-p[i]*log(p[i])) + log(tdot->like)  
	 */

	 if(p > 0) tdot->un_normalized_entropy += (-1.0) * (double)p * log((double)p);
	 if(compute_sharing) 
		find_sharing_probs(pos_in_scan, n, ii, (double)p); /*** new - FIX 6/99 ***/
  }

 

}

void TransFree(TRANSSTRUCT *ts, PBvct_blocks *prob_blocks)
{
  int i;
  unmatrix(ts->maskShift, 128, long long int);

  unarray(ts->tempvct, double);
 
  unarray(ts->bit_cnt, int); 
  free(ts->founder_sim_mask);
  free(ts->founder_sim_mask1);
  free(ts->founder_sim_mask2);
  free(ts->hamming_dist);
  cleanup_PBvct_struct(prob_blocks);
}



/* Saved debug print statements ---------------------- */
/*		printf(" lbtc8mask = %8x \n", lbtc8mask);
		for(i=0; i<32; i++) printf(" mod8[%2d] = %4d \n", i, mod8[i]);
		for(i=0; i<(int)pow2[8]; i++)
			printf(" lbtc8[%4d]=%6d \n", i, lbtc8[i]);
*/		
/*		printf("l=%2d  p_bitc=%2d p_size=%10d  nvfs/nffs=%2d %2d\n", 
		        p_marker, p_bitc, p_size, nvfs, nffs);
		printf("\t p_legal=%8x   n_legal=%8x \n", 	p_legal, n_legal);
		for(i=0; i<nvfs; i++)
			printf("\t p_v_flip_mask[%2d]=%8x \n", i, p_v_flip_mask[i]);
		for(i=0; i<nffs; i++)
			printf("\t p_f_flip_mask[%2d]=%8x \n", i, p_f_flip_mask[i]);
*/
/*			for(j=0; j<p_bitc; j++) {
				bit_cnt[i] += ((i & (int)pow2[j]) ? 1:0);
			}
*/
/*				for(k=0; k<p_bitc; k++) bits_on += ((andmask & (int)pow2[k])?1:0);
*/
/*		for(i=0; i<p_size; i++)
			printf("      bit_cnt[%8x]=%2d \n", i, bit_cnt[i]);
*/		
/*	printf("\t\t ----------------\n");
	for(i=0; i<nMaskShift; i++) 
		printf("\t\t mask, shift, %8x  %4d\n",maskShift[i][0],maskShift[i][1]);
	printf("\t\t ----------------\n");
*/
/*				if((i==0)  && (ifs==0) ) {
					printf("----i=%6d  theta=%12.4e p/n_addr=%8x %8x  ifs=%2d  x0=%12.4e \n",
					i, theta[p_marker], p_address, n_address, ifs, x0);
					printf("    th[%2d]=%8.4e cth[%2d]=%8.4e \n",
					hd, l_theta[hd], hd_max - hd, l_ctheta[hd_max - hd]);
				}
*/
/* END Saved debug print statements ------------------ */

void convolve_fft_2(int nbits, double theta, int *bit_cnt, double *pv)
{
	int i, j, Nstates;
	double trans[100], factor;
	void fft_2(int, double *);


	Nstates = (int)pow2[nbits];
	trans[0] = 1.0;
	factor = 1.0 - 2.0*theta;
	for (i=1; i<100; ++i)
		trans[i] = trans[i-1]*factor;
	fft_2(nbits, pv);
	for(i=0; i<Nstates; i++)
		pv[i] *= trans[bit_cnt[i]];
	fft_2(nbits, pv);
	for(i=0; i<Nstates; i++)
		pv[i] /= Nstates;
}

void fft_2(int nbits, double *pv)
{
	int i,j,ej,flipi,Nstates;
	double temp;

	Nstates = (int)pow2[nbits];
	for (j=0; j<nbits; j++) {
		ej = (int)pow2[j];
		for (i=0; i<Nstates; i++) {
			if ((i & ej) == 0) {
				flipi = i ^ ej;
				temp = pv[i];
				pv[i] = temp + pv[flipi];
				pv[flipi] = temp - pv[flipi];
			}
		}
	}
}

/* -------------------------------------------------------------------*/
/* parallel convolve and FFT routines -S. Plimpton*/

void parallel_convolve_fft_2(int nbits, double theta,
                             int *bit_cnt, double *pv,
                             int me, int nprocs)
{
  int i,Nstates_local;
  long long int Nstates;
  double trans[100],factor;
  int nbits_procs;

  Nstates = pow2[nbits];
  Nstates_local = (int)(Nstates/(long long int)nprocs);

  nbits_procs = 0;
  while ((int)pow2[nbits_procs] != nprocs) nbits_procs++;

  trans[0] = 1.0;
  factor = 1.0 - 2.0*theta;
  for (i = 1; i < 100; ++i) trans[i] = trans[i-1]*factor; 
  
#ifdef GC_TIME
  gct_pre_fft=gct_RunTime();
#endif 
  

#ifdef TEST_COMM
  if (mpi_interface.rank == 0)
    printf("Proc 0 calling FFT routine\n");
#endif
  parallel_fft_2(nbits,pv,me,nprocs,nbits_procs);


#ifdef GC_TIME
  gct_post_fft=gct_RunTime();
  gct_total_fft+=gct_post_fft-gct_pre_fft;
#endif
  
  for (i = 0; i < Nstates_local; i++) pv[i] *= trans[bit_cnt[i]];

#ifdef GC_TIME
	gct_pre_fft=gct_RunTime();
#endif

#ifdef TEST_COMM
  if (mpi_interface.rank == 0)
    printf("Proc 0 calling FFT routine\n");
#endif
  parallel_fft_2(nbits,pv,me,nprocs,nbits_procs);

#ifdef TEST_COMM
  MPI_Barrier(MPI_COMM_WORLD);
  if (mpi_interface.rank == 0)
    printf("Proc 0 done with FFTs\n");
#endif


#ifdef GC_TIME
	gct_post_fft=gct_RunTime();
	gct_total_fft+=gct_post_fft-gct_pre_fft;
#endif

  for(i = 0; i < Nstates_local; i++) pv[i] =  (pv[i]/(double)Nstates);
}



void parallel_fft_2(int nbits, double *pv,
                    int me, int nprocs, int nbits_procs)
{
  int i,j,ej,flipi,Nstates_local;
  long long int Nstates;
  double temp;
  int iproc_mask,nbits_local,partner;
  double *buf;
  MPI_Status status;

  Nstates = pow2[nbits];
  Nstates_local = (int)(Nstates/(long long int)nprocs);
  nbits_local = nbits - nbits_procs;


  buf = (double *) malloc(Nstates_local*sizeof(double));

#ifdef TEST_COMM
  MPI_Barrier(MPI_COMM_WORLD);
  if (mpi_interface.rank ==0)
    printf("Proc 0 has buf : %d\n", buf);
#endif
    

  if (buf == NULL) {
    printf("ERROR: Insufficient FFT buffer memory\n");
    MPI_Abort(MPI_COMM_WORLD,1);
  }


  
  for (j = 0; j < nbits_local; j++) {
      ej = (int)pow2[j];
   
    for (i = 0; i < Nstates_local; i++) {
     
      if ((i & ej) == 0) {	
	flipi = i ^ ej;
        temp = pv[i];
        pv[i] = temp + pv[flipi];
        pv[flipi] = temp - pv[flipi];
	
      }
    }
  }



  for (iproc_mask = 1; iproc_mask < nprocs; iproc_mask *= 2) {
    partner = me ^ iproc_mask;
   
    MPI_Sendrecv(pv,Nstates_local,MPI_DOUBLE,partner,0,
                 buf,Nstates_local,MPI_DOUBLE,partner,0,
                 MPI_COMM_WORLD,&status);

    
    if (me < partner)
      for (i = 0; i < Nstates_local; i++) pv[i] = pv[i] + buf[i];
    else
      for (i = 0; i < Nstates_local; i++) pv[i] = buf[i] - pv[i];
  }


  free(buf);
}

/*End of S. Plimpton's new parallel fft*/


void Setup_MaskShift(int nbits, long long int p_msk, long long int n_msk, 
                     long long int n_fixed, TRANSSTRUCT *ts)

{
/* -----------------------------------------------
Prepare the mask-shift operations to transform the n_representation
inheritance vector to a p_representation inh. vector.
ts                  Transition Structure (used in TransSetupConvolve(), etc)
n_bits              # of bits in founder symmetry (fs) representation.
p_msk               mask of fixed bits in previous locus (fs rep.)
n_msk               mask of fixed bits in next locus (fs rep.)
n_fixed             value of fixed bits in next locus (n_representation)
ts->p_address0      value of fixed bits in next locus transformed to
                    p_representation.
ts->nMaskShift          # of mas-shift operations needed.
ts->maskShift[iop][0]   mask  for iop operation
ts->maskShift[iop][1]   shift for iop operation
   ----------------------------------------------- */
	int i, j, nMS, k_n, k_o, k_p, p_nvb, n_nvb, t_j, nop;
	long long int test;
	/*G. Conant changed sbit_flag from 64 to 128--just in case*/
	int nop_max, sbit_flag[128];
	
#ifdef TEST_COMM
	MPI_Barrier(MPI_COMM_WORLD);
	if (mpi_interface.rank == 0)
	  printf("Proc 0 has nmsk: %lld, pmsk: %lld, nval: %lld\n", n_msk, p_msk, n_fixed);
#endif

	
	p_nvb = n_nvb = 0;
	for(i=0; i<nbits; i++) {
		if((pow2[i] & p_msk) == 0) p_nvb++;
		if((pow2[i] & n_msk) == 0) n_nvb++;
	}
	/*	printf("\t\t p_msk, n_msk = %8x  %8x \n", p_msk, n_msk);
		printf("\t\t p_nvb, n_nvb = %8d  %8d \n", p_nvb, n_nvb);
	*/

	/* define nbits mask-shift operations that map 
	   n_representation to p_representation 
	   k_n  bit position in n_representation
	   k_o  bit position in fs representation (original)
	   k_p  bit position in p_representation  
	*/	
	for(k_n=0; k_n<nbits; k_n++) {
		j=0;
		t_j  = ((k_n<n_nvb) ? k_n:(k_n-n_nvb));

		/*test = ((k_n<n_nvb) ? (n_msk^0xffffffff):n_msk);*/
		test = ((k_n<n_nvb) ? (n_msk^0xffffffffffffffff):n_msk);
		for(k_o=0; k_o<nbits; k_o++) {
			if(pow2[k_o] & test) {
				if(j==t_j) break;
				j++;
			}
		}
		
		k_p  = ((pow2[k_o] & p_msk) ? p_nvb:0);
		/*test = ((pow2[k_o] & p_msk) ? p_msk:(p_msk^0xffffffff));*/
		test = ((pow2[k_o] & p_msk) ? p_msk:(p_msk^0xffffffffffffffff));
		for(i=0; i<k_o; i++) {
			if(pow2[i] & test) k_p++;
		}
		
		/*printf("\t\t k_p, k_o, k_n= %2d  %2d  %2d\n", k_p, k_o, k_n); */
		ts->maskShift[k_n][0] = pow2[k_n];
		ts->maskShift[k_n][1] = (long long int)(k_p - k_n);
	}
	
	/* define p_address0 and keep transformations of variable bits only	*/	
	nop = 0;
	ts->p_address0 = (long long int)0;
	for(i=0; i<nbits; i++) {
		if(i<n_nvb) {
			ts->maskShift[nop][0] = ts->maskShift[i][0];
			ts->maskShift[nop][1] = ts->maskShift[i][1];
			nop++;
		} else {
			if(ts->maskShift[i][1] >= 0) {
				ts->p_address0 |= (n_fixed & ts->maskShift[i][0]) 
				                <<  (int)ts->maskShift[i][1];
			} else {
				ts->p_address0 |= (n_fixed & ts->maskShift[i][0]) 
				                >> - (int)ts->maskShift[i][1];
			}
		}
	}

#ifdef TEST_COMM
	MPI_Barrier(MPI_COMM_WORLD);
	if (mpi_interface.rank == 0)
	  printf("Proc 0 about to compact mask shifts\n");
#endif

	
	/* group together variable bits that share the same shift value */
	nop_max = nop;
	nop     = 0;
	for(i=0; i<nop_max; i++) sbit_flag[i] = 0;
	for(i=0; i<nop_max; i++) {
		if(sbit_flag[i]) continue;
		sbit_flag[i] = 1;
		ts->maskShift[nop][0] = ts->maskShift[i][0];
		ts->maskShift[nop][1] = ts->maskShift[i][1];
		for(j=i+1; j<nop_max; j++) {
			if(ts->maskShift[nop][1] == ts->maskShift[j][1]) {
				sbit_flag[j] = 1;
				ts->maskShift[nop][0] |= ts->maskShift[j][0];
			}
		}
		nop++;
	}
	
	ts->nMaskShift = nop;
}

void Setup_flip_masks(long long int p_mask, int *nvfs, long long int p_v_flip_mask[],
                               int *nffs, long long int p_f_flip_mask[], PBvct_blocks *prob_blocks)
{
  int p_bitc, nv, nf, i, j, k1, k2, k3, k4;
  long long int mask, test, p_flip_mask;
  int flip_m_v_bits, flip_m_t_bits;
	
/*	j=0;
	for(i=0; i<n; i++) { if((uninf_mask & pow2[i]) != 0) j++; }
	*tfs = j;
*/	
	p_bitc = 0;
	for(i=0; i<rn; i++) { if((p_mask & pow2[i]) == 0) p_bitc++; }

	nv = nf = 0;
	prob_blocks->founder_sim_mask_fullrep[0]=(long long int)0;
	for (i=0; i<n; i++) {
		if ((uninf_mask & pow2[i]) == 0) continue;
		p_flip_mask=0;
		mask = flip_mask[i] ^ pow2[i]; /* all but uninformative bit */
		flip_m_v_bits = flip_m_t_bits = 0;
		for(j=0; j<n; j++) {
			if((mask & pow2[j]) == 0) continue;
			flip_m_t_bits++;
			test = pow2[j];
			/* k1   full inh. vector rep.
			   k2   founder symmetry reduced inh. vector rep.
			   k3   genotyping reduced inh. vector rep. position in variable section
			   k4   genotyping reduced inh. vector rep. position in  fixed   section
			*/
			k2 = k3 = k4 = 0;
			for(k1=0; k1<n; k1++) {
				if((uninf_mask & pow2[k1]) != 0) continue;
				if(test & pow2[k1]) break;
				if((p_mask & pow2[k2]) == 0) { k3++; } else { k4++; } 
				k2++;
			}
			/* if flip mask and not_fixed_bit set flip mask in 
			   genotype reduced representation */
			if(k1<n) {
				if((p_mask & pow2[k2]) == 0) {      /* variable bit */
					flip_m_v_bits++;
					p_flip_mask |= pow2[k3];
				} else {                            /*   fixed  bit */
					p_flip_mask |= pow2[p_bitc + k4];
				}
			}
		}
		if(p_flip_mask != 0) {   /* first check if ref. phase has no sibs */
			if(flip_m_v_bits == flip_m_t_bits) {
				p_v_flip_mask[nv] = p_flip_mask; /* full mask in variable bit set*/
				nv++;
			} else {
			  /*Need to store the full-rep founder sim information for communication*/
			  prob_blocks->founder_sim_mask_fullrep[nf] |= flip_mask[i];
			  p_f_flip_mask[nf] = p_flip_mask; /* mixed or all in fixed bit set */
			  nf++;
			  prob_blocks->founder_sim_mask_fullrep[nf]=(long long int)0;
			}
		}
	}
	*nvfs=nv;
	*nffs=nf;
	
	/*G. Conant--creates a founder_sim representation of the bit in
	  each founder symmetry group (i.e. founder sim bits are left out*/
	for (i=0; i<*nffs; i++)
	  {
	    k1=0; 
	    p_flip_mask=0;
	    for (j=0; j<n; j++)
	      {
		if ((pow2[j] & uninf_mask) == 0) 
		  p_flip_mask |= (prob_blocks->founder_sim_mask_fullrep[i] & pow2[j])>>k1;
		
		else
		  k1++;
	      }
	    prob_blocks->founder_sim_mask_fullrep[i]=p_flip_mask;
	  }
	
}

/* Katz, Thu Jun 22 14:26:31 2000
 * If n_marker = -1, are going between markers, so n_legal is 0
 * (no fixed bits in destination)
 */

void Setup_legal_vectors(int p_bitc, long long int *p_mask_v_bits, 
                         int p_marker, long long int *p_legal, 
						 int n_marker, long long int *n_legal)
{
	int i, j;

	*p_mask_v_bits = 0;
	for(i=0; i<p_bitc; i++)    *p_mask_v_bits |= pow2[i];

	*p_legal = 0;
	j       = 0;
	for(i=0; i<rn; i++) {
		if(pow2[i] & maskTest[p_marker][0]) {
			if(pow2[i] & maskTest[p_marker][1]) *p_legal |= pow2[j];
			j++;
		}
	}
	*n_legal = 0;

	if (n_marker < 0)  /* Going between markers, *n_legal=0, no fixed bits */
	  return;

	j       = 0;
	for(i=0; i<rn; i++) {
		if(pow2[i] & maskTest[n_marker][0]) {
			if(pow2[i] & maskTest[n_marker][1]) *n_legal |= pow2[j];
			j++;
		}
	}
}


void Setup_founder_sim_masks(TRANSSTRUCT *ts)
{
  int i, j;


  ts->founder_sim_mask=(long long int*)malloc(sizeof(long long int)*(int)pow2[ts->nffs]);
  ts->founder_sim_mask1=(long long int*)malloc(sizeof(long long int)*(int)pow2[ts->nffs]);
  ts->founder_sim_mask2=(long long int*)malloc(sizeof(long long int)*(int)pow2[ts->nffs]);
  ts->hamming_dist=(int*)malloc(sizeof(int)*(int)pow2[ts->nffs]); 

  if (( ts->founder_sim_mask == 0) || ( ts->founder_sim_mask1 == 0) || ( ts->founder_sim_mask2 == 0) ||
      (ts->hamming_dist == 0))
    {
      printf("Proc %d has insufficient memory for founder_sim_masks\n", mpi_interface.rank);
      MPI_Abort(MPI_COMM_WORLD,1);
    }
 

  for(i=0; i<(int)pow2[ts->nffs]; i++) {
    ts->hamming_dist[i]= ts->founder_sim_mask[i] = 0;
    for(j=0; j<ts->nffs; j++) { 
      if(i & (int)pow2[j]) {
	ts->hamming_dist[i]++;
	ts->founder_sim_mask[i] |= ts->p_f_flip_mask[j]; 
      }
    }
   
    ts->founder_sim_mask1[i] = ts->founder_sim_mask[i] & ts->p_mask_v_bits;
    
    ts->founder_sim_mask2[i] = (ts->founder_sim_mask[i] >> ts->p_bitc) 
      ^ ts->p_legal; 
    
  }

}


void Check_results_01(int l, int n_pntf, int test0, int test1,
                      int reduced_bitc,       int full_bitc,
                   double reduced_array[], double full_array[])
{
	int i, j, r_size, f_size, nerrors, n_ptr, dump_limit, error_limit;
	double x1, x2, x3;
	
	dump_limit  = 0;
	error_limit = 8;
	
	r_size = pow2[reduced_bitc];
	f_size = pow2[full_bitc];
	
	x3 = 0;
	for(i=0; i<pow2[reduced_bitc]; i++) x3 += reduced_array[i];
	/* printf("  sub x3=%12.4e \n", x3); */

	n_ptr = nerrors = 0;
	for(i=0; i<f_size; i++) {
		if((i & test0) == test1) {
			x1 = reduced_array[n_ptr];
			x2 = full_array[i];
			j=!real_eq_10( (x1-x2)/x3, 0.);
			if(j) nerrors++;
			if( (j && (nerrors<error_limit)) || (n_ptr<dump_limit) ) {
				if(j) { printf("\t\t*"); }
				else  { printf("\t\t "); }
				printf(" l, n_ptr, new, old r, %2d %6d %6d %12.4e %12.4e",
				l, n_ptr+n_pntf, n_ptr, reduced_array[n_ptr], full_array[i]);
				if(j) {
					if(x1 != 0) {
						printf(" %16.8e \n", x2/x1);
					} else {
						printf(" %16.8e inverse\n", x1/x2);
					}
				} else {
					printf("   1.\n");
				}
			}
			n_ptr++;
		}
	}
	if(nerrors >= error_limit) {
		printf("\t\t ............. nerrors=%10d \n", nerrors);
	} else if(nerrors != 0) {
		printf("\t\t               nerrors=%10d \n", nerrors);
	}
}



double Get_apm_score(int new_vec)
{
	static int npl_pnt, vec_previous;

	if(new_vec != 0) {
		if( (vec_previous & score_mask_rdc) != 
	    	(new_vec & score_mask_rdc) )       npl_pnt++;
	} else {
		npl_pnt = vec_previous = 0;
	}
	vec_previous = new_vec;
	return(apm_score[npl_pnt]);
}






/*G. Conant modified for MPI
  In the TransBetweenAndDot function this function is called without having gone through
  all of the N vectors, so we need an MPI version that "knows" where to start (npl_pnt and
  vec_previous are static)*/
double Get_apm_score_mpi(long long int new_vec)
{
	static int npl_pnt;
	static long long int vec_previous;

	if(new_vec != mpi_interface.vec_offset) {
		if( (vec_previous & score_mask_rdc) != 
	    	(new_vec & score_mask_rdc) )       npl_pnt++;
	} else {
		npl_pnt = 0;
		vec_previous = 0;
	}
	vec_previous = new_vec;
	return(apm_score[npl_pnt]);
}


/*Function added to give proper behavior of Get_apm_score under
  MPI.  This function calculates the starting value of npl_pnt
  for Get_apm_scores --G. Conant*/
long long int Get_apm_offset_mpi(long long int new_vec, long long int score_mask_rdc)
{
	static long long int npl_pnt;
	static long long int vec_previous;

	if(new_vec != 0) {
		if( (vec_previous & score_mask_rdc) != 
	    	(new_vec & score_mask_rdc) )       npl_pnt++;
	} else {
		npl_pnt = vec_previous = 0;
	}
	vec_previous = new_vec;
	return(npl_pnt);

}




