/* GENEHUNTER - Kruglyak, Daly, Reeve-Daly, and Lander
   Whitehead Institute for Biomedical Research, Copyright 1996 */
#define INC_LIB
#define INC_SHELL
#include "npl.h"

#define real_eq(x,y) (fabs((x)-(y))<.0000001)

double **newscore, **newprior, **newpost, *new_num_scores;
double raw_total, total_max;


command two_locus_test(void)
{
    int i, j, num_peds1, num_peds2, total_pval_max, this_score;
    char *tempstr;
    FILE *fp1, *fp2;
    double test_2d_ped(FILE*,FILE*,int,double*,double*), Z, pval, total_Z;
    double *prior_dist, *post_dist, pval_total;

    tempstr = get_temp_string();
    input("enter peak info file #1: ",tempstr,TEMP_STRING_LEN);
    run {
      fp1 = open_file(tempstr,"r");
    } except_when(CANTOPEN) {
      sf(ps,"Can't open file '%s'\n"); pr();
      return;
    }

    tempstr = get_temp_string();
    input("enter peak info file #2: ",tempstr,TEMP_STRING_LEN);
    run {
      fp2 = open_file(tempstr,"r");
    } except_when(CANTOPEN) {
      sf(ps,"Can't open file '%s'\n"); pr();
      return;
    }

    /* read headers and make sure num_peds matches up */
    run {
      num_peds1 = -1; num_peds2 = -2;
      fgetln(fp1);
      sscanf(ln,"%d",&num_peds1);
      fgetln(fp2);
      sscanf(ln,"%d",&num_peds2);

      if (num_peds1 != num_peds2) {
	error(
"number of analyzed pedigrees is different in the two files - cannot combine");
      }

      /* allocate space */
      array(newscore, num_peds1, double*);
      array(newprior, num_peds1, double*);
      array(newpost, num_peds1, double*);
      array(new_num_scores, num_peds1, double);

      total_Z=0.0; total_max=0.0; raw_total=0.0;
      for (i=0; i<num_peds1; i++) {
	test_2d_ped(fp1,fp2,i,&Z,&pval);
	if (pval < .00001) 
	  sf(ps,"pedigree %d: Z = %.5lf, p-value = %.4g\n",i+1,Z,pval);
	else sf(ps,"pedigree %d: Z = %.5lf, p-value = %.6lf\n",i+1,Z,pval);
	pr();
	total_Z += Z;
      }

      /* now that all pedigrees have been read in, we can convolve the
	 distributions and calculate the p-value */

      init_convolution(total_max);
      total_pval_max=(int)(total_max*pval_precision)+10;
      array(prior_dist,total_pval_max,double);
      array(post_dist,total_pval_max,double);

      for (j=0; j<total_pval_max; j++) prior_dist[j]=0.0;
      for (i=0; i<new_num_scores[0]; i++) {
	this_score = (int) ((newscore[0][i]*pval_precision)+.5);
	prior_dist[this_score] = newprior[0][i];
      }
      for (i=1; i<num_peds1; i++) {
	convolve(prior_dist, newprior[i], newscore[i], new_num_scores[i]);
      }

      for (j=0; j<total_pval_max; j++) post_dist[j]=0.0;
      for (i=0; i<new_num_scores[0]; i++) {
	this_score = (int) ((newscore[0][i]*pval_precision)+.5);
	post_dist[this_score] = newpost[0][i];
      }
      for (i=1; i<num_peds1; i++) {
	convolve(post_dist, newpost[i], newscore[i], new_num_scores[i]);
      }
      
      pval_total=0.0;
      for (j=(int)(raw_total*pval_precision); j<=total_pval_max; j++) 
	pval_total += prior_dist[j];
      
      if (pval_total < .00001) 
	sf(ps,"total Z = %.5lf, p-value = %.4g\n",
	   total_Z/sqrt(num_peds1), pval_total); 
      else
	sf(ps,"total Z = %.5lf, p-value = %.6lf\n",
	   total_Z/sqrt(num_peds1), pval_total); 
      pr();

      free_convolution();

    } on_exit {
      close_file(fp1);
      close_file(fp2);
      if (msg == ENDOFILE) print("Unexpected end-of-file reached\n");
      else relay_messages;
    }
}

double test_2d_ped(FILE *fp1, FILE *fp2, int ped, double *Z, double *pvalue) 
{
    int i, j, num_scores1, num_scores2, index;
    double *score1=NULL, *score2=NULL, *prior1=NULL, 
           *prior2=NULL, *post1=NULL, *post2=NULL;
    double raw1, raw2, rnum, max, p_val, ped_total, exp, exp_2;

    run {
      fgetln(fp1);
      rtoken(&ln,-999.0,&raw1);
      itoken(&ln,-1,&num_scores1);
      if (raw1 < 0.0 || num_scores1 < 0) {
	sf(ps,"bad values in peak file 1 - pedigree %d",ped+1);
	error(ps);
      }

      fgetln(fp2);
      rtoken(&ln,-999.0,&raw2);
      itoken(&ln,-1,&num_scores2);
      if (raw2 < 0.0 || num_scores2 < 0) {
	sf(ps,"bad values in peak file 2 - pedigree %d",ped+1);
	error(ps);
      }

      if (num_scores1 != num_scores2) {
	  sf(ps,"pedigree info doesn't match in these two files for ped %d",
	     ped+1); error(ps);
      }

      array(score1,num_scores1,double);
      array(prior1,num_scores1,double);
      array(post1,num_scores1,double);
      array(score2,num_scores2,double);
      array(prior2,num_scores2,double);
      array(post2,num_scores2,double);

      /* now read in the data for each peak - the list of raw scores
	 and prior probs should be the same in each file (as long as
	 the pedigrees match) but the posts will be different */

      fgetln(fp1);
      for (i=0; i<num_scores1; i++) {
	rtoken(&ln,0.0,&rnum); score1[i]=rnum;
      }
      fgetln(fp1);
      for (i=0; i<num_scores1; i++) {
	rtoken(&ln,0.0,&rnum); prior1[i]=rnum;
      }
      fgetln(fp1);
      for (i=0; i<num_scores1; i++) {
	rtoken(&ln,0.0,&rnum); post1[i]=rnum;
      }

      fgetln(fp2);
      for (i=0; i<num_scores1; i++) {
	rtoken(&ln,0.0,&rnum); score2[i]=rnum;
      }
      fgetln(fp2);
      for (i=0; i<num_scores1; i++) {
	rtoken(&ln,0.0,&rnum); prior2[i]=rnum;
      }
      fgetln(fp2);
      for (i=0; i<num_scores1; i++) {
	rtoken(&ln,0.0,&rnum); post2[i]=rnum;
      }
      
      /* now check these for consistency - add code later */


      /* now combine these distributions for one 2-locus distribution */

      new_num_scores[ped] = num_scores1*num_scores2;
      array(newscore[ped], new_num_scores[ped], double);
      array(newprior[ped], new_num_scores[ped], double);
      array(newpost[ped], new_num_scores[ped], double);

      max = 0.0; exp = exp_2 = 0.0;
      for (i=0; i<num_scores1; i++) {
	for (j=0; j<num_scores2; j++) {
	  index= (num_scores1*i)+j;
	  newscore[ped][index] = score1[i]+score2[j];
	  newprior[ped][index] = prior1[i]*prior2[j];
	  newpost[ped][index] = post1[i]*post2[j];
	  if (newscore[ped][index] > max) max=newscore[ped][index];
	  exp += (newscore[ped][index]*newprior[ped][index]);
	  exp_2 += (newscore[ped][index]*newscore[ped][index]*newprior[ped][index]);
	}
      }

      total_max += max;
      ped_total = raw1+raw2;
      p_val = 0.0;

      for (i=0; i<num_scores1*num_scores2; i++) {
	if (ped_total < newscore[ped][i]) p_val+=newprior[ped][i];
	else if (real_eq(ped_total,newscore[ped][i])) p_val+=newprior[ped][i];
      }

      *pvalue = p_val;
      *Z = (ped_total-exp)/sqrt(exp_2 - (exp*exp));
      raw_total += ped_total;

    } on_exit {
      relay_messages;
    }
}


