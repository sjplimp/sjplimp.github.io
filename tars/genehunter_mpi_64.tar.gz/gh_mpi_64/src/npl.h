/* GENEHUNTER - Kruglyak, Daly, Reeve-Daly, and Lander
   Whitehead Institute for Biomedical Research, Copyright 1996 */
/* npl.h */
#ifndef ___NPL_H___
#define ___NPL_H___

#include "system.h"


/*G. Conant added function defs*/
#include "math.h"
void init_sharing_probs(long long int number_vecs, int number_bits);
void find_sharing_probs(int, int, long long int, double);
int  print_requirements(int, int, int, int, int, int, int *, int, int *);
void scan_pedigree(int *,long long int *, double *, double *, int, int *, int *,
		  int, double *, long long int, double, double , int, int, int *,
		  int, long long int, long long int *, long long int **);
void modify_setup_lodscores(void);
int lookup_mask(int vec);
int min_diff_bits(int, int, int *);
int pad_inhvec(int);
int diff_bits(int, int);
void fill_placeholder_alleles_2(int, int, long long int, int, int);
void fill_placeholder_alleles(long long int, int, int);
int  FindIllegalBits(int, int, int, int, int, int *, int *);
int Setup_local_pad_inhvec_2(long long int, int, long long int [], long long int []);
int Set_npl_score_masks(long long int *, long long int *, long long int*, int , int);
int Define_family_map_order( int, int, int, int *,int *,int *,int );
void tally_score(double, int, double);
void set_mom_index(int,int);
void set_dad_index (int,int);
void add_rec(int, double);
void sort_pedigree (int);
void check_for_unlinked (int);
void check_for_loop (int, int, int, int, int);
int resort_pedigree(int);
int Dump();
int Push(int);
int Pop();
void set_weights(int);
FILE *open_out_file(char *, char *);
void allocate_pair_analysis_storage();
void count_recs_2(int, double, int *, double *);
FILE* open_postscript_file(char *, char *);
void norm_sharing_probs(int, double);
void make_member_list(char *, int);
void nonparametric(void);
void ml_variance(void);
void no_dom_var(void);
void cntab1(int **, int, int, double *, double *, double *,double *, double *);
void extract_warray(void);
void compute_haplotype(int);

#include "pslib.h"

#define MAXLOCI 300
#define MAX_PEDIGREES 1000
#define MAX_NAME_SIZE 50
#define MAX_ALLELE_SIZE 1000
#define MAX_POSITIONS 1000
#define MAX_INDIVIDUALS 100  /* in a pedigree */
/*Modified from 16 by G. Conant for 64 bit version*/
#define MAX_KIDS 32
#define MAX_PARTNERS 10
#define MAX_NUCLEAR_FAM 1000
#define MAX_SIBSHIPS 1000
#define MAX_PAIRS 10000
#define MAX_FILE_NAME_LEN 200 
#define MAX_TITLE 60 
#define MAX_PHENOTYPES 31 
#define MAX_COVARIATES 10
#define MISSING_PHENO -999999.0 
#define LOG10E 0.434294481902 

#define TRANSMITTED 0
#define UNTRANSMITTED 1

typedef struct {
    char   name[MAX_NAME_SIZE];
    double allele_freq[MAX_ALLELE_SIZE];
    double allele_sum;
    int allele_count[MAX_ALLELE_SIZE][3];
} LOCUS_INFO;

typedef struct {     
  char name[MAX_NAME_SIZE];
} PHENOTYPE_INFO;

typedef struct assign_struct {
    int allele_list[MAX_ALLELE_SIZE];
    int force_list[MAX_INDIVIDUALS*2];
    int num_alleles;
    struct assign_struct *next;
} ASSIGN_STRUCT;


/* global variables */

extern int num_pedigrees;
extern LOCUS_INFO *locus;
extern PHENOTYPE_INFO *phenotype; /* Not currently used for anything */
extern int num_phenotypes;
extern int num_covs; 
extern int num_loci;
extern int num_markers;
extern int num_in_map_order;
extern int *map_order;
extern double *map_distance;
extern bool display_scores;     /* whether to display NPL scores, LOD scores 
				   and info content on screen */ 

extern double off_end_dist;     /* how far beyond map to scan */

extern int scan_steps;          /* how to divide intervals */
extern double scan_increment;

extern int map_function;        /* cM <--> rec-frac conversion */
#define HALDANE 1
#define KOSAMBI 2

extern int units;               /* output in cM or rec-fracs */
#define CENTIMORGANS 0
#define RECFRACS 1

extern int use_letters;         /* display haplotypes as letters or numeric alleles */

extern char *current_filename;

/* disease affectation status */
#define UNKNOWN     0
#define UNAFFECTED  1
#define AFFECTED    2

/* disease allele status */
#define HOM_AFF     0
#define HOM_UNAFF   1
#define HET         2
/* subclasses of heterozygotes so we don't have to deal with phase */
#define HET_UA      2
#define HET_AU      3
/* if X inheritance, we need these also */
#define AFF_NULL    4
#define UNAFF_NULL  5

#define MAX_LIABILITY_CLASSES 25
/* disease information */
extern double penetrance[MAX_LIABILITY_CLASSES+1][6];
extern double affected_freq;
extern double apriori_disease[MAX_LIABILITY_CLASSES+1][6][6];
extern int num_liability_classes;

/* specific to pairs stuff */
#define MAX_EXCLUSION_POINTS 9 
#define CONVERGE 0.0000001 /* definition of convergence for the EM algorithms */
extern bool scan_done;  /* Keep track of whether or not a scan has
			   been done since the start of the program or
			   the most recent change in the increment */
extern double *****wmatrix;
extern double ***warray;
extern double ****prior_wmatrix;
extern double ***pheno;
extern int **sex;
extern double ***covariates;
extern bool *both_affected;
extern double **pair_pheno;
extern double *weight;
extern char ****pair_name;
extern int *pedigree_size;
extern int total_num_sib_pairs;
extern int total_num_aff_sib_pairs;
extern int total_num_sibships;

extern int pair_setting;
#define FIRST_PAIR     1
#define INDEPEND_PAIRS 2
#define ALL_PAIRS      3
#define ALL_UNWEIGHTED 4
#define OTHER          5 /*Not sure what this one does. See sibs_prep.c: set_weights.*/

extern bool means_by_sex;
extern int start_values;
#define ADJACENT 1
#define CONSTANT 2

/* specific to NPL stuff */
extern double **apm_stat;
extern double **raw_stat;
extern double **apm_info;
extern double **apm_entropy;
extern double **pvec_entropy;
extern double **p_value;
extern double *null_variance;
extern int pedigrees_calculated;
#define PVAL_PRECISION 10000 /* no longer used */
#define DEFAULT_PRECISION 10000
/*****
extern double *saved_pval;
extern int saved_pval_max;
extern double *newpval;
*****/
extern double **prior_pscore, **pscore_list, ***post_pscore;
extern int *num_pscores;

extern int pval_precision;

/* Convolution code -- combolod.c */
void init_convolution(double), free_convolution(void);
void convolve(double*, double*, double*, int);


/* if Linkage-style LOD scores are computed */
extern double *total_lod;
extern double **sub_lods;

/* for rec-counting option */
extern double *total_recs;

/* type of analysis */
#define NPL_ANALYSIS  1
#define LOD_ANALYSIS  2
#define BOTH_ANALYSES 3
extern int analysis_type;

/* NPL score function choices */
extern int score_function;
#define SCORE_PAIRS 1
#define SCORE_ALL 2
#define SCORE_ONE 3

/* used to store scanned positions */
extern double *wpos;
extern int num_w_pos;

extern int discard_unaffected;
extern int show_expected_recs; /* turn count_recs on for error checking */
extern int postscript_output;  /* enables/disables PS output of totals */
extern int haplotype_output;   /* enable/disables haplotype output */
extern int haplo_method;       /* Method for haplotyp, 0=viterbi,1=maxprob */
extern int dump_requirements;  /* If true, only dump memory requirements */
extern double haplo_ratio;     /* for pvector acceptance in haplo algorithm */

/* scaling of PostScript output */
#define FIT_TO_PAGE 1
#define CONSTANT_SCALE 2
extern int ps_scaling;           /* 1 or 2 (as defined above) */
extern double constant_ps_scale; /* active if CONSTANT_SCALE selected */

extern int single_point_mode;
extern int max_bits_to_analyze;
extern int skip_large;
extern int compute_sharing; /*** new 11/99 ***/

/* TDT storage */
extern int **transmitted, **untransmitted, **double_het;
extern int TDTcount;
extern int one_parent_TDT, missing_TDT;
extern int dhskip;

/* QTDT storage */
extern int **qgenotype, **qparental;
extern double **qphenotype;
extern int num_qkids;
extern int qtdt_on;

/* Temporary storage for pedigrees & haplotype drawing */
typedef struct {
  char indiv_ID[50]; /* Individual's ID in the pedigree */
  char dad[50], mom[50]; /* Mom & Dad indiv_ID as given in the pedigree file */
  int dad_index, mom_index; /* Mom & Dad index in family tree struct list */
  int sex;
  int nkids;
  int place_allele[2];
  int discard;
  int is_pivot;
  int dad_bit_uninf, mom_bit_uninf;
  int kids_found;

  /* the following is for the peeling code */
  int affectation_status;
  int liability_class;
  int inh_vec_pos;
  double disease_prob[4];
  bool in_loop;
  bool analyzed_parent;

  /* the following are for the drawing code */
  int psblock;
  bool original;
  int num_partners;
  int partner[MAX_PARTNERS];
  int nkids_in_nuc[MAX_PARTNERS];
  int nuc_family[MAX_PARTNERS][MAX_NUCLEAR_FAM];
  int kid_index[MAX_KIDS];
  
  /* the following is for the pair analyses */
  double phenotype[MAX_PHENOTYPES];
  double covariate[MAX_COVARIATES];

  int not_peeled;
} PED_MEMBER;

extern PED_MEMBER *famtree; /* Store the pedigree as a list */

extern long long int *pow2; /* store powers of 2 for bit lookup --made long long by G. Conant*/

/* COMMANDS */

/* in pedprep.c */
void pedigree_prep(void);
void get_mat_ancestors(int,int*);
void get_pat_ancestors(int,int*);


/* in locprep.c */
void load_markers(void);

/* in newcmds.c */
void set_scan_increment(void);
void set_use_map(void);
void set_units(void);
void set_map_function(void);
void set_off_end_distance(void);

void show_total_stat(void);
void set_discard(void);
void set_score_function(void);
void set_analysis_type(void);
void set_count_recs(void);
void set_postscript_output(void);
void set_haplotype(void);
void set_haplomethod(void);
void set_dump_req(void);
void set_haplo_ratio(void);

void dump_peak_info(void);
void two_locus_test(void);

void set_postscript_scaling(void);
void set_single_point_mode(void);
void set_max_bits(void);
void set_skip_large(void);
void set_compute_sharing(void); /*** new 11/99 ***/

void set_display_scores(void); 

void set_letters(void);

/* in pair_prep.c */
void pair_usage(void); 
void dump_ibd(void); 

/* in pair_analysis.c */
void exclude_switch(void);
void estimate_switch(void);
void he_switch(void); 
void ml_variance(void);
void no_dom_var(void); 
void nonparametric(void);

/* in varcom.c */
void var_com_switch(void);
void set_start_values(void);
void set_num_means(void);

/* in simped.c */
void simulation(void);

/* helpful functions */

/* in newcmds.c */
void dump_total_lodscore(void); /* not a command, called after a LOD scan */

void draw_graph(FILE*,double*,double*,int,char*,char*);  
         /* args: PS_file, xpos, yval, num_pts, graph title, axis title -  draws a PS graph */
void draw_mult_y_plots(FILE *fpps, double *xpos, double **yval,
		       int num_points, int num_y_plots, char *title,
		       char **ylabel, char *y_title);
FILE *open_out_file(char*,char*); /* args: filename, test descrtiption of
				     file purpose (e.g., "postscript plot",
				     "peak info")
				     general version of above, second arg
				     is a text description of file purpose */

/* in draw.c */
FILE *open_postscript_file(char*, char*); /* args: filename and purpose */

/* in lod.c */
void allocate_lod_vars(int), free_lod_vars(int);
double dist_to_rec(double),rec_to_dist(double);

/* in tdtprep.c */
void tdt_prep(void);
void tdt2(void);
void tdt3(void);
void tdt4(void);
void tdt5(void);
void set_one_parent_TDT(void);
void set_missing_TDT(void);
void set_dhskip(void);
void set_qtdt(void);
void perm1(void);
void perm2(void);
void pexcess1(void);
void pexcess2(void);
void pexcess3(void);
void qtdt_test(void);


#endif

