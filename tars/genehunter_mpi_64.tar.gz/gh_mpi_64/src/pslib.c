/* GENEHUNTER - Kruglyak, Daly, Reeve-Daly, and Lander
   Whitehead Institute for Biomedical Research, Copyright 1996 */
/***** pslib.c *****/
/*G. Conant added to do postscript output from MPI*/
#include "mpi_info.h"


#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include "pslib.h"
#include "time.h"

void draw_rect(FILE *fp, double x, double y, double height, 
	       double width, double gray_scale)
{
    
    /* Draws a rectangle with the lower left corner on the point (x,y) 
     * and fills and outlines it with the specified shade of gray
     */
    
    /* Create the path of the rectangle */
    fprintf(fp, "newpath\n");
    fprintf(fp, "%.2lf %.2lf moveto\n", x, y);
    fprintf(fp, "0 -%.2lf rlineto\n", height);
    fprintf(fp, "%.2lf 0 rlineto\n", width);
    fprintf(fp, "0 %.2lf rlineto\n", height);
    fprintf(fp, "-%.2lf 0 rlineto\n", width);
    fprintf(fp, "closepath\n");
    
    
    
    /* Need to store and retrieve the state so that we can
     * also outline the rectangle. If we don't outline it,
     * when we put another box on top it will be different
     * by the value of linewidth. If we don't save the GS
     * the current path is cleared by the fill command.
     */
    fprintf(fp, "%.2lf setgray\n", gray_scale);
    fprintf(fp, "gsave\n");
    fprintf(fp, "fill\n");
    fprintf(fp, "grestore\n");
    /* Take out the next line if you want the outline to be
       the same as the fill color */
    fprintf(fp, "0 setgray\n");
    fprintf(fp, "0.2 LW\n");
    fprintf(fp, "stroke\n");
}


void draw_labeled_rect(FILE *fp, double x, double y, double height, 
	double width, double gray_scale, double top_offset, char *label)
{
  /* Draw a rectangle and put a label on it, centered along a 
   * horizontal line top_offset from the top of the rectangle.
   ***NOTE(BUG) -- Right now code assumes that the label will fit across
   * the width of the rectangle.  Maybe input the default point size
   * and then scale it down or divide up the lines if there is room
   * to fit two or more lines of text in the bar
   */
  

  double y_value_label;

  /***** Draw the unfilled rectangle ******/
  draw_rect(fp, x, y, height, width, gray_scale);
  
  /** Don't put the label on if there isn\'t room **/
  if(height > 8){
  /***** Add the label ******/
  /* Set the font and point size */
  fprintf(fp, "/Times-Bold findfont 8 scalefont setfont\n");
  /* Center the label */
  y_value_label = (height * top_offset) + y - 4;
  
  fprintf(fp, "%.2lf (%s) stringwidth pop sub\n", width, label);
  fprintf(fp, "2 div %.21f add %.2lf moveto\n", x, y_value_label);
  /* Put the label on */
  fprintf(fp, "0 setgray (%s) show\n", label);}

}


void draw_pie_chart(FILE *fp, char *title, char **pie_labels, 
	double *pie_fractions, int num_slices)
{

  int i;

  /** Pie chart code from p.183 of the PS tutorial **/
  /* Only a few comments, explained well in the book if you're
   * that interested! */

  /* DrawSlice procedure */
  fprintf(fp, "/PieDict 24 dict def\n");
  fprintf(fp, "PieDict begin\n");
  fprintf(fp, "/DrawSlice\n");
  fprintf(fp, "{ /grayshade exch def\n");
  fprintf(fp, "/endangle exch def\n");
  fprintf(fp, "/startangle exch def\n");
  fprintf(fp, "/thelabel exch def\n");

  fprintf(fp, "newpath 0 0 moveto 0 0 radius startangle endangle arc\n");
  fprintf(fp, "closepath\n");
  fprintf(fp, "1.415 setmiterlimit\n");
  
  fprintf(fp, "gsave grayshade setgray fill grestore\n");
  fprintf(fp, "stroke\n");
  fprintf(fp, "gsave startangle endangle add 2 div rotate\n");
  fprintf(fp, "radius 0 translate\n");
  fprintf(fp, "newpath\n");
  fprintf(fp, "0 0 moveto labelps .8 mul 0 lineto stroke\n");
  fprintf(fp, "labelps 0 translate\n");
  fprintf(fp, "0 0 transform\n");
  fprintf(fp, "grestore\n");
  fprintf(fp, "itransform\n");
  fprintf(fp, "/y exch def /x exch def\n");
  fprintf(fp, "x y moveto\n");

  fprintf(fp, "x 0 lt\n");
  fprintf(fp, "{ thelabel stringwidth pop neg 0 rmoveto } if \n");
  fprintf(fp, "y 0 lt { 0 labelps neg rmoveto } if \n");
  fprintf(fp, "thelabel show\n");
  fprintf(fp, "} def\n");

  
  /* findgray procedure */
  fprintf(fp, "/findgray\n");
  fprintf(fp, "{ /i exch def /n exch def\n");
  fprintf(fp, "i 2 mod 0 eq\n");
  fprintf(fp, "{ i 2 div n 2 div round add n div }\n");
  fprintf(fp, "{i 1 add 2 div n div}\n");
  fprintf(fp, "ifelse \n");
  fprintf(fp, "} def end\n");

  
  /* DrawPieChart procedure */
  fprintf(fp, "/DrawPieChart\n");
  fprintf(fp, "{ PieDict begin\n");
  fprintf(fp, "/radius exch def\n");
  fprintf(fp, "/ycenter exch def /xcenter exch def\n");
  fprintf(fp, "/PieArray exch def\n");
  fprintf(fp, "/labelps exch def /titleps exch def /title exch def\n");
  
  fprintf(fp, "gsave xcenter ycenter translate\n");
  fprintf(fp, "/Helvetica findfont titleps scalefont setfont\n");
  fprintf(fp, "title stringwidth pop 2 div neg radius neg\n");
  fprintf(fp, "titleps 3 mul sub moveto\n");
  fprintf(fp, "title show\n");
  fprintf(fp, "/Helvetica findfont labelps scalefont setfont\n");
  fprintf(fp, "/numslices PieArray length def\n");
  fprintf(fp, "/slicecnt 0 def\n");
  fprintf(fp, "/curangle 0 def\n");

  fprintf(fp, "PieArray\n");
  fprintf(fp, "{/slicearray exch def\n");
  fprintf(fp, "slicearray aload pop\n");
  fprintf(fp, "/percent exch def /label exch def\n");
  fprintf(fp, "/perangle percent 360 mul def\n");
  fprintf(fp, "/slicecnt slicecnt 1 add def\n");
  fprintf(fp, "label curangle curangle perangle add numslices slicecnt\n");
  fprintf(fp, "findgray DrawSlice\n");
  fprintf(fp, "/curangle curangle perangle add def\n");
  fprintf(fp, "} forall grestore end } def\n");


  /* Put on the specific array for our chart */
  fprintf(fp, "(%s) 24 12\n", title);
  fprintf(fp, "[\n");
  
  for(i = 0; i < num_slices; i++)
    fprintf(fp, "[(%s) %.4lf]\n", pie_labels[i], pie_fractions[i]);
  
  fprintf(fp, "] 306 396 140 DrawPieChart\n");

}
     

void draw_axes(FILE *fp, int xnum, double *xval, char **xlabel, int ynum, 
	double *yval, char **ylabel, char *y_name, char *x_name, 
	double xscale, double yscale, double dotted_val, int rotate)
{
    int i;
    double prev, next, current, small_y, yax;
    time_t now;

    now = time((time_t *) 0);

    /* set origin appropriately  - translate sets postscript 0,0 to the */
    /* origin of this set of axes - this holds for the entire page */

    /* if smallest y value > 0, set origin at 0, else at the lowest neg val. */
    small_y=0.0;
    for (i=0; i<ynum; i++) {
      if (yval[i] < small_y) small_y=yval[i];
    }

    if (rotate) {
        /* make x-axis run along long side of page */
        /* axis length: x=700, y=462 */
      if (mpi_interface.rank==0) {
        fprintf(fp,"%d %d translate\n",512,72);
	fprintf(fp,"90 rotate\n");
	fprintf(fp,"0 0 moveto\n");
	fprintf(fp,"GS 0.5 LW 650 0 rlineto stroke GR\n");
	fprintf(fp,"GS 655 0 rmoveto /Times-Roman FF 14 SF F (%s)S GR\n",
		x_name);
	fprintf(fp,"GS 0.5 LW 0 462 rlineto stroke GR\n");
	fprintf(fp,"GS 0 472 rmoveto /Times-Roman FF 14 SF F (%s)S GR\n",
		y_name);
	/* draw dotted line - y = dotted_val */
	fprintf(fp,"0 %.2lf moveto\n", ((dotted_val-small_y)*yscale));
	fprintf(fp,"GS 0.5 LW %s 650 0 rlineto stroke GR\n",EVEN_DASH);
	
	fprintf(fp,"580 -70 moveto\n");
	fprintf(fp,"/Times-Roman FF 10 SF F\n");
	fprintf(fp,"(%s) show\n", ctime(&now));
      }
    } else {
      if (mpi_interface.rank==0) {
        /* make x-axis run along bottom of page (short side) */
        /* axis length: x=520, y=642 */
        fprintf(fp,"%d %d translate\n",72,100);
	fprintf(fp,"0 0 moveto\n");
	fprintf(fp,"GS 0.5 LW 520 0 rlineto stroke GR\n");
	fprintf(fp,"GS 0.5 LW 0 642 rlineto stroke GR\n");
	fprintf(fp,"GS 0 652 rmoveto /Times-Roman FF 14 SF F (%s)S GR\n",
		y_name);
	/* draw dotted line - y = dotted_val */
	fprintf(fp,"0 %.2lf moveto\n", ((dotted_val-small_y)*yscale));
	fprintf(fp,"GS 0.5 LW %s 520 0 rlineto stroke GR\n",EVEN_DASH);
      }
    }

    /* draw x-axis features */
    prev = 0.0; 
    for (i=0; i<xnum; i++) {
        current = xval[i]*xscale;
	next = (i < xnum-1) ? (xval[i+1]*xscale) : 999.9;

	if(next-current < 5.0) {
	    if(current-prev > 6.0) current -= 1.0;
	}
	if (mpi_interface.rank==0) {
	  fprintf(fp,"%.2lf -4 moveto\n",current);
	  fprintf(fp,"GS 0.5 LW 0 2 rmoveto 0 4 rlineto stroke GR\n");
	  fprintf(fp,"GS -90 rotate 0 -3 rmoveto /Times-Roman FF 8 SF F (%s)S GR\n",
		xlabel[i]);
	}
	prev = current;
    }

    /* translate y-axis for any subsequent drawing */

    yax = small_y * yscale * (-1.0);
  if (mpi_interface.rank==0)  fprintf(fp,"0 %.2lf translate\n",yax);

    /* draw y-axis features */

    for(i=0; i<ynum; i++) {
      if (mpi_interface.rank==0) {
        fprintf(fp,"-4 %.2lf moveto\n", ((double)yval[i]*yscale));
	fprintf(fp,"GS 0.5 LW 9 0 rlineto stroke GR\n");
	fprintf(fp,"GS -3 -3 rmoveto /Times-Roman FF 9 SF F (%s)SR GR\n",
		ylabel[i]);
      }
    }


}


void draw_x(FILE *fp)
{
    fprintf(fp,"GS -3 -3 rlineto stroke GR\n");
    fprintf(fp,"GS 3 3 rlineto stroke GR\n");
    fprintf(fp,"GS 3 -3 rlineto stroke GR\n");
    fprintf(fp,"GS -3 3 rlineto stroke GR\n");
}


void ps_file_start(FILE *fp)
{
    fprintf(fp,"%%!PS-Adobe-3.0\n");
    fprintf(fp,"%%%%Creator: MAPMAKER\n");
    fprintf(fp,"%%%%LanguageLevel: 1\n");
    fprintf(fp,"%%%%PageOrder: Special\n");

    fprintf(fp,"%%%%BeginProlog\n");
    fprintf(fp,"%%%%BeginResource: procset Map_Painter_prolog\n");
    fprintf(fp,"/Map_Painter_prolog 100 dict def\n");
    fprintf(fp,"Map_Painter_prolog begin\n");
    fprintf(fp,"/CF {dup 0 eq\n");
    fprintf(fp,"       {pop /Times-Bold}\n");
    fprintf(fp,"       {1 eq {/Times-Roman} {/Times-Italic} ifelse}\n");
    fprintf(fp,"     ifelse} def\n");
    fprintf(fp,"/F {setfont} def\n");
    fprintf(fp,"/FF {findfont} def\n");
    fprintf(fp,"/GM {restore} def\n");
    fprintf(fp,"/GR {grestore} def\n");
    fprintf(fp,"/GS {gsave} def\n");
    fprintf(fp,"/LC {currentpoint pop dup /l exch def add /r exch def\n");
    fprintf(fp,"     counttomark 3 idiv {\n");
    fprintf(fp,"       currentpoint pop r ge {l currentpoint exch pop LLD sub moveto} if\n");
    fprintf(fp,"       LD\n");
    fprintf(fp,"     } repeat pop} def\n");
    fprintf(fp,"/LD {/f exch def /n exch def /p exch def\n");
    fprintf(fp,"     p length 0 ne {\n");
    fprintf(fp,"       /Times-Roman findfont LFS 1 sub scalefont setfont p show\n");
    fprintf(fp,"       2.5 0 rmoveto\n");
    fprintf(fp,"     } if\n");
    fprintf(fp,"     f CF findfont LFS scalefont setfont\n");
    fprintf(fp,"     n show 6 0 rmoveto} def\n");
    fprintf(fp,"/LM {save} def\n");
    fprintf(fp,"/LW {setlinewidth} def\n");
    fprintf(fp,"/S {show} def\n");
    fprintf(fp,"/SF {scalefont} def\n");
    fprintf(fp,"/SR {dup stringwidth pop neg 0 rmoveto show} def\n");
    fprintf(fp,"/TR {translate} def\n");
    fprintf(fp,"/XY {moveto} def\n");
    fprintf(fp,"/US {stringwidth 0 rlineto stroke } def\n");
    fprintf(fp,"/CS {dup stringwidth pop 2 div neg 0 rmoveto show} def\n");
    fprintf(fp,"end\n");
     fprintf(fp,"%%%%EndResource\n");
    fprintf(fp,"%%%%EndProlog\n");

    fprintf(fp,"/LFS 8 def /LLD 7.5 def\n");
    fprintf(fp,"%%%%BeginSetup\n");
    fprintf(fp,"Map_Painter_prolog begin\n");
    fprintf(fp,"gsave\n");
    fprintf(fp,"%%%%EndSetup\n");
}

void ps_file_end(FILE *fp)
{
    fprintf(fp,"%%%%Trailer\n");
    fprintf(fp,"grestore\n");
    fprintf(fp,"end %% Map_Painter_prolog\n");
    fprintf(fp,"%%%%EOF\n");
}

void ps_page_start(FILE *fp, int pagenum)
{
    fprintf(fp,"%%%%Page: ? %d\n",pagenum);
    fprintf(fp,"%%%%BeginPageSetup\n");
    fprintf(fp,"LM\n");
    fprintf(fp,"%%%%EndPageSetup\n");
}

void ps_page_end(FILE *fp, int pagenum)
{
    /**********
    time_t now;
    now = time((time_t *) 0);
    * Move to the bottom left hand corner to print the page number and date *
    fprintf(fp,"600 -90 moveto\n");
    fprintf(fp,"/Times-Roman FF 10 SF F\n");
    fprintf(fp,"(page %d - ) show\n", pagenum);
    fprintf(fp,"(%s) show\n", ctime(&now));
    **********/
    fprintf(fp,"GM showpage\n");
}



void do_bezier(FILE *fp, double *xval, double *yval, int num_points, 
	double s0, double sn, char *line_type, double xscale, double yscale)
{
    int i, j;
    double *x0, *x1, *x2, *x3, *y0, *y1, *y2, *y3, *slope, s1, s2;

    x0 = (double *) malloc (num_points * sizeof(double));
    x1 = (double *) malloc (num_points * sizeof(double));
    x2 = (double *) malloc (num_points * sizeof(double));
    x3 = (double *) malloc (num_points * sizeof(double));
    y0 = (double *) malloc (num_points * sizeof(double));
    y1 = (double *) malloc (num_points * sizeof(double));
    y2 = (double *) malloc (num_points * sizeof(double));
    y3 = (double *) malloc (num_points * sizeof(double));
    slope = (double *) malloc (num_points * sizeof(double));

    /* Bezier functionality draws an appropriate curve between points (x0,y0)
       and (x3,y3) based on Bezier cubic control points (x1,y1) and (x2,y2)
       (x1,y1) lies on the tangent from (x0,y0) and (x2,y2) lies on the tangent
       from (x3,y3) with x0 < x1 < x2 < x3 for our cases since 
       x3 = x0 + scan_interval_length (usually 2 cM) */


    /* (x0,y0) and (x3,y3) are the known data points, scaled to size of page */
 
    for(i = 0; i < num_points-1; i++) {
        x0[i] = xval[i]*xscale + XZERO;
	y0[i] = yval[i]*yscale + YZERO;
	x3[i] = xval[i+1]*xscale + XZERO;
	y3[i] = yval[i+1]*yscale + YZERO;
    }

    /* estimate the slope of the tangent at each data point...given three 
       points on a curve (x1,y1) (x2,y2) (x3,y3), a good guess for the 
       slope of the tangent at (x2,y2) is the average of the slopes of the 
       lines connecting (x1,y1)(x2,y2) and (x2,y2)(x3,y3) - since this method 
       does not work for the first or last point on the curve for obvious 
       reasons, those values are handed into the function as s0 and sn...
       usually values of 0.0 will be just fine */

    slope[0] = s0;
    for(i = 1; i < num_points-1; i++) {
        if (x3[i-1]==x0[i-1]) s1=0.0; /* discontinuity */ 
	else s1 = (y3[i-1]-y0[i-1])/(x3[i-1]-x0[i-1]);
	if (x3[i]==x0[i]) s2=0.0; /* discontinuity */
	else s2 = (y3[i]-y0[i])/(x3[i]-x0[i]);

	slope[i] = (s1+s2)/2.0;
	if(slope[i] > 10.0) slope[i] = 10.0;
	if(slope[i] < -10.0) slope[i] = -10.0;
    }
    slope[i] = sn;


    /* calculate points (x1,y1) and (x2,y2) now that we have approximate 
       tangent lines for our real data points */

    for(i = 0; i < num_points-1; i++) {
        x1[i] = (x3[i]-x0[i])/3.0;
	y1[i] = y0[i] + x1[i]*slope[i];
	x2[i] = x1[i];
	y2[i] = y3[i] - x2[i]*slope[i+1];
	x1[i] += x0[i];
	x2[i] += x1[i];
    }

    /* Postscript conveniently draws a Bezier cubic section from the current 
       position to position (x3,y3) based on the calculated control points
       (x1,y1) and (x2,y2) */

   if (mpi_interface.rank==0) fprintf(fp,"%.2lf %.2lf moveto\n",x0[0],y0[0]);

    for(i = 0; i < num_points-1; i++) {
        if (x0[i]!=x3[i]) {
	 if (mpi_interface.rank==0) fprintf(fp,
	      "GS %s %.4lf %.4lf %.4lf %.4lf %.4lf %.4lf curveto stroke GR\n",
		  line_type, x1[i], y1[i], x2[i], y2[i], x3[i], y3[i]);
	}
       if (mpi_interface.rank==0) fprintf(fp,"%.4lf %.4lf moveto\n", x3[i], y3[i]);
    }
   if (mpi_interface.rank==0) fprintf(fp,"%.4lf %.4lf moveto\n", x3[i-1], y3[i-1]);
     
    free (x0);
    free (x1);
    free (x2);
    free (x3);
    free (y0);
    free (y1);
    free (y2);
    free (y3);
    free (slope);
}

void print_poster(FILE *fp)
{
    /* Directly from the postscript cookbook, pg. 179 */

    fprintf(fp,"/printposter\n");
    fprintf(fp,"{\n");
    fprintf(fp,"/rows exch def\n");
    fprintf(fp,"/columns exch def\n");
    fprintf(fp,"/bigpictureproc exch def\n");
    fprintf(fp,"newpath\n");
    fprintf(fp,"leftmargin botmargin moveto\n");
    fprintf(fp,"0 pageheight rlineto\n");
    fprintf(fp,"pagewidth 0 rlineto\n");
    fprintf(fp,"0 pageheight neg rlineto\n");
    fprintf(fp,"closepath clip\n");
    fprintf(fp,"leftmargin botmargin translate\n");
    fprintf(fp,"0 1 rows 1 sub\n");
    fprintf(fp,"{/rowcount exch def\n");
    fprintf(fp,"0 1 columns 1 sub\n");
    fprintf(fp,"{/colcount exch def\n");
    fprintf(fp,"gsave\n");
    fprintf(fp,"pagewidth colcount mul neg\n");
    fprintf(fp,"pageheight rowcount mul neg\n");
    fprintf(fp,"translate\n");
    fprintf(fp,"bigpictureproc\n");
    fprintf(fp,"gsave showpage grestore\n");
    fprintf(fp,"grestore\n");
    fprintf(fp,"}for\n");
    fprintf(fp,"}for\n");
    fprintf(fp,"}def\n");
}

void draw_centered_rect(FILE *fp, double x_center, double y_center,
			double height, double width, double gray_scale, 
			char *label, int label_font_size)
{

  /* Draws a rectangle centered around the point (x_center,y_center)
     and fills and outlines it with the specified shade of gray */
  double x_start,y_start;
  double y_value_label;

  x_start = x_center-(width/2.0);
  y_start = y_center+(height/2.0);

  /* Create the path of the rectangle */
    fprintf(fp, "newpath\n");
    fprintf(fp, "%.2lf %.2lf moveto\n", x_start, y_start);
    fprintf(fp, "0 -%.2lf rlineto\n", height);
    fprintf(fp, "%.2lf 0 rlineto\n", width);
    fprintf(fp, "0 %.2lf rlineto\n", height);
    fprintf(fp, "-%.2lf 0 rlineto\n", width);
    fprintf(fp, "closepath\n");
    
    
    
    /* Need to store and retrieve the state so that we can
     * also outline the rectangle. If we don't outline it,
     * when we put another box on top it will be different
     * by the value of linewidth. If we don't save the GS
     * the current path is cleared by the fill command.
     */
    fprintf(fp, "%.2lf setgray\n", gray_scale);
    fprintf(fp, "gsave\n");
    fprintf(fp, "fill\n");
    fprintf(fp, "grestore\n");
    /* Take out the next line if you want the outline to be
       the same as the fill color */
    fprintf(fp, "0 setgray\n");
    fprintf(fp, "0.2 LW\n");
    fprintf(fp, "stroke\n");

  fprintf(fp, "/Times-Bold findfont %d scalefont setfont\n",
	  label_font_size);
  y_value_label = y_start - height - label_font_size;
  fprintf(fp, "%.2lf (%s) stringwidth pop sub\n", width, label);
  fprintf(fp, "2 div %.21f add %.2lf moveto\n", x_start, y_value_label);
  /* Put the label on */
  fprintf(fp, "0 setgray (%s) show\n", label);

  
}
  
void draw_circle (FILE *fp, double x_center, double y_center, double diameter,
		  double gray_scale, char *label, int label_font_size)
{

  /* Draw a circle and put a label at the bottom */
  double y_value_label;

  fprintf(fp, "%.2lf %.2lf moveto\n", x_center, y_center);
  fprintf(fp, "newpath\n");
  fprintf(fp, "%.2lf %.2lf %.2lf 0 360 arc\n",x_center, 
	  y_center, diameter/2.0);
  fprintf(fp, "closepath\n");

  fprintf(fp, "%.2lf setgray\n", gray_scale);
  fprintf(fp, "gsave\n");
  fprintf(fp, "fill\n");
  fprintf(fp, "grestore\n");
  /* Take out the next line if you want the outline to be
     the same as the fill color */
  fprintf(fp, "0 setgray\n");
  fprintf(fp, "0.2 LW\n");
  fprintf(fp, "stroke\n");


  fprintf(fp, "/Times-Bold findfont %d scalefont setfont\n",label_font_size);
  y_value_label = y_center - (diameter/2.0) - label_font_size;
  fprintf(fp, "%.2lf (%s) stringwidth pop sub\n", diameter, label);
  fprintf(fp, "2 div %.21f add %.2lf moveto\n", x_center-(diameter/2.0), 
	  y_value_label);
  /* Put the label on */
  fprintf(fp, "0 setgray (%s) show\n", label);
}


char *line_choice(int order)
{
    switch(order) {
        case 0: return(THICK_LINE);
        case 1: return(THIN_LINE);
        case 2: return(DOTTED2);
        case 3: return(EVEN_DASH);
        case 4: return(DASH42);
        case 5: return(DOTTED1);
        case 6: return(DASH24);
        case 7: return(BIG_DASH);
        case 8: return(SMALL_DASH);
        default: return(SOLID_LINE);
    }
}
