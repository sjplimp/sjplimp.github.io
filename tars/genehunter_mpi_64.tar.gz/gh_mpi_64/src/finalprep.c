/* GENEHUNTER - Kruglyak, Daly, Reeve-Daly, and Lander
   Whitehead Institute for Biomedical Research, Copyright 1996 */
/*G. Conant added mpi includes*/
#include "mpi_info.h"
/*G. Conant added timing function include*/
#include "timing.h"


#define INC_LIB

/*G. Conant added INC_SHELL define for c++ compile*/
#define INC_SHELL
#include "npl.h"
#include "time.h"

#ifdef _TEST_PVCT
double *test_pvct;
#endif


#define REMOVE_BITS

/* for FindIllegalBits() */
#define COMP_GENOTYPES(a,b,c,d) ((a==c && b==d) || (a==d && b==c))

/* For Debugging and Testing, define as necessary: */
#undef PR_00
#undef PR_01
#undef PR_02  /* not used */
#undef PR_03
#undef PR_04
#undef PR_05
#undef PR_06
#undef PR_07  /* not used */
#undef PR_08  /* not used */
#undef PR_09  /* not used */
#undef PR_10  /* not used */
#undef PR_11  /* not used */
/* warning: if use pr_12 or 13, must define both to either 0 or 1 (or non-0)*/
/*   define PR_12 1 and define pr_13 0  */
#undef PR_12 /* search result absolute restrictions*/
#undef PR_13 /* search result relative restrictions*/
#undef PR_14  /* not used */
#undef PR_15
#undef PR_16
#undef PR_17
#undef PR_18
#undef PR_19  /* Debugging for maskHomP */
#undef PR_20  /* not used */

/* partition prior computation */
/* set to 1 as necessary: */
#define SKIP_SHORTCUT 0
#define TEST_SHORTCUT 0
#define EXIT_EARLY 0
#define COMPUTE_SIZE_ONLY 0

#undef DUMP_SINGLE_P_INFOC
#undef DUMP_TIME


static long long int **maskTest=NULL;
static long long int *maskHomP;
static int inconsistent_genotypes[MAXLOCI];
static double  pr_time[200], pr_time_all=0;

/* Internal methods */
void prep_linkage_pedigree(char*);
void analyze_family(int);
void orig_haplotypes (int,int*,int**,int**,int**);
void draw_pedigree(int,int,int*,char*,int**,int*,int*,int,int**,int,int**);

int total_meioses;
int total_affecteds[12];
FILE *haplofp;

static int sorted_ped[MAX_INDIVIDUALS]; /* Store the indices of
					   famtree sorted so that all
					   ancestors are at the front
					   of the list */
static bool placed[MAX_INDIVIDUALS]; /* Boolean list same length as famtree
					 indicating whether or not the 
					 corresponding indiv in famtree has 
					 been placed yet or not */
static int num_placed;
         /* Keep track of how many individuals have been placed */

double npl_pos, npl_max;


command pedigree_prep(void)
{

  /* Determine the type of pedigree we are dealing with (LINKAGE
     or our own internal format and call the appropriate method) */

  char *filename,s1[100],*hfilename;
  FILE *fpin;
  void prep_stanford_pedigree(char*),prep_linkage_pedigree(char*);
  int i,j,k,n,a,b,c,d,e;
  double theta, chisq, diff, sum, chisq_prob(double,double), total_total;
  int temp_ser, temp_hap, temp_num_in_map_order, temp_map[MAXLOCI];

  if (num_markers == 0) {
    print("Please load marker information using 'load markers' first.\n");
    return;
  }

  run {

    filename = get_temp_string();
    use_uncrunched_args();
    get_one_arg(stoken,"",filename);
	  
    if (nullstr(filename)) print("need filename as argument\n");
    
    fpin = open_file(filename,"r");
    fgetln(fpin);
    while(nullstr(ln)) fgetln(fpin);

    n = sscanf(ln,"%s %d %d %d %d %d",s1,&a,&b,&c,&d,&e);
    close_file(fpin); fpin=NULL;

    if (n > 0) {

      hfilename = get_temp_string();
      strcpy(hfilename,"haplo.dump");
      haplofp = open_file(hfilename,"w");

      if (single_point_mode) {
	temp_ser = show_expected_recs; show_expected_recs=FALSE;
	temp_hap = haplotype_output;   haplotype_output=FALSE;
	temp_num_in_map_order = num_in_map_order;
	for (i=0; i < num_in_map_order; i++) temp_map[i] = map_order[i];
	num_in_map_order = num_markers;
	for (i=0; i<num_markers; i++) map_order[i]=i;
      }

      total_meioses=0; 
      prep_linkage_pedigree(filename); /* LINKAGE has 6 or more fields */

      if (show_expected_recs && num_pedigrees>1) {
	  total_total=0.0;
	  sf(ps,"TOTAL RECOMBINATION COUNT (%d total meioses):\n",
	     total_meioses); pr();
	  print("interval   theta  exp-recs obs-recs\n");
	  for (i=0; i<num_in_map_order-1; i++) {
	    theta = dist_to_rec(map_distance[i]);
	    sf(ps,"%4d-%-4d %6.4lf %8.3lf %8.3lf\n",map_order[i]+1,
	       map_order[i+1]+1,theta,theta*total_meioses,total_recs[i]);
	    pr();
	    total_total += total_recs[i];
	  }
	  sf(ps,"RECTOT = %.2lf\n",total_total); pr(); 
      }
      unarray(total_recs, double);

     
	close_file(haplofp);

#ifdef TDT_ACTIVE
      if (haplotype_output) {
	/* TDT-results */
	for (k=0; k<1; k++) { /* was 12 */
	  /**********
	  sf(ps,"TDT Summary - GROUP %d - (%d non-original affecteds):\n",
	     k+1, total_affecteds[k]); pr();
	  **********/
	  sf(ps,"TDT Summary - (%d non-original affecteds):\n",
	     total_affecteds[k]); pr();

	  for (i=0; i<num_in_map_order; i++) {
	    sf(ps,"Marker %-3d       trans untrans  Chi2  p-val\n",map_order[i]+1); pr();
	    for (j=0; j<MAX_ALLELE_SIZE; j++) {
	      if (locus[map_order[i]].allele_count[j][k][0] > 0 ||
		  locus[map_order[i]].allele_count[j][k][1] > 0) {
		diff = (double) (locus[map_order[i]].allele_count[j][k][0] -
				 locus[map_order[i]].allele_count[j][k][1]);
		sum = (double)  (locus[map_order[i]].allele_count[j][k][0] +
				 locus[map_order[i]].allele_count[j][k][1]);
		chisq = diff*diff/sum;
		sf(ps,"M%-3d - Allele %-3d  %4d  %4d   %6.2lf  %.6lf\n",
		   map_order[i]+1, j,
		   locus[map_order[i]].allele_count[j][k][TRANSMITTED],
		   locus[map_order[i]].allele_count[j][k][UNTRANSMITTED],
		   chisq, chisq_prob(1.0, chisq)); pr();
	      }
	    }
	  }
	}
      }
#endif

      if (single_point_mode) {
	show_expected_recs= temp_ser;
	haplotype_output= temp_hap;
	num_in_map_order= temp_num_in_map_order;
	for (i=0; i<num_in_map_order; i++) {
	  map_order[i] = temp_map[i];
	}
      }
      
    } else { 
      sf(ps,"error: can't recognize first line of pedigree file (%s)\n",ln);
      pr();
    }

    scan_done = TRUE; /*** new ***/
  } on_error {
    if (msg == CANTOPEN) {
      sf(ps,"Can't open file '%s'\n",filename); pr();
    } else {
      relay_messages;
    }
  }

}


void prep_stanford_pedigree(char *filename)
{

  /* eliminated to save space */
  error("old pedigree format - not supported");
}

/*********************************/
/* LINKAGE PEDIGREE READING CODE */
/*********************************/



typedef struct {
  int dad;
  int mom;
  int num_kids;
  int kid[MAX_KIDS];
  int pivot;
  bool inbred;        

  /* the following vars are for inbred families (or families in their loop)*/
  int num_common_anc; /* Number of ancestors in common between the mom&dad of this
			 nuclear family, for half-sibs it would be 1, in most other
			 cases it will be 2. */
  int dad_to_common;  /* Number of pedigree levels to the common ancestor.  For */
  int mom_to_common;  /* sibs marrying each other 0 levels, 1st cousins 1, etc */

  bool in_loop;
  int loop_indiv;

} NUC_FAMILY;

static NUC_FAMILY nuc_fam[MAX_INDIVIDUALS];
static int num_nuc_fam;
static int num_nuc_fams_to_peel;
/*G. Conant made int for c++ compile*/
static int order_assigned[MAX_INDIVIDUALS];

#define MISSING (-1) /* Value to set uncalculated fields to */
#define MALE 1
#define FEMALE 2
static char current_ped[MAX_NAME_SIZE];
int allele_data[MAX_INDIVIDUALS][MAXLOCI*2];
int num_allele_data[MAX_INDIVIDUALS];
char **pedigree_data;
int allele_offset;
int num_data;

/* Linkage pedigree auxiliary methods */
void set_mom_index(int,int);
void set_dad_index(int,int);
void check_for_unlinked(int);
void check_for_loop(int,int,int,int,int);
void sort_pedigree(int);
void place_indiv(int);
void fill_nuc_families(int);
int inbred_matings(void);
int mark_pivots(int);
void order_inbred_family(void);
int list_index;

/* Katz, Aug 2000, Check for Homozygote parents and only calc one prior
 *  prob for each equiv class, look up the rest.
 *  The mask maskHomP has a bit set for each homozygote parent 
 */

void CheckHomozygotes(int num_bits, int real_num_bits, int num_in_ped, 
							 int f_num, int uninformative_bit[], 
							 int f_map_order[], int non_originals) {

  int i, j, jj, k, kk, l, numkids;
  int thebit, theoldbit;


#ifdef PR_19
  printf("---------------doing CheckHomozygotes------------\n\n");
  printf("--NuminPed: %d, numbits: %d, real_numbits: %d, f_num: %d, non_originals: %d--\n", 
			num_in_ped, num_bits, real_num_bits, f_num, non_originals);
#endif


/* initialize */
  for (j=0; j < f_num; j++) 
	 maskHomP[j]=0;

  for (i=0; i < num_in_ped; i++) {
	 if (famtree[i].nkids == 0) continue;
	 numkids=0;
	 for (jj=0; jj < f_num; jj++) {
		j=f_map_order[jj];

		if ((allele_data[i][allele_offset+(2*j)] ==
			 allele_data[i][allele_offset+(2*j+1)]) &&
			 (allele_data[i][allele_offset+(2*j)] != 0))	{

#ifdef PR_19
		  printf ("Homozygote %d (%s), (has %d,%d) marker: %d(%d), kids=\n",
					 i, famtree[i].indiv_ID, 
					 allele_data[i][allele_offset+(2*j)],
					 allele_data[i][allele_offset+(2*j+1)],jj,j);
#endif

		  for (kk=0; kk < non_originals; kk++) {
			 k=sorted_ped[kk];
			 if (k == i) continue;
			 if (famtree[k].dad_index == i) {
				numkids++;
				thebit = (num_bits - (famtree[k].inh_vec_pos)*2 -1);
				theoldbit=thebit;
				for (l=0; l < theoldbit; l++)
				  if ((uninformative_bit[l]) && (thebit > 0))
					 thebit--;

#ifdef PR_19
				printf ("     %d(%s) - Dad (bit %d (from %d))\n", 
						  k, famtree[k].indiv_ID, thebit,famtree[k].inh_vec_pos);
				if (famtree[k].dad_bit_uninf)
				  printf ("    *****Dad bit unif %d(%s)*****\n",
							 k, famtree[k].indiv_ID);

#endif
				if (famtree[k].discard) {
#ifdef PR_19
				  printf ("   ****Dad, discard this %d(%s)****\n",
							 k, famtree[k].indiv_ID);
#endif
				  continue;
				}

				if (!(famtree[k].dad_bit_uninf) && (thebit < real_num_bits))
					 maskHomP[jj] |= (1 << thebit);
				if (numkids == famtree[i].nkids) break;
			 }

			 if (famtree[k].mom_index == i) {
				numkids++;
				thebit = (num_bits - (famtree[k].inh_vec_pos)*2 -2);
				theoldbit=thebit;
				for (l=0; l < theoldbit; l++)
				  if ((uninformative_bit[l]) && (thebit > 0))
					 thebit--;

#ifdef PR_19
				printf ("     %d(%s) = Mom (bit %d (from %d))\n",
						  k, famtree[k].indiv_ID, thebit,famtree[k].inh_vec_pos);
				if (famtree[k].mom_bit_uninf)
				  printf ("    *****Mom bit unif %d(%s)*****\n",
							 k, famtree[k].indiv_ID);
#endif
				if (famtree[k].discard) {
#ifdef PR_19
				  printf ("   ****Mom, discard this %d(%s)****\n",
							 k, famtree[k].indiv_ID);
#endif
				  continue;
				}
					 if (!(famtree[k].mom_bit_uninf) && (thebit < real_num_bits))
						maskHomP[jj] |= (1 << thebit);

				if (numkids == famtree[i].nkids) break;
			 }
		  }
		}
#ifdef PR_19
		printf("----Mask for marker %d(from %d): %x\n----", j, jj, maskHomP[jj]);
#endif
	 }
  }
}



void prep_linkage_pedigree(char *filename)
{

  FILE *fpin;
  char ped_name[MAX_NAME_SIZE];
  char indiv_ID[MAX_NAME_SIZE];
  char father_ID[MAX_NAME_SIZE], mother_ID[MAX_NAME_SIZE];
  char *temp_data;
  int sex, j, datum, pedigrees_loaded;
  double rdatum;

  /* Open the input file with the LINKAGE format pedigrees, and
     the output file where the inheritance vectors will be written */

  num_pedigrees=0;


  run {
#ifdef GC_TIME
    gct_pre=gct_RunTime();
#endif
    fpin = NULL; 
    fpin = open_file(filename,"r");
    strcpy(current_filename, filename);

  } except_when(CANTOPEN) {
    sf(ps,"Can't open file: %s\n",filename); pr();
    return;
  }

  if(compute_sharing) allocate_pair_analysis_storage(); /*** new ***/
  array(famtree,MAX_INDIVIDUALS+5,PED_MEMBER);
  matrix(pedigree_data, MAXLOCI*2+MAX_PHENOTYPES, 256, char);
  run {
    list_index=0;
    strcpy(current_ped,"");
    while(1) {
      fgetln(fpin);
      if (!maxstoken(&ln,sREQUIRED,ped_name,MAX_NAME_SIZE)) {
	/* blank line, read the next line */
      }
      else {
	/* actual line of data */
	if (nullstr(current_ped)) {
	  /* Record the new pedigree information for the first pedigree */
	  strcpy(current_ped,ped_name);
	  num_pedigrees++;
	} else if (strcasecmp(current_ped,ped_name) != 0) {
	  /* This line is the start of a new pedigree,
	     dump out the old one and reset the list index to 0 */
	  analyze_family(list_index); /* scans the family */

	  strcpy(current_ped,ped_name);
	  list_index=0;
	  num_pedigrees++;
	}
	
	/* Read the individual's index within the pedigree */
	if (!maxstoken(&ln,sREQUIRED,indiv_ID,MAX_NAME_SIZE)) {
	  sf(ps,"bad input line - no indivdual ID"); error(ps);
	}
	/* Read the parents' indices in the pedigree */
	if (!maxstoken(&ln,sREQUIRED,father_ID,MAX_NAME_SIZE)) {
	  sf(ps,"bad input line - no paternal ID for indiv %s",
	     indiv_ID); error(ps);
	}
	if (!maxstoken(&ln,sREQUIRED,mother_ID,MAX_NAME_SIZE)) {
	  sf(ps,"bad input line - no maternal ID for indiv %s",
	     indiv_ID); error(ps);
	}
	/* Read the sex of the individual */
	if (!itoken(&ln,iREQUIRED,&sex)) {
	  sf(ps,"bad input line - no sex for individual %s",indiv_ID);
	  error(ps);
	}
	
	/* Record the information in the family tree struct */
	strcpy(famtree[list_index].indiv_ID,indiv_ID);
	strcpy(famtree[list_index].dad,father_ID);
	strcpy(famtree[list_index].mom,mother_ID);
	famtree[list_index].sex=sex;
	/* Initialize values to be filled in later */
	famtree[list_index].nkids=0;
	famtree[list_index].dad_index=MISSING;
	famtree[list_index].mom_index=MISSING;
	for (j=0; j<MAX_PHENOTYPES; j++)
	  famtree[list_index].phenotype[j]=MISSING_PHENO;
	for (j=0; j<MAX_COVARIATES; j++)
	  famtree[list_index].covariate[j]=0.0;

	/* Check that this isn't a duplicate indiv_ID */
	for (j=0; j<list_index; j++)
	  if (!strcasecmp(famtree[j].indiv_ID,
			  famtree[list_index].indiv_ID)) {
	    sf(ps,"indiv %s appears more than once in pedigree %s",
	       famtree[list_index].indiv_ID,current_ped); error(ps);
	  }

	/* Read in the genotype and phenotype data */
	j=0;
	while (stoken(&ln,sREQUIRED,pedigree_data[j]))
	  j++;			

	num_data=j;
	if (num_data == 2*num_markers + num_phenotypes + num_covs + 1)
	  allele_offset = 1;
	else if (num_data == 2*num_markers + num_phenotypes + num_covs + 2)
	  allele_offset = 2;
	else {
	  sf(ps,"number of loci and phenotypes in pedigree file different from number in locus file - ped %s\n",
	     current_ped); 
	  error(ps);
	}

	/* Store the genotype data in static structs */
	temp_data = get_temp_string();
	for (j=0; j<(num_data-num_phenotypes); j++) {
	  strcpy(temp_data, pedigree_data[j]);
	  itoken(&temp_data, iREQUIRED, &datum);
	  allele_data[list_index][j]=datum;
	}
	num_allele_data[list_index]=j;

	/* Store the phenotype data in static structs */
	for (j=0; j<num_phenotypes; j++) {
	  strcpy(temp_data, pedigree_data[j+2*num_markers+allele_offset]);
	  if (strcasecmp(temp_data, "-")) {
	    rtoken(&temp_data, rREQUIRED, &rdatum);
	    famtree[list_index].phenotype[j]=rdatum;
	  }
	}

	/* Store the covariate data in static structs */
	for (j=0; j<num_covs; j++) {
	  strcpy(temp_data, pedigree_data[j+2*num_markers+num_phenotypes+allele_offset]);
	  if (strcasecmp(temp_data, "-")) {
	    rtoken(&temp_data, rREQUIRED, &rdatum);
	    famtree[list_index].covariate[j] = rdatum;
	  }
	}
	

	list_index++;
      }
    }	
    
    close_file(fpin);
    pedigrees_loaded=TRUE;
    unarray(famtree,PED_MEMBER);
    unmatrix(pedigree_data, MAXLOCI*2+MAX_PHENOTYPES, char);
  } except {
      when SOFTABORT: 
          pedigrees_loaded = FALSE;
          num_pedigrees = 0;
          close_file(fpin); fpin=NULL;
          unarray(famtree,PED_MEMBER);
          unmatrix(pedigree_data, MAXLOCI*2+MAX_PHENOTYPES, char);
          relay;
      when ENDOFILE:
          if (list_index > 0) {
	    pedigrees_loaded = TRUE;
	    run { 
#ifdef GC_TIME
    gct_post=gct_RunTime();
    if (mpi_interface.rank == 0)
      printf("Proc %d runtime for reading pedigree file: %d\n", mpi_interface.rank,
	   gct_post-gct_pre);
#endif
	      analyze_family(list_index); 
	      if(compute_sharing) extract_warray();  
	      if(compute_sharing) set_weights(-1); /* Sets weights for affectation analysis (default) */
	
	    }
	    on_error {
	      pedigrees_loaded = FALSE;
	    }
	  }

    
	     
	      close_file(fpin); fpin=NULL;

          unarray(famtree,PED_MEMBER);
	  unmatrix(pedigree_data, MAXLOCI*2+MAX_PHENOTYPES, char);

          break;
      default:
          close_file(fpin); fpin=NULL;
          unarray(famtree,PED_MEMBER);
          unmatrix(pedigree_data, MAXLOCI*2+MAX_PHENOTYPES, char);

          relay;
  }
 
}


int uninformative_bit[64];

void analyze_family(int num_in_ped)
{
  /*G. Conant uninformative_marker_r as a receive buffer*/
  int *uninformative_marker_r;
  int i, jj,k,mom,dad; 
  long long int j;
  int num_loci,originals,non_originals,real_non_originals;
  int num_vecs, cur_place, skip_ped, num_bits;
  long long int vec;
  int p0, p1, m0, m1, ptry[2], mtry[2], pall[2], mall[2], call[20];
  int pset0[10], pset1[10], mset0[10], mset1[10], pflag;
  /*G. Conant added total_s as a send buffer for MPI*/
  double prob, graph_assign_probs(long long int,int,int,int,int**,bool), total, total_s, *total_m, *total_mr;
  double *score=NULL, exp, exp_2, apm_score(int**,int), **pvector=NULL;
  /*G. Conant added exp_r, and exp_2_r as receive buffers*/
  double exp_r, exp_2_r;
  double score_npl_val;
  int num_aff, **affected_allele=NULL, parents_informative(int), score_count;
  int *uninformative_marker=NULL, num_inbred;
  int *best_pvector=NULL, has_data(int);
  long long int *num_real_vecs=NULL;
  void init_disease_probs(int);
  void peel(long long int,int);
  double brute_force_analyze(long long int,int,int);
  int nf,complexity,num_uninformative_bits,real_num_bits;
  long long int real_num_vecs,new_vec;
  long long int vec_previous;
  int **alleles_to_draw,**haplotype,new_real_num_bits,**inferred;
  TIME_TYPE this_time, last_time;
  int  vecpos, parent, this_parent,
      this_indiv, really_uninformative_bits;
  long long int count, *flip_mask=NULL, uninformative_mask;
  int dad0, dad1, mom0, mom1, dkid, mkid, found_kid;
  int old_mom, inb_fam, dis_geno;
  double saved_d_prob[4], this_prob;
  int legal_vector, iMarker, ibit, n_genotyped, 
    last_marker, i1, i2, i3, i4;
  long long int score_mask, score_mask_rdc, score_alloc;
  long amount_to_alloc;
  int    *nz_bits=NULL;
  long long int  *p_pnt=NULL, *nz_pointer=NULL;
  int    npl_pnt;
  double *pvct=NULL, *par_score=NULL;
  int     f_num_in_map_order, f_map_order[MAXLOCI], f_uninformative[MAXLOCI];
  int     npadMS;
  long long int padMask[64], padShift[64];
  int     *best_pvector_tmp=NULL;
  double  x_tmp;
  /*G. Conant added ibit3*/
  int ibit2, ibit3, misses=0;
  long long int lookfor;
  /*G. Conant added fill_p_flag*/
  int fill_p_flag;
	
#ifdef GC_TIME
  gct_pre=gct_RunTime();
#endif


  /* For all individuals, look up the person's mom and dad
     and record it in the pedigree structure */
  run {
    sf(ps,"\nanalyzing pedigree %s...\n",current_ped); pr();
    pr_time[10] = (double)clock()/(double)CLOCKS_PER_SEC;
    
    for (i=0; i<num_in_ped; i++) {
      set_dad_index(i,num_in_ped);
      set_mom_index(i,num_in_ped);
      famtree[i].analyzed_parent=FALSE; /* for counting inh. vec complexity */
      famtree[i].dad_bit_uninf=FALSE;
      famtree[i].mom_bit_uninf=FALSE;
      famtree[i].kids_found=FALSE; /* used later in bit chopping section */
    }
    
    for (i=0; i<num_in_ped; i++) famtree[i].discard=FALSE;
    
    /* get rid of unlinked individuals - set discard to TRUE */
    check_for_unlinked(num_in_ped);
    
    /* at this point we can eliminate from consideration:
       a) untyped individuals with no offspring in the pedigree
       b) those individuals that are unaffected, have no kids, and have 
       informative parents (they add next to nothing to an APM study) */
    
    for (i=0; i<num_in_ped; i++) {
      if (famtree[i].discard) continue;
      
      if (famtree[i].nkids == 0 && !has_data(i)) {
#ifdef DEBUGGING_OUTPUT
	sf(ps,"DISCARDING individual %s (pedigree leaf with no genotype data)\n",
	   famtree[i].indiv_ID); pr();
#endif
	famtree[i].discard = TRUE;
      }
      
      if (discard_unaffected) {
	/* discard_unaffected is a flag ("discard") set at command level */
	if ( famtree[i].nkids == 0 && 
	     allele_data[i][0] != 2 &&
	     parents_informative(i) ) {
#ifdef DEBUGGING_OUTPUT
	  sf(ps,"DISCARDING individual %s (unaffected leaf - informative parents)\n",
	     famtree[i].indiv_ID); pr();
#endif
	  famtree[i].discard = TRUE;
	}
      }
    }

    originals = non_originals = 0;
    cur_place=0;

   
    /* set placeholder alleles for original pedigree members */
    for (i=0; i<num_in_ped; i++) {
      if (famtree[i].dad_index == MISSING &&
	  famtree[i].mom_index == MISSING) {
	if (!famtree[i].discard) {
	  originals++;
	  famtree[i].place_allele[0]=cur_place; cur_place++;
	  famtree[i].place_allele[1]=cur_place; cur_place++;
	}
      }
      
      else if (famtree[i].dad_index == MISSING ||
	       famtree[i].mom_index == MISSING) {
        sf(ps,"person %s has ONE parent",famtree[i].indiv_ID); error(ps);
      }
      else {
	if (!famtree[i].discard) non_originals++;
	famtree[i].place_allele[0]=-1;
	famtree[i].place_allele[1]=-1;
      }
    }

    /* Now we need to figure out how many loci there are -
       if odd number of alleles, the first is affectation status 
       and there is no liability class column - if even number 
       of alleles, the first is affectation status and the 
       second is liability class */
    
    num_loci = num_markers;
    
    /* fill in affectation_status and liability_class in PED_MEMBERs */
    for (i=0; i<num_in_ped; i++) {
      famtree[i].affectation_status = allele_data[i][0];
      if (allele_offset == 2) famtree[i].liability_class = allele_data[i][1];
      else famtree[i].liability_class = 1;
    }

    /* now let's do a preliminary sort of non-originals so that
       we can accurately determine how much analysis needs to be done */

    /* new_sort_pedigree(); */
    sort_pedigree(num_in_ped);
    resort_pedigree(non_originals);
    
    /* now read through this sorted list of non_originals until we
       hit the limit of our analytic capabilities */
    
    really_uninformative_bits = 0;
    num_bits = real_num_bits = 0;
    real_non_originals = non_originals;
    
    for (i=0; i<non_originals; i++) {
      
      dad = famtree[sorted_ped[i]].dad_index;
      mom = famtree[sorted_ped[i]].mom_index;
      num_bits += 2;
      new_real_num_bits = real_num_bits+2;
      
      if (!famtree[dad].kids_found && famtree[dad].dad_index==MISSING && 
	  famtree[dad].mom_index==MISSING) {
	/* first kid of this father, hold bit fixed */
	famtree[sorted_ped[i]].dad_bit_uninf = TRUE;
	new_real_num_bits--;
	famtree[dad].kids_found=TRUE;
	/* debugging message */
#ifdef DEBUGGING_OUTPUT
	sf(ps,"dropping paternal bit of indiv %s\n",
	   famtree[sorted_ped[i]].indiv_ID); pr();
#endif
	if (famtree[dad].nkids == 1) really_uninformative_bits++;
      }
      
      if (!famtree[mom].kids_found && famtree[mom].dad_index==MISSING &&
	  famtree[mom].mom_index==MISSING) {
	/* first kid of this mother, hold bit fixed */
	famtree[sorted_ped[i]].mom_bit_uninf = TRUE;
	new_real_num_bits--;
	famtree[mom].kids_found=TRUE;
	/* debugging message */
#ifdef DEBUGGING_OUTPUT
	sf(ps,"dropping maternal bit of indiv %s\n",
	   famtree[sorted_ped[i]].indiv_ID); pr();
#endif
	    if (famtree[mom].nkids == 1) really_uninformative_bits++;
      }
      /*Changed for 64-bit--G. Conant*/
	if ((new_real_num_bits > max_bits_to_analyze) || (num_bits> 64)) {
	  /* we've hit the limit...can't accept this guy */
	  real_non_originals = i;
	  num_bits -= 2;
	  break;
	}
	real_num_bits = new_real_num_bits;

	/*Changed for 64-bit--G. Conant*/
	if ((new_real_num_bits == max_bits_to_analyze) || (num_bits == 64)) {
	  real_non_originals = i+1;
	  break;
	}
    }

  
    /* print out a most abject apology regarding our inability
       to analyze beyond a certain point within reasonable
       time and memory constraints */
    
    skip_ped=FALSE;
    
    if (real_non_originals < non_originals) {
      
      if (skip_large) {
	print("WARNING: Pedigree is too large to be computed!\n");
	print(
	      "To analyze you can either turn off the 'skip large' option which will\n");
	print(
	      "allow the program to discard less informative individuals or you may\n");
	print(
	      "raise the 'max bits' option which will allow larger pedigrees to be\n");
	print(
	      "analyzed while raising the time and memory requirements of the program.\n");
	skip_ped=TRUE; num_pedigrees--;
	    
      } else {
	sf(ps,
	   "WARNING: due to computation time and memory constraints, individual%s\n",
	   (non_originals-real_non_originals > 1)?"s":"");
	pr();
	for (i=real_non_originals; i<non_originals; i++) {
	  sf(ps,"%s ",famtree[sorted_ped[i]].indiv_ID); pr();
	  famtree[sorted_ped[i]].discard = TRUE;
	}
	sf(ps,"%s been dropped from the analysis.\n",
	   (non_originals-real_non_originals > 1)?"have":"has");
	pr();
      }
    }
    
    /* Now we should go through and discard any originals who
       have had all their kids discarded */
    
    /*****
	  for (i=0; i<num_in_ped; i++) {
	  if (famtree[i].dad_index == MISSING &&
	  famtree[i].mom_index == MISSING && !famtree[i].discard) {
	  found_kid=FALSE;
	  for (j=0; j<num_in_ped; j++) {         
	  if ((famtree[j].dad_index == i || famtree[j].mom_index == i) &&
	  !famtree[j].discard) {
	  found_kid=TRUE; break;
	  }
	  }
	  if (!found_kid) { famtree[i].discard=TRUE; originals--; }
	  }
	  }
    *****/
    
    if (non_originals <= 1) {
      sf(ps,"< 2 non-original members in pedigree %s...SKIPPING\n",
	 current_ped);
      pr();
      skip_ped = TRUE; num_pedigrees--;
    } 

    /*Changed for 64-bit--G. Conant*/
    if (!skip_ped && (num_bits > 64)) {
      sf(ps,"num_bits > 64 in pedigree %s...SKIPPING\n",
	 current_ped);
      pr();
      skip_ped = TRUE; num_pedigrees--;
    } 

    if (!skip_ped || (non_originals==1)) {
     
      /* Check for impossible loops */
      for (i=0; i<num_in_ped; i++) {
	/* We've already know that no one can be their own
	   direct parent so we'll start up a level */
	if (famtree[i].dad_index != MISSING) { /* If one parent is missing,both are*/
	  check_for_loop(i,famtree[i].sex,famtree[i].dad_index,1,num_in_ped);
	  check_for_loop(i,famtree[i].sex,famtree[i].mom_index,1,num_in_ped);
	}
      }

      /* Sort pedigree top down into a list */
      /* sort_pedigree(num_in_ped); already completed above */

      /********** bit count completed above 
	num_bits=0;
	for (i=0; i<non_originals; i++) {
        if (!famtree[sorted_ped[i]].dad_bit_uninf) num_bits++;
        if (!famtree[sorted_ped[i]].mom_bit_uninf) num_bits++;
	}
	if (num_bits > 16) error("too many individuals left...hackprep failed");
      **********/

      /* so now we have 2^2*non_originals possible pvectors but only
	 2^real_num_bits of those are interesting...to get them, we will
	 hold the uninformative bits at 0 while allowing all others
	 to be 0 or 1 */
   
    
      /* Fill the array of nuclear families */
      fill_nuc_families(num_in_ped);
    
      /* Count the number of inbred matings in the pedigree and
	 do the right thing if there are any */
      num_inbred = inbred_matings();
      if (num_inbred >= 1) {
	sf(ps,"family %s is inbred\n",current_ped); pr();
	/*** order_inbred_family(); ***/

	if (num_inbred == 1) {
	  /* break the first inbred marriage */
	  for (i=0; i<num_nuc_fam; i++) {
	    if (nuc_fam[i].inbred) {
	      inb_fam = i; 
	      break;
	    }
	  }

	  /* make fake individual (N=num_in_ped) with no parents
	     to be the new wife in this family */
	  old_mom = nuc_fam[inb_fam].mom;
	  nuc_fam[inb_fam].mom = num_in_ped;
	  famtree[num_in_ped].dad_index=MISSING;
	  famtree[num_in_ped].mom_index=MISSING;
	  famtree[num_in_ped].nkids = famtree[old_mom].nkids;

	  famtree[old_mom].nkids=0; /* temporarily */
	  num_in_ped++;
	} else {
	  /* more than one inbreeding loop - do by brute force
	     as if there were no inbreeding loops */
	  num_inbred=0;
	}
      }

      if (num_nuc_fam > 1) {
	  if (mark_pivots(num_in_ped) == -1) { 
	      if (!skip_ped) { skip_ped=TRUE; num_pedigrees--; }
	  } else {
	    if (num_inbred >= 1) {
	      /* fix variable that were corrupted for mark_pivots */
	      num_in_ped--;
	      famtree[old_mom].nkids=famtree[num_in_ped].nkids;
	    }
	    if (num_nuc_fams_to_peel == 0) {
	      /* if we still can't peel after breaking the loop
		 we want to go straight to brute_force and forget
		 the loop breaking stuff */
	      num_inbred=0; /* skip the inbred broken peeling stuff */
	    }
	  }
      } else {
	  /* Mark the interesting individuals so that they are
	     fully analyzed by the exhaustive method */
	  famtree[nuc_fam[0].dad].not_peeled=TRUE;
	  famtree[nuc_fam[0].mom].not_peeled=TRUE;
	  for (k=0; k<nuc_fam[0].num_kids; k++) 
	    famtree[nuc_fam[0].kid[k]].not_peeled=TRUE;

	  order_assigned[0]=0;
	  num_nuc_fams_to_peel=0;
      }
    }


	if(!skip_ped || (skip_ped && non_originals==1)) {
      /* now connect to graphing code for determining inh. vector probs */
		num_vecs=1;
		for (i=0; i<num_bits; i++) num_vecs *= 2;
		real_num_vecs=1;
		for (i=0; i<real_num_bits; i++) real_num_vecs *= 2;

		
  
		
	pr_time[20] = (double)clock()/(double)CLOCKS_PER_SEC;
/*----------------------------------------------------*/

	/* dangerous kludge 
	   meant to take care of repeated appearance of same marker 
	   when merging data sets from several groups */

		f_num_in_map_order =
		Define_family_map_order(originals, real_non_originals,
                            	num_in_map_order, map_order,
								f_map_order,
								f_uninformative,
								0);

	/*	printf("originals, real_non_originals, num_bits, real_num_bits = %d %d %d %d\n", 
		originals, real_non_originals, num_bits, real_num_bits);
		printf("---before FindIllegalBits num_in_map_order = %d\n", num_in_map_order);
	*/	
		/*Changed size from 1 to 2--G. Conant
		  matrix (maskTest, f_num_in_map_order, 1, long long int); */
		matrix (maskTest, f_num_in_map_order, 2, long long int);
		array (maskHomP, f_num_in_map_order, long long int);
		/* redundant call to fill_placeholder_alleles(..) to fill uninformative_bit[] array */
		fill_placeholder_alleles_2(0, 0, 0, real_non_originals,0);


		pr_time[30] = (double)clock()/(double)CLOCKS_PER_SEC;
		FindIllegalBits(originals, real_non_originals, num_bits, real_num_bits,
	                	f_num_in_map_order, f_map_order, f_uninformative);
		pr_time[35] = (double)clock()/(double)CLOCKS_PER_SEC;

 		CheckHomozygotes(num_bits, real_num_bits, num_in_ped, f_num_in_map_order,
							  uninformative_bit, f_map_order, non_originals);

		/* now obtain NPL score mask */

		Set_npl_score_masks(&score_mask, &score_mask_rdc, &score_alloc,
	                    	real_non_originals, num_bits);
		npl_pnt     = 0;
		/*G. Conant moved vec_previous initializations to after
		  mpi_initializations to allow distribution of calculation
		  vec_previous=-1;*/

	
		array(p_pnt,      num_in_map_order  , long long int);
		array(nz_bits,    num_in_map_order  , int);
		array(nz_pointer, num_in_map_order+1, long long int);
		
		nz_pointer[0] = 0;
		mpi_interface.real_markers=0;
		for(iMarker=0; iMarker<f_num_in_map_order; iMarker++) {
		  nz_bits[iMarker] = 0;
		  if(f_uninformative[iMarker]){
		    nz_pointer[iMarker+1] = nz_pointer[iMarker] + pow2[ nz_bits[iMarker] ];
		  } else {
		    mpi_interface.real_markers++;
		    for(ibit=0; ibit<real_num_bits; ibit++) {
		      if((maskTest[iMarker][0] & pow2[ibit]) == 0) nz_bits[iMarker]++;
		    }
		    nz_pointer[iMarker+1] = nz_pointer[iMarker] + pow2[ nz_bits[iMarker] ];
		  }
		}
		
		/*G. Conant--handles the distribution of markers and disease vector across procs*/
		mpi_distribution_setup(nz_bits, nz_pointer, &amount_to_alloc, f_num_in_map_order, 
				       maskTest, score_mask_rdc, f_uninformative, real_num_vecs, 
				       analysis_type, &score_alloc);
		
	
		if (dump_requirements) {
		    print_requirements(num_in_map_order, num_bits, real_num_bits, 
				       score_mask_rdc,
				       amount_to_alloc, score_alloc, nz_bits,
				       f_num_in_map_order,
				       f_uninformative);
		  }
		  
		  if((COMPUTE_SIZE_ONLY || dump_requirements) && 
		     !(skip_ped && non_originals==1)) {
		    unarray(nz_pointer, long long int);
		    unarray(nz_bits,    int);
		    unarray(p_pnt,     long long int);
		    unmatrix (maskTest, f_num_in_map_order, long long int);
		    unarray (maskHomP, long long int);
		    
		    skip_ped = TRUE; num_pedigrees--;
		  }
		
	}

    if (!skip_ped || (skip_ped && non_originals==1)) {
      if (mpi_interface.rank == 0) {
	printf("Proc %d allocating %d for pvct, %d for disease vct and %d for score vct\n", 
	       mpi_interface.rank, amount_to_alloc, mpi_interface.vecs_per_proc, score_alloc);
	printf("Total memory usage: %3.2fMB\n", 
	       (double)(8*3*amount_to_alloc+mpi_interface.vecs_per_proc+score_alloc)/(double)pow2[20]);
	flush();
      }
      run {

	  array(pvct, amount_to_alloc,    double);
    	if(analysis_type != NPL_ANALYSIS) {
	  
	  /* printf("----allocating par_score all\n"); */
	       /*Allocation changed for mpi--G. Conant*/
	  array(par_score,        mpi_interface.vecs_per_proc,      double);
	

	} else {
	  /* printf("----allocating nothing\n"); */
	  array(par_score,   1,  double); /* need to allocate it because it is passed a sub. argument */
	
	}

	
	array(score, (int)score_alloc, double);
	

	matrix(affected_allele,     num_in_ped,         2,             int);
	array(uninformative_marker, num_in_map_order+1, int);
	array(num_real_vecs,        num_in_map_order+1, long long int);
	array(best_pvector,         num_in_map_order+1, int); 
	
 
      } except_when (NOMEMORY) {
	print("Can't get enough memory for this scan\n");
	printf("Proc %d failed allocating %d for pvct, %d for disease vct and %d for score vct\n", 
	       mpi_interface.rank, amount_to_alloc, mpi_interface.vecs_per_proc, 
	       mpi_interface.vecs_per_proc);
    	unarray(best_pvector,         int);
    	unarray(num_real_vecs,        long long int);
    	unarray(uninformative_marker, int);
    	unmatrix(affected_allele,     num_in_ped,         int);
    	unarray(score,                double);
    	unarray(par_score,            double);
    	unarray(pvct,                 double);
	MPI_Abort(MPI_COMM_WORLD,1);
      }

	
      for (i=0; i<f_num_in_map_order; i++) {
	uninformative_marker[i] = (maskTest[i][0] == 0);
	num_real_vecs[i]=0;
      }
      exp = exp_2 = 0.0;
	
      /*G. Conant changed to distrib. markers on procs*/
      for(i=0; i<f_num_in_map_order; i++)
	p_pnt[i] = 0;
      
     
      fill_placeholder_alleles(0,real_non_originals,0);
      vec = 0;
      uninformative_mask=0;
      for (i=0; i<num_bits; i++) 
	if (uninformative_bit[i]) uninformative_mask+=pow2[i];
      npadMS = Setup_local_pad_inhvec_2(uninformative_mask, num_bits,
					padMask, padShift);

 /*vec_previous is always -1, so that every processor calculates its first entry--G. Conant*/
      /*if (mpi_interface.rank!=0){
	
	vec_previous = 0;
	for(i=0; i<npadMS; i++)
	  vec_previous |= (mpi_interface.vec_offset-1 & padMask[i]) << padShift[i];
	  
	  }
	  else*/
	vec_previous=-1;

      pr_time[40] = (double)clock()/(double)CLOCKS_PER_SEC;

  
#ifdef GC_TIME		
      gct_post=gct_RunTime();
      if (mpi_interface.rank == 0) 
      printf("Proc %d total runtime up to step 1: %d: %d-%d\n", mpi_interface.rank, gct_post-gct_prerun, gct_post, gct_prerun);
      gct_pre_graphtotal=gct_RunTime();
      gct_total_graphmarkers=0;
      gct_total_graphdisease=0;
      gct_total_graphstartup=0;
      gct_total_graphnpl=0;
#endif


	for (new_vec=0; new_vec<real_num_vecs; new_vec++) {
#ifdef GC_TIME
	  gct_pre_graphmarkers=gct_RunTime();
#endif
	  
	  fill_p_flag=0;
	  /* Move this code to check to see if this proc needs this vec.  fill_p_flag allows you do
	     fill_placeholder_alleles exactly once--G. Conant
	     if (new_vec > 0) {
	     vec = 0;
	     for(i=0; i<npadMS; i++)
	     vec |= (new_vec & padMask[i]) << padShift[i];
	     fill_placeholder_alleles(vec,real_non_originals,0);
	     }*/
	  
	  /* now every member of famtree has two placeholder alleles
	     filled in and we can advance to the prob assignment
	     for each of the markers */

	  
	  for (i=0; i<f_num_in_map_order; i++) {

	    if (mpi_interface.do_marker_in_parallel[i]==1){
	     
	      legal_vector = 
		((new_vec & maskTest[i][0]) == maskTest[i][1]);
	     
	      if (p_pnt[i]>=mpi_interface.marker_vec_start[i] &&
		  p_pnt[i]<=mpi_interface.marker_vec_end[i])
		{
		 
		  if(legal_vector || TEST_SHORTCUT) {
		    if ((new_vec > 0) && (fill_p_flag == 0)) {
		      fill_p_flag=1;
		      vec = 0;
		      for(jj=0; jj<npadMS; jj++)
			vec |= (new_vec & padMask[jj]) << padShift[jj];
		      fill_placeholder_alleles(vec,real_non_originals,0);
		    }		 
		    
		    if ((new_vec & maskHomP[i]) == 0) {
		      /*G. Conant modified so that equiv classes lookup last previous member, rather than first
			this allows distribution across several processor with less recalculation*/
		      /* This is the first (representative) of homozygote parent equiv class */
		      prob = graph_assign_probs(vec, originals, real_non_originals, 
						f_map_order[i], NULL, FALSE); 
		    }
		    else {
		     
		      /* This is a subsequent element of an equiv class, look up the previous one */
		      ibit2=0;
		      j=0;
		      for (ibit=0; ibit <= real_num_bits; ibit++)
			{
			  if (((pow2[ibit] & maskTest[i][0])!=0) || ((pow2[ibit] & maskHomP[i]) == 0))
			    ibit2++;
			  else
			    j |= (new_vec & pow2[ibit])>>ibit2;
			 
			}
		      /*We find the _last_ member of this equiv. class calculated*/
		      j--;
		     
		      lookfor=j;
		      j=(new_vec & ~maskHomP[i]); 
		      /*printf("Proc %d has val of %d in tiny rep: %d (Remaining bits: %d)\n", mpi_interface.rank, new_vec, lookfor, j);*/
		      ibit2=ibit3=0;
		      for (ibit=0; ibit <= real_num_bits; ibit++)
			{
			  if (((pow2[ibit] & maskTest[i][0])!=0) || ((pow2[ibit] & maskHomP[i]) == 0))
			    ibit2++;
			  else 
			    j |= (lookfor & pow2[ibit3++])<<ibit2;
			}
		    
		      lookfor=j;
		      ibit2=0;
		      j=0; 
		      for (ibit=0; ibit <= real_num_bits; ibit++)
			if ((maskTest[i][0] & pow2[ibit]) == 0) {
			  j |= ((lookfor & pow2[ibit]) >> (ibit - ibit2++));
			}
		     
	     
		      /*ibit3=j;*/
		      /* printf("Proc %d has vect %d, maskhomP: %d, masktest: %d thinks it needs vect %d\n", mpi_interface.rank,
			 new_vec, maskHomP[i], maskTest[i][0], j);*/

		     
		      /*If the element is calculated on this processor use it, otherwise, recalculate*/
		      if ((j>=mpi_interface.marker_vec_start[i]) && (j<=mpi_interface.marker_vec_end[i])) {
			
			prob = pvct[mpi_interface.marker_memory_offset[i]+(int)(j-
				   mpi_interface.marker_vec_start[i])];
}
		      else{
			misses++;
			prob = graph_assign_probs(j, originals, real_non_originals, 
						  f_map_order[i], NULL, FALSE); 
		      }
		    }
		    
		    if (prob > 0.0) num_real_vecs[i]++;
		    
		    if(legal_vector) {
		      pvct[ (int)(p_pnt[i]-mpi_interface.marker_vec_start[i]) +
			  mpi_interface.marker_memory_offset[i] ] = prob;
		    }
		    
		    if(TEST_SHORTCUT) {
		      if(!legal_vector && !(prob==0.)) {
			printf("iM=%3d m=%3d, new_vec=%8x, vec=%8x, is not illegal\n",
			       i, f_map_order[i], new_vec, vec);
			exit (1);
		      }
		    }
		  } else {
		    prob = 0;
		  }
		  
		  if(uninformative_marker[i])
		    if ((new_vec > 0) && 
			(prob != pvct[mpi_interface.marker_memory_offset[i]])) 
		      uninformative_marker[i]=FALSE;
		  
		}
	      if(!f_uninformative[i] && legal_vector) p_pnt[i]++;
	    }  /*End if--check to see if this marker is parallel*/		
	    else /*Marker is serial*/
	      {
		if(f_uninformative[i] && !TEST_SHORTCUT) {
		  prob = 1;
		  pvct[ (int)(p_pnt[i])+mpi_interface.marker_memory_offset[i] ] = prob;
		} else {
		 
		  legal_vector = 
		    ((new_vec & maskTest[i][0]) == maskTest[i][1]);
		  
		  if(legal_vector || TEST_SHORTCUT) {
		 
		    if ((new_vec > 0) && (fill_p_flag == 0)) {
		      fill_p_flag=1;
		      vec = 0;
		      for(jj=0; jj<npadMS; jj++)
			vec |= (new_vec & padMask[jj]) << padShift[jj];
		      fill_placeholder_alleles(vec,real_non_originals,0);
		    }

   
		    if ((new_vec & maskHomP[i]) == 0) {
		      /* This is the first (representative) of homozygote parent equiv class */
		      prob = graph_assign_probs(vec, originals, real_non_originals, 
						f_map_order[i], NULL, FALSE); 
		    }
		    else {
		      /* This is a subsequent element of an equiv class, look up the first one */
		      ibit2 = 0;
		      j = 0;
		      lookfor = (new_vec & ~maskHomP[i]);
		      
		      /*   	  (pvct array ptr is only for variable (nz) bits of inher vec) */
		      for (ibit=0; ibit <= real_num_bits; ibit++)
			if ((maskTest[i][0] & pow2[ibit]) == 0) {
			  j |= ((lookfor & pow2[ibit]) >> (ibit - ibit2++));
			}
		      
#ifdef PR_19
		      if ((lookfor & maskTest[i][0]) != maskTest[i][1])
			printf (
				"Lookfor is inconsistent, marker %d, lookfor %x, vec %x, maskhom %x, maskt0 %x, maskt1 %x, prob %1.12lf\n",
				i, lookfor, new_vec, maskHomP[i], maskTest[i][0], maskTest[i][1],
				pvct[mpi_interface.marker_memory_offset[i]+j]);
#endif
		      
		      prob = pvct[mpi_interface.marker_memory_offset[i]+(int)(j)];
		      
		    }
		    
		    if (prob > 0.0) num_real_vecs[i]++;
		    
		    if(legal_vector) {
		      pvct[ (int)(p_pnt[i])+mpi_interface.marker_memory_offset[i] ] = prob;
		      if(!f_uninformative[i]) p_pnt[i]++;
		    }
		    
		    if(TEST_SHORTCUT) {
		      if(!legal_vector && !(prob==0.)) {
			printf("iM=%3d m=%3d, new_vec=%8x, vec=%8x, is not illegal\n",
			       i, f_map_order[i], new_vec, vec);
			exit (1);
		      }
		    }
		  } else {
		    prob = 0;
		  }
		  
		}
		if(uninformative_marker[i])
		  if ((new_vec > 0) && 
		      (prob != pvct[mpi_interface.marker_memory_offset[i]])) 
		    uninformative_marker[i]=FALSE;
		
		      
	      }
	  }
	  
#ifdef GC_TIME
		gct_post_graphmarkers=gct_RunTime();
		gct_total_graphmarkers+=gct_post_graphmarkers-gct_pre_graphmarkers;
#endif
#ifdef GC_TIME
		    gct_pre_graphnpl=gct_RunTime();
#endif		       
		if ((new_vec>=mpi_interface.vec_offset) && (new_vec<=mpi_interface.vec_end))
		  {
   		
		  if ((new_vec > 0) && (fill_p_flag == 0)) {
		    fill_p_flag=1;
		    vec = 0;
		    for(jj=0; jj<npadMS; jj++)
		      vec |= (new_vec & padMask[jj]) << padShift[jj];
		    fill_placeholder_alleles(vec,real_non_originals,0);
		  }

		  /*G. Conant added the drop-out for LOD-only analysis of large (2n>32) problems to speed
		    debugging.  This may not be wise for production runs*/
		  if (analysis_type != LOD_ANALYSIS) {
		  /* now obtain NPL score for this assignment of placeholder
		     alleles for this pedigree */
		  /*-----------------------------------------------*/
		  if( (vec_previous & score_mask) != (vec & score_mask) ) {
		    for (i=0,num_aff=0; i<num_in_ped; i++) {
		      if (famtree[i].discard || famtree[i].place_allele[0]==-1) continue;
		      
		      if (allele_data[i][0] == 2) {
			/* this individual is affected */
			affected_allele[num_aff][0] = famtree[i].place_allele[0];
			affected_allele[num_aff][1] = famtree[i].place_allele[1];
			num_aff++;
		      }
		    }

		   
		    
		    if(num_aff>32) {
		      sf(ps," ******Error num_aff>32 *******\n");
		      pr();
		      exit (1);
		    }

		    score_npl_val = apm_score(affected_allele, num_aff);
		
		    if (score_npl_val  < 0)
		      mpi_interface.npl_error=1;
		    score[npl_pnt] = score_npl_val;
		    npl_pnt++;
		   
		  }
		  
		  
		  vec_previous = vec;
		  /*-----------------------------------------------*/
		  exp += score_npl_val;
		  exp_2 += (score_npl_val*score_npl_val);
		  }
  
#ifdef GC_TIME
		    gct_post_graphnpl=gct_RunTime();
		    gct_total_graphnpl+=gct_post_graphnpl-gct_pre_graphnpl;
		    gct_pre_graphdisease=gct_RunTime();
#endif	
		  if (analysis_type != NPL_ANALYSIS) {
		    /* Changed for MPI--only performs disease analysis if in the
		       range of the vector stored on this processor--G. Conant*/
	
		    if (num_inbred >= 1) {
		      
		      /* break the loop! */
		      par_score[(int)(new_vec-mpi_interface.vec_offset)] = 0.0;
		      
		      for (dis_geno=0; dis_geno<4; dis_geno++) {
			init_disease_probs(num_in_ped);
			this_prob = famtree[old_mom].disease_prob[dis_geno];
			for (jj=0; jj<4; jj++) {
			  famtree[old_mom].disease_prob[jj]=0.0;
			  famtree[num_in_ped].disease_prob[jj]=0.0;
			}
			famtree[old_mom].disease_prob[dis_geno]=1.0;
			famtree[num_in_ped].disease_prob[dis_geno]=1.0;
			if (num_nuc_fams_to_peel > 0) peel(vec, num_bits);
			famtree[num_in_ped].place_allele[0]=
			  famtree[old_mom].place_allele[0];
			famtree[num_in_ped].place_allele[1]=
			  famtree[old_mom].place_allele[1];
			this_prob *= brute_force_analyze(vec, num_bits, num_in_ped+1);
			par_score[(int)(new_vec-mpi_interface.vec_offset)] += this_prob;
		      }
		      
		    } else {
		      init_disease_probs(num_in_ped);		      
		      if (num_nuc_fams_to_peel > 0) peel(vec, num_bits);		      
		      par_score[(int)(new_vec-mpi_interface.vec_offset)] = 
			brute_force_analyze(vec, num_bits, num_in_ped);
		   
		    }
		  }
#ifdef GC_TIME
	gct_post_graphdisease=gct_RunTime();
	gct_total_graphdisease+=gct_post_graphdisease-gct_pre_graphdisease;
#endif
		  }
		
	}
    
	MPI_Barrier(MPI_COMM_WORLD);  
#ifdef GC_TIME
	gct_post_graphtotal=gct_RunTime();
	if (mpi_interface.npl_error == 1)
	  printf("ERROR--THERE ARE NPL SCORES LESS THAN ZERO: %d\n", mpi_interface.rank);
	if (mpi_interface.rank == 0) {
	  printf("GC: Proc %d Total run time for assignment of probs to inher. vects (Step 1): %d (Net %d)\n", 
		 mpi_interface.rank, gct_post_graphtotal-gct_pre_graphtotal, gct_RunTime());
	  printf("GC: Proc %d Time spent analyzing markers: %d\n", mpi_interface.rank,gct_total_graphmarkers);
	  printf("GC: Proc %d Time spent in npl analysis: %d\n", mpi_interface.rank,gct_total_graphnpl);
	  printf("GC: Proc %d Time spend preparing disease probs: %d\n", mpi_interface.rank,gct_total_graphdisease);
	  printf("Proc %d: num misses for marker vct calc: %d\n", mpi_interface.rank, misses);
	}
	  gct_pre=gct_RunTime();
#endif
	/*The uninformative_marker array is originally alloced as num_in_map_order+1.  This should be equal to
	  f_num_in_map_order, but I have used the original size to be safe--G. Conant*/
	uninformative_marker_r=(int*)malloc(sizeof(int)*num_in_map_order+1);
	exp_r=exp_2_r=0;
	MPI_Allreduce(uninformative_marker, uninformative_marker_r, num_in_map_order+1, MPI_INT, MPI_MIN, MPI_COMM_WORLD);
	MPI_Allreduce(&exp, &exp_r, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
	MPI_Allreduce(&exp_2, &exp_2_r, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
	
	for (i=0; i<num_in_map_order+1; i++)
	  uninformative_marker[i]=uninformative_marker_r[i];
	
	free(uninformative_marker_r);
	
	exp=exp_r;
	exp_2=exp_2_r;
#ifdef GC_TIME
	if (mpi_interface.rank == 0)
	  printf("Proc %d runtime past reduces: %d\n", mpi_interface.rank, gct_RunTime()-gct_pre);   	
#endif


	pr_time[50] = (double)clock()/(double)CLOCKS_PER_SEC;
	/*		printf(" finished graph_assign_probs\n");
	 */
	for (i=0; i<f_num_in_map_order; i++) {
	  if(f_uninformative[i]) p_pnt[i]++;
	  
	  if(p_pnt[i] !=pow2[nz_bits[i]]) {
	    sf(ps," Pointer concistency error: \n"); pr();
	    sf(ps," \t locus, p_pnt, nz_pointer, 2^bits = %4d  %lld %d %lld \n",
	       i, p_pnt[i], mpi_interface.marker_memory_offset[i+1],pow2[nz_bits[i]] ); pr();
	    exit(1);}
	     
	      
	}
    

      if (new_vec != real_num_vecs) error("num_vecs don't match in hackprep");

      
      exp /= real_num_vecs;
      exp_2 /= real_num_vecs;
      total_m=(double*)malloc(sizeof(double)*f_num_in_map_order);
      total_mr=(double*)malloc(sizeof(double)*f_num_in_map_order);
     
      /* normalize probabilities to sum to 1.0 for each marker */
	if (!skip_ped) {
	  for (i=0; i<f_num_in_map_order; i++) {
		  
	      total_m[i]=0.0;
	      if (mpi_interface.do_marker_in_parallel[i]==1) {
		for(j=mpi_interface.marker_vec_start[i]; 
		    j<=mpi_interface.marker_vec_end[i]; j++) 
		  total_m[i] += pvct[(int)(j-mpi_interface.marker_vec_start[i])
				 +mpi_interface.marker_memory_offset[i]];
	  
	      }
	      else {
	     	for(j=0; j<pow2[nz_bits[i]];  j++) 
		  total_m[i] += pvct[(int)(j+mpi_interface.marker_memory_offset[i])];
	      }
	  }

	  
	  MPI_Allreduce(total_m, total_mr, f_num_in_map_order, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);

	  for (i=0; i<f_num_in_map_order; i++) {
	    if (mpi_interface.do_marker_in_parallel[i]==1)
	      total=total_mr[i];
	    else
	      total=total_m[i];

	      if (total == 0.0) {
		sf(ps,"ERROR: bad inheritance in pedigree %s, # %d marker %s\n",
		   current_ped, i, locus[f_map_order[i]].name); pr();
		print("SKIPPING THIS PEDIGREE\n");
		skip_ped = TRUE; num_pedigrees--; break;
	      } else {
		for(jj=mpi_interface.marker_memory_offset[i]; 
		    jj<mpi_interface.marker_memory_offset[i+1]; jj++) pvct[jj] /= total;
		if(f_uninformative[i]) pvct[mpi_interface.marker_memory_offset[i]] = 1/real_num_vecs;
	      }
	  }
	}

	free(total_m);
	free(total_mr);
     
	
	/* calculate single marker entropy */
#ifdef DUMP_SINGLE_P_INFOC 
		if (!skip_ped) {
			for (i=0; i<f_num_in_map_order; i++) {
				k = 0;
				total=0.0;
				for(jj=mpi_interface.marker_memory_offset[i]; 
				    jj<mpi_interface.marker_memory_offset[i+1]; jj++) {
				  if(pvct[jj] != 0) { total += (-1.0) * pvct[jj] * log(pvct[jj]); }
				  else             { k++; }
				}
				printf("                        ");
				if(f_uninformative[i]) {
				  printf("iM = %3d  *\n", i);
				} else {
				  printf("iM = %3d  more_zeroes= (%10d/%10d)  (%2d/%2d) s-info = %6.4f\n",
					 i, k, pow2[nz_bits[i]],
					 real_num_bits - nz_bits[i], real_num_bits, 
					 1 - total/(real_num_bits*log(2)));
				}
			}
		}
#endif
		
	/* Check for uninformative markers */
		j = 0;  for(i=0; i<f_num_in_map_order; i++) if(uninformative_marker[i]) j++;
		if(j) {
		  
#if 0
		  Debugging only:
		    sf(ps,"-------------------------------------------------- \n"); pr();
		  sf(ps,"WARNING: the following marker(s) are uninformative \n"); pr();
		  sf(ps,"-------------------------------------------------- \n"); pr();
		  sf(ps,"  index(ordered)  index(unordered)  position\n"); pr();
		  total = 0.;
		  for (i=0; i<f_num_in_map_order; i++) {
		    if(uninformative_marker[i]) {
				sf(ps,"          %3d             %3d      %12.4e\n",
				   i, map_order[i], total); pr();
			}
		    total += map_distance[i];
		  }
#endif
		  
		  
		  sf(ps,"f_map_order[0:%2d] = ", f_num_in_map_order - 1); pr();
		  for(iMarker=0; iMarker<f_num_in_map_order; iMarker++) {
		    sf(ps,"%3d", f_map_order[iMarker]); pr();
		  }
		  
		  sf(ps,"\n"); pr();
		  sf(ps,"                    "); pr();
		  for(iMarker=0; iMarker<f_num_in_map_order; iMarker++) {
		    if(uninformative_marker[iMarker]) { 
		      if(f_uninformative[iMarker]) {
			sf(ps,"  *");
			pr();
		      } 
		      else {
			sf(ps,"  X");
			pr();
		      } /* X--> it was not caught before */
		    } else { 
		      sf(ps,"   "); 
		      pr();
		    }
		  }
		  sf(ps,"\n"); pr();
		  sf(ps,"  (The markers marked above with a * or X are uninformative.)\n"); pr();
		  sf(ps,"  (* --> automatically removed                              )\n"); pr();
		  sf(ps,"  (X --> still used for prior/left/right probabilities      )\n"); pr();
		  
		  if( !skip_ped  &&  j == f_num_in_map_order) {
		    sf(ps,"ERROR: no informative markers in pedigree %s\n",
		       current_ped); pr();
		    print("SKIPPING THIS PEDIGREE\n");
		    skip_ped = TRUE; num_pedigrees--;
		  }
		}
		
		if ((!skip_ped) && (analysis_type != NPL_ANALYSIS)){
		  total=total_s=0.0;
		  /*G. Conant modified for mpi distribution of par_score*/
		  for(j=0; j<mpi_interface.vecs_per_proc; j++) total_s += par_score[(int)j];
		  
		  MPI_Allreduce(&total_s, &total, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
		  
		
		  if (total == 0.0) {
		    print("disease pvectors sum to 0.0 - SKIPPING THIS PEDIGREE\n");
			skip_ped = TRUE; num_pedigrees--;
		  } else {
		  /*Also modified for MPI--G. Conant*/
		  for(j=0; j<mpi_interface.vecs_per_proc; j++) par_score[(int)j] /= total;
		}
		}
	
		if(EXIT_EARLY) { 
		  sf(ps," ------ EXIT_EARLY ------\n"); pr();
		  skip_ped = TRUE;; 
		}

    } /* if (!skip_ped) */
  


    if (!skip_ped) {
      /* call scan stuff now that pvector is filled in */
      /* count original parents of analyzed members */
      complexity=0;
      total_meioses += num_bits - really_uninformative_bits;

      /***** now that we correctly cut out first kids bits for each
	     original parent, we should actually be passing no
	     redundant vectors (except in the double missing parent
	     case) so we'll leave complexity=0 *****/
      /**********
      for (i=0; i<num_in_ped; i++) {
	if (famtree[i].dad_index==MISSING && famtree[i].mom_index==MISSING &&
	    famtree[i].analyzed_parent) complexity++;
      }
      if (num_bits < non_originals*2) complexity -= (non_originals*2-num_bits);
      if (complexity < 0) complexity=0;
      **********/

      /* make bitmasks */
      uninformative_mask=0; count=1;
      array(flip_mask, num_bits, long long int);

      for (i=0; i<num_bits; i++) {
	if (uninformative_bit[i]) {
	    uninformative_mask+=count;
	    flip_mask[i]=0;
	
	    if (i%2 == 1) { vecpos = (num_bits-i-1)/2; parent=MALE; }
	    else          { vecpos = (num_bits-i-2)/2; parent=FEMALE; }
	    for (jj=0; jj<real_non_originals; jj++) {
	      if (famtree[sorted_ped[jj]].inh_vec_pos == vecpos) {
		/* mark this person and sibs pat or mat bit */
		this_indiv = sorted_ped[jj];
		if (parent == MALE) this_parent=famtree[this_indiv].dad_index;
		else                this_parent=famtree[this_indiv].mom_index;
		break;
	      }
	    }
	    for (jj=0; jj<real_non_originals; jj++) {
	        if (parent == MALE) {
		  if (famtree[sorted_ped[jj]].dad_index == this_parent) {
		    vecpos=famtree[sorted_ped[jj]].inh_vec_pos;
		    flip_mask[i]+=pow2[num_bits-(2*vecpos)-1];
		  }
		} else {
		  if (famtree[sorted_ped[jj]].mom_index == this_parent) {
		    vecpos=famtree[sorted_ped[jj]].inh_vec_pos;
		    flip_mask[i]+=pow2[num_bits-(2*vecpos)-2];
		  }
		}
	    }
	}
	count *= 2;
      }
      
      if(compute_sharing) make_member_list(current_ped, num_in_ped); /*** new - alt 10/18 ***/

      
/*      printf("call scan_pedigree \n");
*/	  pr_time[60] = (double)clock()/(double)CLOCKS_PER_SEC;
    
       scan_pedigree(nz_bits, nz_pointer, pvct, par_score,
	        f_num_in_map_order, f_uninformative, f_map_order,
	        real_num_bits, score, score_mask_rdc, exp, exp_2,
		    num_pedigrees-1,complexity,best_pvector,
		    num_bits,uninformative_mask,flip_mask,maskTest);
      pr_time[80] = (double)clock()/(double)CLOCKS_PER_SEC;

	pr_time_all +=  pr_time[80] - pr_time[10];
	for(i=11; i<200; i++) { 
		pr_time[i] = pr_time[i] - pr_time[10];
	}



#ifdef DUMP_TIME 
	  printf("time 40,60,80,all=%12.4e %12.4e %12.4e %12.4e\n",
				pr_time[40], pr_time[60], pr_time[80], pr_time_all);

/*	printf("cum% 40,60,80,all=%12.3f %12.3f %12.3f\n",
	100*pr_time[40]/pr_time[80], 
	100*pr_time[60]/pr_time[80], 
	100*pr_time[80]/pr_time[80]);
*/	
	  printf("     40,60,80,all=%12.3f %12.3f %12.3f\n",
				100*pr_time[40]/pr_time[80], 
				100*(pr_time[60]-pr_time[40])/pr_time[80], 
				100*(pr_time[80]-pr_time[60])/pr_time[80]);
#endif


	if (haplotype_output) {
	/* need to replace eliminated bits in best_pvectors so that
	   the haplotyping display can do everything easily */
	/*****
	for (i=0; i<num_bits; i++) {
	  if (uninformative_bit[i]) {
	    add_bit(num_bits-num_uninformative_bits,i,
		    best_pvector,num_in_map_order);
	    num_uninformative_bits--;
	  }
	}
	*****/

	npl_max = npl_pos = apm_stat[num_pedigrees-1][2];
	for (i=0; i<num_w_pos; i++) {
	  if (apm_stat[num_pedigrees-1][i] > npl_max) 
	    npl_max = apm_stat[num_pedigrees-1][i];
	}
	matrix(alleles_to_draw,num_in_ped,num_in_map_order*2,int);
	matrix(inferred,num_in_ped,num_in_map_order*2,int);
	matrix(haplotype,originals*2,num_markers,int);
	array(best_pvector_tmp, num_in_map_order, int)
	
	/* Map best_vector from f_map_order to map_order */	
	for(i=0; i<f_num_in_map_order; i++)
		best_pvector_tmp[i] = best_pvector[i];
	jj=0;
	for(i=0; i<f_num_in_map_order; i++) {
		best_pvector[jj] = best_pvector_tmp[i];
		while((map_distance[jj] == 0.) && (jj<num_in_map_order)) {
			best_pvector[++jj] = best_pvector_tmp[i]; 
		}
		jj++;
	}

	sf(ps,"*****  %s  %.3lf\n",current_ped,npl_max); 
	fpr(haplofp);
	orig_haplotypes(num_in_ped,best_pvector,alleles_to_draw,haplotype,inferred);

	if (postscript_output)
	  draw_pedigree(num_in_ped,num_in_map_order,map_order,current_ped,
			alleles_to_draw,best_pvector,sorted_ped,
			real_non_originals,haplotype,originals,inferred);
	unarray(best_pvector_tmp, int)
	unmatrix(haplotype,originals*2,int);
	unmatrix(inferred,num_in_ped,int);
	unmatrix(alleles_to_draw,num_in_ped,int);
	}
    } else if (non_originals==1) {
      /* dump haplotypes of single affected member pedigrees */
      if (haplotype_output) {
	/* need to replace eliminated bits in best_pvectors so that
	   the haplotyping display can do everything easily */

	matrix(alleles_to_draw,num_in_ped,num_in_map_order*2,int);
	matrix(inferred,num_in_ped,num_in_map_order*2,int);
	matrix(haplotype,originals*2,num_markers,int);

	sf(ps,"*****  %s  0.000\n",current_ped);
	fpr(haplofp);
	for (i=0; i<num_in_map_order; i++) best_pvector[i]=0;
	orig_haplotypes(num_in_ped,best_pvector,alleles_to_draw,haplotype,inferred);

	if (postscript_output)
	  draw_pedigree(num_in_ped,num_in_map_order,map_order,current_ped,
			alleles_to_draw,best_pvector,sorted_ped,
			real_non_originals,haplotype,originals,inferred);
	unmatrix(haplotype,originals*2,int);
	unmatrix(inferred,num_in_ped,int);
	unmatrix(alleles_to_draw,num_in_ped,int);
      }
    }

  } on_exit {


    /* free memory */
    unarray(flip_mask, long long int);
    
	unarray(best_pvector,         int);
    unarray(num_real_vecs,        long long int);
    unarray(uninformative_marker, int);
    unmatrix(affected_allele,     num_in_ped,         int);
    
    unarray(score,                double);
    unarray(pvct,                 double); 
      unarray(par_score,            double);



/*    unmatrix(pvector,             num_in_map_order+1, double);
*/    unarray(par_score,            double);
    
   
    mpi_cleanup();
    unarray(nz_pointer, long long int);
    unarray(nz_bits,    int);
    unarray(p_pnt,      long long int);

	 unmatrix (maskTest, f_num_in_map_order,  long long int);
	 unarray (maskHomP, long long int);

    relay_messages;

  }
}

int Define_family_map_order( int originals, int non_originals,
                             int num_in_map_order, int *map_order,
							 int *f_map_order,
							 int *f_uninformative,
							 int print_flag)
{
	/* dangerous kludge 
	   meant to take care of repeated appearance of same marker 
	   when merging data sets from several groups */

	int i, j, iMarker, n_genotyped, last_marker;
	int i1, i2, i3, i4, f_num, process_marker, im;
	int *uninformative, *save_ngen;
	double total;


	if(single_point_mode) {
		for(iMarker=0; iMarker<num_in_map_order; iMarker++) {
			f_map_order[iMarker]   = map_order[iMarker];
			f_uninformative[iMarker] = FALSE;
			f_num=num_in_map_order;
		}
		return (f_num);	
	}
	
	array(uninformative, num_in_map_order+1, int);
	array(save_ngen,     num_in_map_order+1, int);

	for(iMarker=0; iMarker<num_in_map_order; iMarker++) {
		uninformative[iMarker] = TRUE;
		save_ngen[iMarker]     = 0;
	}
	for(iMarker=0; iMarker<num_in_map_order; iMarker++) {
		n_genotyped = 0;
		for (i=0,j=0; i<originals+non_originals; i++,j++) {
			if (famtree[j].discard) { i--; continue; }
			if (allele_data[j][allele_offset+(2*map_order[iMarker])] != 0 ||
			    allele_data[j][allele_offset+(2*map_order[iMarker])+1] != 0) 
				n_genotyped++;
		}
		uninformative[iMarker] = (n_genotyped < 2);
		save_ngen[iMarker]     = n_genotyped;
	}
/*	printf("Found uninformative marker(s): \n");
	i = 0;
	for(iMarker=0; iMarker<num_in_map_order; iMarker++) {
		if(uninformative[iMarker]) {
			i++;
			if(i > 10) { i=1;  printf("\n"); }
			printf("%4d", map_order[iMarker]);
		}
	}
	printf("\n");
*/	
	f_num = 0;
	i1 = i2 = -1;
	total = 0;
	if(print_flag & 1) printf("  iM map_order d1     d2    n_genotyped \n");
	for(iMarker=0; iMarker<num_in_map_order; iMarker++) {
	
		last_marker = (iMarker == num_in_map_order - 1);
		if(i1 == -1) i1 = iMarker;
		i2 = iMarker;
		
		if(print_flag & 1) {
			printf(" %3d  %3d  %7.2lf %7.2lf %2d",
			iMarker, map_order[iMarker], map_distance[iMarker], 
			total, save_ngen[iMarker]);
			if(uninformative[iMarker]) {
				printf(" *\n");
			} else {
				printf("  \n");
			}
		}

		total += map_distance[iMarker];
		
		if(!last_marker) { if(map_distance[iMarker] == 0.) continue; }
		
/*		if(last_marker) {
			process_marker = TRUE;
		} else {
			process_marker = (map_distance[iMarker] != 0.);
		}
*/		
		/* process completed group */
		i3 = 0;
		for(i=i1; i<=i2; i++) { 
			if(!uninformative[i]) {
				i3++;     /* # of informative in group */
				i4 = i;   /* last informative index */
			}
		}
		if(i3 == 0) { /* no marker in the group is informative.  Pick first*/
			i4 = i1;
			if(print_flag & 2) printf("                                 ");
			if(i1 == i2) {
				if(print_flag & 2) { printf("WARNING uninformative marker      : (%4d,%4d)\n",
				iMarker, map_order[iMarker]); }
			} else {
				if(print_flag & 2) { sf(ps,"WARNING uninformative marker group: (%4d,%4d)-(%4d,%4d)\n",
				i1, map_order[i1], i2, map_order[i2]); pr(); }
			}
		} else if(i3 > 1) { /* can't have more than one informative at the same spot */
			sf(ps,"**** Error two informative markers at the same position\n"); pr();
			sf(ps,"     check markers (ordered, unordered) index:\n"); pr();
			for(i=i1; i<=i2; i++) { sf(ps,"(%4d,%4d) ", i, map_order[i]); pr(); }
			sf(ps,"\n"); pr();
			
			
			
			
			for(im=i1; im<=i2; im++) {
				printf(" im, map_order = %4d %4d \n", im, map_order[im]);
				for (i=0,j=0; i<originals+non_originals; i++,j++) {
					if (famtree[j].discard) { i--; continue; }
					printf(" %s\t  %2d  %2d \n", famtree[j].indiv_ID,
					allele_data[j][allele_offset+(2*map_order[im])],
					allele_data[j][allele_offset+(2*map_order[im])+1]);
				}
			}
			
			
			
			exit(1);
		}
		f_map_order[f_num]   = map_order[i4];       /* previous group */
		f_uninformative[f_num] = uninformative[i4];
		f_num++;
		i1 = i2 = -1;
		if(print_flag & 1) printf("                                 select (%4d,%4d)\n", 
			i4, map_order[i4]);
	}

	if(print_flag & 4) { 
		printf("f_map_order[0:%2d] = ", f_num - 1);
		for(iMarker=0; iMarker<f_num; iMarker++) {
			printf("%3d", f_map_order[iMarker]);
		}
		printf("\n");
		printf("                    ");
		for(iMarker=0; iMarker<f_num; iMarker++) {
			if(f_uninformative[iMarker]) { printf("  *"); } else { printf("   "); }
		}
		printf("\n");
	}
    
	unarray(uninformative, int);
	unarray(save_ngen,     int);
	
	return (f_num);
}

int Set_npl_score_masks(long long int *score_mask, long long int *score_mask_rdc, long long int *score_alloc,
                         int real_non_originals, int num_bits)
{
	int i, j, bits_used;
	long long int s_mask, s_mask_rdc, test;
	s_mask = 0;
	for (i=0; i<real_non_originals; i++) {
		/* if (not affected) && (does not have kids) */
		if ((allele_data[sorted_ped[i]][0] != 2) && 
		    (famtree[sorted_ped[i]].nkids==0)) {
			j = famtree[sorted_ped[i]].inh_vec_pos;
			s_mask |= ((long long int)3) << (num_bits - j*2 - 2);
		}
	}

	s_mask_rdc = j = bits_used = 0;
	for (i=0; i<num_bits; i++) {
		if(!uninformative_bit[i]) {
			if(s_mask & pow2[i]) {
				s_mask_rdc |= pow2[j];
			} else {
				bits_used++;
			}
			j++;
		}
	}
	/*Mod for 64 bits--G. Conant*/
	s_mask     ^= 0xffffffffffffffff;
	s_mask_rdc ^= 0xffffffffffffffff;
	*score_mask     = s_mask;
	*score_mask_rdc = s_mask_rdc;
	*score_alloc    = (int)pow2[bits_used];

	
	

}

int parents_informative(int ind)
{
    int dad,mom,dad_sum,mom_sum,i;

    dad = famtree[ind].dad_index;
    mom = famtree[ind].mom_index;

    dad_sum=mom_sum=0;
    for (i=allele_offset; i<num_allele_data[dad]; i++) {
        if (allele_data[dad][i] > 0) dad_sum++;
	if (allele_data[mom][i] > 0) mom_sum++;
    }
    if (dad_sum == num_allele_data[dad]-allele_offset &&
	mom_sum == num_allele_data[mom]-allele_offset) return(TRUE);
    else return(FALSE);
}

int has_data(int ind)
{
    int i, sum, pos;

    sum=0;
    /**********
    for (i=allele_offset; i<num_allele_data[ind]; i++) {
        if (allele_data[ind][i] > 0) sum++;
    }
    **********/
    for (i=0; i<num_in_map_order; i++) {
        pos = (map_order[i]*2) + allele_offset;
	if (allele_data[ind][pos] > 0) sum++;
	if (allele_data[ind][pos+1] > 0) sum++;
    }

    if (sum > 0) return(TRUE);
    else return(FALSE);
}

void set_dad_index (int indiv,int num_in_ped)
{
  /* Find the index of dad in the the pedigree list and
     do basic pedigree checks */

  bool found;
  int i;

  /* If the LINKAGE pedigree has a 0 for dad or mom
     that means the parent is missing */
  if (!strcmp(famtree[indiv].dad,"0")) {
    famtree[indiv].dad_index = MISSING;
  } else {
    /* Go through the pedigree to find dad */
    found=FALSE;
    for (i=0; i<num_in_ped; i++) {
      if (!strcasecmp(famtree[indiv].dad, famtree[i].indiv_ID)) {
	/* Check that the father isn't impossible */
	if (i == indiv) {
	  sf(ps, "individual %s is own father",
	     famtree[indiv].indiv_ID);
	  error(ps);
	}
	if (famtree[i].sex != MALE) {
	  sf(ps, "father of indiv %s is female", 
	     famtree[indiv].indiv_ID); error(ps);
	}
	/* No errors, record the info */
	found=TRUE;
	famtree[indiv].dad_index=i;
	famtree[i].nkids++; /* Increment dad's # of kids */
	break;
      }
    }
    if (!found) {
      sf(ps,"can't find father of indiv %s (%s) in pedigree",
	 famtree[indiv].indiv_ID,famtree[indiv].dad);
      error(ps);
    }
  }
}

void set_mom_index (int indiv,int num_in_ped)
{
  /* Find the index of mom in the the pedigree list and
     do some basic pedigree checks */

  bool found;
  int i;

  /* If the LINKAGE pedigree has a 0 for mom or dad
     that means the parent is missing */
  if (!strcmp(famtree[indiv].mom,"0")) {
    famtree[indiv].mom_index = MISSING;
  } else {
    /* Go through the pedigree to find mom */
    found=FALSE;
    for (i=0; i<num_in_ped; i++) {
      if (!strcasecmp(famtree[indiv].mom, famtree[i].indiv_ID)) {
	/* Check that the mother isn't impossible */
	if (i == indiv) {
	  sf(ps, "individual %s is own mother",
	     famtree[indiv].indiv_ID);
	  error(ps);
	}
	if (famtree[i].sex != FEMALE) {
	  sf(ps, "mother of indiv %s is male", 
	     famtree[indiv].indiv_ID); error(ps);
	}
	/* No errors, record the info */
	found=TRUE;
	famtree[indiv].mom_index=i;
	famtree[i].nkids++; /* Increment mom's # of kids */
	break;
      }
    }
    if (!found) {
      sf(ps,"can't find mother of indiv %s (%s) in pedigree",
	 famtree[indiv].indiv_ID,famtree[indiv].mom);
      error(ps);
    }
  }
}


void check_for_unlinked (int num_in_ped)
{
  /* Everyone in the pedigree should either have
     parents or kids, otherwise they have no links
     to the rest of the pedigree and can be excluded
     from analysis.  Finds any such individuals, prints
     a warning and removes them from the famtree list */

  int i,j,num_unlinked=0,*unlinked,new_num_in_ped;

  array(unlinked,MAX_INDIVIDUALS,int);
  new_num_in_ped = num_in_ped;

  for (i=0; i<new_num_in_ped; i++)
    if (famtree[i].nkids==0 &&
	famtree[i].dad_index==MISSING &&
	famtree[i].mom_index==MISSING) {
      unlinked[num_unlinked]=i;
      num_unlinked++;
    }

  if (num_unlinked > 0) {

#ifdef DEBUGGING_OUTPUT
    if (num_unlinked==1) {
      sf(ps,
     "pedigree %s contains an unlinked individual (%s) that will not be analyzed\n",
	 current_ped, famtree[unlinked[0]].indiv_ID); pr();

    } else {
      sf(ps,
     "pedigree %s contains unlinked individuals that will not be analyzed\n",
	 current_ped); pr();
    }
#endif

    for (i=0; i<num_unlinked; i++) {
      /* Remove unlinked indivs from the famtree list */
      famtree[unlinked[i]].discard=TRUE;
    }
  }
  unarray(unlinked,int);
}

void check_for_loop (int start_indiv, int sex, int new_index, 
		     int level, int max_levels)
{

  /* Make sure that start_indiv does not create a loop in
     the pedigree.  Recursively check all the ancestors */

  int dad, mom; /* dad and mom of the individual where we
		   are up in the pedigree */
  
  if (level >= max_levels) {
    sf(ps,"loop detected in pedigree %s\n",current_ped); pr();
    return;
  }

  dad = famtree[new_index].dad_index;
  mom = famtree[new_index].mom_index;

  if (dad != MISSING) {
    if (sex == MALE)
      if (!strcasecmp(famtree[dad].indiv_ID,
		      famtree[start_indiv].indiv_ID)) {
	sf(ps,"individual %s is his own ancestor",
	   famtree[start_indiv].indiv_ID); error(ps);
      }
    check_for_loop(start_indiv,sex,dad,level+1,max_levels);
  }
  if (mom != MISSING) {
    if (sex == FEMALE)
      if (!strcasecmp(famtree[mom].indiv_ID,
		      famtree[start_indiv].indiv_ID)) {
	sf(ps,"individual %s is her own ancestor",
	   famtree[start_indiv].indiv_ID); error(ps);
      }
    check_for_loop(start_indiv,sex,mom,level+1,max_levels);
  }
}  


/*******************************************************
 Sort the pedigree into a list with all ancestors first
 *******************************************************/
void sort_pedigree (int num_in_ped)
{

  /* Take the famtree list of PED_MEMBERs and
     make a list of its indices such that each
     member is present after his or her parents */

  int i;

  if (num_in_ped > MAX_INDIVIDUALS) {
    sf(ps,"too many individuals in pedigree %s - max %d",
       current_ped, MAX_INDIVIDUALS); error(ps);
  }

  for (i=0; i<num_in_ped; i++) {
    if (famtree[i].discard) placed[i]=TRUE;
    else placed[i]=FALSE;
  }
  num_placed=0;

  for (i=0; i<num_in_ped; i++) {
    /* add each member of the pedigree to the sorted list */
    if (!placed[i]) place_indiv(i);    
  }

}

void place_indiv (int ped_index)
{
  /* Place each individual after recursively
     placing any parents */
  
  /* Only place the individual if they are a non-original */
  if (famtree[ped_index].dad_index == MISSING &&
      famtree[ped_index].mom_index == MISSING) {
    /* Individual is an original */
    placed[ped_index]=TRUE;
    return;
  }
      
  /* Check that dad has been added to the list */
  if (!placed[famtree[ped_index].dad_index])
    place_indiv(famtree[ped_index].dad_index);

  /* Check that mom has been added to the list */
  if (!placed[famtree[ped_index].mom_index])
    place_indiv(famtree[ped_index].mom_index);

  /* All ancestors in the list, add the current
     individual */
  sorted_ped[num_placed]=ped_index;
  placed[ped_index]=TRUE;
  num_placed++;

}



void fill_placeholder_alleles(long long int vec, int non_originals, int for_hap)
{
    int i,mom,dad,num_bits;

    num_bits = non_originals*2;
    
    for (i=0; i<non_originals; i++) {
        famtree[sorted_ped[i]].place_allele[0] = -1;
        famtree[sorted_ped[i]].place_allele[1] = -1;
    }

    if (vec==0 && !for_hap) print("using non-originals: ");
    for (i=0; i<non_originals; i++) {
        /* sorted_ped[] = index of non_originals in correct order */
        dad = famtree[sorted_ped[i]].dad_index;
	mom = famtree[sorted_ped[i]].mom_index;

        famtree[sorted_ped[i]].place_allele[0] = 
	  famtree[dad].place_allele[(int)((vec>>(num_bits-(2*i)-1))%2)];

        famtree[sorted_ped[i]].place_allele[1] = 
	  famtree[mom].place_allele[(int)((vec>>(num_bits-(2*i)-2))%2)];

	if (vec==0 && !for_hap) { 
	  sf(ps," %s",famtree[sorted_ped[i]].indiv_ID); pr(); 
	  famtree[sorted_ped[i]].inh_vec_pos = i;
	  famtree[dad].analyzed_parent=TRUE;
	  famtree[mom].analyzed_parent=TRUE;
	  uninformative_bit[num_bits-(2*i)-1]=FALSE;
	  uninformative_bit[num_bits-(2*i)-2]=FALSE;	  
	  if (famtree[sorted_ped[i]].dad_bit_uninf)
	    uninformative_bit[num_bits-(2*i)-1] = TRUE;
	  if (famtree[sorted_ped[i]].mom_bit_uninf)
	    uninformative_bit[num_bits-(2*i)-2] = TRUE;
	}
    }
   
       if (vec==0 && !for_hap) nl();
       
}


double graph_assign_probs(long long int vec,int originals,int non_originals,int marker,
			  int **haplotype, bool record_haplotype)
{
    /* allele_data[][]  holds the allele data for each member of
       famtree as follows:

       allele_data[indiv][0] = affectation value

       allele_data[indiv][allele_offset+(2*i)] and
       allele_data[indiv][allele_offset+(2*i)+1]  = alleles for ith marker
    
       famtree[indiv].place_allele [0] and [1] are the two place holder
       alleles for the individual...for originals, these represent the 
       nodes of the graph, for non-originals, these represent the obligate
       assignments given the assignments of the originals and the 
       particular inheritance vector (vec) we are working on
    */
    int i, j, num_edges;
    void create_nodes(int), AddEdge(int,int,int,int),
         process_graph(ASSIGN_STRUCT*), free_assign(ASSIGN_STRUCT*);
    ASSIGN_STRUCT *assign_list,*alist;
    double prob, total_prob;

    create_nodes(originals*2);
    
    num_edges=0;
    for (i=0,j=0; i<originals+non_originals; i++,j++) {
      
        if (famtree[j].place_allele[0]==-1) { i--; continue; }
	if (famtree[j].discard) { i--; continue; }

	/* Changed the following from && to || to allow
	   processing of (A,0) genotypes - MJD 3/98 */

        if (allele_data[j][allele_offset+(2*marker)] != 0 ||
	    allele_data[j][allele_offset+(2*marker)+1] != 0) {

	    /******
	   sf(ps,"IN: (%d,%d,%d,%d) \n", 
	       famtree[j].place_allele[0],
	       famtree[j].place_allele[1],
	       allele_data[j][allele_offset+(2*marker)],
	       allele_data[j][allele_offset+(2*marker)+1] ); pr();
	    ******/
	    /******
	    if((vec < 1) && (marker<3) ){
	    	printf("--v=%d\t m=%d\t j=%d\t %s\t-- ",
		       vec, marker, j, famtree[j].indiv_ID);
		   sf(ps,"IN: (%d,%d,%d,%d) \n", 
		       famtree[j].place_allele[0],
		       famtree[j].place_allele[1],
		       allele_data[j][allele_offset+(2*marker)],
		       allele_data[j][allele_offset+(2*marker)+1] ); pr();
	    }
	    ******/
	    
	    AddEdge( famtree[j].place_allele[0],
		     famtree[j].place_allele[1],
		     allele_data[j][allele_offset+(2*marker)],
		     allele_data[j][allele_offset+(2*marker)+1] );
	    num_edges++;
	}
    }

    if (num_edges > 0) { 
        single (assign_list, ASSIGN_STRUCT);
	assign_list->next=NULL; assign_list->num_alleles=0;
        process_graph(assign_list);
	/*** free_assign(assign_list); WHY WAS THIS HERE? ***/
	/******
	if (marker == 0) {
		alist=assign_list;
		if (alist->num_alleles != 0){
			printf("--v=%x\t m=%d\t--", vec, marker);
			while(alist != NULL) {
				printf(":%d:", alist->num_alleles);
				for(i=0; i<alist->num_alleles; i++) {
					printf("%d ",alist->allele_list[i]);
				}
				alist = alist->next;
			}
			printf("--\n");
		} else {
			printf("..v=%x\t m=%d\t \n", vec, marker);
		}
	}
	******/
	alist=assign_list; total_prob=0.0;

	if (record_haplotype == TRUE) {
	  for (i=0; i<(originals*2); i++)
	    haplotype[i][marker] = alist->force_list[i];
	  /***** debugging output
	  sf(ps,"marker %d: ",marker+1); pr(); 
	  for (i=0; i<alist->num_alleles; i++) {
	    sf(ps,"%d ",alist->allele_list[i]); pr();
	  }
	  nl();
	  *****/
	}
	
	if (alist->num_alleles == 0) {
	  /* no consistent assignments, prob=0.0 */
	} else {
	  while (alist!=NULL) {
	    if (alist->num_alleles == 0) { prob=0.0; }
	    else {
	      prob = 1.0;
	      for (i=0; i<alist->num_alleles; i++) {
		if (alist->allele_list[i] == 0) {
		  /* add nothing to prob - this node was held at zero */
		} else if (locus[marker].allele_freq[alist->allele_list[i]] == 0.0) {
		  sf(ps,"non-existant allele %d at marker %d in graph_probs",
		     alist->allele_list[i],marker+1); error(ps);
		} else {
		  prob *= locus[marker].allele_freq[alist->allele_list[i]];
		  /* to normalize as Linkage does, prob would also have to
		     be divided by locus[marker].allele_sum here each time */
		}
	      }
	    }
	    total_prob += prob;
	    alist = alist->next;
	  }
	}
	free_assign(assign_list);
	return(total_prob);
    } else {
      /* all individuals are missing, set all vec probs = 1 */
      return(1.0);
    }
  }


void free_assign(ASSIGN_STRUCT *alist)
{
    if (alist->next != NULL) free_assign(alist->next);
    unsingle(alist, ASSIGN_STRUCT);
}


void fill_nuc_families(int num_in_ped)
{
  
  int i,j,kid[MAX_KIDS],nf;
  int num_kids, found, dad, mom;
  bool checked[MAX_INDIVIDUALS];


  for (i=0; i<num_in_ped; i++)
    checked[i]=FALSE;
  
  num_nuc_fam=0;
  
  for (i=0; i<num_in_ped; i++) {
    if (famtree[i].discard) continue;
    if (checked[i]) continue;

    if (famtree[i].nkids > 0) {

      /* Make a list of all the kids of the individual */
      num_kids=0;
      for (j=0; j<num_in_ped; j++){
	if (num_kids == famtree[i].nkids) break;
	if (famtree[j].dad_index == i ||
	    famtree[j].mom_index == i) {
	  if (famtree[j].discard) continue;
	  kid[num_kids]=j;
	  num_kids++;
	}
      }
      
      if (num_kids > 0) {
	nuc_fam[num_nuc_fam].pivot = -1;
	nuc_fam[num_nuc_fam].inbred=FALSE;
	nuc_fam[num_nuc_fam].in_loop=FALSE;
	nuc_fam[num_nuc_fam].loop_indiv=FALSE;
	nuc_fam[num_nuc_fam].num_common_anc=0;
	nuc_fam[num_nuc_fam].dad = famtree[kid[0]].dad_index;
	nuc_fam[num_nuc_fam].mom = famtree[kid[0]].mom_index;
	nuc_fam[num_nuc_fam].num_kids=0;
	for (j=0; j<num_kids; j++) {
	  if (famtree[kid[j]].mom_index == nuc_fam[num_nuc_fam].mom &&
	      famtree[kid[j]].dad_index == nuc_fam[num_nuc_fam].dad) {
	    nuc_fam[num_nuc_fam].kid[nuc_fam[num_nuc_fam].num_kids]=kid[j];
	    nuc_fam[num_nuc_fam].num_kids++;
	  }
	}
	num_nuc_fam++;
      }

      checked[nuc_fam[num_nuc_fam-1].dad]=TRUE;
      checked[nuc_fam[num_nuc_fam-1].mom]=TRUE;
    }
  }

  /* Final check to ensure that all kids have their nuclear
     family represented - just to cover the unusual case where
     both parents are also parents of other nuclear pedigrees */

  for (i=0; i<num_in_ped; i++) {
    if (famtree[i].discard) continue;
    dad = famtree[i].dad_index;
    mom = famtree[i].mom_index;
    if (dad == MISSING || mom == MISSING) continue;

    found=FALSE;
    for (j=0; j<num_nuc_fam; j++) {
      if (nuc_fam[j].dad == dad && nuc_fam[j].mom == mom) {
	found=TRUE; break;
      }
    }

    if (!found) {
      /* Create a new nuc_fam */
      num_kids=0;
      for (j=0; j<num_in_ped; j++){
	if (famtree[j].dad_index == dad && famtree[j].mom_index == mom) {
	  if (famtree[j].discard) continue;
	  kid[num_kids]=j;
	  num_kids++;
	}
      }
      if (num_kids > 0) {
	print("Special double half-sib case detected\n");
	nuc_fam[num_nuc_fam].pivot = -1;
	nuc_fam[num_nuc_fam].inbred=FALSE;
	nuc_fam[num_nuc_fam].in_loop=FALSE;
	nuc_fam[num_nuc_fam].loop_indiv=FALSE;
	nuc_fam[num_nuc_fam].num_common_anc=0;
	nuc_fam[num_nuc_fam].dad = dad;
	nuc_fam[num_nuc_fam].mom = mom;
	nuc_fam[num_nuc_fam].num_kids=0;
	for (j=0; j<num_kids; j++) {
	  if (famtree[kid[j]].mom_index == nuc_fam[num_nuc_fam].mom &&
	      famtree[kid[j]].dad_index == nuc_fam[num_nuc_fam].dad) {
	    nuc_fam[num_nuc_fam].kid[nuc_fam[num_nuc_fam].num_kids]=kid[j];
	    nuc_fam[num_nuc_fam].num_kids++;
	  }
	}
	num_nuc_fam++;
      }
    }
  }

}

int mark_pivots (int num_in_ped)
{
  /* Make a list of all the pivots in the extended family.
     Then each family who has one member in the pivot
     list is peripheral and we assign them unless we have
     already assigned num_nuc_fam-1 (num_nuc_fam is the
     number of nuclear families in the extended pedigree). */
  
  int i,j,k;
  int num_pivots=0,pivot[MAX_INDIVIDUALS];
  int num_assigned,fam_pivot,fam_pivots,num_kids,fam_pivot_list[MAX_INDIVIDUALS];
  int shared[MAX_INDIVIDUALS];
  int assigned[MAX_INDIVIDUALS];
  int possible_pivot[MAX_INDIVIDUALS], poss, assigned_this_round;
  bool done;
  

  /* Make the list of pivots -- pivots are individuals
     who have not been discarded, who are non-originals,
     and who have at least one child */
  for (i=0; i<num_in_ped; i++) {
    possible_pivot[i]=0;

    if (famtree[i].discard) continue;
    if (famtree[i].mom_index != MISSING &&
	famtree[i].dad_index != MISSING) {

      /* Count up non-discarded kids */
      num_kids=0;
      if (famtree[i].nkids > 0)  {
	for (j=0; j<num_in_ped; j++) {
	  if (famtree[j].discard) continue;
	  if (famtree[j].mom_index == i ||
	      famtree[j].dad_index == i)
	    num_kids++;
	}
      }
      if (num_kids > 0) {
	possible_pivot[i]=1; /* has kids and parents */
	pivot[num_pivots]=i;
	num_pivots++;
      }
    }
  }

  if (num_pivots < (num_nuc_fam-1)) {
    /* In this case we have a string of marriages with
       half sibs on the next level, so the pivots will
       be individuals with more than one partner (and may
       actually be original) */
    for (i=0; i<num_nuc_fam; i++) 
      for (j=i+1; j<num_nuc_fam; j++) {
	/* Make a list of individuals shared between two nuc fams */
	if (nuc_fam[i].dad == nuc_fam[j].dad) {
	  pivot[num_pivots]=nuc_fam[i].dad;
	  num_pivots++;
	  possible_pivot[nuc_fam[i].dad]++;
	}
	if (nuc_fam[i].mom == nuc_fam[j].mom) {
	  pivot[num_pivots]=nuc_fam[i].mom;
	  num_pivots++;
	  possible_pivot[nuc_fam[i].mom]++;
	}
      }
  }


  for (i=0; i<num_nuc_fam; i++)
    assigned[i]=FALSE;

  /* Assign pivots within nuclear families */
  num_assigned = 0;
  done=FALSE;
  while(!done) {
    assigned_this_round=FALSE;

    for (i=0; i<num_nuc_fam; i++) {
      if (assigned[i]) continue;

      poss=0;
      if (possible_pivot[nuc_fam[i].dad]) { poss++; fam_pivot=nuc_fam[i].dad; }
      if (possible_pivot[nuc_fam[i].mom]) { poss++; fam_pivot=nuc_fam[i].mom; }
      for (k=0; k<nuc_fam[i].num_kids; k++) {
	if (possible_pivot[nuc_fam[i].kid[k]]) {
	  poss++; fam_pivot=nuc_fam[i].kid[k];
	}
      }

      if (poss == 1) {
	  /* use it, mark the members as done, subtract 1
	     from possible_pivot[member] */
	  assigned_this_round=TRUE;
	  nuc_fam[i].pivot = fam_pivot;
	  order_assigned[num_assigned]=i;
	  num_assigned++;
	  assigned[i]=TRUE;
	  possible_pivot[fam_pivot]--;
	  if (num_assigned == (num_nuc_fam-1)) {
	    done=TRUE; break;
	  }
      } else if (poss == 0) {
	  /* we have a nuclear family that is not connected to 
	     the rest of the pedigree - ERROR */
	  sf(ps,"pedigree contains disconnected arms...SKIPPING\n"); pr();
	  sf(ps,"This means that either two pedigrees that are not related\n");
	  pr();
	  sf(ps,"or are related only by a marriage with uninformative\n");
	  pr();
	  sf(ps,"children are present with the same name and should be\n");
	  pr();
	  sf(ps,"divided into two separate pedigrees.\n");
	  pr();
	  return(-1);
	  /* returns -1 to indicate to skip the pedigree above */
      }
    }
   
    if (!assigned_this_round) {
      /* can't assign any more, must have hit some sort of loop */
      done=TRUE;
    }
  }

  /* Mark everyone in the unassigned nuclear families as requiring
     further analysis */

  for (i=0; i<num_in_ped; i++) famtree[i].not_peeled=FALSE;
  
  for (i=0; i<num_nuc_fam; i++) {
    if (assigned[i]) continue;
    
    famtree[nuc_fam[i].dad].not_peeled = TRUE;
    famtree[nuc_fam[i].mom].not_peeled = TRUE;
    for (k=0; k<nuc_fam[i].num_kids; k++) 
      famtree[nuc_fam[i].kid[k]].not_peeled = TRUE;
  }

  num_nuc_fams_to_peel = num_assigned;

  /* Now peeling can be done on all the nuclear families in the
     assigned list, then a brute_force analysis can be applied
     to the remaining individuals not peeled off - yielding one
     analysis method for all types of pedigrees */

  /* All that remains is to recognize long inbreeding loops and
     to subsequently break them (a la Linkage - but automatically)
     or to develop an inbred peeling method  - this has now been
     done in the analyze_family code! */

  return(1);
}


void order_inbred_family (void)
{
  int i,j,k,inbred_family,mom_anc,dad_anc;
  int max_to_common,*loop_order,num_in_loop=0,num_assigned;
  bool *in_loop,found,*checked;

  array(loop_order,num_nuc_fam,int);
  array(checked,num_nuc_fam,bool);
  array(in_loop,num_nuc_fam,bool);
  for (i=0; i<num_nuc_fam; i++) {
    in_loop[i]=FALSE;
    checked[i]=FALSE;
  }

  /* Find the inbred family */
  for (i=0; i<num_nuc_fam; i++) {
    if (nuc_fam[i].inbred) {
      inbred_family=i;
      break;
    }
  }
  checked[inbred_family]=TRUE;
  in_loop[inbred_family]=TRUE;
  famtree[nuc_fam[inbred_family].mom].in_loop=TRUE;
  famtree[nuc_fam[inbred_family].dad].in_loop=TRUE;
  loop_order[num_in_loop]=inbred_family;
  num_in_loop++;
  if (nuc_fam[inbred_family].mom_to_common >
      nuc_fam[inbred_family].dad_to_common)
    max_to_common = nuc_fam[inbred_family].mom_to_common;
  else
    max_to_common = nuc_fam[inbred_family].dad_to_common;

  
  /* Starting with the inbred nuclear family, work
     upward through the families that are in the inbreeding
     loop */
  mom_anc = nuc_fam[inbred_family].mom;
  dad_anc = nuc_fam[inbred_family].dad;
  for (i=0; i<=max_to_common; i++) {
    if (i<=nuc_fam[inbred_family].mom_to_common) {
      /* Find the nuclear family that mom is a part 
	 of.  We'll always be peeling upward, so the
	 indiv will always be among the children */
      for (j=0; j<num_nuc_fam; j++) {
	if (checked[j]) continue;
	found = FALSE;
	for (k=0; k<nuc_fam[j].num_kids; k++)
	  if (nuc_fam[j].kid[k] == mom_anc) {
	    found=TRUE;
	    break;
	  }
	if (found) {
	  /* found the family mom of her ancestor is a part of, one
	     of the parents of this nuclear family will be the
	     next 1/2 of a superpivot */
	  if (famtree[nuc_fam[j].mom].mom_index != MISSING &&
	      famtree[nuc_fam[j].mom].dad_index != MISSING &&
	      famtree[nuc_fam[j].mom].nkids > 0)
	    mom_anc = nuc_fam[j].mom;
	  else
	    mom_anc = nuc_fam[j].dad;
	  checked[j] = TRUE;
	  nuc_fam[j].in_loop = TRUE;
	  nuc_fam[j].loop_indiv = mom_anc;
	  famtree[mom_anc].in_loop=TRUE;
	  loop_order[num_in_loop]=j;
	  num_in_loop++;
	}
      }
    }
    /* Now do the same routine for dad */
    if (i<=nuc_fam[inbred_family].dad_to_common) {
      for (j=0; j<num_nuc_fam; j++) {
	if (checked[j]) continue;
	found = FALSE;
	for (k=0; k<nuc_fam[j].num_kids; k++)
	  if (nuc_fam[j].kid[k] == dad_anc){
	    found=TRUE;
	    break;
	  }
	if (found) {
	  /* found the family mom of her ancestor is a part of, one
	     of the parents of this nuclear family will be the
	     next 1/2 of a superpivot */
	  if (famtree[nuc_fam[j].mom].mom_index != MISSING &&
	      famtree[nuc_fam[j].mom].dad_index != MISSING &&
	      famtree[nuc_fam[j].mom].nkids > 0)
	    dad_anc = nuc_fam[j].mom;
	  else
	    dad_anc = nuc_fam[j].dad;
	  checked[j] = TRUE;
	  nuc_fam[j].in_loop = TRUE;
	  nuc_fam[j].loop_indiv = dad_anc;
	  famtree[dad_anc].in_loop=TRUE;
	  loop_order[num_in_loop]=j;
	  num_in_loop++;
	}
      }
    }
  }

  num_assigned=0;
  if (num_in_loop < num_nuc_fam) {
    /* In this case there are peripheral families outside
       the inbreeding loop where we can assign pivots in
       the usual fashion */
    num_assigned++;
  }
  for (i=0; i<num_in_loop; i++) {
    order_assigned[num_assigned] = loop_order[i];
    num_assigned++;
  }
  
  unarray(in_loop,bool);
  unarray(loop_order,int);
  unarray(checked,bool);
}
  
static int num_mom, num_dad;

int inbred_matings (void)
{
  /* Return the number of inbred matings */
  
  int i,j,k;
  int mom,dad;
  int *mom_anc, *dad_anc;
  int num_inbred_matings=0;
  int num_in_common;


  array(mom_anc,MAX_INDIVIDUALS,int);
  array(dad_anc,MAX_INDIVIDUALS,int);

  /* If a person has > 0 kids make a list of the
     person's ancestors and the partner(s)'s ancestors
     and make sure they have none in common */
  for (i=0; i<num_nuc_fam; i++) {
    mom = nuc_fam[i].mom;
    dad = nuc_fam[i].dad;

    /* Make a list of each parents ancestors */
    num_mom=0;
    num_dad=0;
    get_mat_ancestors(mom,mom_anc);
    get_pat_ancestors(dad,dad_anc);

    /* Compare the lists */
    num_in_common=0;
    for (k=0; k<num_mom; k++) {
      for (j=0; j<num_dad; j++) {
	if (mom_anc[k] == dad_anc[j]) {
	  if (num_in_common == 0) {
	    nuc_fam[i].mom_to_common = (k+2)/2-1;
	    nuc_fam[i].dad_to_common = (j+2)/2-1;
	  }
	  num_in_common++;
	}
      }
    }
    if (num_in_common > 0) {
      num_inbred_matings++;
      nuc_fam[i].inbred=TRUE;
      nuc_fam[i].num_common_anc=num_in_common;
    }
  }

  unarray(mom_anc,int);
  unarray(dad_anc,int);
  
  return(num_inbred_matings);
}
     

void get_mat_ancestors(int indiv,int *list)
{

  if (famtree[indiv].mom_index != MISSING) {
    list[num_mom]=famtree[indiv].mom_index;
    num_mom++;
    get_mat_ancestors(famtree[indiv].mom_index,list);
  }
  if (famtree[indiv].dad_index != MISSING) {
    list[num_mom]=famtree[indiv].dad_index;
    num_mom++;
    get_mat_ancestors(famtree[indiv].dad_index,list);
  }

}
void get_pat_ancestors(int indiv,int *list)
{

  if (famtree[indiv].mom_index != MISSING) {
    list[num_dad]=famtree[indiv].mom_index;
    num_dad++;
    get_pat_ancestors(famtree[indiv].mom_index,list);
  }
  if (famtree[indiv].dad_index != MISSING) {
    list[num_dad]=famtree[indiv].dad_index;
    num_dad++;
    get_pat_ancestors(famtree[indiv].dad_index,list);
  }

}

  
    
void init_disease_probs(int num_in_ped) 
{
  /* sets each pedigree member's a-priori disease allele frequencies */
  /* called before peel() for each inheritance vector */

  int i,aff_stat,liab_class;
  double total_pen[MAX_LIABILITY_CLASSES+1];

  for (i=0; i<=num_liability_classes; i++)
    total_pen[i] = penetrance[i][HOM_AFF] + penetrance[i][HOM_UNAFF] +
      (2.0*penetrance[i][HET]);

  for (i=0; i<num_in_ped; i++) {
    aff_stat = famtree[i].affectation_status;
    liab_class = famtree[i].liability_class;
    if (famtree[i].dad_index==MISSING && famtree[i].mom_index==MISSING) {
      famtree[i].disease_prob[HOM_AFF]=apriori_disease[liab_class][aff_stat][HOM_AFF];
      famtree[i].disease_prob[HET_UA]=apriori_disease[liab_class][aff_stat][HET];
      famtree[i].disease_prob[HET_AU]=apriori_disease[liab_class][aff_stat][HET];
      famtree[i].disease_prob[HOM_UNAFF]=apriori_disease[liab_class][aff_stat][HOM_UNAFF];
    } else {
      switch (aff_stat) {
        case 1: 
	  famtree[i].disease_prob[HOM_AFF]=
	    (1.0-penetrance[liab_class][HOM_AFF])/(4.0-total_pen[liab_class]);
	  famtree[i].disease_prob[HET_UA]=
	    (1.0-penetrance[liab_class][HET])/(4.0-total_pen[liab_class]);
	  famtree[i].disease_prob[HET_AU]=
	    (1.0-penetrance[liab_class][HET])/(4.0-total_pen[liab_class]);
	  famtree[i].disease_prob[HOM_UNAFF]=
	    (1.0-penetrance[liab_class][HOM_UNAFF])/(4.0-total_pen[liab_class]);
	  break;
	case 2:
	  famtree[i].disease_prob[HOM_AFF]=
	    penetrance[liab_class][HOM_AFF]/total_pen[liab_class];
	  famtree[i].disease_prob[HET_UA]=
	    penetrance[liab_class][HET]/total_pen[liab_class];
	  famtree[i].disease_prob[HET_AU]=
	    penetrance[liab_class][HET]/total_pen[liab_class];
	  famtree[i].disease_prob[HOM_UNAFF]=
	    penetrance[liab_class][HOM_UNAFF]/total_pen[liab_class];
	  break;
	default: /* UNKNOWN */
	  famtree[i].disease_prob[HOM_AFF]=0.25;
	  famtree[i].disease_prob[HET_UA]=0.25;
	  famtree[i].disease_prob[HET_AU]=0.25;
	  famtree[i].disease_prob[HOM_UNAFF]=0.25;
	  break;
      }
    }
  }
}

/* expects global nuc_fam[], num_nuc_fams to be filled in */


void peel(long long int inh_vec, int num_bits)
{
    int nf, f, i, j, k, this_pivot, this_spouse, kid_allele, pivot_allele;
    double this_prob, total_prob, new_prob[4];
    int get_kid_allele(int,int,int,long long int,int);

    for (f=0; f<num_nuc_fams_to_peel; f++) {
      nf = order_assigned[f];

      this_pivot = nuc_fam[nf].pivot;
      if (this_pivot == MISSING)
	error("no pivot listed in non-final nuclear family");

      if (this_pivot == nuc_fam[nf].dad || this_pivot == nuc_fam[nf].mom) {
	/* PEEL ONTO PARENT */
	this_spouse =
	  (this_pivot==nuc_fam[nf].dad) ? nuc_fam[nf].mom : nuc_fam[nf].dad;
	for (i=0; i<4; i++) { /* pivot_parent genotypes */
	  new_prob[i]=0.0;
	  for (j=0; j<4; j++) { /* spouse's genotypes */
	    this_prob = famtree[this_spouse].disease_prob[j];
	    for (k=0; k<nuc_fam[nf].num_kids; k++) {
	      /* for each kid - lookup alleles based on i,j,inh_vec */
	      if (this_pivot==nuc_fam[nf].dad)
		kid_allele = 
		  get_kid_allele(nuc_fam[nf].kid[k],i,j,inh_vec,num_bits);
	      else
		kid_allele = 
		  get_kid_allele(nuc_fam[nf].kid[k],j,i,inh_vec,num_bits);
	      this_prob *= famtree[nuc_fam[nf].kid[k]].disease_prob[kid_allele];
	    }
	    new_prob[i] += this_prob;
	  }
	  /* update the pivot's probability based on this sub-pedigree */
	  famtree[this_pivot].disease_prob[i] *= new_prob[i];
	}

      } else { 
	/* PEEL ONTO KID */
	for (i=0; i<4; i++) new_prob[i]=0.0;
	for (i=0; i<4; i++) { /* dad's genotypes */
	  for (j=0; j<4; j++) { /* mom's genotypes */
	    this_prob = famtree[nuc_fam[nf].dad].disease_prob[i] *
	      famtree[nuc_fam[nf].mom].disease_prob[j];
	    for (k=0; k<nuc_fam[nf].num_kids; k++) {
	      kid_allele = get_kid_allele(nuc_fam[nf].kid[k],i,j,inh_vec,num_bits);
	      this_prob *= famtree[nuc_fam[nf].kid[k]].disease_prob[kid_allele];
	      if (nuc_fam[nf].kid[k] == this_pivot) pivot_allele=kid_allele;
	    }
	    new_prob[pivot_allele] += this_prob;
	  }
	}
	/* save the new probs for the pivot child */
	for (i=0; i<4; i++) famtree[this_pivot].disease_prob[i] = new_prob[i];
      }
    }
}


int get_kid_allele(int kid_index, int dad_disease, int mom_disease, 
		   long long int inh_vec, int num_bits)
{
    int bit,dad_all,mom_all,k1,k2;

    /* 1st non-original has dad bit at num_bits-1, mom_bit at num_bits-2, etc... */

    bit = famtree[kid_index].inh_vec_pos;

    dad_all = (int)((inh_vec >> (num_bits-(2*bit)-1))% 2);
    mom_all = (int)((inh_vec >> (num_bits-(2*bit)-2)) % 2);

    if (dad_all == 0) {
      if (dad_disease == HOM_AFF || dad_disease==HET_AU) k1=AFFECTED;
      else k1=UNAFFECTED;
    } else {
      if (dad_disease == HOM_AFF || dad_disease==HET_UA) k1=AFFECTED;
      else k1=UNAFFECTED;
    }

    if (mom_all == 0) {
      if (mom_disease == HOM_AFF || mom_disease==HET_AU) k2=AFFECTED;
      else k2=UNAFFECTED;
    } else {
      if (mom_disease == HOM_AFF || mom_disease==HET_UA) k2=AFFECTED;
      else k2=UNAFFECTED;
    }

    if (k1==AFFECTED && k2==AFFECTED) return(HOM_AFF);
    if (k1==AFFECTED && k2==UNAFFECTED) return(HET_AU);
    if (k1==UNAFFECTED && k2==AFFECTED) return(HET_UA);
    return(HOM_UNAFF);
}


void orig_haplotypes (int num_in_ped, int *iv_idx, int **draw_alleles,
		      int **haplotype, int **inferred)
{

  /* Fill in the haplotypes for the originals in ped */

  int i, j, k, count_it, vec_idx, num_orig=0, num_nonorig=0;
  int *original, indiv;
  int lookup_force(int);
  int dad0, dad1, mom0, mom1, dkid, mkid, all;

  array(original,num_in_ped,int);
  for (i=0; i<num_in_ped; i++) {
    if ( famtree[i].mom_index == MISSING &&
	 famtree[i].dad_index == MISSING ) {
      if (!famtree[i].discard) {
	original[num_orig] = i;
	num_orig++;
      }
    } else { if (!famtree[i].discard) num_nonorig++; }
  }

  for (i=0; i<num_orig*2; i++)
    for (j=0; j<num_markers; j++)
      haplotype[i][j]=0;

  /* Fill in the haplotype matrix */
  for (i=0; i<num_in_map_order; i++) {
    /* Call the allele dropping code so that the node_array
       and the EdgeList are filled in */
    fill_placeholder_alleles(iv_idx[i],num_nonorig,1);
    for (j=0; j<num_in_ped; j++) {
      draw_alleles[j][i*2]=famtree[j].place_allele[0];
      draw_alleles[j][i*2+1]=famtree[j].place_allele[1];
      if (allele_data[j][allele_offset+(map_order[i]*2)] == 0 ||
	  allele_data[j][allele_offset+(map_order[i]*2)+1] == 0) {
	  inferred[j][i*2]=TRUE; inferred[j][i*2+1]=TRUE;
      } else {
	  inferred[j][i*2]=FALSE; inferred[j][i*2+1]=FALSE;
      }
    }
    
    graph_assign_probs(iv_idx[i],num_orig,num_nonorig,map_order[i],haplotype,TRUE);

#ifdef TDT_ACTIVE

    /* keep TDT statistics */

    for (k=0; k<1; k++) { /* was 12 */

      count_it=TRUE;

      /**********
      count_it=FALSE;
      if (k==0 && npl_pos > 2.0) count_it=TRUE;
      else if (k==1 && npl_pos > 1.5) count_it=TRUE;
      else if (k==2 && npl_pos > 1.0) count_it=TRUE;
      else if (k==3 && npl_pos > 0.5) count_it=TRUE;
      else if (k==4 && npl_pos > 0.0) count_it=TRUE;
      else if (k==5 && npl_pos < 0.0) count_it=TRUE;
      else if (k==6 && npl_max > 2.0) count_it=TRUE;
      else if (k==7 && npl_max > 1.5) count_it=TRUE;
      else if (k==8 && npl_max > 1.0) count_it=TRUE;
      else if (k==9 && npl_max > 0.5) count_it=TRUE;
      else if (k==10 && npl_max > 0.0) count_it=TRUE;
      else if (k==11 && npl_max < 0.0) count_it=TRUE;
      **********/

      if (!count_it) continue;

     for (j=0; j<num_in_ped; j++) {
       
       if (famtree[j].affectation_status != AFFECTED) continue;
       if (famtree[j].discard) continue;
       if (famtree[j].dad_index==MISSING || famtree[j].mom_index==MISSING) 
	 continue;

       if (i == 0) total_affecteds[k]++;

       dad0 = haplotype[famtree[famtree[j].dad_index].place_allele[0]][map_order[i]];
       dad1 = haplotype[famtree[famtree[j].dad_index].place_allele[1]][map_order[i]];
       mom0 = haplotype[famtree[famtree[j].mom_index].place_allele[0]][map_order[i]];
       mom1 = haplotype[famtree[famtree[j].mom_index].place_allele[1]][map_order[i]];
       dkid = haplotype[famtree[j].place_allele[0]][map_order[i]];
       mkid = haplotype[famtree[j].place_allele[1]][map_order[i]];

       if (dad0 <= 0 || dad1 <= 0) {
	 if (mom0 <= 0 || mom1 <= 0) {
	    continue; /* both parents are missing in part */
	 } else {
	    if (mkid==mom0 && dkid!=mom1 && mom0!=mom1 && mkid!=dkid) {
	      locus[map_order[i]].allele_count[mom0][k][TRANSMITTED] += 1;
	      locus[map_order[i]].allele_count[mom1][k][UNTRANSMITTED] += 1;
	    } else if (mkid==mom1 && dkid!=mom0 && mom0!=mom1 && mkid!=dkid) {
	      locus[map_order[i]].allele_count[mom1][k][TRANSMITTED] += 1;
	      locus[map_order[i]].allele_count[mom0][k][UNTRANSMITTED] += 1;
	    } else {
	      continue;
	    }
	  }
	} else {
	  if (mom0 <= 0 || mom1 <= 0) {
	    if (dkid==dad0 && mkid!=dad1 && dad0!=dad1 && mkid!=dkid) {
	      locus[map_order[i]].allele_count[dad0][k][TRANSMITTED] += 1;
	      locus[map_order[i]].allele_count[dad1][k][UNTRANSMITTED] += 1;
	    } else if (dkid==dad1 && mkid!=dad0 && dad0!=dad1 && mkid!=dkid) {
	      locus[map_order[i]].allele_count[dad1][k][TRANSMITTED] += 1;
	      locus[map_order[i]].allele_count[dad0][k][UNTRANSMITTED] += 1;
	    } else {
	      continue;
	    }
	  } else {
	    /* both parents present */
	    if (dad0 != dad1) {
	      if (dkid==dad0) {
		locus[map_order[i]].allele_count[dad0][k][TRANSMITTED] += 1;
		locus[map_order[i]].allele_count[dad1][k][UNTRANSMITTED] += 1;
	      } else {
		locus[map_order[i]].allele_count[dad1][k][TRANSMITTED] += 1;
		locus[map_order[i]].allele_count[dad0][k][UNTRANSMITTED] += 1;
	      }
	    }
	    if (mom0 != mom1) {
	      if (mkid==mom0) {
		locus[map_order[i]].allele_count[mom0][k][TRANSMITTED] += 1;
		locus[map_order[i]].allele_count[mom1][k][UNTRANSMITTED] += 1;
	      } else {
		locus[map_order[i]].allele_count[mom1][k][TRANSMITTED] += 1;
		locus[map_order[i]].allele_count[mom0][k][UNTRANSMITTED] += 1;
	      }
	    }
	  }
	}

      } /* for each ped member (j) */
     } /* for k = 0 to 12 */

#endif

    } /* for each marker (i) */


  /* Print out the haplotype matrix */
  if (display_scores) {
    print("\nHAPLOTYPES OF ORIGINAL INDIVIDUALS: \n");
    for (i=0; i<(num_orig*2); i++) {
      indiv = i/2;
      if (i%2 == 0) {
	sf(ps,"\nindiv %s:\t",famtree[original[indiv]].indiv_ID); pr();
      } else { print("        \t"); }
      
      if (i%2 == 0) {
	sf(ps,"%s\t0\t0\t%d\t",famtree[original[indiv]].indiv_ID,
	   famtree[original[indiv]].affectation_status); fpr(haplofp);
      } else {
	sf(ps,"\t\t\t\t"); fpr(haplofp);
      }
      
    for (j=0; j<num_in_map_order; j++) {
      sf(ps,"%-3d ",haplotype[i][map_order[j]]); pr();
      fpr(haplofp);
    }
      nl(); fnl(haplofp);
    }
  }

  /* dump haplos of non-originals to haplofp */
  for (i=0; i<num_in_ped; i++) {
    if (famtree[i].discard) continue;
    if (famtree[i].dad_index==MISSING || famtree[i].mom_index==MISSING) 
      continue;
   
    sf(ps,"%s\t%s\t%s\t%d\t",famtree[i].indiv_ID,
       famtree[i].dad, famtree[i].mom, famtree[i].affectation_status);
    fpr(haplofp);
    for (j=0; j<num_in_map_order; j++) {
      all = draw_alleles[i][j*2];
      sf(ps,"%-3d ",haplotype[all][map_order[j]]);
      fpr(haplofp);
    }
    sf(ps,"\n\t\t\t\t"); fpr(haplofp);
    for (j=0; j<num_in_map_order; j++) {
      all = draw_alleles[i][(j*2)+1];
      sf(ps,"%-3d ",haplotype[all][map_order[j]]);
      fpr(haplofp);
    }
    fnl(haplofp);
  }
  unarray(original,int);
}
    
#define real_eq(x,y) (fabs((x)-(y))<.0000000001)

void remove_bit(int num_bits, int bit_to_remove, double **pvector, double *score,
	   int num_markers)
{
    int i, j, num_vecs, bitval, newcount;
    double *newlist;

    num_vecs=1; bitval=1;
    for (i=0; i<num_bits; i++) num_vecs*=2;
    for (i=0; i<bit_to_remove; i++) bitval*=2;
    array(newlist, num_vecs, double);

    for (j=0; j<num_markers; j++) {
      newcount=0;
      for (i=0; i<num_vecs; i++) {
	if ((i>>bit_to_remove) % 2 == 0) {
	  newlist[newcount] = pvector[j][i];
	  newcount++;
	  if (!real_eq(pvector[j][i],pvector[j][i+bitval])) {
	    sf(ps,"vectors %d and %d differ (marker %d), bit %d is relevant\n",
	       i,i+bitval,j+1,bit_to_remove); pr();
	    sf(ps,"%.12lf vs. %.12lf\n",pvector[j][i],pvector[j][i+bitval]);
	    pr();
	  }
	}
      }
      if (newcount != num_vecs/2) error("in remove_bit");
      for (i=0; i<newcount; i++) pvector[j][i]=newlist[i]*2.0;
    }

    newcount=0;
    for (i=0; i<num_vecs; i++) {
      if ((i>>bit_to_remove) % 2 == 0) {
	newlist[newcount] = score[i];
	newcount++;
	if (score[i] != score[i+bitval]) {
	  sf(ps,"scores for vectors %d and %d differ, bit %d is relevant\n",
	     i,i+bitval,bit_to_remove); pr();
	  break;
	}
      }
    }
    if (newcount != num_vecs/2) error("in remove_bit");
    for (i=0; i<newcount; i++) score[i]=newlist[i];
}


void add_bit(int num_bits, int bit_to_insert, int *pvec, int num_loci)
{
    int i, j, newpvec, pow2;

    for (i=0; i<num_loci; i++) {
      j=0; newpvec=0; pow2=1;
      while (j < bit_to_insert) {
	newpvec += ((pvec[i] >> j)%2)*pow2;
	pow2 *= 2;
	j++;
      }
      j++; pow2 *= 2;
      while (j-1 < num_bits) {
	newpvec += ((pvec[i] >> j-1)%2)*pow2;
	pow2 *= 2;
	j++;
      }
      pvec[i] = newpvec;
    }
}

/**********
int new_acceptable_vector(int vec, int mask)
{
    if ((vec&mask) > 0) return(FALSE);
    else return(TRUE);
}
**********/

int acceptable_vector(int vec, int num_bits)
{
    int i;
    /* for a vector to be acceptable, all uninformative bits must be 0 */

    for (i=0; i<num_bits; i++) {
      if (uninformative_bit[i]) {
	if ((vec>>i)%2 == 1) return(FALSE);
      }
    }
    return(TRUE);
}

int resort_pedigree(int non_originals)
{
    int i, temp, any_changes_made=FALSE;

    for (i=0; i<non_originals-1; i++) {
        if (famtree[sorted_ped[i]].affectation_status != AFFECTED &&

	    (famtree[sorted_ped[i+1]].affectation_status == AFFECTED ||
	     (famtree[sorted_ped[i]].nkids == 0 && 
	      famtree[sorted_ped[i+1]].nkids > 0)) &&

	    (famtree[sorted_ped[i+1]].dad_index != sorted_ped[i] &&
	     famtree[sorted_ped[i+1]].mom_index != sorted_ped[i]) ) {
	    /* we can flip them */
	    temp = sorted_ped[i];
	    sorted_ped[i] = sorted_ped[i+1];
	    sorted_ped[i+1] = temp;
	    any_changes_made=TRUE;
	}
    }
    if (any_changes_made) resort_pedigree(non_originals);
}



double brute_force_analyze(long long int inh_vec, int num_bits, int num_in_ped)
{
    unsigned long i, j;
    long long int or_vec, pow4[32];
    int original_list[MAX_INDIVIDUALS], node_assign[MAX_INDIVIDUALS*2]; 
    int originals, non_originals, non_original_list[MAX_INDIVIDUALS];
    int indiv, a0, a1, this_dis_loc, n1, n2;
    double this_prob, total_prob;

    originals=0; non_originals=0;
    for (i=0; i<num_in_ped; i++) {
      if (famtree[i].not_peeled) {
	if (famtree[i].dad_index==MISSING && famtree[i].mom_index==MISSING) {
	    original_list[originals]=i;
	    originals++;
	} 
	else if (!famtree[famtree[i].dad_index].not_peeled ||
		 !famtree[famtree[i].mom_index].not_peeled) {
	    original_list[originals]=i;
	    originals++;
	} else {
	    non_original_list[non_originals]=i;
	    non_originals++;
	}
      }
    }

    
    /*    if (originals > 15) { */
    /* G. Conant--I can't find why this function won't work with >15, so I changed to >31 */
       if (originals > 31 ) {
      if(inh_vec == 0) {
        sf(ps,"too many originals (%d) to run this routine (brute_force)\n",
	   originals);
	pr();
	print("Cannot compute LOD scores for this pedigree\n");
      }
      return(1.0);
    }

    pow4[0]=1;
    for (i=1; i<32; i++) pow4[i]=pow4[i-1]*4;

    total_prob = 0.0;
    for (or_vec=0; or_vec<pow4[originals]; or_vec++) {
     
      this_prob=1.0;
      for (i=0; i<MAX_INDIVIDUALS; i++) node_assign[i]=-1;

      for (i=0; i<originals; i++) {
	if (i == 0) this_dis_loc = (int)(or_vec % 4);
	else this_dis_loc = (int)((or_vec/pow4[i]) % 4);
	this_prob *= famtree[original_list[i]].disease_prob[this_dis_loc];
	n1 = famtree[original_list[i]].place_allele[0];
	n2 = famtree[original_list[i]].place_allele[1];
	
	switch (this_dis_loc) {
	  case HOM_AFF: node_assign[n1]=AFFECTED; node_assign[n2]=AFFECTED; break;
	  case HOM_UNAFF: node_assign[n1]=UNAFFECTED; node_assign[n2]=UNAFFECTED; break;
	  case HET_UA: node_assign[n1]=UNAFFECTED; node_assign[n2]=AFFECTED; break;
	  case HET_AU: node_assign[n1]=AFFECTED; node_assign[n2]=UNAFFECTED; break;
	  default: sf(ps,"%d is not a valid N % 4",this_dis_loc); error(ps);
	}
      }
      for (i=0; i<non_originals; i++) {
	/* tack on probs of each non-orig disease_prob[disease_alleles] */
	indiv = non_original_list[i];
	a0 = node_assign[famtree[indiv].place_allele[0]];
	a1 = node_assign[famtree[indiv].place_allele[1]];
	if (a0 == -1 || a1 == -1) { 
	  printf("ERROR--undefined placeholder allele - brute_force_analyze: ft: %d, %d, na: %d, %d \n",
		 famtree[indiv].place_allele[0], famtree[indiv].place_allele[1], node_assign[famtree[indiv].place_allele[0]],
		 node_assign[famtree[indiv].place_allele[1]]);
	  error("undefined placeholder allele - brute_force_analyze"); 
	}

	if (a0 == AFFECTED) {
	  if (a1 == AFFECTED) this_prob *= famtree[indiv].disease_prob[HOM_AFF];
	  else this_prob *= famtree[indiv].disease_prob[HET_AU];
	} else {
	  if (a1 == AFFECTED) this_prob *= famtree[indiv].disease_prob[HET_UA];
	  else this_prob *= famtree[indiv].disease_prob[HOM_UNAFF];
	}
      }
    
      total_prob += this_prob;
    }
   
    /* if (inh_vec == 0) { print("done\n"); } */
    return(total_prob);
}

int local_pad_inhvec(int vec, int uninf_mask, int num_bits)
{
    int i, newvec, count, realcount;

    newvec=0; realcount=0;
    for (i=0; i<num_bits; i++) {
      if ((uninf_mask&pow2[i]) > 0) {
        /* bit inserted here */
      } else {
        if ((vec&pow2[realcount]) > 0) {
          newvec += pow2[i];
        }
        realcount++;
      }
    }
    return(newvec);
}

/*----------------------------------------------------*/
/*----------------------------------------------------*/
int Setup_local_pad_inhvec_2(long long int uninf_mask, int num_bits,
                         long long int padMask[], long long int padShift[])
{
	int i, fs_bit, npadMS;
	
	for(i=0; i<64; i++) { padMask[ i] = padShift[i] = -1; }
	
	fs_bit = 0;
	for(i=0; i<num_bits; i++) {
		if(uninf_mask & pow2[i]) continue;
		padMask[ fs_bit] = pow2[fs_bit];
		padShift[fs_bit] = i - fs_bit;
		fs_bit++;
	}
	
	npadMS = 0;
	for(i=1; i<fs_bit; i++) {
		if(padShift[npadMS] == padShift[i]) {
			padMask[npadMS] |= padMask[i];
		} else {
			npadMS++;
			padMask[ npadMS] = padMask[ i];
			padShift[npadMS] = padShift[i];
		}
	}
	npadMS++;
	
/*	printf(" ------------------------ start i, padMask, padShift\n");
	for(i=0; i<npadMS; i++) 
		printf(" %6d  %8x %8x\n", i, padMask[ i], padShift[i]);
	printf(" ------------------------ end   i, padMask, padShift\n");
*/	
	return(npadMS);
}

/*----------------------------------------------------*/
/*----------------------------------------------------*/
void fill_placeholder_alleles_2(int print_flag, int iFirstMember,
                           long long int vec, int non_originals, int for_hap)
{
	int i,mom,dad,num_bits;

	num_bits = non_originals*2;
	
	for (i=iFirstMember; i<non_originals; i++) {
		famtree[sorted_ped[i]].place_allele[0] = -1;
		famtree[sorted_ped[i]].place_allele[1] = -1;
	}

	if (vec==0 && !for_hap) {
		if(print_flag) print("using non-originals: ");
		for (i=0; i<non_originals; i++) {
			if(print_flag) {sf(ps," %s",famtree[sorted_ped[i]].indiv_ID); pr(); }
			dad = famtree[sorted_ped[i]].dad_index;
			mom = famtree[sorted_ped[i]].mom_index;
			famtree[sorted_ped[i]].inh_vec_pos = i;
			famtree[dad].analyzed_parent=TRUE;
			famtree[mom].analyzed_parent=TRUE;
			uninformative_bit[num_bits-(2*i)-1]=FALSE;
			uninformative_bit[num_bits-(2*i)-2]=FALSE;	  
			if (famtree[sorted_ped[i]].dad_bit_uninf)
				uninformative_bit[num_bits-(2*i)-1] = TRUE;
			if (famtree[sorted_ped[i]].mom_bit_uninf)
				uninformative_bit[num_bits-(2*i)-2] = TRUE;
		}
    	if(print_flag) nl();
	}

	for (i=iFirstMember; i<non_originals; i++) {
		/* sorted_ped[] = index of non_originals in correct order */
		dad = famtree[sorted_ped[i]].dad_index;
		mom = famtree[sorted_ped[i]].mom_index;

		famtree[sorted_ped[i]].place_allele[0] = 
		famtree[dad].place_allele[(int)(vec>>(num_bits-(2*i)-1))%2];

		famtree[sorted_ped[i]].place_allele[1] = 
		famtree[mom].place_allele[(int)(vec>>(num_bits-(2*i)-2))%2];
	}
}
/*----------------------------------------------------*/










/*----------------------------------------------------*/

int  FindIllegalBits(int originals, int real_non_originals,
                     int num_bits, int real_num_bits,
					 int f_num_in_map_order, int *f_map_order, int *f_uninformative)
{
	int i, j, dad, mom, nSibships, nSibs, nSibs_all, ifamily;
	int nPhaseFixed, iPhaseFixed;
	long long int mask, maskPhaseFixed; 
	int inh_vec_pos;
	int arrSibships[MAX_INDIVIDUALS], arrPhaseFixed[MAX_INDIVIDUALS];
	int arrSibs[MAX_INDIVIDUALS];
	long long int uninformative_mask;
	long long int sib_mask, sib_inf_mask;
	int iMarker, marker, nSibs_inf, arrSibs_inf[9], 
	    arrSibs_inf_rep[MAX_INDIVIDUALS];
	int allele1, allele2, allele3, allele4, allele[2];
	int i1, inList;
	int nSibs_inf_bits, nSibs_inf_vecs, nSibMS,  sibShift[64];
	long long int vec, sibMask[64];
	int iFmem, iSib, iSib_inf, num_edges;
	int ibit, ibit_s, sum_s[MAX_INDIVIDUALS*2][2];
	int ipass;
	int b_fixed, p_fixed, m_fixed, ibit_r, ibit_o;
	long long int ibmask;
	int arrSib_flipMask[MAX_INDIVIDUALS][MAXLOCI][2];
	int emi[MAXLOCI][MAX_INDIVIDUALS*2][2];
	int iparent, iparent_o, ig_dad, ig_mom, lgc[2], child_homozygote;
	int iSpMem, nSpMem, spMemID[MAX_INDIVIDUALS], cur_place, spFirstMember;
	int bitcnt_fix, bitcnt_use;
/*-------------------------------------------- include 	grandparents algorithm */
#define B_POS_OFFS  5
	int nbit_pos, bit_pos[MAX_INDIVIDUALS*B_POS_OFFS*2];
	int indID, nPar_bits, nF_bits;
	int nSibs_inf_bits_all, nSibs_inf_bits_wp;
	int nSibs_inf_vecs_all, nSibs_inf_vecs_wp;
/*-------------------------------------------- matrix num_in_map_order here */
/*-------------------------------------------- position */
	int    jMarker;
	double total, map_position;
	
	int *legalVec=NULL;
	ASSIGN_STRUCT *assign_list,*alist;
	void create_nodes(int), AddEdge(int,int,int,int),
	     process_graph(ASSIGN_STRUCT*), free_assign(ASSIGN_STRUCT*);

#ifdef PR_00
	  printf("----------- FindIllegalBits ------------\n");
#endif

	for(i=0; i<f_num_in_map_order; i++) inconsistent_genotypes[i] = FALSE;
	
	for(i=0; i<MAXLOCI; i++) {
		for(j=0; j<MAX_INDIVIDUALS*2; j++) {
			emi[i][j][0] = emi[i][j][1] = 9;
		}
	}
	
	uninformative_mask=0;
	for (i=0; i<num_bits; i++) {
		if (uninformative_bit[i]) uninformative_mask |= pow2[i];
	}
#ifdef PR_01
	printf("uninformative_mask=%x \n", uninformative_mask);
#endif
	
	/* Define nuclear families ---------------------------------------*/
	nSibships=0;
	for (i=0; i<real_non_originals; i++) {
		/* sorted_ped[] = index of real_non_originals in correct order */
		dad = famtree[sorted_ped[i]].dad_index;
		mom = famtree[sorted_ped[i]].mom_index;
		for(j=0; j<nSibships; j++) {
			if( (dad==arrSibships[j*2]) && (mom==arrSibships[j*2+1]) ) break;
		}
		if( j==nSibships ) {
			arrSibships[nSibships*2]  =dad;
			arrSibships[nSibships*2+1]=mom;
			nSibships++;
		}
	}
	if( (nSibships*2-1) > MAX_INDIVIDUALS ) { 
		printf(" ******Error arrSibships overflow *******\n");
		exit (1);
	}
	
	/* Execute per nuclear family ---------------------------------------*/
	for(ifamily=0; ifamily<nSibships; ifamily++) {
		dad=arrSibships[ifamily*2];
		mom=arrSibships[ifamily*2+1];

#ifdef PR_03
		printf("sibship of %s  %s\n", famtree[dad].indiv_ID, 
		                                        famtree[mom].indiv_ID);
#endif
		
		/* Define sibship (array arrSibs[] & sib_mask -----*/
		nSibs=0;
		for(i=0; i<real_non_originals; i++) {
			if( (dad==famtree[sorted_ped[i]].dad_index) && 
			    (mom==famtree[sorted_ped[i]].mom_index) ) {
				arrSibs[nSibs]=sorted_ped[i];
				nSibs++;
			}
		}
/* Here define nSibs_all for discarded indiv. */

#ifdef PR_04
		printf("                  (nSibs=%d)  ", nSibs);
		for(i=0; i<nSibs; i++) printf("%s  ", famtree[ arrSibs[i] ].indiv_ID);
#endif
		sib_mask = j = nPhaseFixed = iPhaseFixed = 0;
		for(i=0; i<nSibs; i++) {
			j         = famtree[ arrSibs[i] ].inh_vec_pos;
			mask      = pow2[ num_bits - j*2 -1 ] +
			            pow2[ num_bits - j*2 -2 ];
			sib_mask |= mask;
			if((mask & uninformative_mask) != 0) { 
				nPhaseFixed++; 
				iPhaseFixed=i;
				maskPhaseFixed=mask;
			}
		}
		if(nPhaseFixed > 1) { 
			printf(" ******Error nPhaseFixed > 1 *****\n"); exit (1);
		}

#ifdef PR_04
			printf("  sib_mask=%x", sib_mask);
			if(nPhaseFixed==0) printf("  -- no PhaseFixed sib -- ");
			else printf("  PhaseFixed=%s, maskPhaseFixed=%x ", 
			famtree[ arrSibs[iPhaseFixed] ].indiv_ID, maskPhaseFixed);
			printf("\n");
#endif

		/* itterate over the marker list.  Informative sibship set is 
		marker dependent */
		/*------- execute per marker ---------------------------*/
		for(iMarker=0; iMarker<f_num_in_map_order; iMarker++) {
			marker = f_map_order[iMarker];
			
			/* find a set of informative sibs (unique genotype) */
			/* if no "phase fixer" just 
			set first sib (e.g. consanguineous pedigree) */
 			if(nPhaseFixed==0) iPhaseFixed=0;
 			/* save the id of sib used to fix phase */
 			arrPhaseFixed[ifamily]=arrSibs[iPhaseFixed];
			
			/* now define set of informative sibs */
			arrSibs_inf[0]=arrSibs[iPhaseFixed];
			nSibs_inf=1;
			for(i=0; i<nSibs; i++) {
				if(i==iPhaseFixed) { continue; }
				i1=arrSibs[i];
				allele1=allele_data[i1][allele_offset+(2*marker)];
				allele2=allele_data[i1][allele_offset+(2*marker)+1];
				if(allele1==0 && allele2==0) { 
					arrSibs_inf_rep[arrSibs[i]]=-1;
					continue; 
				}
				inList=0;
				for(j=1; j<nSibs_inf; j++) {
					i1=arrSibs_inf[j];
					allele3=allele_data[i1][allele_offset+(2*marker)];
					allele4=allele_data[i1][allele_offset+(2*marker)+1];
					if(COMP_GENOTYPES(allele1,allele2,allele3,allele4)) {
						inList=1;
						arrSibs_inf_rep[arrSibs[i]]=j;
						break;
					}
				}
				if(!inList) { 
					arrSibs_inf[nSibs_inf]=arrSibs[i];
					arrSibs_inf_rep[arrSibs[i]]=nSibs_inf;
					nSibs_inf++;
				}
			}
			sib_inf_mask=0;
			for(i=0; i<nSibs_inf; i++) {
				j         = famtree[ arrSibs_inf[i] ].inh_vec_pos;
				mask      = pow2[ num_bits - j*2 -1 ] +
				            pow2[ num_bits - j*2 -2 ];
				sib_inf_mask |= mask;
			}

#ifdef PR_05
			  printf("                  marker=%d\t nSibs_inf=%d\t arrSibs_inf=", 
						marker, nSibs_inf);
			for(i=0; i<nSibs_inf; i++) printf("%s  ", 
														 famtree[ arrSibs_inf[i] ].indiv_ID);
			printf("  sib_inf_mask=%x\n", sib_inf_mask);
#endif

/*---- max number of informative sibs = 9 = 1*phaseFixer + 4*(A,B) + 4*(A,0) */
			if(nSibs_inf>9) {
				printf(" ******Error nSibs_inf overflow *******\n");
				exit (1);
			}

			nSibs_inf_bits = 2*(nSibs_inf-1);
			nSibs_inf_vecs = (int)pow2[ nSibs_inf_bits ];
			nbit_pos       = 0;

			/*  for array (struct)  bit_pos[]: 
			    indID    index for famtree[indID].x access
			    ibit_s   bit position for (inf.sibs+parent) inheritance vector 
			    ibit_r   bit position for founder symmetry reduced inheritance vector
			    i1       flag that:
				         -1  the bit belongs to an individual ungenotyped 
				             in this marker => cannot be constrained.
				          1  bit participates in the inf.sibs+parent 
						     inheritance vector.
				          0  bit represented in the inf.sibs+parent inh. vector.
			    ibit_o   bit position for original inheritance vector*/
			
			/* all sibs but the phase fixer */
			for(i=0; i<nSibs; i++) {
				if(i==iPhaseFixed) { continue; }
				iSib_inf    = arrSibs_inf_rep[arrSibs[i]];
				indID       = arrSibs[i];
				inh_vec_pos = famtree[indID].inh_vec_pos;

				/* ibit paternal=1, maternal=0 */
				for(ibit=1; ibit >= 0; ibit--) {
					ibit_r = ibit_o = (num_bits - inh_vec_pos*2 - 2) + ibit;
					for(j=0; j<ibit_o; j++) if(uninformative_bit[j]) ibit_r--;
					if(iSib_inf==-1) {
						/* this marker is ungenotyped, meiosis cannot be constrained*/
						ibit_s =  0;
						i1     = -1;
					} else {
						ibit_s = 2*(nSibs_inf - 1- iSib_inf)    + ibit;
						i1 = 0;
					}
					for(j=1; j<nSibs_inf; j++) {
						if(indID==arrSibs_inf[j]) {i1=1; continue;}
					}
					bit_pos[B_POS_OFFS*nbit_pos]     = indID;
					bit_pos[B_POS_OFFS*nbit_pos + 1] = ibit_s;
					bit_pos[B_POS_OFFS*nbit_pos + 2] = ibit_r;
					bit_pos[B_POS_OFFS*nbit_pos + 3] = i1;
					bit_pos[B_POS_OFFS*nbit_pos + 4] = ibit_o;
					nbit_pos++;
				}
			}

			/* parents if grandparents exist */
			nPar_bits = 0;
			for(i=0; i<2; i++) {
				if(i==0) indID = mom;
				else     indID = dad;

				/* require both grandparents in pedigree */
				if( (famtree[indID].dad_index==MISSING) || 
	    			(famtree[indID].mom_index==MISSING)   ) continue;

				inh_vec_pos = famtree[indID].inh_vec_pos;

				for(ibit=0; ibit<2; ibit++) {
					ibit_r = ibit_o = (num_bits - inh_vec_pos*2 - 2) + ibit;
					for(j=0; j<ibit_o; j++) if(uninformative_bit[j]) ibit_r--;

					/* bit fixed by founder symmetry?*/
					if((uninformative_mask & pow2[ibit_o]) != 0) continue;

					if( (emi[marker][ibit_r][0] != 0) &&
		    			(emi[marker][ibit_r][0] != 1)   ) {
						nPar_bits++;
						ibit_s = nSibs_inf_bits - 1 + nPar_bits;
						bit_pos[B_POS_OFFS*nbit_pos]     = indID;
						bit_pos[B_POS_OFFS*nbit_pos + 1] = ibit_s;
						bit_pos[B_POS_OFFS*nbit_pos + 2] = ibit_r;
						bit_pos[B_POS_OFFS*nbit_pos + 3] = 1;
						bit_pos[B_POS_OFFS*nbit_pos + 4] = ibit_o;
						nbit_pos++;
					}
				}
			}

			/* reference phase (phase fixer) sib */
			nF_bits     = 0;
			indID       = arrSibs[iPhaseFixed];
			inh_vec_pos = famtree[indID].inh_vec_pos;

			/* ibit paternal=1, maternal=0 */
			for(ibit=1; ibit >= 0; ibit--) {
				ibit_r = ibit_o = (num_bits - inh_vec_pos*2 - 2) + ibit;
				for(j=0; j<ibit_o; j++) if(uninformative_bit[j]) ibit_r--;

				/* bit fixed by founder symmetry?*/
				if((uninformative_mask & pow2[ibit_o]) != 0) continue;

				nF_bits++;
				ibit_s = nSibs_inf_bits - 1 + nPar_bits + nF_bits;
				bit_pos[B_POS_OFFS*nbit_pos]     = indID;
				bit_pos[B_POS_OFFS*nbit_pos + 1] = ibit_s;
				bit_pos[B_POS_OFFS*nbit_pos + 2] = ibit_r;
				bit_pos[B_POS_OFFS*nbit_pos + 3] = 1;
				bit_pos[B_POS_OFFS*nbit_pos + 4] = ibit_o;
				nbit_pos++;
			}

			nSibs_inf_bits_wp  = nSibs_inf_bits    + nPar_bits;
			nSibs_inf_bits_all = nSibs_inf_bits_wp + nF_bits;
			nSibs_inf_vecs     = (int)pow2[ nSibs_inf_bits ];
			nSibs_inf_vecs_wp  = (int)pow2[ nSibs_inf_bits_wp ];
			nSibs_inf_vecs_all = (int)pow2[ nSibs_inf_bits_all ];
			
#ifdef PR_15
			for(i=0; i<nbit_pos; i++) {
			  indID  = bit_pos[B_POS_OFFS*i];
			  ibit_s = bit_pos[B_POS_OFFS*i + 1];
			  ibit_r = bit_pos[B_POS_OFFS*i + 2];
			  i1     = bit_pos[B_POS_OFFS*i + 3];
			  ibit_o = bit_pos[B_POS_OFFS*i + 4];
			  printf("                  ");
			  printf("%s ibit_r=%3d  ibit_s=%3d  %2d  ibit_o=%3d \n", 
						famtree[ indID ].indiv_ID, ibit_r, ibit_s, i1, ibit_o);
			}
#endif


			array (legalVec, nSibs_inf_vecs_all, int);
			for(i=0; i<nSibs_inf_vecs_all; i++) legalVec[i]=0;
			for(ibit=0; ibit<nSibs_inf_bits_all; ibit++) {
				sum_s[ibit][0] = sum_s[ibit][1] = 0;
			}
			
			/* build a mask-shift array */
			for(i=0; i<64; i++) { sibShift[i] = -1; }
			for(i=0; i<nbit_pos; i++) {
				ibit_s = bit_pos[B_POS_OFFS*i + 1];
				i1     = bit_pos[B_POS_OFFS*i + 3];
				ibit_o = bit_pos[B_POS_OFFS*i + 4];
				if(i1==1) {
					sibMask[ibit_s]  = 1 << ibit_s;
					sibShift[ibit_s] = ibit_o - ibit_s;
				}
			}
			nSibMS=0;
			for(i=1; i<nSibs_inf_bits_all; i++) {
				if(sibShift[i]==sibShift[nSibMS]) {
					sibMask[nSibMS] |= sibMask[i];
				} else {
					nSibMS++;
					sibMask[nSibMS]  = sibMask[i];
					sibShift[nSibMS] = sibShift[i];
				}
			}
			nSibMS++;
			/* END build a mask-shift array */
			
#ifdef PR_16
			for(i=0; i<nSibMS; i++){
			  printf("                  MaskShift %3d  %8x  %d\n", 
						i, sibMask[i], sibShift[i]);
			}
#endif

#ifdef PR_17
			for(i=0; i<nSibs_inf_vecs_all; i++) {
			  vec = 0;
			  for(j=0; j<nSibMS; j++){ 
				 if(sibShift[j]>0) vec |= ((long long int)(i & sibMask[j])) <<  sibShift[j];
				 else              vec |= ((long long int)(i & sibMask[j])) >> -sibShift[j];
			  }
			  printf("  i=%6x  vec=%6x \n", i, vec);
			}
#endif


			/* Define founders and members of subPedigree */
			nSpMem=0;
			cur_place=originals*2;
			spFirstMember=real_non_originals;
			for(iFmem=0; iFmem < nSibs_inf+6; iFmem++) {
				if(iFmem==0) {
					j=famtree[dad].dad_index;
				} else if(iFmem==1) {
					j=famtree[dad].mom_index;
				} else if(iFmem==2) {
					j=famtree[mom].dad_index;
				} else if(iFmem==3) {
					j=famtree[mom].mom_index;
				} else if(iFmem==4) {
					j=dad;
				} else if(iFmem==5) {
					j=mom;
				} else {
					iSib = iFmem - 6;
					j=arrSibs_inf[iSib];
				}
				
				if(j==MISSING) continue;
				spMemID[nSpMem++] = j;
				
				/* check if grandparents whole pedigree founders.
				   Error due to single parent individual already checked */
				if(iFmem<4){
					if(famtree[j].dad_index != MISSING) {
						famtree[j].place_allele[0]=cur_place++;
						famtree[j].place_allele[1]=cur_place++;
					}
				}
				
				/* find the firsd individual that needs placeholder alleles
				   set by inheritance pattern.  dad, mom, or sibs. */
				if(iFmem>3) {
					for(i=0; i<real_non_originals; i++) {
						if((j==sorted_ped[i]) && (i<spFirstMember)) 
							spFirstMember=i;
					}
				}
			}

#ifdef PR_18
			printf("spFirstMember=%2d nSpMem=%d : ", spFirstMember, nSpMem);
			for(iSpMem=0; iSpMem<nSpMem; iSpMem++) {
			  j=spMemID[iSpMem];
			  printf("%s ", famtree[ j ].indiv_ID);
			}
			printf("\n");
#endif

			
			/* Check all possible inheritance vectors in nuclear family */
			for(i=0; i<nSibs_inf_vecs_all; i++) {
				vec = 0;
				for(j=0; j<nSibMS; j++){ 
					if(sibShift[j]>0) vec |= ((long long int)(i & sibMask[j])) <<  sibShift[j];
					else              vec |= ((long long int)(i & sibMask[j])) >> -sibShift[j];
				}
				fill_placeholder_alleles_2(0, spFirstMember, 
				                           vec, real_non_originals,0);
				create_nodes(cur_place);
				num_edges=0;
				for(iSpMem=0; iSpMem<nSpMem; iSpMem++) {
					j=spMemID[iSpMem];
					
					if (allele_data[j][allele_offset+(2*marker)] == 0 &&
					allele_data[j][allele_offset+(2*marker)+1] == 0) continue;
					
					AddEdge( famtree[j].place_allele[0],
					         famtree[j].place_allele[1],
					         allele_data[j][allele_offset+(2*marker)],
					         allele_data[j][allele_offset+(2*marker)+1] );
					num_edges++;
				}

				if (num_edges > 0) { 
					single (assign_list, ASSIGN_STRUCT);
					assign_list->next=NULL; assign_list->num_alleles=0;
					process_graph(assign_list);
					alist=assign_list;
					
					if (alist->num_alleles != 0) {
						legalVec[i]=1;
						for(ibit=0; ibit<nSibs_inf_bits_all; ibit++) {
							if((int)pow2[ibit] & i) sum_s[ibit][1]++;
							else               sum_s[ibit][0]++;
						}
					} 
					free_assign(assign_list);
				} else {
					/* all individuals are missing, all patterns legal */
					legalVec[i]=1;
					for(ibit=0; ibit<nSibs_inf_bits_all; ibit++) {
						if((int)pow2[ibit] & i) sum_s[ibit][1]++;
						else               sum_s[ibit][0]++;
					}
				}
				
				/*-------------- save in emi array */
				/* Save result in emi[marker][ibit_r][1/0],  
				arrSib_flipMask[ifamily][marker][1/0] */
				if(i==(nSibs_inf_vecs_wp-1)) {
					if((sum_s[0][1] + sum_s[0][0]) == 0) {
						/* no solution for this phase fix */
						for(j=0; j<nbit_pos; j++) {
							ibit_s = bit_pos[B_POS_OFFS*j + 1];
							ibit_r = bit_pos[B_POS_OFFS*j + 2];

							/* set only if not set already (for parents)*/
							if( (emi[marker][ibit_r][1]>1) && 
							    (ibit_s<nSibs_inf_bits)   ) {
								emi[marker][ibit_r][1] = 8;
							}
						}
					} else {
						for(j=0; j<nbit_pos; j++) {
							ibit_s = bit_pos[B_POS_OFFS*j + 1];
							ibit_r = bit_pos[B_POS_OFFS*j + 2];

							if(bit_pos[B_POS_OFFS*i + 3] == -1) {
						       /* this marker is ungenotyped, meiosis cannot be constrained*/
								i1=2;
							} else {
								if(     sum_s[ibit_s][1] == 0) { i1=0; }
								else if(sum_s[ibit_s][0] == 0) { i1=1; }
								else                           { i1=2; }
							}
							/* set only if not set already (for parents)*/
							if( (emi[marker][ibit_r][1]>1) && 
							    (ibit_s<nSibs_inf_bits_wp)   ) {
								emi[marker][ibit_r][1] = i1;
							}
						}
					}
				} 
				if(i==(nSibs_inf_vecs_all-1)) {
					/* In case no informative bits exist (two founders with a single
					child) the single legal pattern has 
					(sum_s[0][1] + sum_s[0][0]) == 0) but  (legalVec[1] == 1) */
					if( ((sum_s[0][1] + sum_s[0][0]) == 0) && (legalVec[0] == 0) ) {

/*						printf(" ******Error Inconsistent genotypes\n");
						printf(" family of %s  %s\n", famtree[dad].indiv_ID, 
	                                        	famtree[mom].indiv_ID);
						printf(" marker=%d\t nSibs_inf=%d\t arrSibs_inf=", 
						marker, nSibs_inf);
						for(iSib=0; iSib<nSibs_inf; iSib++) printf("%s  ", 
						famtree[ arrSibs_inf[iSib] ].indiv_ID);
						printf("  sib_inf_mask=%x\n", sib_inf_mask);
						printf(" *************************************\n");
*/
						sf(ps,"ERROR: bad inheritance in pedigree %s, marker %s\n",
						current_ped, locus[marker].name); pr();
						sf(ps,"       family of %s  %s\n", 
						famtree[dad].indiv_ID, 
						famtree[mom].indiv_ID); pr();
						print("SKIPPING THIS PEDIGREE\n");

						inconsistent_genotypes[iMarker] = TRUE; 
						/* since this is the last itteration (last in list of 
						   possible inheritance vectors) we do not need 
						   a break statement here*/
						/* exit (1); */
					} else {
						for(j=0; j<nbit_pos; j++) {
							ibit_s = bit_pos[B_POS_OFFS*j + 1];
							ibit_r = bit_pos[B_POS_OFFS*j + 2];

							if(bit_pos[B_POS_OFFS*j + 3] == -1) {
						       /* this marker is ungenotyped, meiosis cannot be constrained*/
								i1=2;
							} else {
								if(     sum_s[ibit_s][1] == 0) { i1=0; }
								else if(sum_s[ibit_s][0] == 0) { i1=1; }
								else                           { i1=2; }
							}
							
							/* set only if not set already (for parents)*/
							if(emi[marker][ibit_r][0]>1) {
								emi[marker][ibit_r][0] = i1;
							}
						}
					}
				}
				/*-------------- END save in emi array */
				
			}
			/* END Check all possible inheritance vectors in nuclear family */
			
#ifdef PR_06
			printf("                  sum 0-1(ibit) ");
			for(ibit=nSibs_inf_bits-1; ibit>=0; ibit--) {
			  printf("%d-%d(%d)  ", 
						sum_s[ibit][0], sum_s[ibit][1], ibit);
			}
			printf("\n");
#endif

			unarray (legalVec, int);
		} /*-------END execute per marker-------------------------*/
	} /* ---------------------------------END Execute per nuclear family */
	
#if defined(PR_12) || defined(PR_13)
		printf("\n");
		for(ipass=1; ipass>=0; ipass--) {
			if((ipass == 0) && !PR_12) continue;
			if((ipass == 1) && !PR_13) continue;
			printf("                          non-originals:     ");
			for(i=0; i<real_non_originals; i++) {
				printf("  %2s", famtree[sorted_ped[i]].indiv_ID);
			}
			printf("\n");
			total   = 0.0;
			jMarker = 0;
			for(iMarker=0; iMarker<f_num_in_map_order; iMarker++) {
				marker = f_map_order[iMarker];
				map_position = total;
				while(map_distance[jMarker] == 0.) jMarker++;
				total += map_distance[jMarker];
				jMarker++;
				printf("                  e[%1d]  iM=%3d  m=%3d %7.2lf", 
				ipass, iMarker, marker, map_position);
				ibit_r  = real_num_bits-1;
				bitcnt_use = bitcnt_fix = 0;
				for(ibit=num_bits-1; ibit>=0; ibit--) {
					ibmask=pow2[ibit];
					if(ibit & 1) printf("  ");
					if((ibmask & uninformative_mask) != 0) {
						printf("_");
					}
					else if(emi[marker][ibit_r][ipass]==2) {
						printf("x");
						bitcnt_use++;
					}
					else {
						printf("%1d", emi[marker][ibit_r][ipass]); 
						bitcnt_use++;
						bitcnt_fix++;
					}
					if((ibmask & uninformative_mask) == 0) ibit_r--;
				}
				printf("  (%2d/%2d)",bitcnt_fix,bitcnt_use);
				if(f_uninformative[iMarker]) printf("*");
				printf("\n");
			}
			printf("\n");
		}
#endif


	/* make a mask/test per marker */
	for(iMarker=0; iMarker<f_num_in_map_order; iMarker++) {
		marker = f_map_order[iMarker];
/*		printf("marker = f_map_order[%2d] =%d\n", iMarker, marker); */
		
		/* if no possible solution just set maskTest[][0:1] = 1,0 */
		if(inconsistent_genotypes[iMarker]) {
			maskTest[iMarker][0] = 1;
			maskTest[iMarker][1] = 0;
		} else {
			maskTest[iMarker][0] = maskTest[iMarker][1] = 0;
			for(ibit=0; ibit<real_num_bits; ibit++) {
				j = emi[marker][ibit][0];
				if((j==0) || (j==1)) maskTest[iMarker][0] |= pow2[ibit];
				if(j==1)             maskTest[iMarker][1] |= pow2[ibit];
			}

/* Debugging only:
			printf("                  m=%3d,  maskTest %8x\n", 
			iMarker, maskTest[iMarker][0]);
			printf("                          maskTest %8x\n", 
			maskTest[iMarker][1]);
*/

		}

	}

#ifdef PR_00
	printf("----------- FindIllegalBits END---------\n");
#endif
	return 0;
}

int  print_requirements(int num_in_map_order, int num_bits, int real_num_bits, int score_mask_rdc,
                        int amount_to_alloc, int score_alloc, int *nz_bits,
						int f_num_in_map_order,
		                int *f_uninformative)
{
	long long int di, dj;
	int           i, iMarker, nuninformative, max_bitc, max_bitc_n, reduced_num_markers;
	int           print_mode;
	double        num_elements, memsize;
	double        d_num_elements[200], d_memsize[200];
	double        d_num_in_map_order, d_vectors, d_amount_to_alloc, 
	              d_score_alloc, d_one_meg,
				  disease_priors_0, transition_tmp_0,
				  disease_priors_1, transition_tmp_1;

	/*  print_mode = 0  Print details
	                 1  Print summary
	*/
	print_mode = 1;
	
	d_num_in_map_order = (double)num_in_map_order;
	d_vectors          = (double)pow2[real_num_bits];
	if(amount_to_alloc < 0) {  /* overflow */
		num_elements = 0;
		for (i=0; i<f_num_in_map_order; i++) {
			num_elements += (double)pow2[nz_bits[i]];
		}
		d_amount_to_alloc  = num_elements;
	} else {
		d_amount_to_alloc  = (double)amount_to_alloc;
	}
	d_score_alloc      = (double)score_alloc;
	d_one_meg          = (double)pow2[20];
	nuninformative     = 0;
	max_bitc = 0;
	for(iMarker=0; iMarker<f_num_in_map_order; iMarker++) {
		if(f_uninformative[iMarker])     nuninformative++;
		if(max_bitc < nz_bits[iMarker])  {
			max_bitc = nz_bits[iMarker];
			max_bitc_n = 0;  
			if(iMarker>0) max_bitc_n = nz_bits[iMarker-1];
			if(iMarker<(f_num_in_map_order-1)) {
				if(max_bitc_n<nz_bits[iMarker+1]) max_bitc_n = nz_bits[iMarker+1];
			}
		}
	}
/*	printf(" max_bitc, max_bitc_n = %3d, %3d \n", max_bitc,max_bitc_n);
*/	
	disease_priors_0 = 2 * d_vectors;
	disease_priors_1 = d_score_alloc;
	if(analysis_type != NPL_ANALYSIS) 
		disease_priors_1 += d_vectors;
	
	transition_tmp_0 = 2.5 * d_vectors;
	if((scan_steps != 1) || (nuninformative > 0)) {
		transition_tmp_1  = 1.5 * (double)pow2[max_bitc];
		transition_tmp_1 += 1.5 * (double)pow2[max_bitc_n];
	} else {
		transition_tmp_1 = 1.5 * (double)pow2[max_bitc];
	}
	
	reduced_num_markers = f_num_in_map_order - nuninformative;

	/*  0- 99 --> previous allocation
	  100-199 --> current allocation */
	
	/* 0, 100 p+l+r storage*/	
	d_num_elements[  0] = 3 * d_num_in_map_order * d_vectors;
	d_num_elements[100] = 3 * d_amount_to_alloc;
	
	/* 90, 190 all exponential*/
	d_num_elements[ 90] = 3 * d_num_in_map_order * d_vectors
	                    + disease_priors_0
	                    + transition_tmp_0;
	d_num_elements[190] = 3 * d_amount_to_alloc
	                    + disease_priors_1
						+ transition_tmp_1;

	/* 91, 191 p+l+r using reduced map.  */
	d_num_elements[ 91] = 3 * (double)reduced_num_markers * d_vectors;
	d_num_elements[191] = d_num_elements[100];

	/* 92, 192 all using reduced map.  assume that positions with uninf. ignored*/
	d_num_elements[ 92] = 3 * (double)reduced_num_markers * d_vectors
	                    + disease_priors_0
	                    + transition_tmp_0;
	d_num_elements[192] = 3 * d_amount_to_alloc
	                    + disease_priors_1
						+ 1.5 * (double)pow2[max_bitc];
	
	/* 93, 193 all using reduced map.  assume that positions with uninf. USED*/
	d_num_elements[ 93] = 3 * (double)f_num_in_map_order * d_vectors
	                    + disease_priors_0
	                    + transition_tmp_0;
	d_num_elements[193] = d_num_elements[190];
	
	for(i=0; i<200; i++) d_memsize[i] = (d_num_elements[i]*8)/d_one_meg ;

	/* COMPUTE_SIZE_ONLY, flag to interrupt calculation */
/*	if((real_num_bits < 15) || (d_memsize[192] > 4096))return;
*/

	
	if(print_mode==0) {
	  sf(ps,
		"num_bits, real_num_bits, score_mask_rdc, reduced_num_markers = %2d %2d %8x %d\n", 
		 num_bits, real_num_bits, score_mask_rdc, reduced_num_markers);
		pr();
		sf(ps, "N-->%9.3f          p+l+r       all    p+l+r-rmap  all-rmap  all-rmap2\n", (d_vectors*8)/d_one_meg);
		pr();
		sf(ps,"mem.(MBytes) v2.0 = %9.3f  %9.3f  %9.3f  %9.3f  %9.3f\n", 
		d_memsize[  0], d_memsize[ 90], d_memsize[ 91], d_memsize[ 92], d_memsize[ 93]);
		pr();
		sf(ps,"mem.(MBytes) v2.1 = %9.3f  %9.3f  %9.3f  %9.3f  %9.3f\n", 
		d_memsize[100], d_memsize[190], d_memsize[191], d_memsize[192], d_memsize[193]);
		pr();
	}
	if(print_mode==1) {
		sf(ps,"Ped. size =(2n-f)=(%3d -%3d) =%3d bits\n", num_bits,
		num_bits - real_num_bits, real_num_bits); pr();
		sf(ps," Memory requirements for version 2.1 (2.0) = %10.3f (%10.3f) Mbytes \n",
		d_memsize[190],d_memsize[90]);
		pr();
		sf(ps," Disease vct and score vct: %10.3f, markers: %10.3f, trans: %10.3f \n",
		disease_priors_1/d_one_meg, 3*d_amount_to_alloc/d_one_meg, transition_tmp_1/d_one_meg);
		pr();
		sf(ps,"Memory requirements per Marker (Mbytes):\n"); pr();
		for (i=0; i<f_num_in_map_order; i++) {
			num_elements = (int)pow2[nz_bits[i]];
			memsize = (num_elements*3*8)/d_one_meg;
			sf(ps," %3d %10.3f", i, memsize); pr();
			if(f_uninformative[i]){
				sf(ps,"  *\n"); pr();
			} else {
				sf(ps,"\n"); pr();
			}
		}
		if(nuninformative != 0) {
			sf(ps,"Markers followed by a * are removed because they are uninformative. \n"); 
			pr();
		}
	}

}
