/* GENEHUNTER - Kruglyak, Daly, Reeve-Daly, and Lander
   Whitehead Institute for Biomedical Research, Copyright 1996 */
/*G. Conant added mpi for postscript output*/
#include "mpi_info.h"


#define INC_LIB
#define INC_SHELL
#include "npl.h"

/* externs */
int map_function, units, scan_steps;
double scan_increment, off_end_dist;
int pedigrees_calculated;
int discard_unaffected;
int score_function, analysis_type;
int pval_precision;
int show_expected_recs;
int postscript_output;
int haplotype_output;
int haplo_method;
int dump_requirements;
double haplo_ratio;
char *current_filename;
/*G. Conant changed for 64-bit version*/
long long int *pow2;
int ps_scaling;
double constant_ps_scale;
int single_point_mode;
int max_bits_to_analyze;
int skip_large;
bool scan_done; /*** new ***/
bool display_scores; /*** new ***/
int use_letters;
int compute_sharing; /*** new 11/99 ***/

init_variables(void)
{
    int i;

    num_markers = 0;
    num_loci = 0;       /*** new ***/
    num_phenotypes = 0; /*** new ***/
    scan_steps = 5;
    off_end_dist = 0.0;
    scan_increment = 0.0;
    map_function = HALDANE;
    units = CENTIMORGANS;

    pedigrees_calculated=0;
    discard_unaffected=FALSE;
    score_function = SCORE_ALL;
    pval_precision = DEFAULT_PRECISION;
    analysis_type = BOTH_ANALYSES;
    show_expected_recs = FALSE;
    postscript_output = FALSE;
    haplotype_output = FALSE;
	 dump_requirements = FALSE;
	 haplo_method = 0;   /* 0=viterbi,  1=max prob. , initialze to 1, max prob*/
    haplo_ratio=1.0;
    array(current_filename, 1000, char);
    strcpy(current_filename,"");

    /*** new ***/
    scan_done = FALSE;
    pair_setting = FIRST_PAIR;
    start_values = CONSTANT;
    means_by_sex = TRUE;
    display_scores = TRUE;
    /*** new ***/

    /*G. Conant changed pow2 for 64 bit version*/
    array(pow2, 64, long long int);

    pow2[0]=1;
    for (i=1; i<64; i++) pow2[i]=2*pow2[i-1];
    
    ps_scaling = FIT_TO_PAGE;
    constant_ps_scale = 5.0;
    single_point_mode = FALSE;
    max_bits_to_analyze = 16;
    skip_large=FALSE;
    use_letters=FALSE;

    /* external TDT variables */
    TDTcount=0;
    one_parent_TDT=FALSE;
    missing_TDT=FALSE;
    dhskip=0;
    qtdt_on=0;
    compute_sharing=TRUE; /*** new 11/99 ***/
}

command set_scan_increment(void)
{ 
  double rnum, old_increment;
  char *word;
  int inum, old_steps;

  use_uncrunched_args();
  word = get_temp_string();
  
  old_increment=scan_increment;
  old_steps=scan_steps;
  if (!stoken(&args,sREQUIRED,word)) {
    if (scan_steps <= 0) {
      sf(ps,"Scanning is currently being done in constant increments of %.1lf cM",
	 scan_increment); pr(); nl();
    } else {
      sf(ps,"Scanning is currently being done in %d equal steps per map interval",
	 scan_steps); pr(); nl();
    }
    
  } else {
    if (!strncasecmp(word,"DISTANCE",4)) {
      if (!rtoken(&args,rREQUIRED,&rnum)) {
	print("error: a cM distance is required");
      } else if (rnum < 0.00) {
	print("error: the distance must be a positive number");
      } else {
	scan_increment = rnum;
	scan_steps = 0;
	sf(ps,
	   "Scanning will now be done in constant increments of %.1lf cM",
	   scan_increment); pr();
	nl();
      }
    } else if (!strncasecmp(word,"STEP",3)) {
      if (!itoken(&args,iREQUIRED,&inum)) {
	print("error: an integer number of intervals is required");
      } else if (inum < 1) {
	print("error: the number of intervals must be a positive number");
      } else {
	scan_steps = inum;
	scan_increment = 1.0;
	sf(ps,
	   "Scanning will be done in %d steps per map interval",
	   scan_steps); pr();
	nl();
      }
    }
    else {
      print("error: the first argument must be 'distance' or 'steps'\n");
    }
    if ((scan_steps != old_steps || scan_increment != old_increment) && scan_done) {
      scan_done = FALSE;
      sf(ps, "You will need to scan pedigrees again for this to take effect."); pr(); 
      nl();
    }
  }
}

/* map_order[] must be fewer than MAX_LOCI_IN_MAP (100) */

void print_map_order(void);
int lookup_locus(char*);

command set_use_map()
{
    char *loc1, *word;
    int new_order[MAXLOCI], num_new_order;
    int i, this_one, last_one, end_range, use_cM;
    double rnum, new_distance[MAXLOCI];

    use_uncrunched_args();
    
    strcpy(self_delimiting,"-");
    
    run {
      loc1 = get_temp_string();
      word = get_temp_string();
      
      if (!stoken(&args,sREQUIRED,loc1)) { /* no args */ }
      else {
	new_order[0] = lookup_locus(loc1);
	num_new_order = 1;

	if (!stoken(&args,sREQUIRED,word)) {
	  /* only one marker listed, two-point analysis */
	  /* skip to the end */

	} else {
	  /* we will either get markers or '-' indicating ranges,
	     loop over all args until done */
	  last_one = new_order[0];
	  while (1) {

	    if (!rtoken(&word,rREQUIRED,&rnum)) {
	        error("non-number where distance was expected");
	    } else {
	        new_distance[num_new_order-1]= rnum;
	    }

	    if(!stoken(&args,sREQUIRED,word)) {
	        error("map must end with a marker");
	    } else {
	        this_one = lookup_locus(word);
		new_order[num_new_order] = this_one;
		num_new_order++;
	    }
	    if (!stoken(&args,sREQUIRED,word)) break;
	  }
	}
	
	/* check whether rec-fracs or cM are used */
	use_cM=FALSE;
	for (i=0; i<num_new_order-1; i++) 
	  if (new_distance[i] > 0.50) { use_cM=TRUE; break; }

	if (!use_cM) {
	  for (i=0; i<num_new_order-1; i++) 
	    new_distance[i] = rec_to_dist(new_distance[i]);
	}

	/* update the global map order */
	for (i=0; i<num_new_order-1; i++) {
	  map_order[i] = new_order[i];
	  map_distance[i] = new_distance[i];
	}
	map_order[i] = new_order[i];
	num_in_map_order = num_new_order;
      }

      print_map_order();

      /* reset this to previous value */
      strcpy(self_delimiting,"");

    } on_error {
        /* interrupt sent when lookup_locus fails */
        print("map not changed\n");
	strcpy(self_delimiting,"");
	if (msg != INTERRUPT && msg != SOFTABORT) relay_messages;
    }
}

int lookup_locus(char *str)
{
    int i, this_marker, num;
    
    this_marker = -1;

    for (i=0; i<num_markers; i++) {
        if (!strcasecmp(locus[i].name,str)) { this_marker=i; break; }
    }

    if (this_marker == -1) {
        if (!itoken(&str,iREQUIRED,&this_marker)) {
	    sf(ps,"marker %s not found in data set",str);
	    error(ps);
	}
	if (this_marker > num_markers) {
	  sf(ps,"marker %s not found in data set",str);
	  error(ps);
	}
	this_marker--; /* 1 is locus[0] */
    }
    return(this_marker);
}


void print_map_order(void)
{
    int i;

    sf(ps,"Current map (%d markers):\n",num_in_map_order); pr();
    for (i=0; i<num_in_map_order-1; i++) {
        sf(ps,"%s %.4lf ",locus[map_order[i]].name,map_distance[i]); pr();
    }
    sf(ps,"%s\n",locus[map_order[i]].name); pr();
}
    

command set_units(void)
{
    char type[TOKLEN+1];
    int old_units;

    get_one_arg(stoken,"",type);

    old_units=units;
    if (nullstr(type)) {
	if (units==RECFRACS)
	  print("the 'units' are currently recombination-fractions\n");
	else if (map_function==HALDANE)
	  print("the 'units' are currently (Haldane) centimorgans\n");
	else if (map_function==KOSAMBI)
	  print("the 'units' are currently (Kosambi) centimorgans\n");
	else send(CRASH);

    } else { /* have args */
	if (matches(type,"recombination fractions") || 
	    matches(type,"rec-fracs") ||
	    matches(type,"recombination-fractions") ||
	    matches(type,"rec fracs") ||
	    matches(type,"rf")) units=RECFRACS;
	else if (matches(type,"centimorgans") || 
		 matches(type,"cm")) units=CENTIMORGANS;
	else usage_error(1);

	if (units==RECFRACS)
	  print("the 'units' are now recombination-fractions.\n");
	else if (map_function==HALDANE)
	  print("the 'units' are now set to (Haldane) centimorgans.\n");
	else if (map_function==KOSAMBI)
	  print("the 'units' are now set to (Kosambi) centimorgans.\n");
	else send(CRASH);
	if (units != old_units && scan_done) {
	  scan_done = FALSE;
	  print("You will need to scan pedigrees again for this to take effect\n.");
	}
      }
}

command set_map_function(void)
{
    char type[TOKLEN+1];
    int old_map;

    get_one_arg(stoken,"",type);
    
    old_map=map_function;
    if (nullstr(type)) {
        sf(ps,"The %s map function is currently in use.\n",
	   (map_function==HALDANE)?"Haldane":"Kosambi"); pr();
    } else {
        if (matches(type,"haldane")) map_function=HALDANE;
	else if(matches(type,"kosambi")) map_function=KOSAMBI;
	else usage_error(1);
      
	sf(ps,"The %s map function is now in use.\n",
	   (map_function==HALDANE)?"Haldane":"Kosambi"); pr();
	if (map_function != old_map && scan_done) {
	  scan_done=FALSE;
	  print("You will need to scan pedigrees again for this to take effect\n.");
	}
    }
}

command set_off_end_distance(void)
{
    double new_val, old_val;

    get_one_arg(rtoken,-999.0,&new_val);

    old_val=off_end_dist;
    if (new_val < 0.0) {
        sf(ps,"Scanning will be done %.1lf cM beyond the ends of the map\n",
	   off_end_dist); pr();
    } else {
        if (new_val < 0.50) off_end_dist = rec_to_dist(new_val);
        else off_end_dist = new_val;
	sf(ps,"Scanning will now be done %.1lf cM beyond the ends of the map",
	   off_end_dist); pr(); nl();
	if (off_end_dist != old_val && scan_done) {
	  scan_done=FALSE;
	  print("You will need to scan pedigrees again for this to take effect\n.");
	}
    }
}


command show_total_stat(void)
{
    int i,j,k,total_pval_max,this_score,max_num_scores;
    double total,rawtotal,infototal,entropytotal,pval_total,pvent_total;
    double *apmstat,*infosum,*varinfo,alpha,alpha_min,*var_scale,varsum;
    double running_prior,running_post,h_alpha,h_lod,*poslod,*new_score_list;
    double *prior_dist, *post_dist, this_max, total_max, extra_p_thing;
    double prob_extra, chisq_prob(double,double), fixed_alpha;
    FILE *fp, *fpdebug;
    char *lod_str, *pos_str, type[TOKLEN+1], *filename;
    void linkhet(double*,int,double*,double*,int);

    if (pedigrees_calculated == 0)
      error("no pedigree file has been analyzed with the 'scan' command yet");

    get_arg(stoken,"hom",type);
    get_arg(rtoken,-999.0,&fixed_alpha);
    if (fixed_alpha > 1.0) error("fixed alpha must be between 0.0 and 1.0");

    array(apmstat, num_w_pos, double);
    array(infosum, num_w_pos, double);
    array(varinfo, num_w_pos, double);
    array(poslod, pedigrees_calculated, double);
    array(var_scale, pedigrees_calculated, double);

    lod_str = get_temp_string();
    pos_str = get_temp_string();

    /* New variance scales for better p-value calculation */
    varsum = 0.0;
    for (i=0; i<pedigrees_calculated; i++) {
      if (null_variance[i] < .0001) null_variance[i]=.0001;
      var_scale[i] = 1.0/sqrt(null_variance[i]);
      /* varsum += var_scale[i]; */
    }
    /* for (i=0; i<pedigrees_calculated; i++)  var_scale[i] /= varsum; */

    /* get maximum raw score for allocation/convolution */
    total_max=0.0; max_num_scores=1;
    for (i=0; i<pedigrees_calculated; i++) {
      this_max=0.0;

      for (j=0; j<num_pscores[i]; j++) {
	  if (pscore_list[i][j] > this_max) this_max=pscore_list[i][j];
      }
      total_max += (this_max*var_scale[i]);
      if (num_pscores[i] > max_num_scores) max_num_scores=num_pscores[i];
    }
    array(new_score_list, max_num_scores, double);
    init_convolution(total_max);
    total_pval_max=(int)(total_max*pval_precision)+1000;
    array(prior_dist,total_pval_max,double);

    if (analysis_type != LOD_ANALYSIS) {
      print("Totalling pedigrees: ."); flush();
      for (j=0; j<total_pval_max; j++) prior_dist[j]=0.0;
      for (i=0; i<num_pscores[0]; i++) {
        this_score = (int) ((pscore_list[0][i]*pval_precision*var_scale[0])+.5);
	/*prior_dist[this_score] = prior_pscore[0][i];*/
	prior_dist[this_score] += prior_pscore[0][i];
      }
      for (i=1; i<pedigrees_calculated; i++) {
	print("."); flush();
	for (j=0; j<num_pscores[i]; j++) new_score_list[j]=(pscore_list[i][j]*var_scale[i]);
        convolve(prior_dist, prior_pscore[i], new_score_list, num_pscores[i]);
      }
      print("\n");
    }

    if (analysis_type == NPL_ANALYSIS) 
      print("position NPL_score  p-value     information\n");
    else if (analysis_type == LOD_ANALYSIS) {
      if (!strncasecmp(type,"het",3))
	print("position LOD_score  (alpha, HLOD)     information\n");
      else
	print("position LOD_score   information\n");
    }
    else { /* BOTH */
      if (!strncasecmp(type,"het",3)) 
	print("position LOD_score  (alpha, HLOD)    NPL_score  p-value     information\n");
      else 
	print("position LOD_score   NPL_score  p-value     information\n");
    }

    for (i=0; i<num_w_pos; i++) {

        /* post_dist stuff can be removed if we decide just to go with 
	   examining the mean vs. the prior_dist for our significance */

        total=0.0; rawtotal=0.0; infototal=0.0; 
	entropytotal=0.0; pval_total=1.0; pvent_total=0.0;
	extra_p_thing=0.0;
	for (j=0; j<pedigrees_calculated; j++) {
	    total += apm_stat[j][i];
	    rawtotal += (raw_stat[j][i]*var_scale[j]);
	    infototal += apm_info[j][i];
	    entropytotal += apm_entropy[j][i];
	    pvent_total += pvec_entropy[j][i];
	    poslod[j] = sub_lods[j][i];
	}


	if (fixed_alpha > 0.0) {
	  h_alpha = fixed_alpha;
	  linkhet(poslod,pedigrees_calculated,&h_alpha,&h_lod,TRUE);
	} else {
	  linkhet(poslod,pedigrees_calculated,&h_alpha,&h_lod,FALSE);
	}

	pval_total=0.0;
	for (j=(int)(rawtotal*pval_precision); j<=total_pval_max; j++)
	  pval_total += prior_dist[j];

#ifdef DEBUG_DIST
	fpdebug = open_file("debug.dists","w");
	for (j=0; j<=total_pval_max; j++) {
	  if (prior_dist[j] > 0.0) {
	    sf(ps,"%8d   %.10lf\n",j,prior_dist[j]); 
	    fpr(fpdebug);
	  }
	}
	close_file(fpdebug);
#endif

	apmstat[i] = total/sqrt((double)pedigrees_calculated);
	varinfo[i] = infototal/(double)pedigrees_calculated;
	if (varinfo[i] < 0.00) varinfo[i]=0.00;
	infosum[i] = pvent_total/(double)pedigrees_calculated;

	if (total_lod[i] < -9000.0) strcpy(lod_str," -INFINITY");
	else sf(lod_str,"%10.6lf",total_lod[i]); 

	if (!single_point_mode) sf(pos_str,"%7.2lf",wpos[i]);
	else sf(pos_str,"%s",locus[i].name); 
	/* else sf(pos_str,"loc%-4d",i+1); */

	if (analysis_type == NPL_ANALYSIS) {
	  if (pval_total < .00001) {
	    sf(ps,"%s   %9.5lf %8.4g     %9.6lf\n",
	       pos_str, apmstat[i], pval_total, 
	       pvent_total/((double)pedigrees_calculated));
	    pr();
	  } else {
	    sf(ps,"%s   %9.5lf %8.6lf     %9.6lf\n",
	       pos_str, apmstat[i], pval_total, 
	       pvent_total/((double)pedigrees_calculated));
	    pr();
	  }
	} else if (analysis_type==LOD_ANALYSIS) {
	    if (!strncasecmp(type,"het",3))
	      sf(ps,"%s %s (%6.4lf,%7.4lf)    %9.6lf\n",
		 pos_str, lod_str, h_alpha, h_lod,  
		 pvent_total/((double)pedigrees_calculated));
	    else
	      sf(ps,"%s %s   %9.6lf\n",
		 pos_str, lod_str,  
		 pvent_total/((double)pedigrees_calculated));
	    pr(); 
	} else { /* BOTH */
	  if (pval_total < .00001) {
	    if (!strncasecmp(type,"het",3))
	      sf(ps,"%s %s (%6.4lf,%7.4lf)  %9.5lf %8.4g     %9.6lf\n",
		 pos_str, lod_str, h_alpha, h_lod, apmstat[i], 
		 pval_total, pvent_total/((double)pedigrees_calculated));
	    else
	      sf(ps,"%s %s   %9.5lf %8.4g     %9.6lf\n",
		 pos_str, lod_str, apmstat[i], 
		 pval_total, pvent_total/((double)pedigrees_calculated));
	    pr(); 
	  } else {
	    if (!strncasecmp(type,"het",3))
	      sf(ps,"%s %s (%6.4lf,%7.4lf)  %9.5lf %8.6lf     %9.6lf\n",
		 pos_str, lod_str, h_alpha, h_lod, apmstat[i], 
		 pval_total, pvent_total/((double)pedigrees_calculated));
	    else
	      sf(ps,"%s %s   %9.5lf %8.6lf     %9.6lf\n",
		 pos_str, lod_str, apmstat[i], 
		 pval_total, pvent_total/((double)pedigrees_calculated));
	    pr(); 
	  }
	}

	/**********
	if (pval_total < .00001 || alpha_min < .00001) {
	  sf(ps,"%7.2lf %s %9.6lf %9.6lf %9.6lf %9.6lf %9.4g %9.4g\n",
	     wpos[i], lod_str, apmstat[i], 
	     infototal/((double)pedigrees_calculated), 
	     entropytotal/((double)pedigrees_calculated), 
	     pvent_total/((double)pedigrees_calculated),
	     pval_total, alpha_min); pr();
	} else {
	  sf(ps,"%7.2lf %s %9.6lf %9.6lf %9.6lf %9.6lf %9.6lf %9.6lf\n",
	     wpos[i], lod_str, apmstat[i],
	     infototal/((double)pedigrees_calculated), 
	     entropytotal/((double)pedigrees_calculated), 
	     pvent_total/((double)pedigrees_calculated),
	     pval_total, alpha_min); pr();
	}
	**********/
    }

    if (num_w_pos > 1 && postscript_output && !single_point_mode) {

      if (analysis_type != LOD_ANALYSIS) {
	filename = get_temp_string();
	strcpy(filename,"npl_plot.ps");
	fp = open_out_file(filename,"postscript plot");
	if (score_function == SCORE_PAIRS)
	  draw_graph(fp,wpos,apmstat,num_w_pos,"NPL plot","Z-pairs");
	else
	  draw_graph(fp,wpos,apmstat,num_w_pos,"NPL plot","Z-all");
	
      }

      if (analysis_type != NPL_ANALYSIS) {
	filename = get_temp_string();
	strcpy(filename,"lod_plot.ps");	
	fp = open_out_file(filename,"postscript plot");
	draw_graph(fp,wpos,total_lod,num_w_pos,"LOD plot","LOD");
	
      }

      filename = get_temp_string();
      strcpy(filename,"info_content.ps");
      fp = open_out_file(filename,"postscript plot");
      draw_graph(fp,wpos,infosum,num_w_pos,"Information content","Information Content");
      
      /*****
      fp = open_out_file("varinfo.ps","postscript plot");
      draw_graph(fp,wpos,varinfo,num_w_pos,"variance info","variance info");
      *****/
    }

    free_convolution();

    /** unarray(post_dist, double); **/
    unarray(prior_dist, double);

    unarray(poslod, double);
    unarray(varinfo, double);
    unarray(infosum, double);
    unarray(apmstat, double);
}


command set_discard(void)
{
    char type[TOKLEN+1];
    bool old_discarded;

    get_one_arg(stoken,"",type);

    old_discarded=discard_unaffected;
    if (nullstr(type)) {
        sf(ps,"Unaffected children are currently %s.\n",
	   (discard_unaffected)?"discarded":"used"); pr();
    } else {
        if (matches(type,"on")) discard_unaffected=TRUE;
	else if(matches(type,"off")) discard_unaffected=FALSE;
	else usage_error(1);
      
        sf(ps,"Unaffected children are now %s.\n",
	   (discard_unaffected)?"discarded":"used"); pr();
	if (discard_unaffected != old_discarded && scan_done) {
	  scan_done=FALSE;
	  print("You will need to scan pedigrees again for this to take effect\n.");	  
	}
    }
}

command set_skip_large(void)
{
    char type[TOKLEN+1];
    bool old_val;

    get_one_arg(stoken,"",type);

    old_val=skip_large;
    if (nullstr(type)) {
        sf(ps,"Large pedigrees are currently %s.\n",
	   (skip_large)?"skipped":"used but trimmed"); pr();
    } else {
        if (matches(type,"on")) skip_large=TRUE;
	else if(matches(type,"off")) skip_large=FALSE;
	else usage_error(1);
      
        sf(ps,"Large pedigrees are now %s.\n",
	   (skip_large)?"skipped":"used but trimmed"); pr();
	if (skip_large != old_val && scan_done) {
	  scan_done=FALSE;
	  print("You will need to scan pedigrees again for this to take effect\n.");
	}  
    }
}

command set_letters(void)
{
    char type[TOKLEN+1];
    bool old_val;

    get_one_arg(stoken,"",type);

    if (nullstr(type)) {
        sf(ps,"Haplotypes are currently displayed as %s.\n",
	   (use_letters)?"inferred letters":"raw numeric alleles"); pr();
    } else {
        if (matches(type,"on")) use_letters=TRUE;
	else if(matches(type,"off")) use_letters=FALSE;
	else usage_error(1);
      
        sf(ps,"Haplotpes are now displayed as %s.\n",
	   (use_letters)?"inferred letters":"raw numeric alleles"); pr();
    }
}

command set_score_function(void)
{
    char type[TOKLEN+1];
    get_one_arg(stoken,"",type);

    if (nullstr(type)) {
        sf(ps,"The current score function is '%s'\n",
	   (score_function==SCORE_PAIRS)?"pairs":
	   ((score_function==SCORE_ALL)?"all":"one")); pr();
    } else {
        if (matches(type,"pairs")) { 
	    score_function=SCORE_PAIRS; pval_precision=DEFAULT_PRECISION;
	    print("The current score function is now 'pairs'\n");
	} else if (matches(type,"all")) {
	    score_function=SCORE_ALL; pval_precision=DEFAULT_PRECISION/100;
	    print("The current score function is now 'all'\n");
	} else if (matches(type,"one")) {
	    score_function=SCORE_ONE; pval_precision=DEFAULT_PRECISION;
	    print("The current score function is now 'one'\n");
	} else usage_error(1);
      
    }
}

command set_analysis_type(void)
{
    char type[TOKLEN+1];
    get_one_arg(stoken,"",type);

    if (nullstr(type)) {
        sf(ps,"The current analysis type is '%s'\n",
	   (analysis_type==NPL_ANALYSIS)?"NPL":
	   ((analysis_type==LOD_ANALYSIS)?"LOD":"BOTH")); pr();
    } else {
        if (matches(type,"NPL")) 
	    analysis_type=NPL_ANALYSIS;
	else if(matches(type,"LOD") || matches(type,"LINKAGE"))
	    analysis_type=LOD_ANALYSIS;
	else if (matches(type,"BOTH") || matches(type,"both"))
	    analysis_type=BOTH_ANALYSES;
	else usage_error(1);
      
        sf(ps,"The current analysis type is '%s'\n",
	   (analysis_type==NPL_ANALYSIS)?"NPL":
	   ((analysis_type==LOD_ANALYSIS)?"LOD":"BOTH")); pr();
    }
}

command set_count_recs(void)
{
    char type[TOKLEN+1];
    get_one_arg(stoken,"",type);

    if (nullstr(type)) {
        sf(ps,"Count recs is '%s'\n",
	   show_expected_recs?"on":"off"); pr();
    } else {
        if (matches(type,"ON") || matches(type,"TRUE")) 
	    show_expected_recs=TRUE;
	else if(matches(type,"OFF") || matches(type,"FALSE"))
	    show_expected_recs=FALSE;
	else usage_error(1);
      
        sf(ps,"Count recs is now '%s'\n",
	   show_expected_recs?"on":"off"); pr();
    }
}

command set_postscript_output(void)
{
    char type[TOKLEN+1];
    get_one_arg(stoken,"",type);

    if (nullstr(type)) {
        sf(ps,"Postscript output is '%s'\n",
	   postscript_output?"on":"off"); pr();
    } else {
        if (matches(type,"ON") || matches(type,"TRUE")) 
	    postscript_output=TRUE;
	else if(matches(type,"OFF") || matches(type,"FALSE"))
	    postscript_output=FALSE;
	else usage_error(1);
      
        sf(ps,"Postscript output is now '%s'\n",
	   postscript_output?"on":"off"); pr();
    }
}

command set_haplotype(void)
{
    char type[TOKLEN+1];
    get_one_arg(stoken,"",type);

    if (nullstr(type)) {
        sf(ps,"Haplotype output is '%s'\n",
	   haplotype_output?"on":"off"); pr();
    } else {
        if (matches(type,"ON") || matches(type,"TRUE")) 
	    haplotype_output=TRUE;
	else if(matches(type,"OFF") || matches(type,"FALSE"))
	    haplotype_output=FALSE;
	else usage_error(1);
      
        sf(ps,"Haplotype output is now '%s'\n",
	   haplotype_output?"on":"off"); pr();
    }
}

command set_haplomethod(void)
{
    char type[TOKLEN+1];
    get_one_arg(stoken,"",type);

    if (nullstr(type)) {
        sf(ps,"Haplotype method is '%s'\n",
			  (haplo_method == 0)? "Viterbi" : "MaxProb"); 
		  pr();
    } else {
		if (matches(type,"VITERBI") || matches (type, "VIT"))
		  haplo_method = 0;
		else if (matches(type,"MAXPROB") || matches(type,"MAX PROB"))
		  haplo_method = 1;
	else usage_error(1);
        sf(ps,"Haplotype method is now '%s'\n",
			  (haplo_method == 0)? "Viterbi" : "MaxProb"); 
		  pr();
    }
}

command set_dump_req(void)
{
    char type[TOKLEN+1];
    get_one_arg(stoken,"",type);

    if (nullstr(type)) {
        sf(ps,"Dump Requirements is '%s'\n",
	   dump_requirements?"on":"off"); pr();
		  if(dump_requirements) {
			 sf(ps,"  Program will only calculate and dump memory requirements\n");
			 pr();
		  }
    } else {
        if (matches(type,"ON") || matches(type,"TRUE")) 
	    dump_requirements=TRUE;
	else if(matches(type,"OFF") || matches(type,"FALSE"))
	    dump_requirements=FALSE;
	else usage_error(1);
        sf(ps,"Dump Requirements is '%s'\n",
	   dump_requirements?"on":"off"); pr();
		  if(dump_requirements) {
			 sf(ps,"  Program will now only calculate and dump memory requirements.\n");
			 pr();
		  }
    }
}

command set_haplo_ratio(void)
{
    double new_val;

    get_one_arg(rtoken,haplo_ratio,&new_val);

    if (new_val <= 0.0 || new_val > 1.0) {
        sf(ps,"Haplo ratio must be between 0 and 1");
	error(ps);
    } else {
        haplo_ratio = new_val;
    }
    sf(ps,"Haplo ratio is currently %.6lf\n",haplo_ratio); pr();
}


command dump_peak_info(void)
{
    int i,j,index;
    double pos;
    char *filename,*tempstr;
    FILE *fp;

    get_one_arg(rtoken,-9999.9,&pos);

    if (pedigrees_calculated == 0)
      error("no pedigree file has been analyzed with the 'scan' command yet");

    if (pos < -9999.0) 
      error("this command requires an argument which is valid cM position in the most recent scan");

    index = -1;
    for (i=0; i<num_w_pos; i++)
      if (fabs(wpos[i]-pos) < .01) { index=i; break; }
    if (index == -1) {
      sf(ps,"%.2lf is not a valid scan position in the most recent scan");
      error(ps);
    }

    filename = get_temp_string();
    tempstr = get_temp_string();
    strcpy(filename, current_filename);
    split_string(filename,&tempstr,'.');
    sf(ps,"%.2lf",pos);
    strcat(filename,ps);

    fp = open_out_file(filename,"peak info");

    sf(ps,"%d pedigrees  (data file: %s, position: %.2lf)\n",
       pedigrees_calculated, current_filename, pos);
    fpr(fp);

    for (i=0; i<pedigrees_calculated; i++) {
      sf(ps,"%.6lf  \t%d\n",raw_stat[i][index],num_pscores[i]); fpr(fp);
      for (j=0; j<num_pscores[i]; j++) { 
	sf(ps,"%.6lf ",pscore_list[i][j]); fpr(fp);
      }
      sf(ps,"\n"); fpr(fp);
      for (j=0; j<num_pscores[i]; j++) { 
	sf(ps,"%.6lf ",prior_pscore[i][j]); fpr(fp);
      }
      sf(ps,"\n"); fpr(fp);
      for (j=0; j<num_pscores[i]; j++) { 
	sf(ps,"%.6lf ",post_pscore[i][index][j]); fpr(fp);
      }
      sf(ps,"\n"); fpr(fp);
    }
    close_file(fp);
}


command set_single_point_mode(void)
{
    char type[TOKLEN+1];
    bool old_val;

    get_one_arg(stoken,"",type);

    old_val=single_point_mode;
    if (nullstr(type)) {
        sf(ps,"Single point mode is '%s'\n",
	   single_point_mode?"on":"off"); pr();
    } else {
        if (matches(type,"ON") || matches(type,"TRUE")) 
	    single_point_mode=TRUE;
	else if(matches(type,"OFF") || matches(type,"FALSE"))
	    single_point_mode=FALSE;
	else usage_error(1);
      
        sf(ps,"Single point mode is now '%s'\n",
	   single_point_mode?"on":"off"); pr();
	if (single_point_mode != old_val && scan_done) {
	  scan_done=FALSE;
	  print("You will need to scan pedigrees again for this to take effect\n.");
	}
    }
}

command set_compute_sharing(void)
{
    char type[TOKLEN+1];
    bool old_val;

    get_one_arg(stoken,"",type);

    old_val=compute_sharing;
    if (nullstr(type)) {
        sf(ps,"compute sharing is '%s'\n",
	   compute_sharing?"on":"off"); pr();
    } else {
        if (matches(type,"ON") || matches(type,"TRUE")) 
	    compute_sharing=TRUE;
	else if(matches(type,"OFF") || matches(type,"FALSE"))
	    compute_sharing=FALSE;
	else usage_error(1);
      
        sf(ps,"compute sharing is now '%s'\n",
	   compute_sharing?"on":"off"); pr();
	if (compute_sharing != old_val && scan_done) {
	  scan_done=FALSE;
	  print("You will need to scan pedigrees again for this to take effect\n.");
	}
    }
}

command set_max_bits(void)
{
    int new_val;

    get_one_arg(itoken,max_bits_to_analyze,&new_val);
    /*G. Conant mod for 64 bit version*/
    if (new_val < 4 || new_val > 62) {
        sf(ps,"Max bits to analyze must be between 4 and 62");
	error(ps);
    } else {
        max_bits_to_analyze = new_val;
    }
    sf(ps,"Currently analyzing a maximum of %d bits per pedigree\n",
       max_bits_to_analyze); pr();
}

/* Not commands but interface stuff that has no other home */

void draw_graph(FILE *fp, double *xpos, double *yval, 
		int num_points, char *graph_title, char *y_title)
{
    int i, j, top_y, bottom_y, last_one, zero_to_one, num_labels;
    char **y_axis_label, **locus_name, *x_title, *new_y_title;
    double xscale, yscale, max_x, min_y, max_y, old_dist, too_close, x_offset;
    double *y_axis_val, *new_map_pos, total_pos;
    double define_x_scale(double);

    if (mpi_interface.rank==0) {
    ps_file_start(fp);
    ps_page_start(fp,1);

    fprintf(fp,"31 319 moveto\n");
    fprintf(fp,"GS 90 rotate 0 0 rmoveto /Times-Roman FF 12 SF F (%s)S GR\n",
	  graph_title);
    fprintf(fp,
	  "GS 90 rotate 0 -14 rmoveto /Times-Roman FF 10 SF F (Pedigree file: %s)S GR\n",
	  current_filename);
    }
    /* Calculate appropriate scales, etc. */

    max_y = min_y = 0.0;
    for (i=0; i<num_points; i++) {
        if (yval[i] < -1000.0) continue; /* -INFINITY LOD score */
	
	if (yval[i] > max_y) max_y=yval[i];
	if (yval[i] < min_y) min_y=yval[i];
    }

    if (max_y <= 1.0 && min_y >= 0.0) {
        top_y = 1; bottom_y=0;
	yscale=400.0;
	zero_to_one = TRUE;

    } else {
        zero_to_one = FALSE;
        if (max_y < 3.0) top_y=3;
	else top_y= (int)(max_y+1.0);

	if (min_y > -3.0) bottom_y=-3;
	else bottom_y= (int) (min_y-1.0);

	/* hardwired MLS hack */
	/* top_y=6.0; */
	/* bottom_y=0.0; */

	yscale = 400.0/(top_y-bottom_y);
	if (yscale > 65.0) yscale=65.0;

    }

    /* define x_scale for the graph - looks up based on user settings */
    if (xpos[0] < 0.0) x_offset = (-1.0)*xpos[0];
    else          x_offset = 0.0;
    max_x = xpos[num_points-1] + x_offset;
    xscale = define_x_scale(max_x);


    /* eliminate any off chart points (e.g.,-INFINITY LODs) */

    for (i=0; i<num_points; i++) 
      if (yval[i] < bottom_y) yval[i]=bottom_y;

    /* create y-axis labels */

    num_labels = (top_y-bottom_y)+2;
    matrix(y_axis_label, max(11,num_labels), 10, char);
    array(y_axis_val, max(11,num_labels), double);

    if (zero_to_one) {
      for (i=0; i<=10; i++) {
	y_axis_val[i] = (double) i/10.0;
	if (mpi_interface.rank==0) sprintf(y_axis_label[i],"%.1lf",y_axis_val[i]);
      }
    } else {
      for (i=0; i<=(top_y-bottom_y); i++) {
        y_axis_val[i] = (double) i+bottom_y;
	if (mpi_interface.rank==0) sprintf(y_axis_label[i],"%.1lf",y_axis_val[i]);
      }
    }

    /* create x-axis labels */

    matrix(locus_name, num_in_map_order+1, MAX_NAME_SIZE*10, char);
    array(new_map_pos, num_in_map_order+1, double);

    too_close = 6.0/xscale;
    for (i=0; i<num_in_map_order; i++) {
        if (i>0) {
	    if (map_distance[i-1]+old_dist < too_close) {
	        strcat(locus_name[last_one]," ");
		strcat(locus_name[last_one],locus[map_order[i]].name);
		strcpy(locus_name[i],"");
		old_dist += map_distance[i-1];
	    } else {
	        strcpy(locus_name[i],locus[map_order[i]].name);
		last_one=i;
		old_dist=0.0;
	    }
	} else {
	  strcpy(locus_name[i],locus[map_order[i]].name);
	  last_one=i;
	  old_dist=0.0;
	}
    }

    total_pos=0;
    for (i=0; i<num_in_map_order-1; i++) {
      new_map_pos[i]=total_pos+x_offset;
      total_pos+=map_distance[i];
    }
    new_map_pos[i]=total_pos+x_offset;

    /* draw axes */
    x_title = get_temp_string();
    sf(x_title,"%d cM",(int) max_x);

    new_y_title = get_temp_string();
    strcpy(new_y_title,y_title);
    if (zero_to_one)
      draw_axes(fp, num_in_map_order, new_map_pos, locus_name,
		11, y_axis_val, y_axis_label, new_y_title,
		x_title, xscale, yscale, 0.0, TRUE);
    else
      draw_axes(fp, num_in_map_order, new_map_pos, locus_name,
		(top_y-bottom_y)+1, y_axis_val, y_axis_label, new_y_title,
		x_title, xscale, yscale, 0.0, TRUE);

    if (x_offset > 0.0)
      for (i=0; i<num_points; i++) xpos[i]+=x_offset;

    do_bezier(fp, xpos, yval, num_points, 0.0, 0.0,
	      SOLID_LINE, xscale, yscale);

    if (x_offset > 0.0)
      for (i=0; i<num_points; i++) xpos[i]-=x_offset;
	      
    if (mpi_interface.rank==0) ps_page_end(fp,1);
    if (mpi_interface.rank==0) ps_file_end(fp);

    unarray(new_map_pos, double);
    unmatrix(locus_name, num_in_map_order+1, char);
    unarray(y_axis_val, double);
    unmatrix(y_axis_label, max(11,num_labels), char);

    run {
      close_file(fp);
    } except_when(CANTCLOSE) { }

}


void draw_mult_y_plots(FILE *fpps, double *xpos, double **yval,
		       int num_points, int num_y_plots, char *title,
		       char **ylabel, char *y_title)
{
  int i, j, top_y, bottom_y, last_one, num_y_val;
  char **y_axis_label,**locus_name, *x_title;
  double xscale, yscale, *y_axis_val, max_x, max_y, min_y,old_dist;
  double x_offset, *new_map_pos, y_increment,tmp_y,too_close,total_pos;

  ps_file_start(fpps);
  ps_page_start(fpps,1);

  /***** Print general information and a key at the top *****/
  fprintf(fpps,"31 319 moveto\n");
  fprintf(fpps,"GS 90 rotate 0 0 rmoveto /Times-Roman FF 12 SF F (%s)S GR\n",
	  title);
  fprintf(fpps,
	  "GS 90 rotate 0 -12 rmoveto /Times-Roman FF 10 SF F (Pedigree file: %s)S GR\n",
	  current_filename);
  fprintf(fpps,"22 130 rmoveto\n");
  fprintf(fpps,"GS 90 rotate 0 0 rmoveto /Times-Roman FF 10 SF F (Key:)S GR\n");
  for (i=0; i<num_y_plots; i++) {
    fprintf(fpps,"GS 90 rotate %d %d rmoveto ",(i/3)*135,-10-((i%3)*9));
    fprintf(fpps,"/Times-Roman FF 9 SF F (%s)S GR\n",
	    ylabel[i]);
    fprintf(fpps,"GS 90 rotate %d %d rmoveto ",((i/3)*135)+63,-7-((i%3)*9));
    fprintf(fpps,"%s 20 0 rlineto stroke GR\n",line_choice(i));
  }

  
  /***** Calculate appropriate scales, etc. *****/

  /***** Y-axis stuff *****/

  /* Find the min & max out of all the y-plots */
  max_y = min_y = 0.0;
  for (j=0; j<num_y_plots; j++)
    for (i=0; i<num_points; i++) {
      if (yval[j][i] < -1000.0) continue;  /* -INFINITY LOD score */
      if (yval[j][i] > max_y) max_y=yval[j][i];
      if (yval[j][i] < min_y) min_y=yval[j][i];
    }

  /* Set the y-limits on the page according to the min & max */
  if (max_y < 0.0) {
    if (max_y >= -3.0) 
      top_y = 0;
    else top_y = (int)(max_y+1.5);
  } else if (max_y <= 1.0) {
    top_y=1;
  } else { top_y = (int)(max_y+1.5);}
  if (min_y >= 0.0) bottom_y=0;
  else bottom_y = (int)(min_y-1.5);

  yscale = 440.0/(double)(top_y-bottom_y);

  /* eliminate -INFINITY points */
  for (j=0; j<num_y_plots; j++) 
    for (i=0; i<num_points; i++) 
      if (yval[j][i] < bottom_y) 
	yval[j][i]=bottom_y;

  /* set the number of marks that will be shown along the axis */
  if (top_y-bottom_y < 5) {
    y_increment = (double)(top_y-bottom_y)/10.0;
    num_y_val = 10;
  } else {
    y_increment = 1.0;
    num_y_val = top_y-bottom_y+2;
  }

  /* Store the values to be printed on the y-axis as doubles
     and strings */
  matrix(y_axis_label, num_y_val+2, 10, char);
  array(y_axis_val, num_y_val+2, double);
  tmp_y = (double)(bottom_y);
  i=0;
  while(tmp_y < ((double)(top_y))) {
    y_axis_val[i] = tmp_y;
    sprintf(y_axis_label[i],"%.1lf",y_axis_val[i]);
    tmp_y += y_increment;
    i++;
  }
  num_y_val = i;


  /***** X-axis stuff ******/

  if (xpos[0] < 0.0) x_offset = (-1.0)*xpos[0];
  else               x_offset = 0.0;
  max_x = xpos[num_points-1]+x_offset;
  xscale = 600.0/max_x;

  /* Locus name labels */

  matrix(locus_name, num_in_map_order+1, MAX_NAME_SIZE*10, char);
  array(new_map_pos, num_in_map_order+1, double);

  too_close = 6.0/xscale;
  for (i=0; i<num_in_map_order; i++) {
    if (i>0) {
      if (map_distance[i-1]+old_dist < too_close) {
	strcat(locus_name[last_one]," ");
	strcat(locus_name[last_one],locus[map_order[i]].name);
	strcpy(locus_name[i],"");
	old_dist += map_distance[i-1];
      } else {
	strcpy(locus_name[i],locus[map_order[i]].name);
	last_one=i;
	old_dist=0.0;
      }
    } else {
      strcpy(locus_name[i],locus[map_order[i]].name);
      last_one=i;
      old_dist=0.0;
    }
  }

  total_pos=0;
  for (i=0; i<num_in_map_order-1; i++) {
    new_map_pos[i]=total_pos+x_offset;
    total_pos+=map_distance[i];
  }
  new_map_pos[i]=total_pos+x_offset;

  x_title = get_temp_string();
  sf(x_title,"%.1lf cM",max_x);

  /****** Drawing stuff *******/
  /* Draw the axes */
  draw_axes(fpps, num_in_map_order, new_map_pos, locus_name, 
	    num_y_val, y_axis_val, y_axis_label, y_title, 
	    x_title, xscale, yscale, (-2.0), TRUE);

  /* Draw all the analytical curves */
  if (x_offset > 0.0)
    for (i=0; i<num_points; i++) xpos[i]+=x_offset;
  for (i=0; i<num_y_plots; i++) {
    do_bezier(fpps, xpos, yval[i], num_points, 0.0, 0.0,
	      line_choice(i), xscale, yscale);
  }
  

  /* Reset the values */
  if (x_offset > 0.0)
    for (i=0; i<num_points; i++) xpos[i]-=x_offset;

  /* Finish up the postscript file */
  ps_page_end(fpps,1);
  ps_file_end(fpps);

  unarray(new_map_pos, double);
  unarray(y_axis_val,double);
  unmatrix(locus_name, num_in_map_order+1, char);
  unmatrix(y_axis_label, num_y_val+2, char);

}


FILE *open_out_file(char *default_file, char *purpose)
{

  char *out_file,*tmp;
  bool valid;
  FILE *fp;

  array(out_file, PATH_LENGTH+1, char);
  valid = FALSE;
  while(!valid) {
    fp = NULL;
    tmp = get_temp_string();
    sf(ps,"file to store %s [%s]: ",purpose,default_file);
    input(ps,tmp,TEMP_STRING_LEN);
    if (!nullstr(tmp)) {
      run {
	nstrcpy(out_file,tmp,PATH_LENGTH);
	/* User has specified a file */
	fp = open_file(out_file,"r");
	sf(ps," file '%s' already exists, overwrite? y/n [n]: ",
	   out_file);
	close_file(fp);
	tmp = get_temp_string();
	input(ps,tmp,TEMP_STRING_LEN);
	if (tmp[0] == 'y' || tmp[0] == 'Y') {
	  run {
	    fp = open_file(out_file,"w");
	    valid = TRUE;
	  } except_when(CANTOPEN) {
	    print("can't write to that file, try again/n");
	  }
	}
      } except_when(CANTOPEN) {
	run {
	  fp = open_file(out_file,"w");
	  valid = TRUE;
	} except_when(CANTOPEN) {
	  sf(ps," can't open file %s, try again\n"); pr();
	}
      }
    } else {
      /* Use the default filename */
      run {
	fp = open_file(default_file,"r");
	sf(ps," file '%s' already exists, overwrite? y/n [n]: ",
	   default_file);
	close_file(fp);
	tmp = get_temp_string();
	input(ps,tmp,TEMP_STRING_LEN);
	if (tmp[0] == 'y' || tmp[0] == 'Y') {
	  run {
	    fp = open_file(default_file,"w");
	    valid = TRUE;
	  } except_when(CANTOPEN) {
	    print("can't write to that file, try again/n");
	  }
	}
      } except_when (CANTOPEN) {
	run {
	  fp = open_file(default_file,"w");
	  valid=TRUE;
	} except_when (CANTOPEN) {
	  sf(ps,
	     " can't open file '%s' (maybe permission problem?) try again\n",
	     default_file); pr();
	}
      }
    }
  }
  unarray(out_file, char);
  return(fp);
}



double define_x_scale(double max_x)
{
    double xscale;

    if (ps_scaling == FIT_TO_PAGE) {

      xscale = 640.0/max_x;
      if (xscale > 25.0) xscale=25.0;

    } else { /* CONSTANT_SCALE */
      xscale = constant_ps_scale;
      if (xscale*max_x > 650.0) {
	  /* warning: picture won't fit */
	  xscale = 640.0/max_x;
	  sf(ps,"warning: constant scale factor too large, reducing to %.1lf",
	     xscale); pr(); nl();
      } else if (xscale*max_x < 100.0) {
	  /* warning: picture rather small and insignificant looking */
	  xscale = 100.0/max_x;
	  sf(ps,"warning: constant scale factor too small, raising to %.1lf",
	     xscale); pr(); nl();
      }

    }

    return(xscale);
}


command set_postscript_scaling(void)
{
    char *tempstr;
    int num;
    double rnum;

    print("Methods to scale drawings:\n");
    print("1) Scale chromosome drawings to fill the page\n");
    print("2) Set a fixed value for dots per cM\n");
    tempstr = get_temp_string();
    sf(ps,"Enter choice [%d]: ",ps_scaling);
    input(ps,tempstr,TEMP_STRING_LEN);
    itoken(&tempstr,ps_scaling,&num);
    if (num > 2 || num < 1) error("bad value entered");
    ps_scaling = num;

    if (ps_scaling == 2) {
      print(
"There are roughly 650 dots available for the longest map so your scaling\n");
      print(
"factor should be roughly 650 / length of your longest chromosome in cM\n");
      
      sf(ps,"Enter the factor [%.1lf]: ",constant_ps_scale);
      input(ps,tempstr,TEMP_STRING_LEN);
      rtoken(&tempstr,constant_ps_scale,&rnum);
      if (rnum <= 0.0) error("scale factor must be positive");
      constant_ps_scale = rnum;
      sf(ps,"Drawing will be done with a fixed scale of %.1lf dots per cM\n",
	 constant_ps_scale); pr();
    } else {
      print("Drawings will be scaled to full-page size");
    }
}


void set_display_scores(void)
{
  char type[TOKLEN+1];
  get_one_arg(stoken,"",type);

  if (nullstr(type)) {
    sf(ps,"Screen display of NPL scores, LOD scores, and haplotypes is now '%s'\n",
       display_scores?"on":"off"); pr();
  } else {
    if (matches(type,"ON") || matches(type,"TRUE")) 
      display_scores=TRUE;
    else if(matches(type,"OFF") || matches(type,"FALSE"))
      display_scores=FALSE;
    else usage_error(1);
    
    sf(ps,"Screen display of NPL scores, LOD scores, and haplotypes is now '%s'\n",
       display_scores?"on":"off"); pr();
  }
}

