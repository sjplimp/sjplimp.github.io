/* GENEHUNTER - Kruglyak, Daly, Reeve-Daly, and Lander
   Whitehead Institute for Biomedical Research, Copyright 1996 */
#include "mpi_info.h"

#define INC_LIB
#define INC_SHELL
#include "npl.h"


void linkhet(double *lodscore,int num_peds,double *ret_alpha,double *ret_lod,
	     int fixed_flag)
{
    int i, j, k, end_flag;
    double val, lod, oldlod;
    double a, b, g, norm, tot1, tot2, tot3, total;
    double p1, p2, tot, *ratio;
    double mymaxalph, mymaxlod;


    array(ratio, num_peds, double);
    for (i=0; i<num_peds; i++) ratio[i] = pow(10.0,lodscore[i]);

    if (fixed_flag) {
     
      
      a = *ret_alpha; b=1.0-a; lod=0.0; tot1=tot2=0.0;
      for (i=0; i<num_peds; i++) {
	val = a*ratio[i] + b;
	tot1 += a*ratio[i]/val;
	tot2 += b/val;
	if (fabs(val) < 10e-100)
	  lod = -999.0;
	else
	  lod += log10(val);
      }
    }
    else {
      mymaxalph=0.0;
      mymaxlod=0.0;
     
      for (j=0; j<=10000; j++) {
	a = j / 10000.;
	b = 1. - a;
	lod = 0.0;
	for (i=0; i<num_peds; ++i) {
	  val = a*ratio[i] + b;
	  if (fabs(val) < 10e-100)
	    lod = -999.0;
	  else
	    lod += log10(val);
	}
	
	if (lod > mymaxlod)
	  {
	    mymaxlod = lod;
	    mymaxalph = a;
	  }
      }

      lod = mymaxlod;
      *ret_alpha = mymaxalph;
    }

    *ret_lod = lod;


    unarray(ratio, double);
}

#if 0
--------------------------------------------------------
OLD CODE    OLD CODE

OLD WAY:
void linkhet(double *lodscore,int num_peds,double *ret_alpha,double *ret_lod,
	     int fixed_flag)
{
    int i, j, k, end_flag;
    double val, lod, oldlod;
    double a, b, g, norm, tot1, tot2, tot3, total;
    double p1, p2, tot, *ratio;


    array(ratio, num_peds, double);
    for (i=0; i<num_peds; i++) ratio[i] = pow(10.0,lodscore[i]);

/* !!!!! 
    for (i=0; i<num_peds;i++) {
      sf(ps,"      ratio[%d] = %7.4lf,    lod[i] = %7.4lf\n", i, 
	 ratio[i],lodscore[i]);
      pr();
    }
 !!!!! */

    if (fixed_flag) {
      a = *ret_alpha; b=1.0-a; lod=0.0; tot1=tot2=0.0;
      for (i=0; i<num_peds; i++) {
	val = a*ratio[i] + b;
	tot1 += a*ratio[i]/val;
	tot2 += b/val;
	if (fabs(val) < 10e-100)
	  lod = -999.0;
	else
	  lod += log10(val);
      }
    }
    else {
      a = 0.5;
      b = 0.5;
      end_flag = 0;
      lod = -10000.0;
      while(!end_flag) {

        tot1 = tot2 = 0.0;
	oldlod = lod;
	lod = 0.0;
	for (i=0; i<num_peds; ++i) {
	    val = a*ratio[i] + b;
	    tot1 += a*ratio[i]/val;
	    tot2 += b/val;
	    if (fabs(val) < 10e-100)
	      lod = -999.0;
	    else
	      lod += log10(val);
	}
	total = tot1 + tot2;
	a = tot1/total;
	b = tot2/total;
	if (fabs(lod - oldlod) < 0.0001) end_flag = 1;
      }
      *ret_alpha = a;
    }

    *ret_lod = lod;

    unarray(ratio, double);
}
--------------------------------------------------------
END OF OLD CODE
#endif



/*****

command set_heterogeneity(void)
{
    char new_val[TOKLEN+1];
    
    get_one_arg(stoken,"",new_val);

    if (nullstr(new_val)) {
        sf(ps,"Heterogeneity testing is currently '%s'\n",
	   het_test ? "on" : "off"); pr();
    } else {
        if (matches(new_val,"on")) het_test=TRUE;
	else if(matches(new_val,"off")) het_test=FALSE;
	else usage_error(1);
        sf(ps,"Heterogeneity testing is now '%s'\n",
	   het_test ? "on" : "off"); pr();
    }
}
*****/
