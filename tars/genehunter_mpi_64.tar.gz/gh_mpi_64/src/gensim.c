#define INC_MISC
#define INC_LIB
#define INC_SHELL
#include "gensim.h"

int num_markers, num_families, pedigree_copies, simulate_X;
double *map_position, **allele_prob, chrom_len;
int *num_alleles;
double penetrance[3], affected_freq, disease_position;
double disease_prob[3][3], error_rate, missing_rate, heterogeneity_alpha;
int generating_method;
int gen_phenos;

PED_MEMBER **family;
char **family_name;
int *num_members;

/* peeling stuff */
int num_disease_vecs,*pvec_num;
double *pvec_prob;
int num_nuc_fam, order_assigned[20];
NUC_FAMILY nuc_fam[20];

double rec_to_dist(double), dist_to_rec(double);
void fill_nuc_families(int), mark_pivots(int), init_disease_probs(int);
double peel(int,int,int);


init_variables()
{
    num_markers = 0;
    
    num_families = 10;

    penetrance[HOM_AFF] = 0.999;
    penetrance[HET] = 0.999;
    penetrance[HOM_UNAFF] = 0.001;
    affected_freq = .01;

    disease_position = -9999.0; /* default is no disease */

    simulate_X = FALSE;
    pedigree_copies = FALSE;
    
    error_rate=0.0;
    missing_rate=0.0;

    generating_method = USE_PEELING;
    heterogeneity_alpha = 1.0;

    gen_phenos=FALSE;
}


command enter_map(void)
{
    char *tempstr, *temp2, *bigstr;
    int i, j, map_info_by_hand, avg_alleles, even_spacing, num_all, use_rf;
    double dist, saved_dist[MAX_LOCI], total, total_freq, freq;


    tempstr = get_temp_string();
    temp2 = get_temp_string();
    input("Do you want to enter a map by hand? [n]: ",tempstr,TEMP_STRING_LEN);
    stoken(&tempstr,"n",temp2); map_info_by_hand=FALSE;
    if (temp2[0]=='Y' || temp2[0]=='y') map_info_by_hand=TRUE;


    tempstr = get_temp_string();
    input("enter number of loci spanning this region [11]: ",
	  tempstr,TEMP_STRING_LEN);
    itoken(&tempstr,11,&num_markers);
    if (num_markers < 2 || num_markers > 1000) 
      error("number of loci out of range");

    array(map_position, num_markers, double);
    array(num_alleles, num_markers, int);
    matrix(allele_prob, num_markers, MAX_ALLELES, double);

    if (map_info_by_hand) {
        /* enter map info by hand */
        for (i=0; i<num_markers-1; i++) {
	    sf(ps,"enter map distance between markers %d and %d: ",i+1,i+2);
	    input(ps,tempstr,TEMP_STRING_LEN);
	    if (!rtoken(&tempstr,rREQUIRED,&dist)) {
	      print("bad value, try again\n"); i--;
	    } else {
	      saved_dist[i]=dist;
	    }
	}

	use_rf=TRUE;
	for (i=0; i<num_markers-1; i++) 
	  if (saved_dist[i] >= 0.50) { use_rf=FALSE; break; }

	map_position[0]=0.0; total=0.0;
	for (i=1; i<num_markers; i++) {
	  if (use_rf) total += rec_to_dist(saved_dist[i-1]);
	  else total += saved_dist[i-1];
	  map_position[i] = total;
	}
	chrom_len = map_position[i];

	array (bigstr, 10000, char);

	for (i=0; i<num_markers; i++) {
	    sf(ps,"enter list of allele frequencies for marker %d: ",i+1);
	    tempstr=bigstr;
	    input(ps,tempstr,10000);
	    num_all=0; total_freq=0.0;
	    while (rtoken(&tempstr,rREQUIRED,&freq)) {
	      if (num_all == MAX_ALLELES) error("too many alleles");
	      total_freq+=freq;
	      allele_prob[i][num_all]=total_freq;
	      num_all++;
	    }
	    if (num_all < 2) {
	      print("each marker must have more than one allele, try again\n");
	      i--;
	    } else {
	      num_alleles[i] = num_all;
	      /* Normalize to exactly 1.0 */
	      for (j=0; j<num_all; j++) allele_prob[i][j] /= total_freq;
	    }
	}

    } else {
        /* have map info generated */
    
        tempstr = get_temp_string();
	input("enter chromosome length in cM [100.0]: ",
	      tempstr,TEMP_STRING_LEN);
	rtoken(&tempstr,100.0,&chrom_len);
	if (chrom_len < 1.0 || chrom_len > 1000.0) 
	  error("chromosome length out of range");

	tempstr = get_temp_string();
	temp2 = get_temp_string();
	even_spacing=FALSE;
	input("do you want markers evenly spaced? [n]: ",
	      tempstr,TEMP_STRING_LEN);
	stoken(&tempstr,"n",temp2);
	if (temp2[0]=='Y' || temp2[0]=='y') even_spacing=TRUE;
    
	tempstr = get_temp_string();
	input("enter average number of alleles per locus [5]: ",
	      tempstr,TEMP_STRING_LEN);
	itoken(&tempstr,5,&avg_alleles);
	if (avg_alleles < 2 || avg_alleles > MAX_ALLELES) 
	  error("average number of alleles out of range");


	/* create random positions for markers - placing one at 0.0 and
	   one at chrom_len and allowing all others to fall randomly between */

	if (even_spacing) {
	  for (i=0; i<num_markers; i++) {
	    map_position[i]= (double)i*(chrom_len/(double)(num_markers-1));
	  }
	} else {
	  map_position[0] = 0.0; map_position[1] = chrom_len;
	  for (i=2; i<num_markers; i++)
	    map_position[i] = randnum() * chrom_len;

	  /* now sort these so that they're in order */
	  rsort(map_position,num_markers);
	}

	/* for each marker, figure out number of alleles and their
	   respective probabilities: num_alleles = PRV(avg_alleles),
	   then divide 1.0 into num_alleles-1 intervals to get probabilities */

	for (i=0; i<num_markers; i++) {
	  num_alleles[i] = poissonRV((double)avg_alleles);
	  if (num_alleles[i] < 4) num_alleles[i]=4;
	  if (num_alleles[i] > MAX_ALLELES) num_alleles[i]=MAX_ALLELES;
	  
	  allele_prob[i][0]=1.0;
	  for (j=1; j<num_alleles[i]; j++) allele_prob[i][j] = randnum();
	  
	  rsort(allele_prob[i],num_alleles[i]);
	}
    }
}

command show_map(void)
{
    int i, j;
    double last_prob;

    /* display map for the heck of it */
    for (i=0; i<num_markers; i++) {
        sf(ps,"locus %3d:  %5.1lf cM: %2d alleles:",i+1,
	   map_position[i],num_alleles[i]);
	pr();
	last_prob=0.0;
	for (j=0; j<num_alleles[i]; j++) {
	  sf(ps," %.4lf",allele_prob[i][j]-last_prob); pr();
	  last_prob=allele_prob[i][j];
	}
	nl();
    }
    if (disease_position > -100.0) {
      sf(ps,"disease hidden at %.1lf cM\n",disease_position); pr();
    }
}

command do_simulation(void)
{
    int i,j,k,num,fam,mom,dad,other;
    char *tempstr,*temp2,*header_file,*filename1,*filename2,*filename3;
    FILE *fp, *fphead, *fp_pheno;
    double last_prob, re, rm, generate_pheno_value(int);
    void simulate_pedigree(int);

    tempstr = get_temp_string();
    temp2 = get_temp_string();

    matrix (family, MAX_FAMILIES, MAX_MEMBERS, PED_MEMBER);
    matrix (family_name, MAX_FAMILIES, NAME_LEN, char);
    array (num_members, MAX_FAMILIES, int);

    tempstr = get_temp_string();
    header_file = get_temp_string();
    input("enter linkage pedigree header file [header.ped]: ",
	  tempstr,TEMP_STRING_LEN);
    stoken(&tempstr,"header.ped",header_file);

    run {
      fphead = open_file(header_file,"r");
      num_families = read_pedigree_header(fphead);
      close_file(fphead);
    } except {
      when CANTOPEN:
          sf(ps,"Can't open header file '%s'",header_file); pr();
      when CANTCLOSE:
          sf(ps,"Can't close header file '%s'",header_file); pr();
      
    }

    if (num_families == 1) {
      tempstr = get_temp_string();
      input("how many times should this pedigree be duplicated [10]: ",
	    tempstr,TEMP_STRING_LEN);
      itoken(&tempstr,10,&num_families);
      if (num_families < 1 || num_families > 1000) 
        error("num_families out of range");  
 
      copy_pedigree_header(num_families);
      pedigree_copies=TRUE;
    }

    /* now do the simulation of each pedigree */

    for (fam=0; fam<num_families; fam++) {
        simulate_pedigree(fam);
    }

    /* output locus description file */
    tempstr = get_temp_string();
    filename1 = get_temp_string();
    input("enter locus description file name [datain.dat]: ",
	  tempstr,TEMP_STRING_LEN);
    stoken(&tempstr,"datain.dat",filename1);
    run {
      fp = open_file(filename1,"w");
    } except_when (CANTOPEN) {
      sf(ps,"Can't open file '%s'",filename1); error(ps);
    }

    sf(ps,"%d 0 0 5  << NO. OF LOCI, RISK LOCUS, SEXLINKED (IF 1) PROGRAM\n",
       num_markers+1); fpr(fp);
    fprint(fp,"0 0.0 0.0 0  << MUT LOCUS, MUT RATE, HAPLOTYPE FREQUENCIES (IF 1)\n");
    for (i=0; i<num_markers+1; i++) { sf(ps,"%d ",i+1); fpr(fp); }
    fprint(fp,"\n");

    fprint(fp,"1  2  << AFFECTATION, NO. OF ALLELES\n");
    sf(ps,"%.6lf %.6lf  << GENE FREQUENCIES\n",
       1.0-affected_freq, affected_freq); fpr(fp);
    fprint(fp,"1  << NO. OF LIABILITY CLASSES\n");
    sf(ps,"%.6lf %.6lf %.6lf\n",penetrance[HOM_UNAFF],penetrance[HET],
       penetrance[HOM_AFF]); fpr(fp);
    
    for (i=0; i<num_markers; i++) {
        sf(ps,"3  %d  << ALLELE NUMBERS, NO. OF ALLELES\n",num_alleles[i]);
	fpr(fp);
	last_prob=0.00;
	for (j=0; j<num_alleles[i]; j++) {
	  sf(ps,"%.4lf ",allele_prob[i][j]-last_prob); fpr(fp);
	  last_prob=allele_prob[i][j];
	}
	fprintf(fp," << GENE FREQUENCIES\n");
    }
    fprintf(fp,"0 0  << SEX DIFFERENCE, INTERFERENCE (IF 1 OR 2)\n");
    fprintf(fp,"0.10 ");
    
    for (i=0; i<num_markers-1; i++) {
        sf(ps,"%.6lf ",dist_to_rec(map_position[i+1] - map_position[i]));
	fpr(fp);
    }
    fprint(fp," << RECOMB VALUES\n");
    fprint(fp,"1 0.1 0.45  << REC VARIED, INCREMENT, FINISHING VALUE\n");
    
    close_file(fp);

    /* output pedigree file */
    tempstr = get_temp_string();
    filename2 = get_temp_string();
    input("enter pedigree data file name [pedin.pre]: ",
	  tempstr,TEMP_STRING_LEN);
    stoken(&tempstr,"pedin.pre",filename2);
    run {
      fp = open_file(filename2,"w");
    } except_when (CANTOPEN) {
      sf(ps,"Can't open file '%s'",filename2); error(ps);
    }
    /* errors and missing data can be inserted here */
    /* something like before each genotype is output, make a random
       error check and if random < error_rate, pick a new allele
       and if it fits Mendelian-wise, accept it instead */

    if (gen_phenos) {
      tempstr = get_temp_string();
      filename3 = get_temp_string();
      input("enter phenotype data file name [pheno.dat]: ",
	    tempstr,TEMP_STRING_LEN);
      stoken(&tempstr,"pheno.dat",filename3);
      run {
	fp_pheno = open_file(filename3,"w");
      } except_when (CANTOPEN) {
	sf(ps,"Can't open file '%s'",filename3); error(ps);
      }
    }

    for (i=0; i<num_families; i++) {
        for (j=0; j<num_members[i]; j++) {

	    if (gen_phenos) {
	      if (family[i][j].affectation_status == UNKNOWN) {
		sf(ps,"%s\t%s\t-\n",family_name[i],family[i][j].indiv_ID);
		fpr(fp_pheno);
	      } else {
		sf(ps,"%s\t%s\t%.4lf\n",family_name[i],family[i][j].indiv_ID,
		   generate_pheno_value(family[i][j].affectation_status));
		fpr(fp_pheno);
	      }
	    }

	    dad = family[i][j].dad_index;  mom = family[i][j].mom_index;
	    sf(ps,"%s\t%s\t%s\t%s\t%d\t%d",family_name[i],
	       family[i][j].indiv_ID,
	       (dad >= 0) ? family[i][dad].indiv_ID : "0",
	       (mom >= 0) ? family[i][mom].indiv_ID : "0",
	       family[i][j].sex, family[i][j].affectation_status); fpr(fp);

	    if (scored_individual(i,j)) {
	      for (k=0; k<num_markers; k++) {
		rm = randnum(); re = randnum();
		if (rm < (missing_rate/100.0)) {
		  sf(ps,"\t0 0"); fpr(fp);
		} else if (re<(error_rate/100.0) && dad >= 0) {
		  if (re < (error_rate/200.0)) {
		    /* permute dad allele */
		    other = (family[i][j].genotype[k][0]==family[i][dad].genotype[k][0]) ? family[i][dad].genotype[k][1] : family[i][dad].genotype[k][0];
		    sf(ps,"\t%d %d",other,family[i][j].genotype[k][1]); 
		    fpr(fp);
		  } else {
		    /* permute mom allele */
		    other = (family[i][j].genotype[k][1]==family[i][mom].genotype[k][0]) ? family[i][mom].genotype[k][1] : family[i][mom].genotype[k][0];
		    sf(ps,"\t%d %d",family[i][j].genotype[k][0],other); 
		    fpr(fp);
		  }
		} else {
		  sf(ps,"\t%d %d",family[i][j].genotype[k][0],
		     family[i][j].genotype[k][1]); fpr(fp);
		}
	      }
	    } else {
	      for (k=0; k<num_markers; k++) {
		sf(ps,"\t0 0"); fpr(fp);
	      }
	    }
	    fprint(fp,"\n");
	}
    }
    close_file(fp);

    sf(ps,"Simulated data stored in files '%s' and '%s'.\n",
       filename1, filename2);
    pr();

    if (gen_phenos) {
      close_file(fp_pheno);
      sf(ps,"Phenotype data stored in file '%s'.\n",filename3); pr();
    }
}

scored_individual(int fam, int ind)
{
    int IDnum;

    if (sscanf(family[fam][ind].indiv_ID,"%d",&IDnum) != 1)
        error("in scored_individual");
    if (IDnum > 12) return(TRUE);
    else return(FALSE);
}

command set_X_simulation(void)
{
    char type[TOKLEN+1];
    get_one_arg(stoken,"",type);

    if (nullstr(type)) {
        sf(ps,"Simulation is '%s'\n",
	   simulate_X?"X chromosomal":"autosomal"); pr();
    } else {
        if (matches(type,"ON") || matches(type,"TRUE")) 
	    simulate_X=TRUE;
	else if(matches(type,"OFF") || matches(type,"FALSE"))
	    simulate_X=FALSE;
	else usage_error(1);
      
        sf(ps,"Simulation is now '%s'\n",
	   simulate_X?"X chromosomal":"autosomal"); pr();
    }
}

command set_disease_generation(void)
{
    char type[TOKLEN+1];
    get_one_arg(stoken,"",type);

    if (nullstr(type)) {
        sf(ps,"Disease generation is '%s'\n",
	   generating_method==USE_PEELING?"by peeling":"at random"); pr();
    } else {
        if (matches(type,"peel") || matches(type,"peeling")) 
	    generating_method=USE_PEELING;
	else if(matches(type,"rand") || matches(type,"random"))
	    generating_method=USE_RANDGEN;
	else usage_error(1);

        sf(ps,"Disease generation is now '%s'\n",
	   generating_method==USE_PEELING?"by peeling":"at random"); pr();
    }
}

command set_error_rate(void)
{

    double e_rate;
    char type[TOKLEN+1];

    get_one_arg(rtoken,error_rate,&e_rate);
    
    if (e_rate > 1.0 || e_rate < 0.0) {
        print("error rate specified must be between 0 and 1 percent\n");
    } else {
        error_rate = e_rate;
    }
    sf(ps,"Error rate is now %.4lf %%\n",error_rate); pr();
}

command set_missing_rate(void)
{

    double m_rate;
    char type[TOKLEN+1];

    get_one_arg(rtoken,missing_rate,&m_rate);
    
    if (m_rate > 10.0 || m_rate < 0.0) {
        print("missing rate specified must be between 0 and 10 percent\n");
    } else {
        missing_rate = m_rate;
    }
    sf(ps,"Missing rate is now %.4lf %%\n",missing_rate); pr();
}

command set_heterogeneity(void)
{
    double alpha;
    char type[TOKLEN+1];

    get_one_arg(rtoken,heterogeneity_alpha,&alpha);
    
    if (alpha > 1.0 || alpha < 0.0) {
        print("alpha must be between 0.0 and 1.0\n");
    } else {
        heterogeneity_alpha = alpha;
    }
    sf(ps,"alpha (fraction of pedigrees linked) is now %.4lf\n",
       heterogeneity_alpha); pr();
}
    
command set_gen_phenos(void)
{
    char type[TOKLEN+1];
    get_one_arg(stoken,"",type);

    if (nullstr(type)) {
        sf(ps,"Phenotype generation is '%s'\n",
	   gen_phenos?"on":"off"); pr();
    } else {
        if (matches(type,"on") || matches(type,"true")) 
	    gen_phenos=TRUE;
	else if(matches(type,"off") || matches(type,"false"))
	    gen_phenos=FALSE;
	else usage_error(1);

        sf(ps,"Phenotype generation is now '%s'\n",
	   gen_phenos?"on":"off"); pr();
    }
}
    
void set_disease_info(void) 
{
    int i,j,position_selection;
    char *tempstr;
    double rnum, tot_aff, tot_unaff;

    tempstr = get_temp_string();
    sf(ps,"affected disease allele frequency [%.4lf]: ",affected_freq);
    input(ps,tempstr,TEMP_STRING_LEN);
    rtoken(&tempstr,affected_freq,&rnum);
    if (rnum < 0.00 || rnum > 1.00) error("frequency out of range [0,1]");
    affected_freq = rnum;

    print("enter disease model:\n");
    tempstr = get_temp_string();
    sf(ps,"penetrance - homozygous wild type [%.4lf]: ",penetrance[HOM_UNAFF]);
    input(ps,tempstr,TEMP_STRING_LEN);
    rtoken(&tempstr,penetrance[HOM_UNAFF],&rnum);
    if (rnum < 0.00 || rnum > 1.00) error("penetrance out of range [0,1]");
    penetrance[HOM_UNAFF] = rnum;

    tempstr = get_temp_string();
    sf(ps,"penetrance - heterozygous [%.4lf]: ",penetrance[HET]);
    input(ps,tempstr,TEMP_STRING_LEN);
    rtoken(&tempstr,penetrance[HET],&rnum);
    if (rnum < 0.00 || rnum > 1.00) error("penetrance out of range [0,1]");
    penetrance[HET] = rnum;

    tempstr = get_temp_string();
    sf(ps,"penetrance - homozygous affected [%.4lf]: ",penetrance[HOM_AFF]);
    input(ps,tempstr,TEMP_STRING_LEN);
    rtoken(&tempstr,penetrance[HOM_AFF],&rnum);
    if (rnum < 0.00 || rnum > 1.00) error("penetrance out of range [0,1]");
    penetrance[HOM_AFF] = rnum;

    tempstr = get_temp_string();
    print("place disease: \n");
    input("1) at random, 2) at a locus, 3) between two loci, 4) specific pos [1]: ",
	  tempstr,TEMP_STRING_LEN);
    itoken(&tempstr,1,&position_selection);

    if (position_selection == 1) {
      /* at random */
      disease_position = randnum()*chrom_len;
    } else if (position_selection == 2) {
      /* at a marker position */
      i = (int) (randnum()*(double)num_markers);
      disease_position = map_position[i];
    } else if (position_selection == 3) {
      /* exactly between markers */
      i = (int) (randnum()*(double)(num_markers-1));
      disease_position = (map_position[i]+map_position[i+1])/2.0;
    } else if (position_selection == 4) {
      input("enter exact cM disease_position [0.0]: ",tempstr,TEMP_STRING_LEN);
      rtoken(&tempstr,0.0,&disease_position);
    }
    sf(ps,"disease will be placed at %.2lf cM\n",disease_position);
    pr();

    /* precompute some probabilities of parental disease genotypes
       producing an affected kid */
    
    disease_prob[AFFECTED][HOM_AFF] = 
      affected_freq*affected_freq*penetrance[HOM_AFF];
    disease_prob[AFFECTED][HET] = 
      affected_freq*(1.0-affected_freq)*penetrance[HET];
    disease_prob[AFFECTED][HOM_UNAFF] = 
      (1.0-affected_freq)*(1.0-affected_freq)*penetrance[HOM_UNAFF];

    disease_prob[UNAFFECTED][HOM_AFF] = 
      affected_freq*affected_freq*(1.0-penetrance[HOM_AFF]);
    disease_prob[UNAFFECTED][HET] = 
      affected_freq*(1.0-affected_freq)*(1.0-penetrance[HET]);
    disease_prob[UNAFFECTED][HOM_UNAFF] = 
      (1.0-affected_freq)*(1.0-affected_freq)*(1.0-penetrance[HOM_UNAFF]);

    disease_prob[UNKNOWN][HOM_AFF] = 
      disease_prob[AFFECTED][HOM_AFF]+disease_prob[UNAFFECTED][HOM_AFF];
    disease_prob[UNKNOWN][HET] = 
      disease_prob[AFFECTED][HET]+disease_prob[UNAFFECTED][HET];
    disease_prob[UNKNOWN][HOM_UNAFF] = 
      disease_prob[AFFECTED][HOM_UNAFF]+disease_prob[UNAFFECTED][HOM_UNAFF];

    /* normalize the AFFECTED and UNAFFECTED probs */
    tot_aff = disease_prob[AFFECTED][HOM_AFF]+
             (2.0*disease_prob[AFFECTED][HET])+
              disease_prob[AFFECTED][HOM_UNAFF];
    disease_prob[AFFECTED][HOM_AFF] /= tot_aff;
    disease_prob[AFFECTED][HET] /= tot_aff;
    disease_prob[AFFECTED][HOM_UNAFF] /= tot_aff;

    tot_unaff = disease_prob[UNAFFECTED][HOM_AFF]+
             (2.0*disease_prob[UNAFFECTED][HET])+
              disease_prob[UNAFFECTED][HOM_UNAFF];
    disease_prob[UNAFFECTED][HOM_AFF] /= tot_unaff;
    disease_prob[UNAFFECTED][HET] /= tot_unaff;
    disease_prob[UNAFFECTED][HOM_UNAFF] /= tot_unaff;

}


void simulate_pedigree(int famnum)
{
    int num_kids, i, j, last_marker, next_marker, bitval, indiv, g0, g1;
    double r, dist, theta, place_disease;
    int pvector, disease_vector, affected_non_orig;
    int parent1, parent2, non_originals;

    /* assign originals random alleles at all markers */

    non_originals=0;

    for (i=0; i<num_markers; i++) {
    
      for (indiv=0; indiv<num_members[famnum]; indiv++) {

	if (family[famnum][indiv].dad_index != MISSING && 
	    family[famnum][indiv].mom_index != MISSING) { 
	    /* non-original - SKIP */
	    if (i==0) non_originals++;
	} else {
  
	  r = randnum();
	  for (j=0; j<num_alleles[i]; j++) {
	    if(r <= allele_prob[i][j]) break;
	  }
	  family[famnum][indiv].genotype[i][0] = j+1;

	  if (family[famnum][indiv].sex == 1 && simulate_X) {
	      /* if male and X chromosome, only 1 allele */
	      family[famnum][indiv].genotype[i][1] =
		family[famnum][indiv].genotype[i][0];
	  } else {
	    r = randnum();
	    for (j=0; j<num_alleles[i]; j++) {
	      if(r <= allele_prob[i][j]) break;
	    }
	    family[famnum][indiv].genotype[i][1] = j+1;
	  }
	}
      }
    }

    /* choose disease pvector */

    if (generating_method==USE_PEELING || disease_position < -100.0)
      disease_vector = pick_disease_vector(famnum,non_originals);
    else
      disease_vector = gen_random_disease_family(famnum,non_originals);

    /* LK HACK TO GET PERFECT SHARING */
    /* 
    disease_vector = 0;
    */

    /* random disease vector has been chosen, place it at -1.0 cM */
    if (disease_position < -100.0) place_disease = -1.0;
    else place_disease = disease_position;

    /* so now we know phase at the disease position, we just need to
       push forward and backward through the map, inserting crossovers
       at random and then creating kid genotypes accordingly */

    for (i=0; i<num_markers; i++) {
        if (place_disease < map_position[i]) {
	    last_marker=i-1; next_marker=i; break;
	}
    }
    if (i == num_markers) { 
      last_marker=num_markers-1; next_marker=num_markers;
    }

    pvector = disease_vector;
  
    /* push backward to start */
    if (last_marker >= 0) {
      dist = place_disease - map_position[last_marker];
      while (last_marker >= 0) {
	theta = dist_to_rec(dist);
	push_parents(&pvector,theta,last_marker,famnum,non_originals*2);
	if (last_marker > 0) 
	  dist = map_position[last_marker]-map_position[last_marker-1];
	last_marker--;
      }
    }

    pvector = disease_vector; 

    /* push alleles forward to end of map */
    if (next_marker < num_markers)
    dist = map_position[next_marker] - place_disease;
    while (next_marker < num_markers) {
      theta = dist_to_rec(dist);
      push_parents(&pvector,theta,next_marker,famnum,non_originals*2);
      if (next_marker < num_markers-1) 
	dist = map_position[next_marker+1]-map_position[next_marker];
      next_marker++;
    }

}

int poissonRV(double mean)
{
    static long seed=0;
    double val, poidev(double,long*);

    if (seed==0) { seed = randnum()*(-32767); }

    val = poidev(mean, &seed);
    return((int)val);
}


int push_parents(int *pvec, double theta, int locus, int famnum, int num_bits)
{
    int i, old_pvec, new_pvec, bit, bitval, crossovers, dad_all, mom_all;

    old_pvec = *pvec;
    new_pvec = 0;

    bitval = 1;
    for (i=0; i<num_bits; i++) {
        crossovers = (randnum() > theta) ? 0 : 1;
	if (crossovers == 1) new_pvec += ((old_pvec>>i)%2 == 0) ? bitval : 0;
	else new_pvec += ((old_pvec>>i)%2 == 0) ? 0 : bitval;
	bitval *= 2;
    }

    /* now assign kids alleles at locus based on new_pvec */
    for (i=0; i<num_members[famnum]; i++) {

        if (family[famnum][i].dad_index==MISSING && 
	    family[famnum][i].mom_index==MISSING)  continue;

	bit = family[famnum][i].inh_vec_pos;
	dad_all = (new_pvec >> (num_bits-(2*bit)-1)) % 2;
	mom_all = (new_pvec >> (num_bits-(2*bit)-2)) % 2;

	family[famnum][i].genotype[locus][1] =
	  family[famnum][family[famnum][i].mom_index].genotype[locus][mom_all];

	if (family[famnum][i].sex == 1 && simulate_X) {
	  family[famnum][i].genotype[locus][0] =
	    family[famnum][i].genotype[locus][1];
	} else {
	  family[famnum][i].genotype[locus][0] =
	    family[famnum][family[famnum][i].dad_index].genotype[locus][dad_all];
	}
    }

    *pvec = new_pvec;
}

double dist_to_rec(double dist)
{
    /* Kosambi */
    /* return(0.5*tanh(.02*dist)); */

    /* Haldane map function : cM to rec-frac */
    return(0.5 * (1.0-exp(-.02*dist)));
}

double rec_to_dist(double theta)
{
    if (theta > .499) return(999.9);
    /* Kosambi */
    /* return(25.0 * log((1.0+(2.0*theta)) / (1.0-(2.0*theta)))); */
    /* Haldane map function : rec-frac to cM */
    else return(-50.0 * log(1.0-(2.0*theta)));
}

read_pedigree_header(FILE *fp)
{
    int i,j,k,fam,member,vec,num_vecs,num1,num2,non_originals;
    double *pvector, total, running_total, this_prob;
    char famname[TOKLEN+1], savedfam[TOKLEN+1], indivname[TOKLEN+1];
    char dadname[TOKLEN+1], momname[TOKLEN+1];
    
    run {
      fam=0; member=0; strcpy(savedfam,"");

      while (TRUE) {
	fgetln(fp);
	while (nullstr(ln)) fgetln(fp);
	if (sscanf(ln,"%s %s %s %s %d %d",famname,indivname,dadname,momname,
		   &num1,&num2) != 6) 
	    error("pedigree header file must contain 6 fields per line");

	if (nullstr(savedfam)) strcpy(savedfam,famname);
	else if (!streq(savedfam,famname)) {
	  /* new family starting here */
	  num_members[fam] = member;
	  strcpy(family_name[fam], savedfam);
	  fam++; member=0;
	  strcpy(savedfam,famname);
	}

	strcpy(family[fam][member].indiv_ID, indivname);
	strcpy(family[fam][member].dad_ID, dadname);
	strcpy(family[fam][member].mom_ID, momname);
      
	family[fam][member].sex = num1;
	family[fam][member].nkids = 0;
	family[fam][member].affectation_status = num2;
	family[fam][member].discard = FALSE;

	family[fam][member].inh_vec_pos = MISSING;
	
	member++;
      }
    } on_exit { }

    if (member > 0) {
      /* last family not counted in while loop */
      num_members[fam] = member;
      strcpy(family_name[fam], savedfam);
      fam++; member=0;
    }

    for (i=0; i<fam; i++) {
      non_originals=0;
      for (j=0; j<num_members[i]; j++) {

	if (!strcmp(family[i][j].dad_ID,"0")) family[i][j].dad_index=MISSING;
	else {
	    for (k=0; k<num_members[i]; k++) {
	      if (!strcmp(family[i][j].dad_ID,family[i][k].indiv_ID)) {
		family[i][j].dad_index = k; family[i][k].nkids += 1; break;
	      }
	    }
	    if (k==num_members[i]) {
	      sf(ps,"no dad (%s) found for individual (%s), family (%s)",
		 family[i][j].dad_ID, family[i][j].indiv_ID, family_name[i]); 
	      error(ps);
	    }
	}

	if (!strcmp(family[i][j].mom_ID,"0")) family[i][j].mom_index=MISSING;
	else {
	    for (k=0; k<num_members[i]; k++) {
	      if (!strcmp(family[i][j].mom_ID,family[i][k].indiv_ID)) {
		family[i][j].mom_index = k; family[i][k].nkids += 1; break;
	      }
	    }
	    if (k==num_members[i]) {
	      sf(ps,"no mom (%s) found for individual (%s), family (%s)",
		 family[i][j].mom_ID, family[i][j].indiv_ID, family_name[i]); 
	      error(ps);
	    }
	}
      
	if (family[i][j].dad_index != MISSING && 
	    family[i][j].mom_index != MISSING) {
	    family[i][j].inh_vec_pos = non_originals;
	    non_originals++;
	} else {
	    family[i][j].inh_vec_pos = MISSING;
	}
      }
    }

    return(fam);
}

copy_pedigree_header(int num_fams)
{
    int i,j,k;

    for (i=1; i<num_fams; i++) {

      for (j=0; j<num_members[0]; j++) {

	strcpy(family[i][j].indiv_ID,family[0][j].indiv_ID);
	strcpy(family[i][j].dad_ID,family[0][j].dad_ID);
	strcpy(family[i][j].mom_ID,family[0][j].mom_ID);
      
	family[i][j].dad_index = family[0][j].dad_index;
	family[i][j].mom_index = family[0][j].mom_index;
	family[i][j].sex = family[0][j].sex;
	family[i][j].nkids = family[0][j].nkids;
	family[i][j].affectation_status = family[0][j].affectation_status;
	family[i][j].discard = family[0][j].discard;
	family[i][j].inh_vec_pos = family[0][j].inh_vec_pos;
      }

      num_members[i] = num_members[0];
      sf(ps,"%s-%d",family_name[0],i+1);
      strcpy(family_name[i],ps);
    }
}



int pick_disease_vector(int fam, int non_originals)
{
    int i,num_vecs;
    double r;
    void call_peel(int,int);

    r = randnum();

    if (disease_position < -100.0 || r > heterogeneity_alpha) {
      num_vecs = 1;
      for (i=0; i<non_originals; i++) {
	num_vecs *= 4;
      }
      /* no disease selected - just pick a random number 0 to 2^n-1 */
      r = randnum()*(double)num_vecs;
      return((int) r);
    }

    else {
      if (fam > 0 && pedigree_copies) {
	  /* use already existing pvector set, all peds are copies of
	     the first pedigrees */
      } else {
	  unarray(pvec_prob, double);
	  unarray(pvec_num, int);
	  call_peel(fam, non_originals);
      }
      r = randnum();
      for (i=0; i<num_disease_vecs; i++) {
	if (r <= pvec_prob[i]) return(pvec_num[i]);
      }
      error("pvec_prob does not go to 1.0");
    }
}

/* peeling, etc. from APM */

void call_peel(int fam, int non_originals)
{
    /* create all possible inheritance vectors and calculate
       their probabilities via peeling */
    int i,j,num_vecs,vec;
    double total,running_total,this_prob,*pvector;

    fill_nuc_families(fam);

    num_vecs=1;
    for (i=0; i<non_originals; i++) num_vecs *= 4;

    array(pvector, num_vecs, double);
    array(pvec_prob, num_vecs, double);
    array(pvec_num, num_vecs, int);

    total=0.0;
    for (vec=0; vec<num_vecs; vec++) {
        init_disease_probs(fam);
	pvector[vec] = peel(fam, vec, non_originals*2);
	total += pvector[vec];
    }

    /* Now normalize and store creatively such that we can draw 
       pvectors at random from the set */

    running_total=0.0;
    num_disease_vecs=0;
    for (vec=0; vec<num_vecs; vec++) {
        if (pvector[vec] > 0.0) {

	    this_prob = pvector[vec]/total;
	    running_total += this_prob;
	    pvec_prob[num_disease_vecs] = running_total;
	    pvec_num[num_disease_vecs] = vec;
	    num_disease_vecs++;
	}
    }

    unarray(pvector, double);
}


void fill_nuc_families(int fam)
{
  
  int i,j,kid[MAX_MEMBERS],nf;
  int num_kids, num_in_ped;
  bool checked[MAX_MEMBERS];

  num_in_ped = num_members[fam];

  for (i=0; i<num_in_ped; i++)
    checked[i]=FALSE;
  
  num_nuc_fam=0;
  
  for (i=0; i<num_in_ped; i++) {
    if (family[fam][i].discard) continue;
    if (checked[i]) continue;

    if (family[fam][i].nkids > 0) {

      /* Make a list of all the kids of the individual */
      num_kids=0;
      for (j=0; j<num_in_ped; j++){
	if (num_kids == family[fam][i].nkids) break;
	if (family[fam][j].dad_index == i ||
	    family[fam][j].mom_index == i) {
	  if (family[fam][j].discard) continue;
	  kid[num_kids]=j;
	  num_kids++;
	}
      }
      
      if (num_kids > 0) {
	nuc_fam[num_nuc_fam].pivot = -1;

	nuc_fam[num_nuc_fam].dad = family[fam][kid[0]].dad_index;
	nuc_fam[num_nuc_fam].mom = family[fam][kid[0]].mom_index;
	nuc_fam[num_nuc_fam].num_kids=0;
	for (j=0; j<num_kids; j++) {
	  if (family[fam][kid[j]].mom_index == nuc_fam[num_nuc_fam].mom &&
	      family[fam][kid[j]].dad_index == nuc_fam[num_nuc_fam].dad) {
	    nuc_fam[num_nuc_fam].kid[nuc_fam[num_nuc_fam].num_kids]=kid[j];
	    nuc_fam[num_nuc_fam].num_kids++;
	  }
	}
	num_nuc_fam++;
      }

      checked[nuc_fam[num_nuc_fam-1].dad]=TRUE;
      checked[nuc_fam[num_nuc_fam-1].mom]=TRUE;

      
    }

  }
  
  if (num_nuc_fam > 1) 
    mark_pivots(fam);
  else
    order_assigned[0]=0;
}

void mark_pivots (int fam)
{
  /* Make a list of all the pivots in the extended family.
     Then for each family who has one member in the pivot
     list is peripheral and we assign them unless we have
     already assigned num_nuc_fam-1 */
  
  int i,j,k;
  int num_pivots=0,pivot[MAX_MEMBERS];
  int num_assigned,fam_pivot,fam_pivots,num_kids,num_in_ped;
  int assigned[MAX_MEMBERS];
  bool done;
  
  num_in_ped = num_members[fam];

  /* Make the list of pivots */
  for (i=0; i<num_in_ped; i++) {
    if (family[fam][i].discard) continue;
    if (family[fam][i].mom_index != MISSING &&
	family[fam][i].dad_index != MISSING) {

      /* Count up non-discarded kids */
      num_kids=0;
      for (j=0; j<num_in_ped; j++) {
	if (family[fam][j].discard) continue;
	if (family[fam][j].mom_index == i ||
	    family[fam][j].dad_index == i)
	  num_kids++;
      }
      if (num_kids > 0) {
	pivot[num_pivots]=i;
	num_pivots++;
      }
    }
  }

  if (num_pivots < (num_nuc_fam-1)) {
    /* In this case we have a string of marriages with
       half sibs on the next level, so the pivots will
       be individuals with more than one partner */
    for (i=0; i<num_nuc_fam; i++) 
      for (j=i+1; j<num_nuc_fam; j++) {
	/* Make a list of individuals shared between two nuc fams */
	if (nuc_fam[i].dad == nuc_fam[j].dad) {
	  pivot[num_pivots]=nuc_fam[i].dad;
	  num_pivots++;
	}
	if (nuc_fam[i].mom == nuc_fam[j].mom) {
	  pivot[num_pivots]=nuc_fam[i].mom;
	  num_pivots++;
	}
      }
  }
  for (i=0; i<num_nuc_fam; i++)
    assigned[i]=FALSE;

  /* Assign pivots within nuclear families */
  num_assigned = 0;
  done=FALSE;
  while(!done) {
    for (i=0; i<num_nuc_fam; i++) {
      if (assigned[i]) continue;
      fam_pivot = -1;
      fam_pivots=0;
      for (j=0; j<num_pivots; j++) {
	if (pivot[j]==nuc_fam[i].mom ||
	    pivot[j]==nuc_fam[i].dad) {
	  fam_pivot = pivot[j];
	  fam_pivots++;
	} else {
	  for (k=0; k<nuc_fam[i].num_kids; k++) {
	    if (pivot[j]==nuc_fam[i].kid[k]) {
	      fam_pivot = pivot[j];
	      fam_pivots++;
	    }
	  }
	}
      }
      if (fam_pivots == 1) {
	nuc_fam[i].pivot = fam_pivot;
	order_assigned[num_assigned]=i;
	num_assigned++;
	assigned[i]=TRUE;
	if (num_assigned == (num_nuc_fam-1)) {
	  done = TRUE; break;
	}
      }
    }
    if (!done) {
      /* Remove the pivots that have been assigned */
      for (i=0; i<num_assigned; i++) {
	for (j=0; j<num_pivots; j++) {
	  if (pivot[j] ==
	      nuc_fam[order_assigned[i]].pivot) {
	    pivot[j]= -1;
	  }
	}
      }
    }
  }
  /* Fill order_assigned with the last family to be checked */
  for (i=0; i<num_nuc_fam; i++)
    if (!assigned[i])
      order_assigned[num_assigned]=i;

}


void init_disease_probs(int fam) 
{
  /* sets each pedigree member's a-priori disease allele frequencies */
  /* called before peel() for each inheritance vector */

  int i,aff_stat,liab_class,num_in_ped;
  double total_pen;

  num_in_ped = num_members[fam];
  total_pen = penetrance[HOM_AFF]+penetrance[HOM_UNAFF]+(2.0*penetrance[HET]);

  for (i=0; i<num_in_ped; i++) {
    aff_stat = family[fam][i].affectation_status;
    if (family[fam][i].dad_index==MISSING&&family[fam][i].mom_index==MISSING) {
      family[fam][i].disease_prob[HOM_AFF] = disease_prob[aff_stat][HOM_AFF];
      family[fam][i].disease_prob[HET_UA] = disease_prob[aff_stat][HET];
      family[fam][i].disease_prob[HET_AU] = disease_prob[aff_stat][HET];
      family[fam][i].disease_prob[HOM_UNAFF] = disease_prob[aff_stat][HOM_UNAFF];
    } else {
      switch (aff_stat) {
        case 1: 
	  family[fam][i].disease_prob[HOM_AFF]=
	    (1.0-penetrance[HOM_AFF])/(4.0-total_pen);
	  family[fam][i].disease_prob[HET_UA]=
	    (1.0-penetrance[HET])/(4.0-total_pen);
	  family[fam][i].disease_prob[HET_AU]=
	    (1.0-penetrance[HET])/(4.0-total_pen);
	  family[fam][i].disease_prob[HOM_UNAFF]=
	    (1.0-penetrance[HOM_UNAFF])/(4.0-total_pen);
	  break;
	case 2:
	  family[fam][i].disease_prob[HOM_AFF]=
	    penetrance[HOM_AFF]/total_pen;
	  family[fam][i].disease_prob[HET_UA]=
	    penetrance[HET]/total_pen;
	  family[fam][i].disease_prob[HET_AU]=
	    penetrance[HET]/total_pen;
	  family[fam][i].disease_prob[HOM_UNAFF]=
	    penetrance[HOM_UNAFF]/total_pen;
	  break;
	default: /* UNKNOWN */
	  family[fam][i].disease_prob[HOM_AFF]=0.25;
	  family[fam][i].disease_prob[HET_UA]=0.25;
	  family[fam][i].disease_prob[HET_AU]=0.25;
	  family[fam][i].disease_prob[HOM_UNAFF]=0.25;
	  break;
      }
    }
  }
}

/* expects global nuc_fam[], num_nuc_fams to be filled in */

double peel(int fam, int inh_vec, int num_bits)
{
    int nf, f, i, j, k, this_pivot, this_spouse, kid_allele, pivot_allele;
    double this_prob, total_prob, new_prob[4];
    int get_kid_allele(int,int,int,int,int,int);

    for (f=0; f<num_nuc_fam; f++) {
      nf = order_assigned[f];

      if (f==num_nuc_fam-1) {
	/* FINAL FAMILY - compute total probability */
	total_prob=0.0;
	for (i=0; i<4; i++) { /* dad's genotypes */
	  for (j=0; j<4; j++) { /* mom's genotypes */
	    this_prob = family[fam][nuc_fam[nf].dad].disease_prob[i] *
	                family[fam][nuc_fam[nf].mom].disease_prob[j];
	    for (k=0; k<nuc_fam[nf].num_kids; k++) {
	        kid_allele = get_kid_allele(nuc_fam[nf].kid[k],i,j,inh_vec,num_bits,fam);
		this_prob *= family[fam][nuc_fam[nf].kid[k]].disease_prob[kid_allele];
	    }
	    total_prob += this_prob;
	  }
	}
	return(total_prob);

      } else {
	
	this_pivot = nuc_fam[nf].pivot;
	if (this_pivot == MISSING)
	    error("no pivot listed in non-final nuclear family");

	if (this_pivot == nuc_fam[nf].dad || this_pivot == nuc_fam[nf].mom) {
	    /* PEEL ONTO PARENT */
	    this_spouse =
	      (this_pivot==nuc_fam[nf].dad) ? nuc_fam[nf].mom : nuc_fam[nf].dad;
	    for (i=0; i<4; i++) { /* pivot_parent genotypes */
	        new_prob[i]=0.0;
		for (j=0; j<4; j++) { /* spouse's genotypes */
		    this_prob = family[fam][this_spouse].disease_prob[j];
		    for (k=0; k<nuc_fam[nf].num_kids; k++) {
		      /* for each kid - lookup alleles based on i,j,inh_vec */
		      if (this_pivot==nuc_fam[nf].dad)
			kid_allele = 
			  get_kid_allele(nuc_fam[nf].kid[k],i,j,inh_vec,num_bits,fam);
		      else
			kid_allele = 
			  get_kid_allele(nuc_fam[nf].kid[k],j,i,inh_vec,num_bits,fam);
		      this_prob *= family[fam][nuc_fam[nf].kid[k]].disease_prob[kid_allele];
		    }
		    new_prob[i] += this_prob;
		}
		/* update the pivot's probability based on this sub-pedigree */
		family[fam][this_pivot].disease_prob[i] *= new_prob[i];
	    }

	} else { 
	    /* PEEL ONTO KID */
	    for (i=0; i<4; i++) new_prob[i]=0.0;
	    for (i=0; i<4; i++) { /* dad's genotypes */
	      for (j=0; j<4; j++) { /* mom's genotypes */
		this_prob = family[fam][nuc_fam[nf].dad].disease_prob[i] *
		            family[fam][nuc_fam[nf].mom].disease_prob[j];
		for (k=0; k<nuc_fam[nf].num_kids; k++) {
		  kid_allele = get_kid_allele(nuc_fam[nf].kid[k],i,j,inh_vec,num_bits,fam);
		  this_prob *= family[fam][nuc_fam[nf].kid[k]].disease_prob[kid_allele];
		  if (nuc_fam[nf].kid[k] == this_pivot) pivot_allele=kid_allele;
		}
		new_prob[pivot_allele] += this_prob;
	      }
	    }
	    /* save the new probs for the pivot child */
	    for (i=0; i<4; i++) family[fam][this_pivot].disease_prob[i] = new_prob[i];
	}
      }
    }
}


int get_kid_allele(int kid_index, int dad_disease, int mom_disease, 
		   int inh_vec, int num_bits, int fam)
{
    int bit,dad_all,mom_all,k1,k2;

    /* 1st non-original has dad bit at num_bits-1, mom_bit at num_bits-2, etc... */

    bit = family[fam][kid_index].inh_vec_pos;

    dad_all = (inh_vec >> (num_bits-(2*bit)-1)) % 2;
    mom_all = (inh_vec >> (num_bits-(2*bit)-2)) % 2;

    if (dad_all == 0) {
      if (dad_disease == HOM_AFF || dad_disease==HET_AU) k1=AFFECTED;
      else k1=UNAFFECTED;
    } else {
      if (dad_disease == HOM_AFF || dad_disease==HET_UA) k1=AFFECTED;
      else k1=UNAFFECTED;
    }

    if (mom_all == 0) {
      if (mom_disease == HOM_AFF || mom_disease==HET_AU) k2=AFFECTED;
      else k2=UNAFFECTED;
    } else {
      if (mom_disease == HOM_AFF || mom_disease==HET_UA) k2=AFFECTED;
      else k2=UNAFFECTED;
    }

    if (k1==AFFECTED && k2==AFFECTED) return(HOM_AFF);
    if (k1==AFFECTED && k2==UNAFFECTED) return(HET_AU);
    if (k1==UNAFFECTED && k2==AFFECTED) return(HET_UA);
    return(HOM_UNAFF);
}


gen_random_disease_family(int famnum, int non_originals)
{
    int i, j, indiv, g0, g1, affected_non_orig, dad, mom, done_yet;
    int this_bit, disease_pvector, num_vecs, num30s, num40s, tot30s;
    double r;

    r = randnum();

    if (r > heterogeneity_alpha) {
      num_vecs = 1;
      for (i=0; i<non_originals; i++) {
	num_vecs *= 4;
      }
      /* no disease selected - just pick a random number 0 to 2^n-1 */
      r = randnum()*(double)num_vecs;
      return((int) r);
    }

    affected_non_orig=0; num40s=0; num30s=0; done_yet=0;

    while (!done_yet) {

      affected_non_orig=0; num40s=0; num30s=0; tot30s=0;

      /* randomly assign disease genotypes to originals */
      for (indiv=0; indiv<num_members[famnum]; indiv++) {
        
      	if (family[famnum][indiv].dad_index != MISSING && 
	    family[famnum][indiv].mom_index != MISSING) { 
	    /* non-original - SKIP */
	} else {
	    r = randnum();
	    if (r < affected_freq) 
	      g0 = family[famnum][indiv].disease_genotype[0] = AFFECTED;
	    else
	      g0 = family[famnum][indiv].disease_genotype[0] = UNAFFECTED;

	    r = randnum();
	    if (r < affected_freq) 
	      g1 = family[famnum][indiv].disease_genotype[1] = AFFECTED;
	    else
	      g1 = family[famnum][indiv].disease_genotype[1] = UNAFFECTED;

	    r = randnum();
	    if (g0==UNAFFECTED && g1==UNAFFECTED) {
	      if (r < penetrance[HOM_UNAFF])
		family[famnum][indiv].affectation_status = AFFECTED;
	      else 
		family[famnum][indiv].affectation_status = UNAFFECTED;
	    } else if (g0==AFFECTED && g1==AFFECTED) {
	      if (r < penetrance[HOM_AFF]) 
		family[famnum][indiv].affectation_status = AFFECTED;
	      else 
		family[famnum][indiv].affectation_status = UNAFFECTED;
	    } else { /* HET */
	      if (r < penetrance[HET]) 
		family[famnum][indiv].affectation_status = AFFECTED;
	      else 
		family[famnum][indiv].affectation_status = UNAFFECTED;
	    }
	}
      }
      /* now push this allele down through the pedigree, recording
	 the bits chosen for the pvector accordingly */

      disease_pvector = 0;

      for (indiv=0; indiv <num_members[famnum]; indiv++) {
        
      	if (family[famnum][indiv].dad_index != MISSING && 
	    family[famnum][indiv].mom_index != MISSING) { 
	    /* non-original - propagate allele */

	    /* if (family[famnum][indiv].indiv_ID[0]=='3') tot30s++; */
	    
	    dad = family[famnum][indiv].dad_index;
	    mom = family[famnum][indiv].mom_index;

	    r=randnum();
	    if (r < 0.50) this_bit=0;
	    else this_bit=1;

	    g0 = family[famnum][dad].disease_genotype[this_bit];
    	    family[famnum][indiv].disease_genotype[0] = g0;
	    disease_pvector *= 2;
	    disease_pvector += this_bit;
	    
	    r=randnum();
	    if (r < 0.50) this_bit=0;
	    else this_bit=1;

	    g1 = family[famnum][mom].disease_genotype[this_bit];
	    family[famnum][indiv].disease_genotype[1] = g1;
	    disease_pvector *= 2;
	    disease_pvector += this_bit;
	 
	    /* now decide whether this individual is affected or unaffected */
	    r = randnum();
	    if (g0==UNAFFECTED && g1==UNAFFECTED) {
	      if (r < penetrance[HOM_UNAFF]) {
		family[famnum][indiv].affectation_status = AFFECTED;
		if (scored_individual(famnum,indiv)) affected_non_orig++;

		if (family[famnum][indiv].indiv_ID[0]=='3') num30s++;
		else if (family[famnum][indiv].indiv_ID[0]=='4') num40s++;

	      } else {
		  family[famnum][indiv].affectation_status = UNAFFECTED;
	      }
	    } else if (g0==AFFECTED && g1==AFFECTED) {
	      if (r < penetrance[HOM_AFF]) {
		family[famnum][indiv].affectation_status = AFFECTED;
		if (scored_individual(famnum,indiv)) affected_non_orig++;

		if (family[famnum][indiv].indiv_ID[0]=='3') num30s++;
		else if (family[famnum][indiv].indiv_ID[0]=='4') num40s++;

	      } else {
		family[famnum][indiv].affectation_status = UNAFFECTED;
	      }
	    } else { /* HET */
	      if (r < penetrance[HET]) {
		family[famnum][indiv].affectation_status = AFFECTED;
		if (scored_individual(famnum,indiv)) affected_non_orig++;

		if (family[famnum][indiv].indiv_ID[0]=='3') num30s++;
		else if (family[famnum][indiv].indiv_ID[0]=='4') num40s++;

	      } else {
		family[famnum][indiv].affectation_status = UNAFFECTED;
	      }
	    }

	} else {
	    /* original, continue */
	}
      }

      if (num30s >= 1) done_yet=TRUE;

      /*****
      if (family[famnum][18].affectation_status == AFFECTED &&
	  family[famnum][19].affectation_status == AFFECTED)
	  done_yet=TRUE;
      *****/
    } /* keep doing this until enough affected_non_originals */

    return(disease_pvector);
}


double generate_pheno_value(int aff)
{
    double deviate, pheno, aff_mean=5.0, normal_deviate(void);

    deviate = normal_deviate();

    if (aff == 1) pheno = deviate;
    else if (aff == 2) pheno = deviate+aff_mean;

    return(pheno);
}


double normal_deviate(void)
{
    static long seed=0;
    double val, gasdev(long*);

    if (seed==0) { seed = randnum()*(-32767); }

    val = gasdev(&seed);
    return(val);
}

