/* GENEHUNTER - Kruglyak, Daly, Reeve-Daly, and Lander
   Whitehead Institute for Biomedical Research, Copyright 1996 */
#define INC_LIB
#define INC_SHELL
#include "npl.h"

#define REMOVE_BITS

/* Internal methods */
void prep_standford_pedigree(char*);
void prep_linkage_pedigree(char*);
void analyze_family(int);
void orig_haplotypes (int,int*,int**,int**,int**);
void draw_pedigree(int,int,int*,char*,int**,int*,int*,int,int**,int,int**);


int total_meioses;
int total_affecteds[12];
int num_pedigrees;
FILE *haplofp;

static int sorted_ped[MAX_INDIVIDUALS]; /* Store the indices of
					   famtree sorted so that all
					   ancestors are at the front
					   of the list */
static bool placed[MAX_INDIVIDUALS]; /* Boolean list same length as famtree
					 indicating whether or not the 
					 corresponding indiv in famtree has 
					 been placed yet or not */
static int num_placed;
         /* Keep track of how many individuals have been placed */

double npl_pos, npl_max;


command pedigree_prep(void)
{

  /* Determine the type of pedigree we are dealing with (LINKAGE
     or our own internal format and call the appropriate method) */

  char *filename,s1[100],*hfilename;
  FILE *fpin;
  void prep_stanford_pedigree(char*),prep_linkage_pedigree(char*);
  int i,j,k,n,a,b,c,d,e;
  double theta, chisq, diff, sum, chisq_prob(double,double);
  int temp_ser, temp_hap, temp_num_in_map_order, temp_map[MAXLOCI];

  if (num_markers == 0) {
    print("Please load marker information using 'load markers' first.\n");
    return;
  }

  run {
    filename = get_temp_string();
    use_uncrunched_args();
    get_one_arg(stoken,"",filename);
	  
    if (nullstr(filename)) print("need filename as argument\n");
    
    fpin = open_file(filename,"r");
    fgetln(fpin);
    while(nullstr(ln)) fgetln(fpin);

    n = sscanf(ln,"%s %d %d %d %d %d",s1,&a,&b,&c,&d,&e);
    close_file(fpin); fpin=NULL;

    if (n == 2) {
      prep_stanford_pedigree(filename); /* Top line has pedname & num_kids */
    } else if (n == 6)  {

      hfilename = get_temp_string();
      strcpy(hfilename,"haplo.dump");
      haplofp = open_file(hfilename,"w");

      /* TDT storage initialization */
      for (k=0; k<12; k++) {
	for (i=0; i<num_markers; i++) {
	  for (j=0; j<MAX_ALLELE_SIZE; j++) {
	    locus[i].allele_count[j][k][0]=0;
	    locus[i].allele_count[j][k][1]=0;
	  }
	}
	total_affecteds[k]=0;
      }
      
      if (single_point_mode) {
	temp_ser = show_expected_recs; show_expected_recs=FALSE;
	temp_hap = haplotype_output;   haplotype_output=FALSE;
	temp_num_in_map_order = num_in_map_order;
	for (i=0; i < num_in_map_order; i++) temp_map[i] = map_order[i];
	num_in_map_order = num_markers;
	for (i=0; i<num_markers; i++) map_order[i]=i;
      }

      total_meioses=0; 
      prep_linkage_pedigree(filename); /* LINKAGE has 6 or more fields */
      if (show_expected_recs && num_pedigrees>1) {
	  sf(ps,"TOTAL RECOMBINATION COUNT (%d total meioses):\n",
	     total_meioses); pr();
	  print("interval   theta  exp-recs obs-recs\n");
	  for (i=0; i<num_in_map_order-1; i++) {
	    theta = dist_to_rec(map_distance[i]);
	    sf(ps,"%4d-%-4d %6.4lf %8.3lf %8.3lf\n",map_order[i]+1,
	       map_order[i+1]+1,theta,theta*total_meioses,total_recs[i]);
	    pr();
	  }
      }
      unarray(total_recs, double);

      close_file(haplofp);

#ifdef TDT_ACTIVE
      if (haplotype_output) {
	/* TDT-results */
	for (k=0; k<1; k++) { /* was 12 */
	  /**********
	  sf(ps,"TDT Summary - GROUP %d - (%d non-original affecteds):\n",
	     k+1, total_affecteds[k]); pr();
	  **********/
	  sf(ps,"TDT Summary - (%d non-original affecteds):\n",
	     total_affecteds[k]); pr();

	  for (i=0; i<num_in_map_order; i++) {
	    sf(ps,"Marker %-3d       trans untrans  Chi2  p-val\n",map_order[i]+1); pr();
	    for (j=0; j<MAX_ALLELE_SIZE; j++) {
	      if (locus[map_order[i]].allele_count[j][k][0] > 0 ||
		  locus[map_order[i]].allele_count[j][k][1] > 0) {
		diff = (double) (locus[map_order[i]].allele_count[j][k][0] -
				 locus[map_order[i]].allele_count[j][k][1]);
		sum = (double)  (locus[map_order[i]].allele_count[j][k][0] +
				 locus[map_order[i]].allele_count[j][k][1]);
		chisq = diff*diff/sum;
		sf(ps,"M%-3d - Allele %-3d  %4d  %4d   %6.2lf  %.6lf\n",
		   map_order[i]+1, j,
		   locus[map_order[i]].allele_count[j][k][TRANSMITTED],
		   locus[map_order[i]].allele_count[j][k][UNTRANSMITTED],
		   chisq, chisq_prob(1.0, chisq)); pr();
	      }
	    }
	  }
	}
      }
#endif

      if (single_point_mode) {
	show_expected_recs= temp_ser;
	haplotype_output= temp_hap;
	num_in_map_order= temp_num_in_map_order;
	for (i=0; i<num_in_map_order; i++) {
	  map_order[i] = temp_map[i];
	}
      }

    } else { 
      sf(ps,"error: can't recognize first line of pedigree file (%s)\n",ln);
      pr();
    }

  } on_error {
    if (msg == CANTOPEN) {
      sf(ps,"Can't open file '%s'\n",filename); pr();
    } else {
      relay_messages;
    }
  }
}


void prep_stanford_pedigree(char *filename)
{

  /* eliminated to save space */
  error("old pedigree format - not supported");
}

/*********************************/
/* LINKAGE PEDIGREE READING CODE */
/*********************************/



typedef struct {
  int dad;
  int mom;
  int num_kids;
  int kid[MAX_KIDS];
  int pivot;
  bool inbred;        

  /* the following vars are for inbred families (or families in their loop)*/
  int num_common_anc; /* Number of ancestors in common between the mom&dad of this
			 nuclear family, for half-sibs it would be 1, in most other
			 cases it will be 2. */
  int dad_to_common;  /* Number of pedigree levels to the common ancestor.  For */
  int mom_to_common;  /* sibs marrying each other 0 levels, 1st cousins 1, etc */

  bool in_loop;
  int loop_indiv;

} NUC_FAMILY;

static NUC_FAMILY nuc_fam[MAX_INDIVIDUALS];
static int num_nuc_fam;
static int num_nuc_fams_to_peel;
static order_assigned[MAX_INDIVIDUALS];

#define MISSING (-1) /* Value to set uncalculated fields to */
#define MALE 1
#define FEMALE 2
static char current_ped[MAX_NAME_SIZE];
int allele_data[MAX_INDIVIDUALS][MAXLOCI*2];
int num_allele_data[MAX_INDIVIDUALS];
int allele_offset;
int num_original_nodes;

/* Linkage pedigree auxiliary methods */
void set_mom_index(int,int);
void set_dad_index(int,int);
void check_for_unlinked(int);
void check_for_loop(int,int,int,int,int);
void sort_pedigree(int);
void place_indiv(int);
void fill_nuc_families(int);
int inbred_matings(void);
int mark_pivots(int);
void order_inbred_family(void);

void prep_linkage_pedigree(char *filename)
{

  FILE *fpin;
  char ped_name[MAX_NAME_SIZE];
  char indiv_ID[MAX_NAME_SIZE];
  char father_ID[MAX_NAME_SIZE], mother_ID[MAX_NAME_SIZE];
  int list_index, sex, j, datum, pedigrees_loaded;

  /* Open the input file with the LINKAGE format pedigrees, and
     the output file where the inheritance vectors will be written */

  num_pedigrees=0;

  run {

    fpin = NULL; 
    fpin = open_file(filename,"r");
    strcpy(current_filename, filename);

  } except_when(CANTOPEN) {
    sf(ps,"Can't open file: %s\n",filename); pr();
    return;
  }

  array(famtree,MAX_INDIVIDUALS+5,PED_MEMBER);
  run {
    list_index=0;
    strcpy(current_ped,"");
    while(1) {

      fgetln(fpin);
      if (!maxstoken(&ln,sREQUIRED,ped_name,MAX_NAME_SIZE)) {
	/* blank line, read the next line */
      }
      else {
	/* actual line of data */
	if (nullstr(current_ped)) {
	  /* Record the new pedigree information for the first pedigree */
	  strcpy(current_ped,ped_name);
	  num_pedigrees++;
	} else if (strcasecmp(current_ped,ped_name) != 0) {
	  /* This line is the start of a new pedigree,
	     dump out the old one and reset the list index to 0 */
	  analyze_family(list_index); /* scans the family */

	  strcpy(current_ped,ped_name);
	  list_index=0;
	  num_pedigrees++;
	}
	
	/* Read the individual's index within the pedigree */
	if (!maxstoken(&ln,sREQUIRED,indiv_ID,MAX_NAME_SIZE)) {
	  sf(ps,"bad input line - no indivdual ID"); error(ps);
	}
	/* Read the parents' indices in the pedigree */
	if (!maxstoken(&ln,sREQUIRED,father_ID,MAX_NAME_SIZE)) {
	  sf(ps,"bad input line - no paternal ID for indiv %s",
	     indiv_ID); error(ps);
	}
	if (!maxstoken(&ln,sREQUIRED,mother_ID,MAX_NAME_SIZE)) {
	  sf(ps,"bad input line - no maternal ID for indiv %s",
	     indiv_ID); error(ps);
	}
	/* Read the sex of the individual */
	if (!itoken(&ln,iREQUIRED,&sex)) {
	  sf(ps,"bad input line - no sex for individual %s",indiv_ID);
	  error(ps);
	}
	
	/* Record the information in the family tree struct */
	strcpy(famtree[list_index].indiv_ID,indiv_ID);
	strcpy(famtree[list_index].dad,father_ID);
	strcpy(famtree[list_index].mom,mother_ID);
	famtree[list_index].sex=sex;
	/* Initialize values to be filled in later */
	famtree[list_index].nkids=0;
	famtree[list_index].dad_index=MISSING;
	famtree[list_index].mom_index=MISSING;
	
	/* Check that this isn't a duplicate indiv_ID */
	for (j=0; j<list_index; j++)
	  if (!strcasecmp(famtree[j].indiv_ID,
			  famtree[list_index].indiv_ID)) {
	    sf(ps,"indiv %s appears more than once in pedigree %s",
	       famtree[list_index].indiv_ID,current_ped); error(ps);
	  }
	    
	/* Read in the genotype data -store in static structs */
	j=0;
	while (itoken(&ln,iREQUIRED,&datum)) {
	  allele_data[list_index][j]=datum;
	  j++;
	}
	num_allele_data[list_index]=j;
	list_index++;
      }
    }	
    close_file(fpin);
    pedigrees_loaded=TRUE;
    unarray(famtree,PED_MEMBER);
  } except {
      when SOFTABORT: 
          pedigrees_loaded = FALSE;
          num_pedigrees = 0;
          close_file(fpin); fpin=NULL;
          unarray(famtree,PED_MEMBER);
          relay;
      when ENDOFILE:
          if (list_index > 0) {
	    pedigrees_loaded = TRUE;
	    run { analyze_family(list_index); } on_error {
	      pedigrees_loaded = FALSE;
	    }
	  }
          close_file(fpin); fpin=NULL;
          unarray(famtree,PED_MEMBER);
          break;
      default:
          close_file(fpin); fpin=NULL;
          unarray(famtree,PED_MEMBER);
          relay;
    }
}

int uninformative_bit[64];

void analyze_family(int num_in_ped)
{
  int i,j,k,mom,dad; 
  int num_loci,originals,non_originals,real_non_originals;
  int num_vecs, vec, cur_place, skip_ped, num_bits;
  int p0, p1, m0, m1, ptry[2], mtry[2], pall[2], mall[2], call[20];
  int pset0[10], pset1[10], mset0[10], mset1[10], pflag;
  double prob, graph_assign_probs(int,int,int,int,int**,bool), total;
  double *score=NULL, exp, exp_2, X_apm_score(int**,int), **pvector=NULL;
  int num_aff, **affected_allele=NULL, parents_informative(int), score_count;
  int *uninformative_marker=NULL, *num_real_vecs=NULL, num_inbred;
  int *best_pvector=NULL, has_data(int);
  void init_disease_probs(int);
  void peel(int,int);
  double brute_force_analyze(int,int,int);
  int nf,complexity,num_uninformative_bits,real_num_bits,real_num_vecs,new_vec;
  int **alleles_to_draw,**haplotype,new_real_num_bits,**inferred;
  TIME_TYPE this_time, last_time;
  int count, *flip_mask=NULL, uninformative_mask, vecpos, parent, this_parent,
      this_indiv, really_uninformative_bits;
  int dad0, dad1, mom0, mom1, dkid, mkid, found_kid;
  int old_mom, inb_fam, dis_geno;
  double saved_d_prob[4], this_prob;

  /* For all individuals, look up the person's mom and dad
     and record it in the pedigree structure */
  run {
    sf(ps,"\nanalyzing pedigree %s...\n",current_ped); pr();

    if (num_allele_data[0]%2==1) 
      allele_offset = 1;
    else 
      allele_offset = 2;

    for (i=0; i<num_in_ped; i++) {
      set_dad_index(i,num_in_ped);
      set_mom_index(i,num_in_ped);
      famtree[i].analyzed_parent=FALSE; /* for counting inh. vec complexity */
      famtree[i].dad_bit_uninf=FALSE;
      famtree[i].mom_bit_uninf=FALSE;
      famtree[i].kids_found=FALSE; /* used later in bit chopping section */
    }

    for (i=0; i<num_in_ped; i++) famtree[i].discard=FALSE;

    /* get rid of unlinked individuals - set discard to TRUE */
    check_for_unlinked(num_in_ped);

    /* at this point we can eliminate from consideration:
        a) untyped individuals with no offspring in the pedigree
        b) those individuals that are unaffected, have no kids, and have 
           informative parents (they add next to nothing to an APM study) */

    for (i=0; i<num_in_ped; i++) {
      if (famtree[i].discard) continue;
      
      if (famtree[i].nkids == 0 && !has_data(i)) {
#ifdef DEBUGGING_OUTPUT
	  sf(ps,"DISCARDING individual %s (pedigree leaf with no genotype data)\n",
	     famtree[i].indiv_ID); pr();
#endif
	  famtree[i].discard = TRUE;
      }

      if (discard_unaffected) {
	/* discard_unaffected is a flag ("discard") set at command level */
	if ( famtree[i].nkids == 0 && 
	    allele_data[i][0] != 2 &&
	    parents_informative(i) ) {
#ifdef DEBUGGING_OUTPUT
	  sf(ps,"DISCARDING individual %s (unaffected leaf - informative parents)\n",
	     famtree[i].indiv_ID); pr();
#endif
	  famtree[i].discard = TRUE;
	}
      }
    }

    originals = non_originals = 0;
    cur_place=0;

    /* set placeholder alleles for original pedigree members */
    for (i=0; i<num_in_ped; i++) {
      if (famtree[i].dad_index == MISSING &&
	  famtree[i].mom_index == MISSING) {
	if (!famtree[i].discard) {
	  originals++;
	  /* X inheritance - males get 1 placeholder allele, 
	     females get 2 */
	  if (famtree[i].sex == MALE) {
	    famtree[i].place_allele[0]=cur_place;
	    famtree[i].place_allele[1]=cur_place; cur_place++;
	  } else {
	    famtree[i].place_allele[0]=cur_place; cur_place++;
	    famtree[i].place_allele[1]=cur_place; cur_place++;
	  }
	}
      }
      else if (famtree[i].dad_index == MISSING ||
	       famtree[i].mom_index == MISSING) {
        sf(ps,"person %s has ONE parent",famtree[i].indiv_ID); error(ps);
      }
      else {
	if (!famtree[i].discard) non_originals++;
	famtree[i].place_allele[0]=-1;
	famtree[i].place_allele[1]=-1;
      }
    }
    num_original_nodes = cur_place;

    /* Now we need to figure out how many loci there are -
       if odd number of alleles, the first is affectation status 
       and there is no liability class column - if even number 
       of alleles, the first is affectation status and the 
       second is liability class */

    num_loci = (num_allele_data[0]-allele_offset)/2; 
    if (num_loci != num_markers) {
      sf(ps,
"num_loci in pedigree file (%d) != num_markers in locus file (%d) - ped %s\n",
	 num_loci,num_markers,current_ped); error(ps);
    }
    
    /* fill in affectation_status and liability_class in PED_MEMBERs */
    for (i=0; i<num_in_ped; i++) {
      famtree[i].affectation_status = allele_data[i][0];
      if (allele_offset == 2) famtree[i].liability_class = allele_data[i][1];
      else famtree[i].liability_class = 1;
    }

    /* now let's do a preliminary sort of non-originals so that
       we can accurately determine how much analysis needs to be done */

    /* new_sort_pedigree(); */
    sort_pedigree(num_in_ped);
    resort_pedigree(non_originals);

    /* now read through this sorted list of non_originals until we
       hit the limit of our analytic capabilities */

    really_uninformative_bits = 0;
    num_bits = real_num_bits = 0;
    real_non_originals = non_originals;

    for (i=0; i<non_originals; i++) {

        dad = famtree[sorted_ped[i]].dad_index;
	mom = famtree[sorted_ped[i]].mom_index;
        num_bits += 2;
	new_real_num_bits = real_num_bits+2;


	/* all paternal bits are uninformative */
	famtree[sorted_ped[i]].dad_bit_uninf = TRUE;
	new_real_num_bits--;
	famtree[dad].kids_found=TRUE;
	/* debugging message */
#ifdef DEBUGGING_OUTPUT
	sf(ps,"dropping paternal bit of indiv %s\n",
	   famtree[sorted_ped[i]].indiv_ID); pr();
#endif
	really_uninformative_bits++;
	

	if (!famtree[mom].kids_found && famtree[mom].dad_index==MISSING &&
	    famtree[mom].mom_index==MISSING) {
	    /* first kid of this mother, hold bit fixed */
	    famtree[sorted_ped[i]].mom_bit_uninf = TRUE;
	    new_real_num_bits--;
	    famtree[mom].kids_found=TRUE;
	    /* debugging message */
#ifdef DEBUGGING_OUTPUT
	    sf(ps,"dropping maternal bit of indiv %s\n",
	       famtree[sorted_ped[i]].indiv_ID); pr();
#endif
	    if (famtree[mom].nkids == 1) really_uninformative_bits++;
	}

	if (new_real_num_bits > max_bits_to_analyze || num_bits > 31) {
	  /* we've hit the limit...can't accept this guy */
	  real_non_originals = i;
	  num_bits -= 2;
	  break;
	}
	real_num_bits = new_real_num_bits;

	if (new_real_num_bits == max_bits_to_analyze) {
	  real_non_originals = i+1;
	  break;
	}
    }

    /* print out a most abject apology regarding our inability
       to analyze beyond a certain point within reasonable
       time and memory constraints */

    skip_ped=FALSE;

    if (real_non_originals < non_originals) {

        if (skip_large) {
 	    print("WARNING: Pedigree is too large to be computed!\n");
	    print(
"To analyze you can either turn off the 'skip large' option which will\n");
	    print(
"allow the program to discard less informative individuals or you may\n");
	    print(
"raise the 'max bits' option which will allow larger pedigrees to be\n");
	    print(
"analyzed while raising the time and memory requirements of the program.\n");
	    skip_ped=TRUE; num_pedigrees--;

	} else {
	    sf(ps,
     "WARNING: due to computation time and memory constraints, individual%s\n",
	       (non_originals-real_non_originals > 1)?"s":"");
	    pr();
	    for (i=real_non_originals; i<non_originals; i++) {
	      sf(ps,"%s ",famtree[sorted_ped[i]].indiv_ID); pr();
	      famtree[sorted_ped[i]].discard = TRUE;
	    }
	    sf(ps,"%s been dropped from the analysis.\n",
	       (non_originals-real_non_originals > 1)?"have":"has");
	    pr();
	}
      }
  
    /* Now we should go through and discard any originals who
       have had all their kids discarded */

/*****
    for (i=0; i<num_in_ped; i++) {
      if (famtree[i].dad_index == MISSING &&
	  famtree[i].mom_index == MISSING && !famtree[i].discard) {
	  found_kid=FALSE;
	  for (j=0; j<num_in_ped; j++) {
	    if ((famtree[j].dad_index == i || famtree[j].mom_index == i) &&
		!famtree[j].discard) {
	        found_kid=TRUE; break;
	    }
	  }
	  if (!found_kid) { famtree[i].discard=TRUE; originals--; }
      }
    }
*****/

    if (non_originals <= 1) {
      sf(ps,"< 2 non-original members in pedigree %s...SKIPPING\n",current_ped);
      pr();
      skip_ped = TRUE; num_pedigrees--;
    } 

    if (!skip_ped) {
  
      /* Check for impossible loops */
      for (i=0; i<num_in_ped; i++) {
	/* We've already know that no one can be their own
	   direct parent so we'll start up a level */
	if (famtree[i].dad_index != MISSING) { /* If one parent is missing,both are*/
	  check_for_loop(i,famtree[i].sex,famtree[i].dad_index,1,num_in_ped);
	  check_for_loop(i,famtree[i].sex,famtree[i].mom_index,1,num_in_ped);
	}
      }

      /* Sort pedigree top down into a list */
      /* sort_pedigree(num_in_ped); already completed above */

      /********** bit count completed above 
	num_bits=0;
	for (i=0; i<non_originals; i++) {
        if (!famtree[sorted_ped[i]].dad_bit_uninf) num_bits++;
        if (!famtree[sorted_ped[i]].mom_bit_uninf) num_bits++;
	}
	if (num_bits > 16) error("too many individuals left...hackprep failed");
      **********/

      /* so now we have 2^2*non_originals possible pvectors but only
	 2^real_num_bits of those are interesting...to get them, we will
	 hold the uninformative bits at 0 while allowing all others
	 to be 0 or 1 */

      /* Fill the array of nuclear families */
      fill_nuc_families(num_in_ped);
    
      /* Count the number of inbred matings in the pedigree and
	 do the right thing if there are any */
      num_inbred = inbred_matings();
      if (num_inbred >= 1) {
	sf(ps,"family %s is inbred\n",current_ped); pr();
	/*** order_inbred_family(); ***/

	if (num_inbred == 1) {
	  /* break the first inbred marriage */
	  for (i=0; i<num_nuc_fam; i++) {
	    if (nuc_fam[i].inbred) {
	      inb_fam = i; 
	      break;
	    }
	  }

	  /* make fake individual (N=num_in_ped) with no parents
	     to be the new wife in this family */
	  old_mom = nuc_fam[inb_fam].mom;
	  nuc_fam[inb_fam].mom = num_in_ped;
	  famtree[num_in_ped].dad_index=MISSING;
	  famtree[num_in_ped].mom_index=MISSING;
	  famtree[num_in_ped].nkids = famtree[old_mom].nkids;

	  famtree[old_mom].nkids=0; /* temporarily */
	  num_in_ped++;
	} else {
	  /* more than one inbreeding loop - do by brute force
	     as if there were no inbreeding loops */
	  num_inbred=0;
	}
      }

      if (num_nuc_fam > 1) {
	  if (mark_pivots(num_in_ped) == -1) { 
	      skip_ped=TRUE; num_pedigrees--;
	  } else {
	    if (num_inbred >= 1) {
	      /* fix variable that were corrupted for mark_pivots */
	      num_in_ped--;
	      famtree[old_mom].nkids=famtree[num_in_ped].nkids;
	    }
	    if (num_nuc_fams_to_peel == 0) {
	      /* if we still can't peel after breaking the loop
		 we want to go straight to brute_force and forget
		 the loop breaking stuff */
	      num_inbred=0; /* skip the inbred broken peeling stuff */
	    }
	  }
      } else {
	  /* Mark the interesting individuals so that they are
	     fully analyzed by the exhaustive method */
	  famtree[nuc_fam[0].dad].not_peeled=TRUE;
	  famtree[nuc_fam[0].mom].not_peeled=TRUE;
	  for (k=0; k<nuc_fam[0].num_kids; k++) 
	    famtree[nuc_fam[0].kid[k]].not_peeled=TRUE;

	  order_assigned[0]=0;
	  num_nuc_fams_to_peel=0;
      }
    }

    if (!skip_ped) {
    
      /* now connect to graphing code for determining inh. vector probs */
      num_vecs=1;
      for (i=0; i<num_bits; i++) num_vecs *= 2;
      real_num_vecs=1;
      for (i=0; i<real_num_bits; i++) real_num_vecs *= 2;

      matrix (pvector, num_in_map_order+1, real_num_vecs, double);
      array (score, real_num_vecs, double);
      matrix (affected_allele, num_in_ped, 2, int);
      array (uninformative_marker, num_in_map_order+1, int);
      array (num_real_vecs, num_in_map_order+1, int);
      array (best_pvector, num_in_map_order+1, int);
    
      for (i=0; i<num_in_map_order; i++) {
	uninformative_marker[i]=TRUE; num_real_vecs[i]=0;
      }
      exp = exp_2 = 0.0; 
      
      new_vec=0;
    
      for (vec=0; vec<num_vecs; vec++) {

	if (vec == 0) fill_placeholder_alleles(vec,real_non_originals,0);

	if (!acceptable_vector(vec,num_bits)) continue;
	/* now every member of famtree has two placeholder alleles
	   filled in and we can advance to the prob assignment
	   for each of the markers */

	if (vec > 0) fill_placeholder_alleles(vec,real_non_originals,0);

	for (i=0; i<num_in_map_order; i++) {
	  prob = graph_assign_probs(vec, originals, real_non_originals, 
				    map_order[i], NULL, FALSE);

	  pvector[i][new_vec] = prob;
	  if (pvector[i][new_vec] != pvector[i][0]) 
	    uninformative_marker[i]=FALSE;
	  if (pvector[i][new_vec] > 0.0) num_real_vecs[i]++;
	}

	/* now obtain NPL score for this assignment of placeholder
	   alleles for this pedigree */

	for (i=0,num_aff=0; i<num_in_ped; i++) {
	  if (famtree[i].discard || famtree[i].place_allele[0]==-1) continue;

	  if (allele_data[i][0] == 2) {
	      /* this individual is affected */
	      affected_allele[num_aff][0] = famtree[i].place_allele[0];
	      affected_allele[num_aff][1] = famtree[i].place_allele[1];
	      num_aff++;
	  }
	}
	score[new_vec] = X_apm_score(affected_allele, num_aff);
	exp += score[new_vec];
	exp_2 += (score[new_vec]*score[new_vec]);

	if (num_inbred >= 1) {
	  /* break the loop! */
	  pvector[num_in_map_order][new_vec] = 0.0;

	  for (dis_geno=0; dis_geno<4; dis_geno++) {
	      init_disease_probs(num_in_ped);
	      this_prob = famtree[old_mom].disease_prob[dis_geno];
	      for (j=0; j<4; j++) {
		famtree[old_mom].disease_prob[j]=0.0;
		famtree[num_in_ped].disease_prob[j]=0.0;
	      }
	      famtree[old_mom].disease_prob[dis_geno]=1.0;
	      famtree[num_in_ped].disease_prob[dis_geno]=1.0;
	      if (num_nuc_fams_to_peel > 0) peel(vec, num_bits);
	      famtree[num_in_ped].place_allele[0]=
		famtree[old_mom].place_allele[0];
	      famtree[num_in_ped].place_allele[1]=
		famtree[old_mom].place_allele[1];
	      this_prob *= brute_force_analyze(vec, num_bits, num_in_ped+1);
	      pvector[num_in_map_order][new_vec] += this_prob;
	  }

	} else {
	  init_disease_probs(num_in_ped);
	  if (num_nuc_fams_to_peel > 0) peel(vec, num_bits);
	  pvector[num_in_map_order][new_vec] = 
	    brute_force_analyze(vec, num_bits, num_in_ped);
	}
	new_vec++;
      }

      if (new_vec != real_num_vecs) error("num_vecs don't match in hackprep");
      
      exp /= real_num_vecs;
      exp_2 /= real_num_vecs;
    
      /* normalize probabilities to sum to 1.0 for each marker */
      skip_ped = FALSE;
      for (i=0; i<num_in_map_order+1; i++) {
	total=0.0;
	for (vec=0; vec<real_num_vecs; vec++) total += pvector[i][vec];
	if (total == 0.0) {
	  if (i==num_in_map_order) {
	    print("disease pvectors sum to 0.0 - SKIPPING THIS PEDIGREE\n");
	  } else {
	    sf(ps,"ERROR: bad inheritance in pedigree %s, marker %s\n",
	       current_ped, locus[map_order[i]].name); pr();
	    print("SKIPPING THIS PEDIGREE\n");
	  }
	  skip_ped = TRUE; num_pedigrees--; break;
	}

	for (vec=0; vec<real_num_vecs; vec++) {
	  pvector[i][vec] /= total;
	}
      }
    } /* if (!skip_ped) */
  
    if (!skip_ped) {
      /* call scan stuff now that pvector is filled in */
      /* count original parents of analyzed members */
      complexity=0;
      total_meioses += num_bits - really_uninformative_bits;

      /***** now that we correctly cut out first kids bits for each
	     original parent, we should actually be passing no
	     redundant vectors (except in the double missing parent
	     case) so we'll leave complexity=0 *****/
      /**********
      for (i=0; i<num_in_ped; i++) {
	if (famtree[i].dad_index==MISSING && famtree[i].mom_index==MISSING &&
	    famtree[i].analyzed_parent) complexity++;
      }
      if (num_bits < non_originals*2) complexity -= (non_originals*2-num_bits);
      if (complexity < 0) complexity=0;
      **********/

      /* make bitmasks */
      uninformative_mask=0; count=1;
      array(flip_mask, num_bits, int);

      for (i=0; i<num_bits; i++) {
	if (uninformative_bit[i]) {
	    uninformative_mask+=count;
	    flip_mask[i]=0;
	
	    if (i%2 == 1) { vecpos = (num_bits-i-1)/2; parent=MALE; }
	    else          { vecpos = (num_bits-i-2)/2; parent=FEMALE; }
	    for (j=0; j<real_non_originals; j++) {
	      if (famtree[sorted_ped[j]].inh_vec_pos == vecpos) {
		/* mark this person and sibs pat or mat bit */
		this_indiv = sorted_ped[j];
		if (parent == MALE) this_parent=famtree[this_indiv].dad_index;
		else                this_parent=famtree[this_indiv].mom_index;
		break;
	      }
	    }
	    for (j=0; j<real_non_originals; j++) {
	        if (parent == MALE) {
		  if (famtree[sorted_ped[j]].dad_index == this_parent) {
		    vecpos=famtree[sorted_ped[j]].inh_vec_pos;
		    flip_mask[i]+=pow2[num_bits-(2*vecpos)-1];
		  }
		} else {
		  if (famtree[sorted_ped[j]].mom_index == this_parent) {
		    vecpos=famtree[sorted_ped[j]].inh_vec_pos;
		    flip_mask[i]+=pow2[num_bits-(2*vecpos)-2];
		  }
		}
	    }
	}
	count *= 2;
      }

      scan_pedigree(pvector, real_num_bits, score, exp, exp_2,
		    num_pedigrees-1,complexity,best_pvector,
		    num_bits,uninformative_mask,flip_mask);

      if (haplotype_output) {
	/* need to replace eliminated bits in best_pvectors so that
	   the haplotyping display can do everything easily */
	/*****
	for (i=0; i<num_bits; i++) {
	  if (uninformative_bit[i]) {
	    add_bit(num_bits-num_uninformative_bits,i,
		    best_pvector,num_in_map_order);
	    num_uninformative_bits--;
	  }
	}
	*****/

	npl_max = npl_pos = apm_stat[num_pedigrees-1][2];
	for (i=0; i<num_w_pos; i++) {
	  if (apm_stat[num_pedigrees-1][i] > npl_max) 
	    npl_max = apm_stat[num_pedigrees-1][i];
	}
	matrix(alleles_to_draw,num_in_ped,num_in_map_order*2,int);
	matrix(inferred,num_in_ped,num_in_map_order*2,int);
	matrix(haplotype,originals*2,num_markers,int);

	sf(ps,"*****  %s  %.3lf\n",current_ped,npl_max);
	fpr(haplofp);
	orig_haplotypes(num_in_ped,best_pvector,alleles_to_draw,haplotype,inferred);

	if (postscript_output)
	  draw_pedigree(num_in_ped,num_in_map_order,map_order,current_ped,
			alleles_to_draw,best_pvector,sorted_ped,
			real_non_originals,haplotype,originals,inferred);
	unmatrix(haplotype,originals*2,int);
	unmatrix(inferred,num_in_ped,int);
	unmatrix(alleles_to_draw,num_in_ped,int);
      }
    }

  } on_exit {
    /* free memory */
    unarray(flip_mask, int);
    unarray(best_pvector, int);
    unarray(num_real_vecs, int);
    unarray(uninformative_marker, int);
    unmatrix (affected_allele, num_in_ped, int);
    unarray (score, double);
    unmatrix (pvector, num_in_map_order+1, double);
    relay_messages;
  }
}

int parents_informative(int ind)
{
    int dad,mom,dad_sum,mom_sum,i;

    dad = famtree[ind].dad_index;
    mom = famtree[ind].mom_index;

    dad_sum=mom_sum=0;
    for (i=allele_offset; i<num_allele_data[dad]; i++) {
        if (allele_data[dad][i] > 0) dad_sum++;
	if (allele_data[mom][i] > 0) mom_sum++;
    }
    if (dad_sum == num_allele_data[dad]-allele_offset &&
	mom_sum == num_allele_data[mom]-allele_offset) return(TRUE);
    else return(FALSE);
}

int has_data(int ind)
{
    int i, sum;

    sum=0;
    for (i=allele_offset; i<num_allele_data[ind]; i++) {
        if (allele_data[ind][i] > 0) sum++;
    }
    if (sum > 0) return(TRUE);
    else return(FALSE);
}

void set_dad_index (int indiv,int num_in_ped)
{
  /* Find the index of dad in the the pedigree list and
     do basic pedigree checks */

  bool found;
  int i;

  /* If the LINKAGE pedigree has a 0 for dad or mom
     that means the parent is missing */
  if (!strcmp(famtree[indiv].dad,"0")) {
    famtree[indiv].dad_index = MISSING;
  } else {
    /* Go through the pedigree to find dad */
    found=FALSE;
    for (i=0; i<num_in_ped; i++) {
      if (!strcasecmp(famtree[indiv].dad, famtree[i].indiv_ID)) {
	/* Check that the father isn't impossible */
	if (i == indiv) {
	  sf(ps, "individual %s is own father",
	     famtree[indiv].indiv_ID);
	  error(ps);
	}
	if (famtree[i].sex != MALE) {
	  sf(ps, "father of indiv %s is female", 
	     famtree[indiv].indiv_ID); error(ps);
	}
	/* No errors, record the info */
	found=TRUE;
	famtree[indiv].dad_index=i;
	famtree[i].nkids++; /* Increment dad's # of kids */
	break;
      }
    }
    if (!found) {
      sf(ps,"can't find father of indiv %s (%s) in pedigree",
	 famtree[indiv].indiv_ID,famtree[indiv].dad);
      error(ps);
    }
  }
}

void set_mom_index (int indiv,int num_in_ped)
{
  /* Find the index of mom in the the pedigree list and
     do some basic pedigree checks */

  bool found;
  int i;

  /* If the LINKAGE pedigree has a 0 for mom or dad
     that means the parent is missing */
  if (!strcmp(famtree[indiv].mom,"0")) {
    famtree[indiv].mom_index = MISSING;
  } else {
    /* Go through the pedigree to find mom */
    found=FALSE;
    for (i=0; i<num_in_ped; i++) {
      if (!strcasecmp(famtree[indiv].mom, famtree[i].indiv_ID)) {
	/* Check that the mother isn't impossible */
	if (i == indiv) {
	  sf(ps, "individual %s is own mother",
	     famtree[indiv].indiv_ID);
	  error(ps);
	}
	if (famtree[i].sex != FEMALE) {
	  sf(ps, "mother of indiv %s is male", 
	     famtree[indiv].indiv_ID); error(ps);
	}
	/* No errors, record the info */
	found=TRUE;
	famtree[indiv].mom_index=i;
	famtree[i].nkids++; /* Increment mom's # of kids */
	break;
      }
    }
    if (!found) {
      sf(ps,"can't find mother of indiv %s (%s) in pedigree",
	 famtree[indiv].indiv_ID,famtree[indiv].mom);
      error(ps);
    }
  }
}


void check_for_unlinked (int num_in_ped)
{
  /* Everyone in the pedigree should either have
     parents or kids, otherwise they have no links
     to the rest of the pedigree and can be excluded
     from analysis.  Finds any such individuals, prints
     a warning and removes them from the famtree list */

  int i,j,num_unlinked=0,*unlinked,new_num_in_ped;

  array(unlinked,MAX_INDIVIDUALS,int);
  new_num_in_ped = num_in_ped;

  for (i=0; i<new_num_in_ped; i++)
    if (famtree[i].nkids==0 &&
	famtree[i].dad_index==MISSING &&
	famtree[i].mom_index==MISSING) {
      unlinked[num_unlinked]=i;
      num_unlinked++;
    }

  if (num_unlinked > 0) {

#ifdef DEBUGGING_OUTPUT
    if (num_unlinked==1) {
      sf(ps,
     "pedigree %s contains an unlinked individual (%s) that will not be analyzed\n",
	 current_ped, famtree[unlinked[0]].indiv_ID); pr();

    } else {
      sf(ps,
     "pedigree %s contains unlinked individuals that will not be analyzed\n",
	 current_ped); pr();
    }
#endif

    for (i=0; i<num_unlinked; i++) {
      /* Remove unlinked indivs from the famtree list */
      famtree[unlinked[i]].discard=TRUE;
    }
  }
  unarray(unlinked,int);
}

void check_for_loop (int start_indiv, int sex, int new_index, 
		     int level, int max_levels)
{

  /* Make sure that start_indiv does not create a loop in
     the pedigree.  Recursively check all the ancestors */

  int dad, mom; /* dad and mom of the individual where we
		   are up in the pedigree */
  
  if (level >= max_levels) {
    sf(ps,"loop detected in pedigree %s\n",current_ped); pr();
    return;
  }

  dad = famtree[new_index].dad_index;
  mom = famtree[new_index].mom_index;

  if (dad != MISSING) {
    if (sex == MALE)
      if (!strcasecmp(famtree[dad].indiv_ID,
		      famtree[start_indiv].indiv_ID)) {
	sf(ps,"individual %s is his own ancestor",
	   famtree[start_indiv].indiv_ID); error(ps);
      }
    check_for_loop(start_indiv,sex,dad,level+1,max_levels);
  }
  if (mom != MISSING) {
    if (sex == FEMALE)
      if (!strcasecmp(famtree[mom].indiv_ID,
		      famtree[start_indiv].indiv_ID)) {
	sf(ps,"individual %s is her own ancestor",
	   famtree[start_indiv].indiv_ID); error(ps);
      }
    check_for_loop(start_indiv,sex,mom,level+1,max_levels);
  }
}  


/*******************************************************
 Sort the pedigree into a list with all ancestors first
 *******************************************************/
void sort_pedigree (int num_in_ped)
{

  /* Take the famtree list of PED_MEMBERs and
     make a list of its indices such that each
     member is present after his or her parents */

  int i;

  if (num_in_ped > MAX_INDIVIDUALS) {
    sf(ps,"too many individuals in pedigree %s - max %d",
       current_ped, MAX_INDIVIDUALS); error(ps);
  }

  for (i=0; i<num_in_ped; i++) {
    if (famtree[i].discard) placed[i]=TRUE;
    else placed[i]=FALSE;
  }
  num_placed=0;

  for (i=0; i<num_in_ped; i++) {
    /* add each member of the pedigree to the sorted list */
    if (!placed[i]) place_indiv(i);    
  }

}

void place_indiv (int ped_index)
{
  /* Place each individual after recursively
     placing any parents */
  
  /* Only place the individual if they are a non-original */
  if (famtree[ped_index].dad_index == MISSING &&
      famtree[ped_index].mom_index == MISSING) {
    /* Individual is an original */
    placed[ped_index]=TRUE;
    return;
  }
      
  /* Check that dad has been added to the list */
  if (!placed[famtree[ped_index].dad_index])
    place_indiv(famtree[ped_index].dad_index);

  /* Check that mom has been added to the list */
  if (!placed[famtree[ped_index].mom_index])
    place_indiv(famtree[ped_index].mom_index);

  /* All ancestors in the list, add the current
     individual */
  sorted_ped[num_placed]=ped_index;
  placed[ped_index]=TRUE;
  num_placed++;

}



fill_placeholder_alleles(int vec, int non_originals, int for_hap)
{
    int i,mom,dad,num_bits;

    num_bits = non_originals*2;
    
    for (i=0; i<non_originals; i++) {
        famtree[sorted_ped[i]].place_allele[0] = -1;
        famtree[sorted_ped[i]].place_allele[1] = -1;
    }

    if (vec==0 && !for_hap) print("using non-originals: ");
    for (i=0; i<non_originals; i++) {
        /* sorted_ped[] = index of non_originals in correct order */
        dad = famtree[sorted_ped[i]].dad_index;
	mom = famtree[sorted_ped[i]].mom_index;

        famtree[sorted_ped[i]].place_allele[1] = 
	  famtree[mom].place_allele[(vec>>(num_bits-(2*i)-2))%2];

	/* X inheritance */
	if (famtree[sorted_ped[i]].sex == FEMALE)
	  famtree[sorted_ped[i]].place_allele[0] = 
	    famtree[dad].place_allele[(vec>>(num_bits-(2*i)-1))%2];
	else 
	  famtree[sorted_ped[i]].place_allele[0] = 
	    famtree[sorted_ped[i]].place_allele[1];


	if (vec==0 && !for_hap) { 
	  sf(ps," %s",famtree[sorted_ped[i]].indiv_ID); pr(); 
	  famtree[sorted_ped[i]].inh_vec_pos = i;
	  famtree[dad].analyzed_parent=TRUE;
	  famtree[mom].analyzed_parent=TRUE;
	  uninformative_bit[num_bits-(2*i)-1]=FALSE;
	  uninformative_bit[num_bits-(2*i)-2]=FALSE;	  
	  if (famtree[sorted_ped[i]].dad_bit_uninf)
	    uninformative_bit[num_bits-(2*i)-1] = TRUE;
	  if (famtree[sorted_ped[i]].mom_bit_uninf)
	    uninformative_bit[num_bits-(2*i)-2] = TRUE;
	}
    }
    if (vec==0 && !for_hap) nl();
}


double graph_assign_probs(int vec,int originals,int non_originals,int marker,
			  int **haplotype, bool record_haplotype)
{
    /* allele_data[][]  holds the allele data for each member of
       famtree as follows:

       allele_data[indiv][0] = affectation value

       allele_data[indiv][allele_offset+(2*i)] and
       allele_data[indiv][allele_offset+(2*i)+1]  = alleles for ith marker
    
       famtree[indiv].place_allele [0] and [1] are the two place holder
       alleles for the individual...for originals, these represent the 
       nodes of the graph, for non-originals, these represent the obligate
       assignments given the assignments of the originals and the 
       particular inheritance vector (vec) we are working on
    */
    int i, j, num_edges;
    void create_nodes(int), AddEdge(int,int,int,int),
         process_graph(ASSIGN_STRUCT*), free_assign(ASSIGN_STRUCT*);
    ASSIGN_STRUCT *assign_list,*alist;
    double prob, total_prob;

    create_nodes(num_original_nodes);
    
    num_edges=0;
    for (i=0,j=0; i<originals+non_originals; i++,j++) {
      
        if (famtree[j].place_allele[0]==-1) { i--; continue; }
	if (famtree[j].discard) { i--; continue; }

        if (allele_data[j][allele_offset+(2*marker)] != 0 &&
	    allele_data[j][allele_offset+(2*marker)+1] != 0) {

	  /* X inheritance effects --
	     FEMALE - normal, one bit from mom and one from dad (FIXED)
	     MALE - allele data = two copies of identical mom allele */

	  if (famtree[j].sex == FEMALE) {
	    AddEdge( famtree[j].place_allele[0],
		     famtree[j].place_allele[1],
		     allele_data[j][allele_offset+(2*marker)],
		     allele_data[j][allele_offset+(2*marker)+1] );
	    num_edges++;
	  } else {
	    /* Male X Chromosome does not add an edge but simply
	       assigns one of his mother's nodes to his single allele */
	    DefineNode(famtree[j].place_allele[1], 
		       allele_data[j][allele_offset+(2*marker)]);
	  }
	}
    }

    if (num_edges > 0) { 
        single (assign_list, ASSIGN_STRUCT);
	assign_list->next=NULL; assign_list->num_alleles=0;
        process_graph(assign_list);
	alist=assign_list; total_prob=0.0;

	if (record_haplotype == TRUE) {
	  for (i=0; i<(originals*2); i++)
	    haplotype[i][marker] = alist->force_list[i];
	  /***** debugging output
	  sf(ps,"marker %d: ",marker+1); pr();
	  for (i=0; i<alist->num_alleles; i++) {
	    sf(ps,"%d ",alist->allele_list[i]); pr();
	  }
	  nl();
	  *****/
	}
	
	if (alist->num_alleles == 0) {
	  /* no consistent assignments, prob=0.0 */
	} else {
	  while (alist!=NULL) {
	    if (alist->num_alleles == 0) { prob=0.0; }
	    else {
	      prob = 1.0;
	      for (i=0; i<alist->num_alleles; i++) {
		if (locus[marker].allele_freq[alist->allele_list[i]] == 0.0) {
		  sf(ps,"non-existant allele %d at marker %d in graph_probs",
		     alist->allele_list[i],marker+1); error(ps);
		}
		prob *= locus[marker].allele_freq[alist->allele_list[i]];
		/* to normalize as Linkage does, prob would also have to
		   be divided by locus[marker].allele_sum here each time */
	      }
	    }
	    total_prob += prob;
	    alist = alist->next;
	  }
	}
	free_assign(assign_list);
	return(total_prob);
    } else {
      /* all individuals are missing, set all vec probs = 1 */
      return(1.0);
    }
  }


void free_assign(ASSIGN_STRUCT *alist)
{
    if (alist->next != NULL) free_assign(alist->next);
    unsingle(alist, ASSIGN_STRUCT);
}


void fill_nuc_families(int num_in_ped)
{
  
  int i,j,kid[MAX_KIDS],nf;
  int num_kids, dad, mom, found;
  bool checked[MAX_INDIVIDUALS];


  for (i=0; i<num_in_ped; i++)
    checked[i]=FALSE;
  
  num_nuc_fam=0;
  
  for (i=0; i<num_in_ped; i++) {
    if (famtree[i].discard) continue;
    if (checked[i]) continue;

    if (famtree[i].nkids > 0) {

      /* Make a list of all the kids of the individual */
      num_kids=0;
      for (j=0; j<num_in_ped; j++){
	if (num_kids == famtree[i].nkids) break;
	if (famtree[j].dad_index == i ||
	    famtree[j].mom_index == i) {
	  if (famtree[j].discard) continue;
	  kid[num_kids]=j;
	  num_kids++;
	}
      }
      
      if (num_kids > 0) {
	nuc_fam[num_nuc_fam].pivot = -1;
	nuc_fam[num_nuc_fam].inbred=FALSE;
	nuc_fam[num_nuc_fam].in_loop=FALSE;
	nuc_fam[num_nuc_fam].loop_indiv=FALSE;
	nuc_fam[num_nuc_fam].num_common_anc=0;
	nuc_fam[num_nuc_fam].dad = famtree[kid[0]].dad_index;
	nuc_fam[num_nuc_fam].mom = famtree[kid[0]].mom_index;
	nuc_fam[num_nuc_fam].num_kids=0;
	for (j=0; j<num_kids; j++) {
	  if (famtree[kid[j]].mom_index == nuc_fam[num_nuc_fam].mom &&
	      famtree[kid[j]].dad_index == nuc_fam[num_nuc_fam].dad) {
	    nuc_fam[num_nuc_fam].kid[nuc_fam[num_nuc_fam].num_kids]=kid[j];
	    nuc_fam[num_nuc_fam].num_kids++;
	  }
	}
	num_nuc_fam++;
      }

      checked[nuc_fam[num_nuc_fam-1].dad]=TRUE;
      checked[nuc_fam[num_nuc_fam-1].mom]=TRUE;
    }
  }
  
  /* Final check to ensure that all kids have their nuclear
     family represented - just to cover the unusual case where
     both parents are also parents of other nuclear pedigrees */

  for (i=0; i<num_in_ped; i++) {
    if (famtree[i].discard) continue;
    dad = famtree[i].dad_index;
    mom = famtree[i].mom_index;
    if (dad == MISSING || mom == MISSING) continue;

    found=FALSE;
    for (j=0; j<num_nuc_fam; j++) {
      if (nuc_fam[j].dad == dad && nuc_fam[j].mom == mom) {
	found=TRUE; break;
      }
    }

    if (!found) {
      /* Create a new nuc_fam */
      num_kids=0;
      for (j=0; j<num_in_ped; j++){
	if (famtree[j].dad_index == dad && famtree[j].mom_index == mom) {
	  if (famtree[j].discard) continue;
	  kid[num_kids]=j;
	  num_kids++;
	}
      }
      if (num_kids > 0) {
	print("Special double half-sib case detected\n");
	nuc_fam[num_nuc_fam].pivot = -1;
	nuc_fam[num_nuc_fam].inbred=FALSE;
	nuc_fam[num_nuc_fam].in_loop=FALSE;
	nuc_fam[num_nuc_fam].loop_indiv=FALSE;
	nuc_fam[num_nuc_fam].num_common_anc=0;
	nuc_fam[num_nuc_fam].dad = dad;
	nuc_fam[num_nuc_fam].mom = mom;
	nuc_fam[num_nuc_fam].num_kids=0;
	for (j=0; j<num_kids; j++) {
	  if (famtree[kid[j]].mom_index == nuc_fam[num_nuc_fam].mom &&
	      famtree[kid[j]].dad_index == nuc_fam[num_nuc_fam].dad) {
	    nuc_fam[num_nuc_fam].kid[nuc_fam[num_nuc_fam].num_kids]=kid[j];
	    nuc_fam[num_nuc_fam].num_kids++;
	  }
	}
	num_nuc_fam++;
      }
    }
  }


}

int mark_pivots (int num_in_ped)
{
  /* Make a list of all the pivots in the extended family.
     Then each family who has one member in the pivot
     list is peripheral and we assign them unless we have
     already assigned num_nuc_fam-1 (num_nuc_fam is the
     number of nuclear families in the extended pedigree). */
  
  int i,j,k;
  int num_pivots=0,pivot[MAX_INDIVIDUALS];
  int num_assigned,fam_pivot,fam_pivots,num_kids,fam_pivot_list[MAX_INDIVIDUALS];
  int shared[MAX_INDIVIDUALS];
  int assigned[MAX_INDIVIDUALS];
  int possible_pivot[MAX_INDIVIDUALS], poss, assigned_this_round;
  bool done;
  

  /* Make the list of pivots -- pivots are individuals
     who have not been discarded, who are non-originals,
     and who have at least one child */
  for (i=0; i<num_in_ped; i++) {
    possible_pivot[i]=0;

    if (famtree[i].discard) continue;
    if (famtree[i].mom_index != MISSING &&
	famtree[i].dad_index != MISSING) {

      /* Count up non-discarded kids */
      num_kids=0;
      if (famtree[i].nkids > 0)  {
	for (j=0; j<num_in_ped; j++) {
	  if (famtree[j].discard) continue;
	  if (famtree[j].mom_index == i ||
	      famtree[j].dad_index == i)
	    num_kids++;
	}
      }
      if (num_kids > 0) {
	possible_pivot[i]=1; /* has kids and parents */
	pivot[num_pivots]=i;
	num_pivots++;
      }
    }
  }

  if (num_pivots < (num_nuc_fam-1)) {
    /* In this case we have a string of marriages with
       half sibs on the next level, so the pivots will
       be individuals with more than one partner (and may
       actually be original) */
    for (i=0; i<num_nuc_fam; i++) 
      for (j=i+1; j<num_nuc_fam; j++) {
	/* Make a list of individuals shared between two nuc fams */
	if (nuc_fam[i].dad == nuc_fam[j].dad) {
	  pivot[num_pivots]=nuc_fam[i].dad;
	  num_pivots++;
	  possible_pivot[nuc_fam[i].dad]++;
	}
	if (nuc_fam[i].mom == nuc_fam[j].mom) {
	  pivot[num_pivots]=nuc_fam[i].mom;
	  num_pivots++;
	  possible_pivot[nuc_fam[i].mom]++;
	}
      }
  }


  for (i=0; i<num_nuc_fam; i++)
    assigned[i]=FALSE;

  /* Assign pivots within nuclear families */
  num_assigned = 0;
  done=FALSE;
  while(!done) {
    assigned_this_round=FALSE;

    for (i=0; i<num_nuc_fam; i++) {
      if (assigned[i]) continue;

      poss=0;
      if (possible_pivot[nuc_fam[i].dad]) { poss++; fam_pivot=nuc_fam[i].dad; }
      if (possible_pivot[nuc_fam[i].mom]) { poss++; fam_pivot=nuc_fam[i].mom; }
      for (k=0; k<nuc_fam[i].num_kids; k++) {
	if (possible_pivot[nuc_fam[i].kid[k]]) {
	  poss++; fam_pivot=nuc_fam[i].kid[k];
	}
      }

      if (poss == 1) {
	  /* use it, mark the members as done, subtract 1
	     from possible_pivot[member] */
	  assigned_this_round=TRUE;
	  nuc_fam[i].pivot = fam_pivot;
	  order_assigned[num_assigned]=i;
	  num_assigned++;
	  assigned[i]=TRUE;
	  possible_pivot[fam_pivot]--;
	  if (num_assigned == (num_nuc_fam-1)) {
	    done=TRUE; break;
	  }
      } else if (poss == 0) {
	  /* we have a nuclear family that is not connected to 
	     the rest of the pedigree - ERROR */
	  sf(ps,"pedigree contains disconnected arms...SKIPPING\n"); pr();
	  sf(ps,"This means that either two pedigrees that are not related\n");
	  pr();
	  sf(ps,"or are related only by a marriage with uninformative\n");
	  pr();
	  sf(ps,"children are present with the same name and should be\n");
	  pr();
	  sf(ps,"divided into two separate pedigrees.\n");
	  pr();
	  return(-1);
	  /* returns -1 to indicate to skip the pedigree above */
      }
    }
   
    if (!assigned_this_round) {
      /* can't assign any more, must have hit some sort of loop */
      done=TRUE;
    }
  }

  /* Mark everyone in the unassigned nuclear families as requiring
     further analysis */

  for (i=0; i<num_in_ped; i++) famtree[i].not_peeled=FALSE;
  
  for (i=0; i<num_nuc_fam; i++) {
    if (assigned[i]) continue;
    
    famtree[nuc_fam[i].dad].not_peeled = TRUE;
    famtree[nuc_fam[i].mom].not_peeled = TRUE;
    for (k=0; k<nuc_fam[i].num_kids; k++) 
      famtree[nuc_fam[i].kid[k]].not_peeled = TRUE;
  }

  num_nuc_fams_to_peel = num_assigned;

  /* Now peeling can be done on all the nuclear families in the
     assigned list, then a brute_force analysis can be applied
     to the remaining individuals not peeled off - yielding one
     analysis method for all types of pedigrees */

  /* All that remains is to recognize long inbreeding loops and
     to subsequently break them (a la Linkage - but automatically)
     or to develop an inbred peeling method  - this has now been
     done in the analyze_family code! */

  return(1);
}


void order_inbred_family (void)
{
  int i,j,k,inbred_family,mom_anc,dad_anc;
  int max_to_common,*loop_order,num_in_loop=0,num_assigned;
  bool *in_loop,found,*checked;

  array(loop_order,num_nuc_fam,int);
  array(checked,num_nuc_fam,bool);
  array(in_loop,num_nuc_fam,bool);
  for (i=0; i<num_nuc_fam; i++) {
    in_loop[i]=FALSE;
    checked[i]=FALSE;
  }

  /* Find the inbred family */
  for (i=0; i<num_nuc_fam; i++) {
    if (nuc_fam[i].inbred) {
      inbred_family=i;
      break;
    }
  }
  checked[inbred_family]=TRUE;
  in_loop[inbred_family]=TRUE;
  famtree[nuc_fam[inbred_family].mom].in_loop=TRUE;
  famtree[nuc_fam[inbred_family].dad].in_loop=TRUE;
  loop_order[num_in_loop]=inbred_family;
  num_in_loop++;
  if (nuc_fam[inbred_family].mom_to_common >
      nuc_fam[inbred_family].dad_to_common)
    max_to_common = nuc_fam[inbred_family].mom_to_common;
  else
    max_to_common = nuc_fam[inbred_family].dad_to_common;

  
  /* Starting with the inbred nuclear family, work
     upward through the families that are in the inbreeding
     loop */
  mom_anc = nuc_fam[inbred_family].mom;
  dad_anc = nuc_fam[inbred_family].dad;
  for (i=0; i<=max_to_common; i++) {
    if (i<=nuc_fam[inbred_family].mom_to_common) {
      /* Find the nuclear family that mom is a part 
	 of.  We'll always be peeling upward, so the
	 indiv will always be among the children */
      for (j=0; j<num_nuc_fam; j++) {
	if (checked[j]) continue;
	found = FALSE;
	for (k=0; k<nuc_fam[j].num_kids; k++)
	  if (nuc_fam[j].kid[k] == mom_anc) {
	    found=TRUE;
	    break;
	  }
	if (found) {
	  /* found the family mom of her ancestor is a part of, one
	     of the parents of this nuclear family will be the
	     next 1/2 of a superpivot */
	  if (famtree[nuc_fam[j].mom].mom_index != MISSING &&
	      famtree[nuc_fam[j].mom].dad_index != MISSING &&
	      famtree[nuc_fam[j].mom].nkids > 0)
	    mom_anc = nuc_fam[j].mom;
	  else
	    mom_anc = nuc_fam[j].dad;
	  checked[j] = TRUE;
	  nuc_fam[j].in_loop = TRUE;
	  nuc_fam[j].loop_indiv = mom_anc;
	  famtree[mom_anc].in_loop=TRUE;
	  loop_order[num_in_loop]=j;
	  num_in_loop++;
	}
      }
    }
    /* Now do the same routine for dad */
    if (i<=nuc_fam[inbred_family].dad_to_common) {
      for (j=0; j<num_nuc_fam; j++) {
	if (checked[j]) continue;
	found = FALSE;
	for (k=0; k<nuc_fam[j].num_kids; k++)
	  if (nuc_fam[j].kid[k] == dad_anc){
	    found=TRUE;
	    break;
	  }
	if (found) {
	  /* found the family mom of her ancestor is a part of, one
	     of the parents of this nuclear family will be the
	     next 1/2 of a superpivot */
	  if (famtree[nuc_fam[j].mom].mom_index != MISSING &&
	      famtree[nuc_fam[j].mom].dad_index != MISSING &&
	      famtree[nuc_fam[j].mom].nkids > 0)
	    dad_anc = nuc_fam[j].mom;
	  else
	    dad_anc = nuc_fam[j].dad;
	  checked[j] = TRUE;
	  nuc_fam[j].in_loop = TRUE;
	  nuc_fam[j].loop_indiv = dad_anc;
	  famtree[dad_anc].in_loop=TRUE;
	  loop_order[num_in_loop]=j;
	  num_in_loop++;
	}
      }
    }
  }

  num_assigned=0;
  if (num_in_loop < num_nuc_fam) {
    /* In this case there are peripheral families outside
       the inbreeding loop where we can assign pivots in
       the usual fashion */
    num_assigned++;
  }
  for (i=0; i<num_in_loop; i++) {
    order_assigned[num_assigned] = loop_order[i];
    num_assigned++;
  }
  
  unarray(in_loop,bool);
  unarray(loop_order,int);
  unarray(checked,bool);
}
  
static int num_mom, num_dad;

int inbred_matings (void)
{
  /* Return the number of inbred matings */
  
  int i,j,k;
  int mom,dad;
  int *mom_anc, *dad_anc;
  int num_inbred_matings=0;
  int num_in_common;


  array(mom_anc,MAX_INDIVIDUALS,int);
  array(dad_anc,MAX_INDIVIDUALS,int);

  /* If a person has > 0 kids make a list of the
     person's ancestors and the partner(s)'s ancestors
     and make sure they have none in common */
  for (i=0; i<num_nuc_fam; i++) {
    mom = nuc_fam[i].mom;
    dad = nuc_fam[i].dad;

    /* Make a list of each parents ancestors */
    num_mom=0;
    num_dad=0;
    get_mat_ancestors(mom,mom_anc);
    get_pat_ancestors(dad,dad_anc);

    /* Compare the lists */
    num_in_common=0;
    for (k=0; k<num_mom; k++) {
      for (j=0; j<num_dad; j++) {
	if (mom_anc[k] == dad_anc[j]) {
	  if (num_in_common == 0) {
	    nuc_fam[i].mom_to_common = (k+2)/2-1;
	    nuc_fam[i].dad_to_common = (j+2)/2-1;
	  }
	  num_in_common++;
	}
      }
    }
    if (num_in_common > 0) {
      num_inbred_matings++;
      nuc_fam[i].inbred=TRUE;
      nuc_fam[i].num_common_anc=num_in_common;
    }
  }

  unarray(mom_anc,int);
  unarray(dad_anc,int);
  
  return(num_inbred_matings);
}
     

void get_mat_ancestors(int indiv,int *list)
{

  if (famtree[indiv].mom_index != MISSING) {
    list[num_mom]=famtree[indiv].mom_index;
    num_mom++;
    get_mat_ancestors(famtree[indiv].mom_index,list);
  }
  if (famtree[indiv].dad_index != MISSING) {
    list[num_mom]=famtree[indiv].dad_index;
    num_mom++;
    get_mat_ancestors(famtree[indiv].dad_index,list);
  }

}
void get_pat_ancestors(int indiv,int *list)
{

  if (famtree[indiv].mom_index != MISSING) {
    list[num_dad]=famtree[indiv].mom_index;
    num_dad++;
    get_pat_ancestors(famtree[indiv].mom_index,list);
  }
  if (famtree[indiv].dad_index != MISSING) {
    list[num_dad]=famtree[indiv].dad_index;
    num_dad++;
    get_pat_ancestors(famtree[indiv].dad_index,list);
  }

}

  
    
void init_disease_probs(int num_in_ped) 
{
  /* sets each pedigree member's a-priori disease allele frequencies */
  /* called before peel() for each inheritance vector */

  int i,aff_stat,liab_class;
  double total_pen[MAX_LIABILITY_CLASSES+1], 
         total_pen2[MAX_LIABILITY_CLASSES+1];

  /* X inheritance - split based on sex */

  for (i=0; i<=num_liability_classes; i++) {
    total_pen[i] = penetrance[i][HOM_AFF] + penetrance[i][HOM_UNAFF] +
      (2.0*penetrance[i][HET]);
    total_pen2[i] = penetrance[i][AFF_NULL] + penetrance[i][UNAFF_NULL];
  }

  for (i=0; i<num_in_ped; i++) {
    aff_stat = famtree[i].affectation_status;
    liab_class = famtree[i].liability_class;
    if (famtree[i].dad_index==MISSING && famtree[i].mom_index==MISSING) {
      if (famtree[i].sex == FEMALE) {
	famtree[i].disease_prob[HOM_AFF]=
	  apriori_disease[liab_class][aff_stat][HOM_AFF];
	famtree[i].disease_prob[HET_UA]=
	  apriori_disease[liab_class][aff_stat][HET];
	famtree[i].disease_prob[HET_AU]=
	  apriori_disease[liab_class][aff_stat][HET];
	famtree[i].disease_prob[HOM_UNAFF]=
	  apriori_disease[liab_class][aff_stat][HOM_UNAFF];
      } else {
	famtree[i].disease_prob[AFF_NULL]= 
	  apriori_disease[liab_class][aff_stat][AFF_NULL];
	famtree[i].disease_prob[UNAFF_NULL]=
	  apriori_disease[liab_class][aff_stat][UNAFF_NULL];
      }
    } else {
      switch (aff_stat) {
        case 1: 
	  if (famtree[i].sex == FEMALE) {
	    famtree[i].disease_prob[HOM_AFF]=
	     (1.0-penetrance[liab_class][HOM_AFF])/(4.0-total_pen[liab_class]);
	    famtree[i].disease_prob[HET_UA]=
	      (1.0-penetrance[liab_class][HET])/(4.0-total_pen[liab_class]);
	    famtree[i].disease_prob[HET_AU]=
	      (1.0-penetrance[liab_class][HET])/(4.0-total_pen[liab_class]);
	    famtree[i].disease_prob[HOM_UNAFF]=
	      (1.0-penetrance[liab_class][HOM_UNAFF])/(4.0-total_pen[liab_class]);
	  } else {
	    famtree[i].disease_prob[AFF_NULL]=
	      (1.0-penetrance[liab_class][AFF_NULL])/
		(2.0-total_pen2[liab_class]);
	    famtree[i].disease_prob[UNAFF_NULL]=
	      (1.0-penetrance[liab_class][UNAFF_NULL])/
		(2.0-total_pen2[liab_class]);
	  }
	  break;
	case 2:
	  if (famtree[i].sex == FEMALE) {
	    famtree[i].disease_prob[HOM_AFF]=
	      penetrance[liab_class][HOM_AFF]/total_pen[liab_class];
	    famtree[i].disease_prob[HET_UA]=
	      penetrance[liab_class][HET]/total_pen[liab_class];
	    famtree[i].disease_prob[HET_AU]=
	      penetrance[liab_class][HET]/total_pen[liab_class];
	    famtree[i].disease_prob[HOM_UNAFF]=
	      penetrance[liab_class][HOM_UNAFF]/total_pen[liab_class];
	  } else {
	    famtree[i].disease_prob[AFF_NULL]=
	      penetrance[liab_class][AFF_NULL]/total_pen2[liab_class];
	    famtree[i].disease_prob[UNAFF_NULL]=
	      penetrance[liab_class][UNAFF_NULL]/total_pen2[liab_class];
	  }
	  break;
	default: /* UNKNOWN */
	  if (famtree[i].sex == FEMALE) {
	    famtree[i].disease_prob[HOM_AFF]=0.25;
	    famtree[i].disease_prob[HET_UA]=0.25;
	    famtree[i].disease_prob[HET_AU]=0.25;
	    famtree[i].disease_prob[HOM_UNAFF]=0.25;
	  } else {
	    famtree[i].disease_prob[AFF_NULL]=0.50;
	    famtree[i].disease_prob[UNAFF_NULL]=0.50;
	  }
	  break;
      }
    }
  }
}

/* expects global nuc_fam[], num_nuc_fams to be filled in */


void peel(int inh_vec, int num_bits)
{
    int nf, f, i, j, k, this_pivot, this_spouse, kid_allele, pivot_allele;
    double this_prob, total_prob, new_prob[10];
    int get_kid_X_allele(int,int,int,int,int);

    for (f=0; f<num_nuc_fams_to_peel; f++) {
      nf = order_assigned[f];

      this_pivot = nuc_fam[nf].pivot;
      if (this_pivot == MISSING)
	error("no pivot listed in non-final nuclear family");


      if (this_pivot == nuc_fam[nf].dad) {
	  /* PEEL ONTO FATHER */
	  
	  for (i=4; i<=5; i++) { /* pivot_parent genotypes */
	      new_prob[i]=0.0;
	      for (j=0; j<4; j++) { /* mom's genotypes */
		  this_prob = famtree[nuc_fam[nf].mom].disease_prob[j];
		  for (k=0; k<nuc_fam[nf].num_kids; k++) {
		    /* for each kid - lookup alleles based on i,j,inh_vec */
		    kid_allele = 
		     get_kid_X_allele(nuc_fam[nf].kid[k],i,j,inh_vec,num_bits);
		    this_prob *= famtree[nuc_fam[nf].kid[k]].disease_prob[kid_allele];
		  }
		  new_prob[i] += this_prob;
	      }
	      /* update the pivot's probability based on this sub-pedigree */
	      famtree[this_pivot].disease_prob[i] *= new_prob[i];
	  }
      } else if (this_pivot == nuc_fam[nf].mom) {
	  /* PEEL ONTO MOTHER */
	  for (i=0; i<4; i++) { /* pivot_parent genotypes */
	      new_prob[i]=0.0;
	      for (j=4; j<=5; j++) { /* dad's genotypes */
		  this_prob = famtree[nuc_fam[nf].dad].disease_prob[j];
		  for (k=0; k<nuc_fam[nf].num_kids; k++) {
		    kid_allele =
		     get_kid_X_allele(nuc_fam[nf].kid[k],j,i,inh_vec,num_bits);
		    this_prob *= famtree[nuc_fam[nf].kid[k]].disease_prob[kid_allele];
		  }
		  new_prob[i] += this_prob;
	      }
	      /* update the pivot's probability based on this sub-pedigree */
	      famtree[this_pivot].disease_prob[i] *= new_prob[i];
	  }
	} else { 
	  /* PEEL ONTO KID */
	  for (i=0; i<6; i++) new_prob[i]=0.0;
	  for (i=4; i<=5; i++) { /* dad's genotypes */
	    for (j=0; j<4; j++) { /* mom's genotypes */
	      this_prob = famtree[nuc_fam[nf].dad].disease_prob[i] *
		famtree[nuc_fam[nf].mom].disease_prob[j];
	      for (k=0; k<nuc_fam[nf].num_kids; k++) {
		kid_allele = get_kid_X_allele(nuc_fam[nf].kid[k],i,j,inh_vec,num_bits);
		this_prob *= famtree[nuc_fam[nf].kid[k]].disease_prob[kid_allele];
		if (nuc_fam[nf].kid[k] == this_pivot) pivot_allele=kid_allele;
	      }
	      new_prob[pivot_allele] += this_prob;
	    }
	  }
	  /* save the new probs for the pivot child */
	  if (famtree[this_pivot].sex == FEMALE) {
	    for (i=0; i<4; i++) 
	      famtree[this_pivot].disease_prob[i] = new_prob[i];
	  } else {
	    for (i=4; i<=5; i++)
	      famtree[this_pivot].disease_prob[i] = new_prob[i];
	  }
	}
    }
}


int get_kid_X_allele(int kid_index, int dad_disease, int mom_disease, 
		   int inh_vec, int num_bits)
{
    int bit,dad_all,mom_all,k1,k2;

    /* 1st non-original has dad bit at num_bits-1, mom_bit at num_bits-2, etc... */

    bit = famtree[kid_index].inh_vec_pos;

    mom_all = (inh_vec >> (num_bits-(2*bit)-2)) % 2;

    if (dad_disease == AFF_NULL) k1=AFFECTED;
    else k1=UNAFFECTED;

    if (mom_all == 0) {
      if (mom_disease == HOM_AFF || mom_disease==HET_AU) k2=AFFECTED;
      else k2=UNAFFECTED;
    } else {
      if (mom_disease == HOM_AFF || mom_disease==HET_UA) k2=AFFECTED;
      else k2=UNAFFECTED;
    }

    if (famtree[kid_index].sex == FEMALE) {
      if (k1==AFFECTED && k2==AFFECTED) return(HOM_AFF);
      if (k1==AFFECTED && k2==UNAFFECTED) return(HET_AU);
      if (k1==UNAFFECTED && k2==AFFECTED) return(HET_UA);
      return(HOM_UNAFF);
    } else {
      if (k2==AFFECTED) return(AFF_NULL);
      else return(UNAFF_NULL);
    }
}


void orig_haplotypes (int num_in_ped, int *iv_idx, int **draw_alleles,
		      int **haplotype, int **inferred)
{

  /* Fill in the haplotypes for the originals in ped */

  int i, j, k, count_it, vec_idx, num_orig=0, num_nonorig=0;
  int *original, indiv;
  int lookup_force(int);
  int dad0, dad1, mom0, mom1, dkid, mkid, all;

  array(original,num_in_ped,int);
  for (i=0; i<num_in_ped; i++) {
    if ( famtree[i].mom_index == MISSING &&
	 famtree[i].dad_index == MISSING ) {
      if (!famtree[i].discard) {
	original[num_orig] = i;
	num_orig++;
      }
    } else { if (!famtree[i].discard) num_nonorig++; }
  }

  for (i=0; i<num_orig*2; i++)
    for (j=0; j<num_markers; j++)
      haplotype[i][j]=0;

  /* Fill in the haplotype matrix */
  for (i=0; i<num_in_map_order; i++) {
    /* Call the allele dropping code so that the node_array
       and the EdgeList are filled in */
    fill_placeholder_alleles(iv_idx[i],num_nonorig,1);
    for (j=0; j<num_in_ped; j++) {
      draw_alleles[j][i*2]=famtree[j].place_allele[0];
      draw_alleles[j][i*2+1]=famtree[j].place_allele[1];
      if (allele_data[j][allele_offset+(map_order[i]*2)] == 0 ||
	  allele_data[j][allele_offset+(map_order[i]*2)+1] == 0) {
	  inferred[j][i*2]=TRUE; inferred[j][i*2+1]=TRUE;
      } else {
	  inferred[j][i*2]=FALSE; inferred[j][i*2+1]=FALSE;
      }
    }
    
    graph_assign_probs(iv_idx[i],num_orig,num_nonorig,map_order[i],haplotype,TRUE);

    /* keep TDT statistics */

    for (k=0; k<1; k++) { /* was 12 */

      count_it=TRUE;

      /**********
      count_it=FALSE;
      if (k==0 && npl_pos > 2.0) count_it=TRUE;
      else if (k==1 && npl_pos > 1.5) count_it=TRUE;
      else if (k==2 && npl_pos > 1.0) count_it=TRUE;
      else if (k==3 && npl_pos > 0.5) count_it=TRUE;
      else if (k==4 && npl_pos > 0.0) count_it=TRUE;
      else if (k==5 && npl_pos < 0.0) count_it=TRUE;
      else if (k==6 && npl_max > 2.0) count_it=TRUE;
      else if (k==7 && npl_max > 1.5) count_it=TRUE;
      else if (k==8 && npl_max > 1.0) count_it=TRUE;
      else if (k==9 && npl_max > 0.5) count_it=TRUE;
      else if (k==10 && npl_max > 0.0) count_it=TRUE;
      else if (k==11 && npl_max < 0.0) count_it=TRUE;
      **********/

      if (!count_it) continue;

     for (j=0; j<num_in_ped; j++) {
       
       if (famtree[j].affectation_status != AFFECTED) continue;
       if (famtree[j].discard) continue;
       if (famtree[j].dad_index==MISSING || famtree[j].mom_index==MISSING) 
	 continue;

       if (i == 0) total_affecteds[k]++;

       dad0 = haplotype[famtree[famtree[j].dad_index].place_allele[0]][map_order[i]];
       dad1 = haplotype[famtree[famtree[j].dad_index].place_allele[1]][map_order[i]];
       mom0 = haplotype[famtree[famtree[j].mom_index].place_allele[0]][map_order[i]];
       mom1 = haplotype[famtree[famtree[j].mom_index].place_allele[1]][map_order[i]];
       dkid = haplotype[famtree[j].place_allele[0]][map_order[i]];
       mkid = haplotype[famtree[j].place_allele[1]][map_order[i]];

       if (dad0 <= 0 || dad1 <= 0) {
	 if (mom0 <= 0 || mom1 <= 0) {
	    continue; /* both parents are missing in part */
	 } else {
	    if (mkid==mom0 && dkid!=mom1 && mom0!=mom1 && mkid!=dkid) {
	      locus[map_order[i]].allele_count[mom0][k][TRANSMITTED] += 1;
	      locus[map_order[i]].allele_count[mom1][k][UNTRANSMITTED] += 1;
	    } else if (mkid==mom1 && dkid!=mom0 && mom0!=mom1 && mkid!=dkid) {
	      locus[map_order[i]].allele_count[mom1][k][TRANSMITTED] += 1;
	      locus[map_order[i]].allele_count[mom0][k][UNTRANSMITTED] += 1;
	    } else {
	      continue;
	    }
	  }
	} else {
	  if (mom0 <= 0 || mom1 <= 0) {
	    if (dkid==dad0 && mkid!=dad1 && dad0!=dad1 && mkid!=dkid) {
	      locus[map_order[i]].allele_count[dad0][k][TRANSMITTED] += 1;
	      locus[map_order[i]].allele_count[dad1][k][UNTRANSMITTED] += 1;
	    } else if (dkid==dad1 && mkid!=dad0 && dad0!=dad1 && mkid!=dkid) {
	      locus[map_order[i]].allele_count[dad1][k][TRANSMITTED] += 1;
	      locus[map_order[i]].allele_count[dad0][k][UNTRANSMITTED] += 1;
	    } else {
	      continue;
	    }
	  } else {
	    /* both parents present */
	    if (dad0 != dad1) {
	      if (dkid==dad0) {
		locus[map_order[i]].allele_count[dad0][k][TRANSMITTED] += 1;
		locus[map_order[i]].allele_count[dad1][k][UNTRANSMITTED] += 1;
	      } else {
		locus[map_order[i]].allele_count[dad1][k][TRANSMITTED] += 1;
		locus[map_order[i]].allele_count[dad0][k][UNTRANSMITTED] += 1;
	      }
	    }
	    if (mom0 != mom1) {
	      if (mkid==mom0) {
		locus[map_order[i]].allele_count[mom0][k][TRANSMITTED] += 1;
		locus[map_order[i]].allele_count[mom1][k][UNTRANSMITTED] += 1;
	      } else {
		locus[map_order[i]].allele_count[mom1][k][TRANSMITTED] += 1;
		locus[map_order[i]].allele_count[mom0][k][UNTRANSMITTED] += 1;
	      }
	    }
	  }
	}

      } /* for each ped member (j) */
     } /* for k = 0 to 12 */
    } /* for each marker (i) */



  /* Print out the haplotype matrix */
  print("\nHAPLOTYPES OF ORIGINAL INDIVIDUALS: \n");
  for (i=0; i<(num_orig*2); i++) {
    indiv = i/2;
    if (i%2 == 0) {
      sf(ps,"\nindiv %s:\t",famtree[original[indiv]].indiv_ID); pr();
    } else { print("        \t"); }
    
    if (i%2 == 0) {
      sf(ps,"%s\t0\t0\t%d\t",famtree[original[indiv]].indiv_ID,
	 famtree[original[indiv]].affectation_status); fpr(haplofp);
    } else {
      sf(ps,"\t\t\t\t"); fpr(haplofp);
    }

    for (j=0; j<num_in_map_order; j++) {
      sf(ps,"%-3d",haplotype[i][map_order[j]]); pr();
      fpr(haplofp);
    }
    nl(); fnl(haplofp);
  }

  /* dump haplos of non-originals to haplofp */
  for (i=0; i<num_in_ped; i++) {
    if (famtree[i].discard) continue;
    if (famtree[i].dad_index==MISSING || famtree[i].mom_index==MISSING) 
      continue;
   
    sf(ps,"%s\t%s\t%s\t%d\t",famtree[i].indiv_ID,
       famtree[i].dad, famtree[i].mom, famtree[i].affectation_status);
    fpr(haplofp);
    for (j=0; j<num_in_map_order; j++) {
      all = draw_alleles[i][j*2];
      sf(ps,"%-3d",haplotype[all][map_order[j]]);
      fpr(haplofp);
    }
    sf(ps,"\n\t\t\t\t"); fpr(haplofp);
    for (j=0; j<num_in_map_order; j++) {
      all = draw_alleles[i][(j*2)+1];
      sf(ps,"%-3d",haplotype[all][map_order[j]]);
      fpr(haplofp);
    }
    fnl(haplofp);
  }
  unarray(original,int);
}
    
#define real_eq(x,y) (fabs((x)-(y))<.0000000001)

remove_bit(int num_bits, int bit_to_remove, double **pvector, double *score,
	   int num_markers)
{
    int i, j, num_vecs, bitval, newcount;
    double *newlist;

    num_vecs=1; bitval=1;
    for (i=0; i<num_bits; i++) num_vecs*=2;
    for (i=0; i<bit_to_remove; i++) bitval*=2;
    array(newlist, num_vecs, double);

    for (j=0; j<num_markers; j++) {
      newcount=0;
      for (i=0; i<num_vecs; i++) {
	if ((i>>bit_to_remove) % 2 == 0) {
	  newlist[newcount] = pvector[j][i];
	  newcount++;
	  if (!real_eq(pvector[j][i],pvector[j][i+bitval])) {
	    sf(ps,"vectors %d and %d differ (marker %d), bit %d is relevant\n",
	       i,i+bitval,j+1,bit_to_remove); pr();
	    sf(ps,"%.12lf vs. %.12lf\n",pvector[j][i],pvector[j][i+bitval]);
	    pr();
	  }
	}
      }
      if (newcount != num_vecs/2) error("in remove_bit");
      for (i=0; i<newcount; i++) pvector[j][i]=newlist[i]*2.0;
    }

    newcount=0;
    for (i=0; i<num_vecs; i++) {
      if ((i>>bit_to_remove) % 2 == 0) {
	newlist[newcount] = score[i];
	newcount++;
	if (score[i] != score[i+bitval]) {
	  sf(ps,"scores for vectors %d and %d differ, bit %d is relevant\n",
	     i,i+bitval,bit_to_remove); pr();
	  break;
	}
      }
    }
    if (newcount != num_vecs/2) error("in remove_bit");
    for (i=0; i<newcount; i++) score[i]=newlist[i];
}


add_bit(int num_bits, int bit_to_insert, int *pvec, int num_loci)
{
    int i, j, newpvec, pow2;

    for (i=0; i<num_loci; i++) {
      j=0; newpvec=0; pow2=1;
      while (j < bit_to_insert) {
	newpvec += ((pvec[i] >> j)%2)*pow2;
	pow2 *= 2;
	j++;
      }
      j++; pow2 *= 2;
      while (j-1 < num_bits) {
	newpvec += ((pvec[i] >> j-1)%2)*pow2;
	pow2 *= 2;
	j++;
      }
      pvec[i] = newpvec;
    }
}

/**********
int new_acceptable_vector(int vec, int mask)
{
    if ((vec&mask) > 0) return(FALSE);
    else return(TRUE);
}
**********/

int acceptable_vector(int vec, int num_bits)
{
    int i;
    /* for a vector to be acceptable, all uninformative bits must be 0 */

    for (i=0; i<num_bits; i++) {
      if (uninformative_bit[i]) {
	if ((vec>>i)%2 == 1) return(FALSE);
      }
    }
    return(TRUE);
}

int resort_pedigree(int non_originals)
{
    int i, temp, any_changes_made=FALSE;

    for (i=0; i<non_originals-1; i++) {
        if (famtree[sorted_ped[i]].affectation_status != AFFECTED &&

	    (famtree[sorted_ped[i+1]].affectation_status == AFFECTED ||
	     (famtree[sorted_ped[i]].nkids == 0 && 
	      famtree[sorted_ped[i+1]].nkids > 0)) &&

	    (famtree[sorted_ped[i+1]].dad_index != sorted_ped[i] &&
	     famtree[sorted_ped[i+1]].mom_index != sorted_ped[i]) ) {
	    /* we can flip them */
	    temp = sorted_ped[i];
	    sorted_ped[i] = sorted_ped[i+1];
	    sorted_ped[i+1] = temp;
	    any_changes_made=TRUE;
	}
    }
    if (any_changes_made) resort_pedigree(non_originals);
}



double brute_force_analyze(int inh_vec, int num_bits, int num_in_ped)
{
    unsigned long i, j, or_vec, pow4[16];
    int original_list[MAX_INDIVIDUALS], node_assign[MAX_INDIVIDUALS*2]; 
    int originals, non_originals, non_original_list[MAX_INDIVIDUALS];
    int indiv, a0, a1, this_dis_loc, n1, n2;
    double this_prob, total_prob;

    originals=0; non_originals=0;
    for (i=0; i<num_in_ped; i++) {
      if (famtree[i].not_peeled) {
	if (famtree[i].dad_index==MISSING && famtree[i].mom_index==MISSING) {
	    original_list[originals]=i;
	    originals++;
	} 
	else if (!famtree[famtree[i].dad_index].not_peeled ||
		 !famtree[famtree[i].mom_index].not_peeled) {
	    original_list[originals]=i;
	    originals++;
	} else {
	    non_original_list[non_originals]=i;
	    non_originals++;
	}
      }
    }

    if (originals > 15) { 
      if(inh_vec == 0) {
        sf(ps,"too many originals (%d) to run this routine (brute_force)\n",
	   originals);
	pr();
	print("Cannot compute LOD scores for this pedigree\n");
      }
      return(1.0);
    }

    pow4[0]=1;
    for (i=1; i<16; i++) pow4[i]=pow4[i-1]*4;


    total_prob = 0.0;
    for (or_vec=0; or_vec<pow4[originals]; or_vec++) {
      
      this_prob=1.0;
      for (i=0; i<MAX_INDIVIDUALS; i++) node_assign[i]=-1;

      for (i=0; i<originals; i++) {
	if (i == 0) this_dis_loc = or_vec % 4;
	else this_dis_loc = ((int) or_vec/pow4[i]) % 4;
	if (famtree[original_list[i]].sex == FEMALE) {
	  this_prob *= famtree[original_list[i]].disease_prob[this_dis_loc];
	  n1 = famtree[original_list[i]].place_allele[0];
	  n2 = famtree[original_list[i]].place_allele[1];
	  switch (this_dis_loc) {
	    case HOM_AFF: node_assign[n1]=AFFECTED; node_assign[n2]=AFFECTED; break;
	    case HOM_UNAFF: node_assign[n1]=UNAFFECTED; node_assign[n2]=UNAFFECTED; break;
	    case HET_UA: node_assign[n1]=UNAFFECTED; node_assign[n2]=AFFECTED; break;
	    case HET_AU: node_assign[n1]=AFFECTED; node_assign[n2]=UNAFFECTED; break;
	    default: sf(ps,"%d is not a valid N % 4",this_dis_loc); error(ps);
	  }
	} else { /* MALE */
	  if (this_dis_loc % 2 == 0) this_dis_loc=UNAFF_NULL;
	  else this_dis_loc=AFF_NULL;
	  this_prob *= famtree[original_list[i]].disease_prob[this_dis_loc];
	  n1 = famtree[original_list[i]].place_allele[1];
	  switch (this_dis_loc) {
	    case UNAFF_NULL: node_assign[n1]=UNAFFECTED; break;
	    case AFF_NULL: node_assign[n1]=AFFECTED; break;
	    default: sf(ps,"%d is not a valid (4,5)",this_dis_loc); error(ps);
	  }
	}
      }

      for (i=0; i<non_originals; i++) {
	/* tack on probs of each non-orig disease_prob[disease_alleles] */
	indiv = non_original_list[i];
	a0 = node_assign[famtree[indiv].place_allele[0]];
	a1 = node_assign[famtree[indiv].place_allele[1]];
	if (a0 == -1 || a1 == -1) { 
	  error("undefined placeholder allele - brute_force_analyze"); 
	}

	if (famtree[indiv].sex == FEMALE) {
	  if (a0 == AFFECTED) {
	    if (a1 == AFFECTED) this_prob *= famtree[indiv].disease_prob[HOM_AFF];
	    else this_prob *= famtree[indiv].disease_prob[HET_AU];
	  } else {
	    if (a1 == AFFECTED) this_prob *= famtree[indiv].disease_prob[HET_UA];
	    else this_prob *= famtree[indiv].disease_prob[HOM_UNAFF];
	  }
	} else { /* MALE */
	  if (a1 == AFFECTED) this_prob *= famtree[indiv].disease_prob[AFF_NULL];
	  else this_prob *= famtree[indiv].disease_prob[UNAFF_NULL];
	}
      }
    
      total_prob += this_prob;
    }
    /* if (inh_vec == 0) { print("done\n"); } */
    return(total_prob);
}

