#define INC_LIB
#include "npl.h"

#define MAXNODE 20
#define MAXSTACK 100

static int stack[MAXSTACK];
static int stackp;


struct node;
struct edge;

typedef struct list *listptr;
typedef struct edge *edgeptr;
typedef struct node *nodeptr;
typedef struct nodelist *nodelistptr;

struct list
{
  int value;
  listptr next;
};

struct nodelist
{
  nodeptr node;
  nodelistptr next;
};

struct node
{
  int force;
  edgeptr edge_list;
  nodeptr next_node;
};

struct edge
{
  int allele1;
  int allele2;
  edgeptr next_edge;
  nodeptr out_node;
};

void FreeList(listptr);
void FreeEdgeList(edgeptr);

static nodeptr node_list;
static struct node node_array[MAXNODE];
static int mall1,mall2,mall3,free1,free2,free3;
static int gl_num_nodes;
static int defined_forced_nodes[MAXNODE];
static int forced_node_conflict;

void create_nodes(int num_nodes)
{
    int i;

    for (i=0; i<num_nodes; i++) {
      node_array[i].force = 0;
      node_array[i].edge_list = 0;
      node_array[i].next_node = node_array+i+1;
      defined_forced_nodes[i] = 0;
    }
    node_array[num_nodes-1].next_node = 0;
    node_list = node_array;
    mall1=mall2=mall3=0;
    free1=free2=free3=0;
    gl_num_nodes = num_nodes;
    forced_node_conflict = FALSE;
}


void AddEdge(int innode, int outnode, int a1, int a2)
{
  int temp;
  edgeptr ptr;
  ptr = (edgeptr)malloc(sizeof(struct edge)); mall1++;

  if (innode > outnode) { temp=innode; innode=outnode; outnode=temp; }
  ptr->allele1 = a1;
  ptr->allele2 = a2;
  ptr->next_edge = node_array[innode].edge_list;
  ptr->out_node = node_array+outnode;
  node_array[innode].edge_list = ptr;
}

void DefineNode(int innode, int a1)
{
  if (defined_forced_nodes[innode]!=0 && defined_forced_nodes[innode]!=a1) {
    forced_node_conflict = TRUE;
  }
  defined_forced_nodes[innode] = a1;
}

check_forced_list()
{
    int i;

    for (i=0; i<gl_num_nodes; i++) {
      if (defined_forced_nodes[i] != 0) 
	node_array[i].force = defined_forced_nodes[i];
    }
}  


ASSIGN_STRUCT *this_alist;

void process_graph(ASSIGN_STRUCT *alist)
{
    void Process(nodeptr);
    nodeptr newnode;

    alist->next = NULL;
    this_alist = alist;

    if (!forced_node_conflict) Process(node_list);

    newnode = node_list;
    do {
        if (newnode->edge_list != NULL) {
	    if (newnode->edge_list->next_edge != NULL) {
	        FreeEdgeList (newnode->edge_list->next_edge);
	    }
	    free (newnode->edge_list); free1++;
	}
	newnode = newnode->next_node;
    } while (newnode != NULL);

    /*
    sf(ps,"edges: malloced: %d, freed: %d\n",mall1,free1); pr();
    sf(ps,"lists: malloced: %d, freed: %d\n",mall2,free2); pr();
    sf(ps,"force: malloced: %d, freed: %d\n",mall3,free3); pr();
    */
}

void FreeEdgeList(edgeptr thisedge)
{
    if (thisedge->next_edge != NULL) FreeEdgeList(thisedge->next_edge);
    free (thisedge); free1++;
}

void Process(nodeptr node)
{
  listptr allele_list=NULL,tmplist;
  nodelistptr forced_list;
  listptr Alleles(edgeptr);
  void Cleanup(nodelistptr *);

  check_forced_list();

  if (node->next_node == 0)
  {
    if (node->force)
    {
      Push(node->force);
      Dump();
      Pop();
    }
    else
      Dump();
  }
  else
  {
    if (node->edge_list == 0)
    {
      if (node->force)
      {
	Push(node->force);
	Process(node->next_node);
	Pop();
      }
      else
	Process(node->next_node);
    }
    else if ((allele_list=Alleles(node->edge_list)))
    {
      if (node->force)
      {
	if (InList(node->force,allele_list))
	{
	  Push(node->force);
	  if (AssignForce(node->force,node->edge_list,&forced_list))
	    Process(node->next_node);
          Pop();
	  Cleanup(&forced_list);
	}
      }
      else
      {
	while (allele_list)
	{
	  Push(allele_list->value);
	  node->force = allele_list->value;
	  if (AssignForce(allele_list->value,node->edge_list,&forced_list))
	    Process(node->next_node);
          Pop();
	  Cleanup(&forced_list);
	  node->force = 0;
	  tmplist = allele_list->next;
	  free (allele_list); free2++;
	  allele_list = tmplist;
	}
      }
    }
  }
  
  if (allele_list != NULL) FreeList(allele_list);
}

listptr Alleles(edgeptr point)
{
  listptr current, allele_list, nextptr;
  listptr AddToList(int,listptr), RemoveFromList(int,listptr);

  allele_list = 0;
  allele_list = AddToList(point->allele1, allele_list);
  if (point->allele1 != point->allele2)
    allele_list = AddToList(point->allele2, allele_list);
  while (point->next_edge && allele_list)
  {
    point = point->next_edge;

    /* BUG: for (current = allele_list; current; current = current->next) */

    for (current = allele_list; current; ) {
      if (point->allele1 != current->value && point->allele2 != current->value){
	nextptr = current->next;
	allele_list=RemoveFromList(current->value,allele_list);
	current = nextptr;
      } else {
	current = current->next;
      }
    }
  }
  return allele_list;
}

listptr AddToList(int i, listptr l)
{
  listptr ret;
  ret = (listptr)malloc(sizeof(struct list)); mall2++;
  ret->next = l;
  ret->value = i;
  return ret;
}

int InList(int i, listptr l)
{
  while (l)
  {
    if (l->value == i) return 1;
    l = l->next;
  }
  return 0;
}

listptr RemoveFromList(int i, listptr l)
{
    listptr t, oldptr, tmp_ptr;

    if (!l) return(NULL);
    if (!l->next) {
	if (l->value == i) { free(l); free2++; return(NULL); }
	else { return(l); }
    } else {
	if (l->value == i) { tmp_ptr=l->next; free(l); free2++; return(tmp_ptr); }
	oldptr = l;
	t = oldptr->next;
	while (t && t->value != i) {
	    oldptr = oldptr->next;
	    t = t->next;
	}
	if (t == 0) return(l);
	else {
	  oldptr->next = t->next;
	  free(t); free2++;
	  return(l);
	}
    }
}

void FreeList(listptr thislist)
{
    if (thislist->next != NULL) FreeList(thislist->next);
    free (thislist); free2++;
}

int AssignForce(int allele, edgeptr l, nodelistptr *forced_list)
{
  int val, temp;
  nodelistptr AddToForcedList(nodeptr,nodelistptr);

  *forced_list = 0;
  while(l)
  {
    if (l->allele1 == allele) val = l->allele2;
    else if (l->allele2 == allele) val = l->allele1;
    else {printf("ERROR IN ASSIGN_FORCE\n"); exit(1);}
    temp = (l->out_node)->force;
    if (temp && val != temp) return 0;
    if (!temp)
    {
      (l->out_node)->force = val;
      *forced_list = AddToForcedList(l->out_node,*forced_list);
    }
    l = l->next_edge;
  }
  return 1;
}

nodelistptr AddToForcedList(nodeptr i, nodelistptr l)
{
  nodelistptr ret;
  ret = (nodelistptr)malloc(sizeof(struct nodelist)); mall3++;
  ret->node = i;
  ret->next = l;
  return ret;
}

void Cleanup(nodelistptr *forced_list)
{
  nodelistptr l;

  l = *forced_list;

  /* only will happen if initial call to cleanup has NULL arg */
  if (l == NULL) return; 

  if (l->next != NULL) Cleanup(&(l->next));
  (l->node)->force = 0;
  free (l); free3++;
}

int Push(int arg1)
{
	if (stackp >= MAXSTACK-1) {printf("BLEW STACK\n"); exit(1);}
	stack[stackp++] = arg1;
}

int Pop()
{
	if (stackp <= 0) {printf("BLEW STACK\n"); exit(1);}
	stackp--;
}

int Dump()
{
        /* gets called each time there is a full partial result */
	int i;

	/***** debugging output
	for (i=0; i<stackp; ++i) { sf(ps,"%d ",stack[i]); pr(); }
	print(" : ");
	*****/

	for (i=0; i<gl_num_nodes; i++)
	  this_alist->force_list[i] = node_array[i].force;


	
	this_alist->num_alleles = stackp;
	for (i=0; i<stackp; i++) this_alist->allele_list[i] = stack[i];

	if (this_alist->next == NULL) {
	    /* this should always be executed */
	    single(this_alist->next, ASSIGN_STRUCT);
	} else {
	    error("non-null this_alist->next...this should never happen");
	}

	this_alist = this_alist->next;
	this_alist->next=NULL;
	this_alist->num_alleles=0;
}

