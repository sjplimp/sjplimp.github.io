/* GENEHUNTER - Kruglyak, Daly, Reeve-Daly, and Lander
   Whitehead Institute for Biomedical Research, Copyright 1996 */
/******************************************************************************

 #    #    ##       #    #    #           ####
 ##  ##   #  #      #    ##   #          #    #
 # ## #  #    #     #    # #  #          #
 #    #  ######     #    #  # #   ###    #
 #    #  #    #     #    #   ##   ###    #    #
 #    #  #    #     #    #    #   ###     ####

******************************************************************************/
/* pirated from MAPMAKER...call shell for GENEHUNTER code */
/*Added for MPI connectivity--G. Conant*/
#include "mpi_info.h"

/*End of MPI Additions--G. Conant*/

/*G. Conant timing additions*/
#include "timing.h"



#define INC_LIB
#define INC_SHELL
#include "npl.h"


void setup_commands(void), init_variables(void);

/* extern char help_filename[];*/

main(int argc, char **argv)
{
    char *version, help_filename[PATH_LENGTH+1];
    FILE *fp;

    /*MPI Additions--G. Conant */
    int rk, nprs, err;
    MPI_Status *status;

    		
   
    /*G. Conant--Initializes MPI and gets the current processor's rank 
    and the total number of processors.  Both are stored in a 
    Message_pass_interface structure*/
    err = MPI_Init(&argc, &argv);
    err=MPI_Comm_rank(MPI_COMM_WORLD, &rk);
    mpi_interface.rank=rk;
    err=MPI_Comm_size(MPI_COMM_WORLD, &nprs);
    mpi_interface.num_procs=nprs;
    /*End MPI additions*/
    gct_prerun=gct_RunTime();
   
    custom_lib_init();
    tty_hello();
    seedrand(RANDOM);

    strcpy(help_filename,"gh.help"); 
    shell_init("GENEHUNTER - Complete Linkage Analysis",
	       "2.1_r2 beta","1996,1998,2000,2001",help_filename);
   
    banner();
  
    photo_banner_hook= NULL;
    quit_save_hook= NULL;
    
   
    setup_commands();
    init_variables(); /* startup values for global variables - below */

    

    /*G. Conant removed help file for mpi*/
    /*make_help_entries();*/

    /***** place any init calls here *****/
    /***** once in command loop, you will be in the shell *****/
    
   
    command_loop();
    gct_postrun=gct_RunTime();

    printf("Runtime for processor %d: %d: %d-%d\n", mpi_interface.rank, gct_postrun-gct_prerun, gct_postrun, gct_prerun);

    err =  MPI_Finalize();
    exit_main();
}


void setup_commands(void)
{

    /*  command-name	             Abbrev	function	   	type  
	1234567890123456789012345    123	12345678901234...  	123
	------------------------- sp ---  tab   --------------	  tab   --- 
    mc("test command",              "tc",	test_command_code,	CMD);*/

    mc("quit",                       "q",	quit,            	CMD);
    mc("photo",                      "",	do_photo,        	CMD);
    mc("system",                     "",	system_command,  	CMD);
    mc("change directory",           "cd",	cd_command,      	CMD);
    mc("run",                        "",	run_from_file,   	CMD);
    mc("time",                       "",	show_time,       	CMD);
    mc("help",                       "?",       help,                   CMD);
    mc("display scores",             "",        set_display_scores,      CMD);

    /* put command calls here */

    mc("load markers",               "",      load_markers,             CMD);
    mc("scan pedigrees",             "",      pedigree_prep,            CMD);

    mc("increment",                  "",      set_scan_increment,       CMD);
    mc("use",                        "",      set_use_map,              CMD);
    mc("units",                      "",      set_units,                CMD);
    mc("map function",               "",      set_map_function,         CMD);
    mc("off end",                    "",      set_off_end_distance,     CMD);

    mc("total stat",                 "",      show_total_stat,          CMD);
    mc("discard",                    "",      set_discard,              CMD);
    mc("score",                      "",      set_score_function,       CMD);
    mc("analysis",                   "",      set_analysis_type,        CMD);
    mc("count recs",                 "",      set_count_recs,           CMD);
    mc("postscript output",          "ps",    set_postscript_output,    CMD);
    mc("haplotype",                  "",      set_haplotype,            CMD);
    mc("haplotype method",           "",      set_haplomethod,          CMD);
    mc("letters",                    "",      set_letters,              CMD);
/*  mc("haplotype ratio",            "hr",    set_haplo_ratio,          CMD);*/
    mc("dump requirements",          "",      set_dump_req,             CMD); /*** new ***/
    mc("pairs used",                 "",      pair_usage,               CMD); /*** new ***/
    mc("dump ibd",                   "",      dump_ibd,                 CMD); /*** new ***/
    mc("exclude",                    "",      exclude_switch,           CMD); /*** new ***/
    mc("estimate",                   "",      estimate_switch,          CMD); /*** new ***/
    mc("haseman elston",             "",      he_switch,                CMD); /*** new ***/
    mc("ml variance",                "",      ml_variance,              CMD); /*** new ***/
    mc("no dom var",                 "",      no_dom_var,               CMD); /*** new ***/
    mc("nonparametric",              "",      nonparametric,            CMD); /*** new ***/
    mc("variance components",        "",      var_com_switch,           CMD); /*** new ***/
    mc("set starting values",        "",      set_start_values,         CMD); /*** new ***/
    mc("means by sex",               "",      set_num_means,            CMD); /*** new ***/

    mc("dump peak",                  "dp",    dump_peak_info,           CMD);
/*  mc("two locus test",             "",      two_locus_test,           CMD);*/

    mc("drawing scale",              "ds",    set_postscript_scaling,   CMD);
    mc("single point",               "",      set_single_point_mode,    CMD);
    mc("max bits",                   "mb",    set_max_bits,             CMD);
    mc("skip large",                 "",      set_skip_large,           CMD);

    mc("simulate",                   "",      simulation,               CMD);

    mc("tdt",                        "",      tdt_prep,                 CMD);
    mc("tdt2",                       "",      tdt2,                     CMD);
    mc("tdt3",                       "",      tdt3,                     CMD);
    mc("tdt4",                       "",      tdt4,                     CMD);
    mc("tdt5",                       "",      tdt5,                     CMD);
    mc("missing tdt",                "",      set_missing_TDT,          CMD);
    mc("one parent tdt",             "",      set_one_parent_TDT,       CMD);
    mc("perm1",                      "",      perm1,                    CMD);
    mc("perm2",                      "",      perm2,                    CMD);
    mc("pexcess1",                   "px1",   pexcess1,                 CMD);
    mc("pexcess2",                   "px2",   pexcess2,                 CMD);
    mc("pexcess3",                   "px3",   pexcess3,                 CMD);
    mc("dhskip",                     "",      set_dhskip,               CMD);
    mc("qtdt",                     "",      set_qtdt,               CMD);
    mc("qtest",                     "",      qtdt_test,               CMD);

    mc("compute sharing",            "cs",    set_compute_sharing,      CMD);
}






