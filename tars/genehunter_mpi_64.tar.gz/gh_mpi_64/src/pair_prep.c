/* GENEHUNTER - Kruglyak, Daly, Reeve-Daly, and Lander
   Whitehead Institure for Biomedical Research, Copyright 1996 */
#define INC_LIB
#define INC_SHELL
#include "npl.h"

/* externs */
int pair_setting;               /* pair-weighting scheme: first pair, all pairs, etc. */
double *****wmatrix;            /* matrix of sharing probabilities for all pedigree members */
double ***warray;               /* sharing probabilites for each sib pair */
double ****prior_wmatrix;       /* matrix of prior sharing probabilities */
double ***pheno;                /* matrix of phenotype values for each member of each pedigree */
int **sex;                      /* matrix of sex of each member of each pedigree */
double ***covariates;
bool *both_affected;            /* tags pairs with two affected members */
double **pair_pheno;            /* phenotype difference for each pair */
double *weight;                 /* weight used for each pair in analyses */
char ****pair_name;             /* pedigree name and IDs of each member */
int *pedigree_size;             /* number of members in each pedigree */
int total_num_sib_pairs;
int total_num_aff_sib_pairs;
int total_num_sibships;

typedef struct {
  int num_all_members;
  int num_affected_members;
  int num_phenotyped_members[MAX_PHENOTYPES];
} SIBSHIP_SIZE;
static SIBSHIP_SIZE *sibship_info;
static int *member_list;        /* list of members in current pedigree */

/* Internal Methods */
bool are_siblings(int first, int second);
int possible_number_of_pairs(int n);

#define MISSING (-1)

/*** Allocate memory for wmatrix and other global structures used by functions
  in sibs_analysis.c, if these structures do not already exist. Initialize 
  counts of sibships and pairs. Called once at start of scan. Could 
  be smarter. ***/

void allocate_pair_analysis_storage()
{
  int i, j, k, ped, pos, pair, sibship, number_alleles;

  /* Allocate */
  if (!wmatrix) 
    matrix(wmatrix, MAX_PEDIGREES, MAX_POSITIONS, double***);
  if (!prior_wmatrix) 
    array(prior_wmatrix, MAX_PEDIGREES, double***);
  if (!pheno && (num_phenotypes > 0)) 
    array(pheno, MAX_PEDIGREES, double**);
  if (!sex && (num_phenotypes > 0))
    array(sex, MAX_PEDIGREES, int*);
  if (!covariates)
    array(covariates, MAX_PEDIGREES, double**);
  if (!both_affected)
    array(both_affected, MAX_PAIRS, bool);
  if ((num_phenotypes != 0) && !pair_pheno)
    matrix(pair_pheno, MAX_PAIRS, num_phenotypes, double);
  if (!weight)
    array(weight, MAX_PAIRS, double);
  if (!pair_name) 
    array(pair_name, MAX_PEDIGREES, char***);
  if (!sibship_info)
    array(sibship_info, MAX_SIBSHIPS, SIBSHIP_SIZE);
  if (!pedigree_size)
    array(pedigree_size, MAX_PEDIGREES, int);
  array(member_list, MAX_INDIVIDUALS, int);

  /* Initialize */
  for (pair=0; pair<MAX_PAIRS; pair++) {
    both_affected[pair]=FALSE;
    weight[pair]=0.0;
    for (k=0; k<num_phenotypes; k++)
      pair_pheno[pair][k]=MISSING_PHENO;
  }
  for (sibship=0; sibship<MAX_SIBSHIPS; sibship++) {
    sibship_info[sibship].num_all_members=0;
    sibship_info[sibship].num_affected_members=0;
    for (i=0; i<num_phenotypes; i++) 
      sibship_info[sibship].num_phenotyped_members[i]=0;
  }
  for (ped=0; ped<MAX_PEDIGREES; ped++)
    pedigree_size[ped]=0;
  total_num_sibships = 0;
  total_num_sib_pairs = 0;
  total_num_aff_sib_pairs = 0;
}


/*** Make list member_list for pedigree ped_name, of size total_num_members (including discarded members). 
  member_list contains indices from fam_tree, sorted by sibship. Store, in sibship_info, the number of 
  affected and phenotyped members in each true sibship (i.e., sibships with more than one member). Store 
  the total number of true sibships in total_num_sibships. Store the total number of sib pairs and of sib
  pairs in which both members are affected in total_num_sib_pairs and total_num_aff_sib_pairs. Store each
  pair's name, whether both members are affected, and the phenotype difference between members in pair_name,
  both_affected, and pair_pheno. Store the phenotype of each member of each pedigree in pheno***/

void make_member_list(char *ped_name, int total_num_members)
{
  int a, b, i, j, k, ss, pos, pair, current_member, *sibship, num_sibships, num_useful_sibships;
  int num_all, num_aff, *num_pheno, num_members;
  double pheno1, pheno2;
  char name[MAX_NAME_SIZE];

  /* Make list of all members included in analysis */
  num_members = 0;
  for (i=0; i<total_num_members; i++)
    if (famtree[i].discard == FALSE) {
      member_list[num_members] = i;
      num_members++;
    }
  pedigree_size[num_pedigrees-1]=num_members;

  /* Allocate memory */
  for (pos=0; pos<MAX_POSITIONS; pos++) {
    array(wmatrix[num_pedigrees-1][pos], num_members, double**);
    for (i=1; i<num_members; i++)
      matrix(wmatrix[num_pedigrees-1][pos][i], i, 3, double);
  }
  matrix(prior_wmatrix[num_pedigrees-1], num_members, num_members, double*);
  for (i=0; i<num_members; i++)
    for (j=0; j<num_members; j++)
      array(prior_wmatrix[num_pedigrees-1][i][j], 3, double);
  if (num_phenotypes > 0) {
    matrix(pheno[num_pedigrees-1], num_members, num_phenotypes, double);
    array(sex[num_pedigrees-1], num_members, int);
  }
  matrix(covariates[num_pedigrees-1], num_members, 3, double);
  array(pair_name[num_pedigrees-1], num_members, char**);
  for (i=1; i<num_members; i++)
    matrix(pair_name[num_pedigrees-1][i], i, MAX_NAME_SIZE, char);

  /* Initialize */
  for (pos=0; pos<MAX_POSITIONS; pos++)
    for (i=1; i<num_members; i++)
      for (j=0; j<i; j++)
	for (k=0; k<3; k++)
	  wmatrix[num_pedigrees-1][pos][i][j][k] = 0.0;
  for (i=1; i<num_members; i++)
    for (j=0; j<i; j++)
      for(k=0; k<3; k++)
	prior_wmatrix[num_pedigrees-1][i][j][k]=0.0;
  if (num_phenotypes > 0)
    for (i=0; i<num_members; i++)
      for (k=0; k<num_phenotypes; k++)
	pheno[num_pedigrees-1][i][k] = MISSING_PHENO;
  
  /* Count number of sibships and identify the sibship to which each pedigree member belongs */
  array(sibship, num_members, int);
  for (i=0; i<num_members; i++)
    sibship[i] = -1;
  num_sibships=0;
  for (i=0; i<num_members; i++)
    if (sibship[i] < 0) {
      sibship[i]=num_sibships;
      for (j=i+1; j<num_members; j++)
	if (are_siblings(member_list[i], member_list[j])) {
	  sibship[j]=num_sibships;
	}
      num_sibships++;
    }

  /* Sort member_list and sibship by sibship */
  for (j=1; j<num_members; j++) {
    a=sibship[j];
    b=member_list[j];
    i=j-1;
    while (i>=0 && sibship[i] > a) {
      sibship[i+1]=sibship[i];
      member_list[i+1]=member_list[i];
      i--;
    }
    sibship[i+1]=a;
    member_list[i+1]=b;
  }
    
  /* Fill sibship_info structure with numbers of affected and phenotyped members in each sibship */
  if (num_phenotypes > 0)
    array(num_pheno, num_phenotypes, int);
  current_member=0;
  num_useful_sibships=0;
  for (ss=0; ss<num_sibships; ss++) {
    num_all = num_aff = 0;
    for (k=0; k<num_phenotypes; k++)
      num_pheno[k] = 0;
    while ((sibship[current_member] == ss) &&(current_member<num_members)) {
      num_all++;
      if (famtree[member_list[current_member]].affectation_status == AFFECTED)
	num_aff++;
      for (k=0; k<num_phenotypes; k++)
	if (famtree[member_list[current_member]].phenotype[k] != MISSING_PHENO)
	  num_pheno[k]++;
      current_member++;
    }
    if (num_all > 1) {
      sibship_info[total_num_sibships+num_useful_sibships].num_all_members=num_all;
      sibship_info[total_num_sibships+num_useful_sibships].num_affected_members=num_aff;
      for (k=0; k<num_phenotypes; k++)
	sibship_info[total_num_sibships+num_useful_sibships].num_phenotyped_members[k]=num_pheno[k];
      num_useful_sibships++;
    }
  }
  total_num_sibships+=num_useful_sibships;

  /* Fill pair_name, both_affected, pheno, and pair_pheno matrices */
  pair=0;
  for (j=0; j<num_members; j++) {
    if (num_phenotypes > 0)
      sex[num_pedigrees-1][j] = famtree[member_list[j]].sex;
    for (k=0; k<num_phenotypes; k++)
      pheno[num_pedigrees-1][j][k] = famtree[member_list[j]].phenotype[k];
    for (k=0; k<num_covs; k++)
      covariates[num_pedigrees-1][j][k] = famtree[member_list[j]].covariate[k];
    for (i=j+1; i<num_members; i++) {
      sf(name, "%-10.10s  %s,%s", ped_name, famtree[member_list[j]].indiv_ID, famtree[member_list[i]].indiv_ID);
      strcpy(pair_name[num_pedigrees-1][i][j], name);
      if (are_siblings(member_list[i], member_list[j])) {
	for (k=0; k<num_phenotypes; k++) 
	  if (((pheno1=famtree[member_list[i]].phenotype[k]) != MISSING_PHENO) &&
	      ((pheno2=famtree[member_list[j]].phenotype[k]) != MISSING_PHENO))
	    pair_pheno[total_num_sib_pairs+pair][k]=pheno1-pheno2;
	if (famtree[member_list[i]].affectation_status == AFFECTED &&
	    famtree[member_list[j]].affectation_status == AFFECTED) {
	  both_affected[total_num_sib_pairs+pair]=TRUE;
	  total_num_aff_sib_pairs++;
	}
	pair++;
      }
    }
  }
  total_num_sib_pairs+=pair;

  unarray(sibship, int);
  /*    unarray(num_pheno, int); */
}
 

void init_sharing_probs(long long int number_vecs, int number_bits)
{
  int pair;
  long long int ii, vec, padded_vec;
  int num_members, i, j, first_one, first_two, second_one, second_two;
  
  for (vec=0; vec<number_vecs; vec++) {
    padded_vec=pad_inhvec(vec);
    fill_placeholder_alleles(padded_vec, number_bits/2, TRUE);
    num_members=pedigree_size[num_pedigrees-1];
    for (i=1; i<num_members; i++) {
      for (j=0; j<i; j++) {
	first_one = famtree[member_list[i]].place_allele[0];
	first_two = famtree[member_list[i]].place_allele[1];
	second_one = famtree[member_list[j]].place_allele[0];
	second_two = famtree[member_list[j]].place_allele[1];

	if ((first_one != second_one) && (first_one != second_two) && 
	    (first_two != second_one) && (first_two != second_two)) {
	    prior_wmatrix[num_pedigrees-1][i][j][0] += 1.0/number_vecs;
	}
	else if (((first_one == second_one) && (first_two == second_two)) ||
		 ((first_one == second_two) && (first_two == second_one))) {
	    prior_wmatrix[num_pedigrees-1][i][j][2] += 1.0/number_vecs;
	}
	else {
	    prior_wmatrix[num_pedigrees-1][i][j][1] += 1.0/number_vecs;
	}
      }
    }
  }
}


void find_sharing_probs(int position, int number_bits, 
                        long long int vec, double vector_probs)
{
  int pair;
  long long int padded_vec;
  int num_members, i, j, first_one, first_two, second_one, second_two;
  
  padded_vec=pad_inhvec(vec);
  fill_placeholder_alleles(padded_vec, number_bits/2, TRUE);
  num_members=pedigree_size[num_pedigrees-1];
  for (i=1; i<num_members; i++) {
    for (j=0; j<i; j++) {
      first_one = famtree[member_list[i]].place_allele[0];
      first_two = famtree[member_list[i]].place_allele[1];
      second_one = famtree[member_list[j]].place_allele[0];
      second_two = famtree[member_list[j]].place_allele[1];
      
      if ((first_one != second_one) && (first_one != second_two) && 
	  (first_two != second_one) && (first_two != second_two)) {
	wmatrix[num_pedigrees-1][position][i][j][0] += 4*vector_probs;
      }
      else if (((first_one == second_one) && (first_two == second_two)) ||
	       ((first_one == second_two) && (first_two == second_one))) {
	wmatrix[num_pedigrees-1][position][i][j][2] += 4*vector_probs;
      }
      else {
	wmatrix[num_pedigrees-1][position][i][j][1] += 2*vector_probs;
      }
    }
  }
}


void norm_sharing_probs(int position, double like)
{
  int pair, padded_vec;
  int num_members, i, j, k;
  
    num_members=pedigree_size[num_pedigrees-1];
    for (i=1; i<num_members; i++) {
      for (j=0; j<i; j++) {
	    for(k=0; k<3; k++)
	      wmatrix[num_pedigrees-1][position][i][j][k] /= like;
      }
    }
}


/*** Allow the user to set whether or not to analyze the first affected
  sibpair (the default case, which assumes that only one affected 
  sibpair will be provided), all independent pairs, or all pairs. ***/

void pair_usage (void)
{
  char *tmp;
  int tmp_int,a,b,real_count,i;
  bool valid;

  sf(ps,"\nthe current pair setting is: "); pr();
  switch (pair_setting) {
  case 1: 
    print("*first affected/phenotyped sibpair only*\n");
    break;
  case 2: 
    print("*all independent pairs of affected/phenotyped sibs*\n");
    break;
  case 3: 
    print("*all pairs of affected/phenotyped sibs*\n");
    break;
  default:
    print("*all pairs of affected/phenotyped sibs - UNWEIGHTED*\n");
    break;
  }
  print("\n");
  print("  Possible pair options: \n");
  print("   1. First pair of affected/phenotyped sibs\n");
  print("   2. All independent pairs of affected/phenotyped sibs\n");
  print("   3. All pairs of affected/phenotyped sibs\n");
  print("   4. All pairs of affected/phenotyped sibs - UNWEIGHTED\n\n");

  valid = FALSE;
  while(!valid) {
    sf(ps,"Enter the index of the analysis you want to use [%d]: ",
       pair_setting);
    tmp = get_temp_string();
    input(ps,tmp,TEMP_STRING_LEN);
    if (nullstr(tmp)) valid = TRUE;
    else if (itoken(&tmp,iREQUIRED,&tmp_int)) {
      if (tmp_int > 0 && tmp_int < 6) {
	valid=TRUE;
	pair_setting = tmp_int;
      }
      else {
	print("invalid index entered, please try again\n");
      }
    }
  }
}


void set_weights(int phenotype_index)
{
  int current_pair, pair, num_members, sibship, num_pairs_selected, num_sib_pairs;
  
  pair=0;
  for(sibship=0; sibship<total_num_sibships; sibship++) {
    num_sib_pairs=possible_number_of_pairs(sibship_info[sibship].num_all_members);
    num_pairs_selected=0; /* number of pairs in this sibship which have received a non-zero weight */
    current_pair=pair;
    for(pair=current_pair; pair<current_pair+num_sib_pairs; pair++) {
      switch (pair_setting) {
	
      case FIRST_PAIR: 
	if (phenotype_index < 0)
	  if (both_affected[pair] && (num_pairs_selected==0)) {
	    weight[pair]=1.0;	  
	    num_pairs_selected++;
	  }
	  else 
	    weight[pair]=0.0;
	else if (phenotype_index < num_phenotypes) 
	  if ((pair_pheno[pair][phenotype_index] != MISSING_PHENO) && (num_pairs_selected == 0)) {
	    weight[pair]=1.0;
	    num_pairs_selected++;
	  }
	  else
	    weight[pair]=0.0;
	else
	  error("no such phenotype");
	break;
	
      case INDEPEND_PAIRS:
	if (phenotype_index < 0)
	  if (both_affected[pair] && (num_pairs_selected < sibship_info[sibship].num_affected_members-1)) {
	    weight[pair]=1.0;
	    num_pairs_selected++;
	  }
	  else
	    weight[pair]=0.0;
	else if (phenotype_index < num_phenotypes) 
	  if ((pair_pheno[pair][phenotype_index] != MISSING_PHENO) && 
	      (num_pairs_selected < sibship_info[sibship].num_phenotyped_members[phenotype_index]-1)) {
	    weight[pair]=1.0;
	    num_pairs_selected++;
	  }
	  else
	    weight[pair]=0.0;
	else
	  error("no such phenotype");
	break;
	
      case ALL_PAIRS:
	if (phenotype_index < 0)
	  if (both_affected[pair]) {
	    weight[pair]=(2.0/sibship_info[sibship].num_affected_members);
	    num_pairs_selected++;
	  }
	  else
	    weight[pair]=0.0;
	else if (phenotype_index < num_phenotypes) 
	  if (pair_pheno[pair][phenotype_index] != MISSING_PHENO) {
	    weight[pair]=(2.0/sibship_info[sibship].num_phenotyped_members[phenotype_index]);
	    num_pairs_selected++;
	  }
	  else
	    weight[pair]=0.0;
	else
	  error("no such phenotype");
	break;
	
      case ALL_UNWEIGHTED:
	if (phenotype_index < 0)
	  if (both_affected[pair]) {
	    weight[pair]=1.0;
	    num_pairs_selected++;
	  }
	  else
	    weight[pair]=0.0;
	else if (phenotype_index < num_phenotypes) 
	  if (pair_pheno[pair][phenotype_index] != MISSING_PHENO) {
	    weight[pair]=1.0;
	    num_pairs_selected++;
	  }
	  else
	    weight[pair]=0.0;
	else
	  error("no such phenotype");
	break;
	
      case OTHER:
	if (phenotype_index < 0)
	  if (both_affected[pair]) {
	    weight[pair]= (4.0/3.0) * ((2.0*sibship_info[sibship].num_affected_members)+
				       pow(0.50,sibship_info[sibship].num_affected_members-1)-3.0) /
					 (sibship_info[sibship].num_affected_members * (sibship_info[sibship].num_affected_members-1));
	    num_pairs_selected++;
	  }
	  else
	    weight[pair]=0.0;
	else if (phenotype_index < num_phenotypes) 
	  if (pair_pheno[pair][phenotype_index] != MISSING_PHENO) {
	    weight[pair]= (4.0/3.0) *
	      ((2.0*sibship_info[sibship].num_phenotyped_members[phenotype_index])+
	       pow(0.50,sibship_info[sibship].num_phenotyped_members[phenotype_index]-1)-3.0) /
		 (sibship_info[sibship].num_phenotyped_members[phenotype_index]*
		  (sibship_info[sibship].num_phenotyped_members[phenotype_index]-1));
	    num_pairs_selected++;
	  }
	  else
	    weight[pair]=0.0;
	else
	  error("no such phenotype");
	break;
      }
    }
  }
}


command dump_ibd (void)
{
  /* Dump the ibd distribution to a text file */
  char *default_file;
  int i,j,a,b,ped,pos,pair,ss;
  FILE *fp;
  

  /**** Check for the necessary flags ****/
  /* Scan needs to be done to compute the ibd distribution
     which is stored in the wmatrix.  The scan_done flag is
     set to false anytime map features change -- markers
     used, Kosambi vs. Haldane, scan steps, increments, pairs,
     active pedigrees, etc. */
  if (!scan_done)
    error("no scan done for the current map, pair, and pedigree settings\n");

  array(default_file,MAX_FILE_NAME_LEN,char);
  nstrcpy(default_file,"ibd_dist.out",MAX_FILE_NAME_LEN);
  fp = open_out_file(default_file, "IBD distribution");
  unarray(default_file,char);

  if (single_point_mode)
    fprintf(fp,"marker\tpedigree    pair                prior Z0\tprior Z1\tprior Z1\tZ0\t\tZ1\t\tZ2\n");
  else
    fprintf(fp,"pos   \tpedigree    pair                prior Z0\tprior Z1\tprior Z2\tZ0\t\tZ1\t\tZ2\n");    /* Column heading in text file */

  run {
    for (ped=0; ped<num_pedigrees; ped++)
      for (j=0; j< pedigree_size[ped]; j++)
	for (i=j+1; i< pedigree_size[ped]; i++)
	  if (prior_wmatrix[ped][i][j][0] < 1.0)   /* i.e., not unrelated founders */
	    for (pos=0; pos<num_w_pos; pos++)
	      fprintf(fp,"%.3lf\t%-30.30s  %6.6f\t%.6f\t%.6f\t%.6f\t%.6f\t%.6f\n",
		      wpos[pos],
		      pair_name[ped][i][j],
		      prior_wmatrix[ped][i][j][0],
		      prior_wmatrix[ped][i][j][1],
		      prior_wmatrix[ped][i][j][2],
		      (wmatrix[ped][pos][i][j][0]/4.0),
		      (wmatrix[ped][pos][i][j][1]/2.0),
		      (wmatrix[ped][pos][i][j][2]/4.0));
  } on_exit {
    close_file(fp);
  }
}


void extract_warray(void)
{
  int ped, pos, pair, i, j, k;

  if (!warray) {
    array(warray, num_w_pos, double**);
    for (pos=0; pos<num_w_pos; pos++)
      matrix(warray[pos], total_num_sib_pairs, 3, double);
  }

  pair=0;
  for (ped=0; ped<num_pedigrees; ped++)
    for (j=0; j<pedigree_size[ped]; j++)
      for (i=j+1; i<pedigree_size[ped]; i++)
	if (prior_wmatrix[ped][i][j][2] > 0.24) {  /*  Only sibs have 2-sharing prob of 0.25 */
	  for (pos=0; pos<num_w_pos; pos++)
	    for (k=0; k<3; k++)
	      warray[pos][pair][k] = wmatrix[ped][pos][i][j][k];
	  pair++;
	}
}


bool are_siblings(int first, int second)
{
  bool result;

  /* Can't be siblings if either is a founder */
  if (famtree[first].dad_index == MISSING || famtree[first].mom_index == MISSING || famtree[second].dad_index == MISSING || famtree[second].mom_index == MISSING)
    return FALSE;

  result = ((famtree[first].dad_index==famtree[second].dad_index) &&
		 (famtree[first].mom_index==famtree[second].mom_index)) ?
		   TRUE : FALSE;
  return result;
}


int possible_number_of_pairs(int n)
{
  int result;
  if ( n<2 ) 
    result = 0;
  else 
    result = (n == 2) ? 1 : possible_number_of_pairs(n-1) + n-1;
  return result;
}

