/* GENEHUNTER - Kruglyak, Daly, Reeve-Daly, and Lander
   Whitehead Institute for Biomedical Research, Copyright 1996 */
#define INC_LIB
#define INC_MISC
#define INC_SHELL
#include "npl.h"

#define REMOVE_BITS

/* Internal methods */
void sim_linkage_pedigree(char*);
void simulate_family(int);

/*G. Conant made extern to prevent clashes with finalprep.c*/
extern int total_meioses;
extern int total_affecteds[12];
int num_pedigrees;

/*G. Conant added*/
void set_mom_index(int,int);


static int sorted_ped[MAX_INDIVIDUALS]; /* Store the indices of
					   famtree sorted so that all
					   ancestors are at the front
					   of the list */
static bool placed[MAX_INDIVIDUALS]; /* Boolean list same length as famtree
					 indicating whether or not the 
					 corresponding indiv in famtree has 
					 been placed yet or not */
static int num_placed;
         /* Keep track of how many individuals have been placed */

int num_sims, num_chroms_to_sim;
double chrom_length;

typedef struct {
    double pos;
    int bit;
} RECOMBINATION;

RECOMBINATION rec[1000];
int num_recs;

typedef struct {
    double *score;
    double *pos;
    int num_regions;
} SIMCHROM;

SIMCHROM **sim_chrom;

double get_max_NPL(int*);

command simulation(void)
{

  /* Determine the type of pedigree we are dealing with (LINKAGE
     or our own internal format and call the appropriate method) */

  char *filename,s1[100],*hfilename,*tempstr;
  FILE *fpin;
  void prep_stanford_pedigree(char*),prep_linkage_pedigree(char*);
  int i,j,k,n,a,b,c,d,e;
  double theta, chisq, diff, sum, chisq_prob(double,double);
  int temp_ser, temp_hap, temp_num_in_map_order, temp_map[MAXLOCI];
  int *choice;
  double *NPLmax;

  run {
    filename = get_temp_string();
    use_uncrunched_args();
    get_one_arg(stoken,"",filename);
	  
    if (nullstr(filename)) print("need filename as argument\n");
    
    fpin = open_file(filename,"r");
    fgetln(fpin);
    while(nullstr(ln)) fgetln(fpin);

    n = sscanf(ln,"%s %d %d %d %d %d",s1,&a,&b,&c,&d,&e);

    tempstr = get_temp_string();
    input("number of simulations: ",tempstr,TEMP_STRING_LEN);
    itoken(&tempstr,100000,&num_sims);

    tempstr = get_temp_string();
    input("chromosome length: ",tempstr,TEMP_STRING_LEN);
    rtoken(&tempstr,150.0,&chrom_length);

    num_chroms_to_sim=1000;

    if (n == 6)  {
      matrix (sim_chrom, MAX_PEDIGREES, num_chroms_to_sim, SIMCHROM);
      
      sim_linkage_pedigree(filename); /* LINKAGE has 6 or more fields */

    } else { 
      sf(ps,"error: can't recognize first line of pedigree file (%s)\n",ln);
      pr();
    }

    /* Now tally the simulation results */
    array(NPLmax, num_sims, double);
    array(choice, num_pedigrees, int);

    for (i=0; i<num_sims; i++) {

      /* select a random simulated chromosome from each pedigree */
      for (j=0; j<num_pedigrees; j++) {
	choice[j] = num_chroms_to_sim*randnum();
      }
      NPLmax[i] = get_max_NPL(choice);
    }


    inv_rsort(NPLmax, num_sims);

    sf(ps,"Maximum NPL seen: %.2lf\n",NPLmax[0]); pr();
    sf(ps,".0001: %.2lf\n",NPLmax[num_sims/10000]); pr();
    sf(ps,".001: %.2lf\n",NPLmax[num_sims/1000]); pr();
    sf(ps,".002: %.2lf\n",NPLmax[num_sims/500]); pr();
    sf(ps,".0025: %.2lf\n",NPLmax[num_sims/400]); pr();
    sf(ps,".003: %.2lf\n",NPLmax[(num_sims*3)/1000]); pr();
    sf(ps,".004: %.2lf\n",NPLmax[(num_sims*4)/1000]); pr();
    sf(ps,".005: %.2lf\n",NPLmax[(num_sims*5)/1000]); pr();
    sf(ps,".006: %.2lf\n",NPLmax[(num_sims*6)/1000]); pr();
    sf(ps,".007: %.2lf\n",NPLmax[(num_sims*7)/1000]); pr();
    sf(ps,".008: %.2lf\n",NPLmax[(num_sims*8)/1000]); pr();
    sf(ps,".009: %.2lf\n",NPLmax[(num_sims*9)/1000]); pr();
    sf(ps,".01: %.2lf\n",NPLmax[num_sims/100]); pr();
    sf(ps,".02: %.2lf\n",NPLmax[num_sims/50]); pr();
    sf(ps,".03: %.2lf\n",NPLmax[(num_sims*3)/100]); pr();
    sf(ps,".04: %.2lf\n",NPLmax[(num_sims*4)/100]); pr();
    sf(ps,".05: %.2lf\n",NPLmax[num_sims/20]); pr();

    i=0;
    while (NPLmax[i] > 4.05) i++;
    sf(ps,"4.05 exceeded %.5lf of the time\n",(double)i/(double)num_sims);
    pr();
  } on_error {
    if (msg == CANTOPEN) {
      sf(ps,"Can't open file '%s'\n",filename); pr();
    } else {
      relay_messages;
    }
  }
}


/*********************************/
/* LINKAGE PEDIGREE READING CODE */
/*********************************/

typedef struct {
  int dad;
  int mom;
  int num_kids;
  int kid[MAX_KIDS];
  int pivot;
  bool inbred;        

  /* the following vars are for inbred families (or families in their loop)*/
  int num_common_anc; /* Number of ancestors in common between the mom&dad of this
			 nuclear family, for half-sibs it would be 1, in most other
			 cases it will be 2. */
  int dad_to_common;  /* Number of pedigree levels to the common ancestor.  For */
  int mom_to_common;  /* sibs marrying each other 0 levels, 1st cousins 1, etc */

  bool in_loop;
  int loop_indiv;

} NUC_FAMILY;

static NUC_FAMILY nuc_fam[MAX_INDIVIDUALS];
static int num_nuc_fam;
static int num_nuc_fams_to_peel;
/*G. Conant made int for c++ compile*/
static int order_assigned[MAX_INDIVIDUALS];

#define MISSING (-1) /* Value to set uncalculated fields to */
#define MALE 1
#define FEMALE 2
static char current_ped[MAX_NAME_SIZE];
/*G. Conant made extern to prevent clashes with finalprep.c*/
extern int allele_data[MAX_INDIVIDUALS][MAXLOCI*2];
extern int num_allele_data[MAX_INDIVIDUALS];
extern int allele_offset;
extern int list_index;

void sim_linkage_pedigree(char *filename)
{

  FILE *fpin;
  char ped_name[MAX_NAME_SIZE];
  char indiv_ID[MAX_NAME_SIZE];
  char father_ID[MAX_NAME_SIZE], mother_ID[MAX_NAME_SIZE];
  int sex, j, datum, pedigrees_loaded;

  /* Open the input file with the LINKAGE format pedigrees, and
     the output file where the inheritance vectors will be written */

  num_pedigrees=0;

  run {

    fpin = NULL; 
    fpin = open_file(filename,"r");
    strcpy(current_filename, filename);

  } except_when(CANTOPEN) {
    sf(ps,"Can't open file: %s\n",filename); pr();
    return;
  }

  array(famtree,MAX_INDIVIDUALS+5,PED_MEMBER);
  run {
    list_index=0;
    strcpy(current_ped,"");
    while(1) {

      fgetln(fpin);
      if (!maxstoken(&ln,sREQUIRED,ped_name,MAX_NAME_SIZE)) {
	/* blank line, read the next line */
      }
      else {
	/* actual line of data */
	if (nullstr(current_ped)) {
	  /* Record the new pedigree information for the first pedigree */
	  strcpy(current_ped,ped_name);
	  num_pedigrees++;
	} else if (strcasecmp(current_ped,ped_name) != 0) {
	  /* This line is the start of a new pedigree,
	     dump out the old one and reset the list index to 0 */
	  simulate_family(list_index); /* scans the family */

	  strcpy(current_ped,ped_name);
	  list_index=0;
	  num_pedigrees++;
	}
	
	/* Read the individual's index within the pedigree */
	if (!maxstoken(&ln,sREQUIRED,indiv_ID,MAX_NAME_SIZE)) {
	  sf(ps,"bad input line - no indivdual ID"); error(ps);
	}
	/* Read the parents' indices in the pedigree */
	if (!maxstoken(&ln,sREQUIRED,father_ID,MAX_NAME_SIZE)) {
	  sf(ps,"bad input line - no paternal ID for indiv %s",
	     indiv_ID); error(ps);
	}
	if (!maxstoken(&ln,sREQUIRED,mother_ID,MAX_NAME_SIZE)) {
	  sf(ps,"bad input line - no maternal ID for indiv %s",
	     indiv_ID); error(ps);
	}
	/* Read the sex of the individual */
	if (!itoken(&ln,iREQUIRED,&sex)) {
	  sf(ps,"bad input line - no sex for individual %s",indiv_ID);
	  error(ps);
	}
	
	/* Record the information in the family tree struct */
	strcpy(famtree[list_index].indiv_ID,indiv_ID);
	strcpy(famtree[list_index].dad,father_ID);
	strcpy(famtree[list_index].mom,mother_ID);
	famtree[list_index].sex=sex;
	/* Initialize values to be filled in later */
	famtree[list_index].nkids=0;
	famtree[list_index].dad_index=MISSING;
	famtree[list_index].mom_index=MISSING;
	
	/* Check that this isn't a duplicate indiv_ID */
	for (j=0; j<list_index; j++)
	  if (!strcasecmp(famtree[j].indiv_ID,
			  famtree[list_index].indiv_ID)) {
	    sf(ps,"indiv %s appears more than once in pedigree %s",
	       famtree[list_index].indiv_ID,current_ped); error(ps);
	  }
	    
	/* Read in the genotype data -store in static structs */
	j=0;
	while (itoken(&ln,iREQUIRED,&datum)) {
	  allele_data[list_index][j]=datum;
	  j++;
	}
	num_allele_data[list_index]=j;
	list_index++;
      }
    }	
    close_file(fpin);
    pedigrees_loaded=TRUE;
    unarray(famtree,PED_MEMBER);
  } except {
      when SOFTABORT: 
          pedigrees_loaded = FALSE;
          num_pedigrees = 0;
          close_file(fpin); fpin=NULL;
          unarray(famtree,PED_MEMBER);
          relay;
      when ENDOFILE:
          if (list_index > 0) {
	    pedigrees_loaded = TRUE;
	    run { simulate_family(list_index); } on_error {
	      pedigrees_loaded = FALSE;
	    }
	  }
          close_file(fpin); fpin=NULL;
          unarray(famtree,PED_MEMBER);
          break;
      default:
          close_file(fpin); fpin=NULL;
          unarray(famtree,PED_MEMBER);
          relay;
    }
}

/*G. Conant made extern to prevent clashes with finalprep.c*/
extern int uninformative_bit[64];

void simulate_family(int num_in_ped)
{
  int i,j,k,mom,dad; 
  int num_loci,originals,non_originals,real_non_originals;
  int num_vecs, vec, cur_place, skip_ped=FALSE, num_bits;
  int p0, p1, m0, m1, ptry[2], mtry[2], pall[2], mall[2], call[20];
  int pset0[10], pset1[10], mset0[10], mset1[10], pflag;
  double prob, graph_assign_probs(int,int,int,int,int**,bool), total;
  double *score=NULL, exp, exp_2, apm_score(int**,int), **pvector=NULL,varnull;
  int num_aff, **affected_allele=NULL, parents_informative(int), score_count;
  int *uninformative_marker=NULL, *num_real_vecs=NULL, num_inbred;
  int *best_pvector=NULL, has_data(int);
  int nf,complexity,num_uninformative_bits,real_num_bits,real_num_vecs,new_vec;
  int **alleles_to_draw,**haplotype,new_real_num_bits,**inferred;
  TIME_TYPE this_time, last_time;
  int count, *flip_mask=NULL, uninformative_mask, vecpos, parent, this_parent,
      this_indiv, really_uninformative_bits;
  int dad0, dad1, mom0, mom1, dkid, mkid, found_kid;
  int old_mom, inb_fam, dis_geno;
  double saved_d_prob[4], this_prob;
  int sim, pvec, mask;
  double this_length, rnum, next_rec, this_score;
  
  /* For all individuals, look up the person's mom and dad
     and record it in the pedigree structure */
  run {
    sf(ps,"\nsimulating pedigree %s...\n",current_ped); pr();

    if (num_allele_data[0]%2==1) 
      allele_offset = 1;
    else 
      allele_offset = 2;

    for (i=0; i<num_in_ped; i++) {
      set_dad_index(i,num_in_ped);
      set_mom_index(i,num_in_ped);
      famtree[i].analyzed_parent=FALSE; /* for counting inh. vec complexity */
      famtree[i].dad_bit_uninf=FALSE;
      famtree[i].mom_bit_uninf=FALSE;
      famtree[i].kids_found=FALSE; /* used later in bit chopping section */
    }

    for (i=0; i<num_in_ped; i++) famtree[i].discard=FALSE;

    /* get rid of unlinked individuals - set discard to TRUE */
    check_for_unlinked(num_in_ped);

    /* at this point we can eliminate from consideration:
        b) individuals that are unaffected and have no kids
           (they add next to nothing to a perfect-data NPL simulation) */

    for (i=0; i<num_in_ped; i++) {
      if (famtree[i].discard) continue;
      
      /* if (discard_unaffected) { */
      /* discard_unaffected is a flag ("discard") set at command level */

      /* Since we are simulating perfect data here, unaffecteds can
	 have no affect on the resulting NPL score so we skip them */
      if ( famtree[i].nkids == 0 && 
	  allele_data[i][0] != 2 ) {
	  famtree[i].discard = TRUE;
      }
    }
  
    originals = non_originals = 0;
    cur_place=0;

    /* set placeholder alleles for original pedigree members */
    for (i=0; i<num_in_ped; i++) {
      if (famtree[i].dad_index == MISSING &&
	  famtree[i].mom_index == MISSING) {
	if (!famtree[i].discard) {
	  originals++;
	  famtree[i].place_allele[0]=cur_place; cur_place++;
	  famtree[i].place_allele[1]=cur_place; cur_place++;
	}
      }

      else if (famtree[i].dad_index == MISSING ||
	       famtree[i].mom_index == MISSING) {
        sf(ps,"person %s has ONE parent",famtree[i].indiv_ID); error(ps);
      }
      else {
	if (!famtree[i].discard) non_originals++;
	famtree[i].place_allele[0]=-1;
	famtree[i].place_allele[1]=-1;
      }
    }

    num_loci = 0;
    allele_offset=1;
    
    /* fill in affectation_status and liability_class in PED_MEMBERs */
    for (i=0; i<num_in_ped; i++) {
      famtree[i].affectation_status = allele_data[i][0];
      if (allele_offset == 2) famtree[i].liability_class = allele_data[i][1];
      else famtree[i].liability_class = 1;
    }

    /* now let's do a preliminary sort of non-originals so that
       we can accurately determine how much analysis needs to be done */

    /* new_sort_pedigree(); */
    sort_pedigree(num_in_ped);
    resort_pedigree(non_originals);

    /* now read through this sorted list of non_originals until we
       hit the limit of our analytic capabilities */

    really_uninformative_bits = 0;
    num_bits = real_num_bits = (non_originals*2);
    real_non_originals = non_originals;

    if (non_originals < 1) {
      sf(ps,"no affected non-original members in pedigree %s...SKIPPING\n",
	 current_ped);  pr();
      skip_ped = TRUE; num_pedigrees--;
    } 

    if (!skip_ped) {
  
      /* Check for impossible loops */
      for (i=0; i<num_in_ped; i++) {
	/* We've already know that no one can be their own
	   direct parent so we'll start up a level */
	if (famtree[i].dad_index != MISSING) { 
	  /* If one parent is missing,both are */
	  check_for_loop(i,famtree[i].sex,famtree[i].dad_index,1,num_in_ped);
	  check_for_loop(i,famtree[i].sex,famtree[i].mom_index,1,num_in_ped);
	}
      }

      /* we have 2^2*non_originals possible pvectors */


#ifdef WE_DONT_NEED_THIS_FOR_NPL_SIM

      /* Fill the array of nuclear families */
      fill_nuc_families(num_in_ped);
    
      /* Count the number of inbred matings in the pedigree and
	 do the right thing if there are any */
      num_inbred = inbred_matings();
      if (num_inbred >= 1) {
	sf(ps,"family %s is inbred\n",current_ped); pr();
	/*** order_inbred_family(); ***/

	if (num_inbred == 1) {
	  /* break the first inbred marriage */
	  for (i=0; i<num_nuc_fam; i++) {
	    if (nuc_fam[i].inbred) {
	      inb_fam = i; 
	      break;
	    }
	  }

	  /* make fake individual (N=num_in_ped) with no parents
	     to be the new wife in this family */
	  old_mom = nuc_fam[inb_fam].mom;
	  nuc_fam[inb_fam].mom = num_in_ped;
	  famtree[num_in_ped].dad_index=MISSING;
	  famtree[num_in_ped].mom_index=MISSING;
	  famtree[num_in_ped].nkids = famtree[old_mom].nkids;

	  famtree[old_mom].nkids=0; /* temporarily */
	  num_in_ped++;
	} else {
	  /* more than one inbreeding loop - do by brute force
	     as if there were no inbreeding loops */
	  num_inbred=0;
	}
      }

      if (num_nuc_fam > 1) {
	  if (mark_pivots(num_in_ped) == -1) { 
	      skip_ped=TRUE; num_pedigrees--;
	  } else {
	    if (num_inbred >= 1) {
	      /* fix variable that were corrupted for mark_pivots */
	      num_in_ped--;
	      famtree[old_mom].nkids=famtree[num_in_ped].nkids;
	    }
	    if (num_nuc_fams_to_peel == 0) {
	      /* if we still can't peel after breaking the loop
		 we want to go straight to brute_force and forget
		 the loop breaking stuff */
	      num_inbred=0; /* skip the inbred broken peeling stuff */
	    }
	  }
      } else {
	  /* Mark the interesting individuals so that they are
	     fully analyzed by the exhaustive method */
	  famtree[nuc_fam[0].dad].not_peeled=TRUE;
	  famtree[nuc_fam[0].mom].not_peeled=TRUE;
	  for (k=0; k<nuc_fam[0].num_kids; k++) 
	    famtree[nuc_fam[0].kid[k]].not_peeled=TRUE;

	  order_assigned[0]=0;
	  num_nuc_fams_to_peel=0;
      }
#endif

    
      /* now connect to graphing code for determining inh. vector probs */
      num_vecs=1;
      for (i=0; i<num_bits; i++) num_vecs *= 2;
      real_num_vecs=1;
      for (i=0; i<real_num_bits; i++) real_num_vecs *= 2;

      matrix (pvector, num_in_map_order+1, real_num_vecs, double);
      array (score, real_num_vecs, double);
      matrix (affected_allele, num_in_ped, 2, int);
      array (uninformative_marker, num_in_map_order+1, int);
      array (num_real_vecs, num_in_map_order+1, int);
      array (best_pvector, num_in_map_order+1, int);
    
      for (i=0; i<num_in_map_order; i++) {
	uninformative_marker[i]=TRUE; num_real_vecs[i]=0;
      }
      exp = exp_2 = 0.0; 
      
      new_vec=0;
    
      for (vec=0; vec<num_vecs; vec++) {

	if (vec == 0) fill_placeholder_alleles(vec,real_non_originals,0);

	/* now every member of famtree has two placeholder alleles
	   filled in and we can advance to the prob assignment
	   for each of the markers */

	fill_placeholder_alleles(vec,real_non_originals,0);

	/* now obtain NPL score for this assignment of placeholder
	   alleles for this pedigree */

	for (i=0,num_aff=0; i<num_in_ped; i++) {
	  if (famtree[i].discard || famtree[i].place_allele[0]==-1) continue;

	  if (allele_data[i][0] == 2) {
	      /* this individual is affected */
	      affected_allele[num_aff][0] = famtree[i].place_allele[0];
	      affected_allele[num_aff][1] = famtree[i].place_allele[1];
	      num_aff++;
	  }
	}
	score[new_vec] = apm_score(affected_allele, num_aff);
	exp += score[new_vec];
	exp_2 += (score[new_vec]*score[new_vec]);

	new_vec++;
      }

      if (new_vec != real_num_vecs) error("num_vecs don't match in hackprep");
      
      exp /= real_num_vecs;
      exp_2 /= real_num_vecs;
      varnull = exp_2 - (exp*exp);

      /* Now we've stored the score for each pvector, we now need to
	 simulate a chromosome by choosing one at random and then
	 having bits flip to represent crossovers */

      for (sim=0; sim<num_chroms_to_sim; sim++) {
	array(sim_chrom[num_pedigrees-1][sim].pos, num_bits*5, double);
	array(sim_chrom[num_pedigrees-1][sim].score, num_bits*5, double);
	sim_chrom[num_pedigrees-1][sim].num_regions=0;

	/* simulate recombinations */
	num_recs=0;
	for (i=0; i<num_bits; i++) {
	    this_length=0.0;
	    while (this_length < chrom_length) {
	        rnum = randnum();
		next_rec = -100.0 * log(rnum);
		this_length += next_rec;
		if (this_length < chrom_length)
		  add_rec(i,this_length);
	    }
	}

	/* pick a random starting pvector */
	rnum = randnum();
	pvec = (int)(rnum*num_vecs);
	this_score = (score[pvec]-exp)/sqrt(varnull);
	tally_score(this_score,sim,0.0);

	for (i=0; i<num_recs; i++) {
	  mask = pow2[rec[i].bit];
	  pvec = pvec ^ mask;
	  this_score = (score[pvec]-exp)/sqrt(varnull);
	  tally_score(this_score,sim,rec[i].pos);
	}
      }

    } /* if (!skip_ped) */
  
  } on_exit {
    /* free memory */
    unarray(best_pvector, int);
    unarray(num_real_vecs, int);
    unarray(uninformative_marker, int);
    unmatrix (affected_allele, num_in_ped, int);
    unarray (score, double);
    unmatrix (pvector, num_in_map_order+1, double);
    relay_messages;
  }
}


void add_rec(int bit, double pos)
{
    int i=0, j;

    while (i<num_recs) {
      if (rec[i].pos > pos) break;
      i++;
    }
    
    for (j=num_recs-1; j>=i; j--) {
      rec[j+1].pos=rec[j].pos;
      rec[j+1].bit=rec[j].bit;
    }
    rec[i].pos=pos;
    rec[i].bit=bit;
    num_recs++;
}


void tally_score(double this_score, int sim, double this_pos)
{
    int num;

    num = sim_chrom[num_pedigrees-1][sim].num_regions;
    sim_chrom[num_pedigrees-1][sim].score[num]=this_score;
    sim_chrom[num_pedigrees-1][sim].pos[num]=this_pos;
    num++;
    sim_chrom[num_pedigrees-1][sim].num_regions=num;
}

double get_max_NPL(int *choice)
{
    int i,j,position[MAX_PEDIGREES],minsim;
    double max, this_score, minpos, compute_score(int*,int*);

    for (i=0; i<num_pedigrees; i++) position[i]=0;

    max = compute_score(choice,position);

    while (TRUE) {
      minpos=9999.0; minsim=-1;
      for (i=0; i<num_pedigrees; i++) {
	if (position[i]+1 == sim_chrom[i][choice[i]].num_regions) continue;

	if (sim_chrom[i][choice[i]].pos[position[i]+1] < minpos) {
	  minpos=sim_chrom[i][choice[i]].pos[position[i]+1];
	  minsim=i;
	}
      }
      if (minsim < 0) break;

      position[minsim] = position[minsim]+1;
      this_score = compute_score(choice,position);
      if (this_score > max) max=this_score;
    }

    return(max);
}

double compute_score(int *choice, int *position)
{
    int i;
    double sum=0.0;

    for (i=0; i<num_pedigrees; i++) {
      sum += sim_chrom[i][choice[i]].score[position[i]];
    }
    return(sum/sqrt(num_pedigrees));
}

