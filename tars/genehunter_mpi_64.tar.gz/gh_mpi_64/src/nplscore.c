/* GENEHUNTER - Kruglyak, Daly, Reeve-Daly, and Lander
   Whitehead Institute for Biomedical Research, Copyright 1996 */

/*G. Conant added INC_SHELL define for c++ compile*/
#define INC_SHELL


#define INC_LIB
#include "npl.h"

double apm_score(int **allele, int n)
{
    double score_pairs(int**,int), score_all(int**,int);
    double score_all_or_none(int**,int);
	double score_all_2(int**,int);

    if (score_function == SCORE_PAIRS) return(score_pairs(allele, n));
    else if (score_function == SCORE_ALL) return(score_all_2(allele, n));
    else if (score_function == SCORE_ONE) return(score_all_or_none(allele,n));
    else error("undefined NPL score function selected"); 
}

double score_pairs(int **allele, int n)
/*********************************************************************
n is the number of affected pedigree members, allele is the list of
their "dummy" alleles -- unique allele assignments inherited from the
founders.  score_pairs returns a score for the particular inheritance
vector corresponding to the dummy allele pattern by tallying ibd sharing
among all pairs of affecteds
**********************************************************************/
{
  int i, j;
  double score, total;

  if (n < 2) return(0.0);
  score = total = 0.0;

  for (i=0; i<n; ++i)
    for (j=i+1; j<n; ++j) {
        if (allele[i][0] == allele[j][0]) score += 0.25;
	if (allele[i][0] == allele[j][1]) score += 0.25;
	if (allele[i][1] == allele[j][0]) score += 0.25;
	if (allele[i][1] == allele[j][1]) score += 0.25;
	total += 1.0;
    }

  return (score/total);
}

erpa_score_pairs(int **allele, int n, int *sh, int *unsh)
{
    int i,j;
    int shared,unshared,match;

    shared=unshared=0;

    for (i=0; i<n-1; i++) {
      for (j=i+1; j<n; j++) {
	match=0;
	if (allele[i][0] == allele[j][0]) match += 1;
	if (allele[i][0] == allele[j][1]) match += 1;
	if (allele[i][1] == allele[j][0]) match += 1;
	if (allele[i][1] == allele[j][1]) match += 1;

	if (match == 0) { unshared+=2; }
	else if (match == 1) { shared++; unshared++; }
	else if (match == 4) { shared+=2; }
	else if (match == 2) {
	    if (allele[i][0]==allele[i][1] || allele[j][0]==allele[j][1]) {
	        shared++; unshared++;
	    } else {
	        shared+=2;
	    }
	} else {
	    sf(ps,"impossible match score %d %d, %d %d\n",
	       allele[i][0],allele[i][1],allele[j][0],allele[j][1]); pr();
	}
      }
    }
    
    *sh = shared;
    *unsh = unshared;
}


double score_all_2(int **allele, int n)
/********************************************************************
same as score_pairs, except implements Whittemore's score function
that takes into account sharing among all affecteds, not just pairs
*********************************************************************/
{
  int i, j, k, a[MAX_INDIVIDUALS], i_bit[MAX_INDIVIDUALS];
  long long int ii, choices;
  int n_alleles, i_aff, a_option, l, a_mul[MAX_INDIVIDUALS];
  int a_pos[MAX_INDIVIDUALS][2]; 
  long long int s_num;
  double score;
/* ** discart individuals with BOTH alleles that have multiplicity == 1
   but multiply overall score by *2  */
/* First make list of alleles and map to bits of individuals */

 
	n_alleles=0;
	for (i=0; i<2*n; i++) {
		i_aff    = i>>1;
		a_option = i&1;
		l=allele[i_aff][a_option];
		for(j=0; j<n_alleles; j++)
			if(l==a[j]) {
				if(!a_option) a_mul[j]++;
				break;
			}
		if(j==n_alleles) {
			a[j]=l; 
			if(a_option) { a_mul[j]=0; } else { a_mul[j]=1; }
			n_alleles++;
		}
		a_pos[i_aff][a_option]=j;
	}
/*
	execute all configurations.  Here I use a GrayCode to
	cover the space of all sets of allele choices.  One
	assignment only changes per iteration.
*/
	
	choices=pow2[n];
	s_num=(long long int)1;
	for(i=0; i<n_alleles; i++) {
	 
		for(j=2; j<=a_mul[i]; j++) s_num *= (long long int)j;
	}
	for(i=0; i<n;         i++) i_bit[i] = 0 ;
	
	score = (double)(s_num-(long long int)1);
	
	
	for(ii=0; ii<choices-1; ii++) {
		for(i_aff=0; i_aff<n; i_aff++) {
			if((pow2[i_aff] & ii) == 0) break;
		}
		
		k=a_pos[i_aff][i_bit[i_aff]];
		s_num /= (long long int)a_mul[k];
		a_mul[k]--;
		
		i_bit[i_aff]  = 1 - i_bit[i_aff];
		k=a_pos[i_aff][i_bit[i_aff]];
		a_mul[k]++;
		s_num *= (long long int)(a_mul[k]);
		
		
		score += (double)(s_num-(long long int)1);
	}
	/*printf("Final s: %d, final score: %8.7e, choices: %d, final %8.7e\n", (int)s, (double)score, (int)choices,
	  (double)(score/(double)choices));*/
	return (score/(double)choices);
}

double score_all(int **allele, int n)
/********************************************************************
same as score_pairs, except implements Whittemore's score function
that takes into account sharing among all affecteds, not just pairs
*********************************************************************/
{
  int choices, i, j, a[MAX_INDIVIDUALS], bit[MAX_INDIVIDUALS], h(int*,int);
  int h_2(int*, int);
  double score;

  choices = 1;
  for (i=0; i<n; ++i)
    choices *= 2;

  score = 0;
  for (i=0; i<choices; ++i)
  {
    for (j=0; j<n; ++j) bit[j] = (i >> j) % 2;
    for (j=0; j<n; ++j) a[j] = allele[j][bit[j]];

/*******
	score += h(a,n);
*******/
    score += h_2(a,n);
  }
  return (score/(double)choices);
}

int h(int *all, int n)
{
  int i, k, cnt, flg, seen[MAX_INDIVIDUALS], num[MAX_INDIVIDUALS], perms;
  cnt = 0;
  for (i=0; i<n; ++i)
  {
    k=0;
    flg = 1;
    while (k < cnt)
    {
      if (all[i] == seen[k])
      {
	flg =0;
	++num[k];
      }
      ++k;
    }
    if (flg)
    {
      seen[cnt] = all[i];
      num[cnt] = 1;
      ++cnt;
    }
  }
  perms = 1;
  for (i=0; i<cnt; ++i)
    for (k=1; k<=num[i]; ++k)
      perms *= k;

  return perms-1;
}

int h_2(int *all, int n)
{
  int i, k, cnt, flg, seen[MAX_INDIVIDUALS], num[MAX_INDIVIDUALS], perms;
  static int factorial_h[17], iot=1;

	if(iot) {
		factorial_h[0]=1;
		for (i=1; i<=16; i++)
			factorial_h[i] = factorial_h[i-1]*i;
/*******
		for (i=0; i<=16; i++)
			printf("i= %4d \t %d\n", i, factorial_h[i]);
*******/
		iot=0;
	}
  
  cnt = 0;
  for (i=0; i<n; ++i)
  {
    k=0;
    flg = 1;
    while (k < cnt)
    {
      if (all[i] == seen[k])
      {
	flg =0;
	++num[k];
      }
      ++k;
    }
    if (flg)
    {
      seen[cnt] = all[i];
      num[cnt] = 1;
      ++cnt;
    }
  }
  perms = 1;
  for (i=0; i<cnt; ++i)
  	perms *= factorial_h[num[i]];

  return perms-1;
}

double score_all_or_none(int **allele, int n)
/********************************************************************
same as score_pairs, except implements Thomas, Skolnick and Lewis
score function that scores ONE if all affecteds in a pedigree share
an allele IBD and ZERO otherwise
*********************************************************************/
{
  int shared_list[2], shared, i, j, intersect(int*,int*,int);
  
  /* initialize shared_list to contain allele(s) of the first affected */
  if (allele[0][0] == allele[0][1]) {
    shared_list[0] = allele[0][0];
    shared = 1;
  }
  else {
    shared_list[0] = allele[0][0];
    shared_list[1] = allele[0][1];
    shared = 2;
  }

  /* loop over remaining affecteds, updating shared_list */
  for (i=1; i<n; ++i) {
    shared = intersect(shared_list,allele[i],shared);
    if (!shared) break;
  }
  
  return ((shared>0) ? 1.0 : 0.0);
}

int intersect(int *shared_list, int *alleles, int shared)
{
  int new_shared, check1, check2;

  if (shared == 1) {
    if (shared_list[0]==alleles[0] || shared_list[0]==alleles[1])
      new_shared = 1;
    else
      new_shared = 0;
  }
  else if (shared == 2) {
    if (alleles[0] == alleles[1]) {
      if (shared_list[0]==alleles[0] || shared_list[1]==alleles[0]) {
	new_shared = 1;
	shared_list[0] = alleles[0];
      }
      else
	new_shared = 0;
    }
    else {
      check1 = (shared_list[0]==alleles[0] || shared_list[0]==alleles[1]);
      check2 = (shared_list[1]==alleles[0] || shared_list[1]==alleles[1]);
      if (check1 && check2)
	new_shared = 2;
      else if (check1)
	new_shared = 1;
      else if (check2) {
	new_shared = 1;
	shared_list[0] = shared_list[1];
      }
      else
	new_shared = 0;
    }
  }
  else {
    /* PUT PROPER ERROR RETURN HERE */
    printf("ERROR: shared must equal 1 or 2 in intersect\n");
    exit(1);
  }

  return new_shared;
}

/***** Special scoring function for X chromosome *****/

double X_apm_score(int **allele, int n)
/*********************************************************************
n is the number of affected pedigree members, allele is the list of
their "dummy" alleles -- unique allele assignments inherited from the
founders.  score_pairs returns a score for the particular inheritance
vector corresponding to the dummy allele pattern by tallying ibd sharing
among all pairs of affecteds
**********************************************************************/
{
  int i, j;
  double score, total;

  if (n < 2) return(0.0);
  score = total = 0.0;

  for (i=0; i<n; ++i)
    for (j=i+1; j<n; ++j) {
        if (allele[i][1] == allele[j][1]) score += 1.0;
	total += 1.0;
    }

  return (score/total);
}
