/* GENEHUNTER - Kruglyak, Daly, Reeve-Daly, and Lander
   Whitehead Institute for Biomedical Research, Copyright 1996 */
/*G. Conant included mpi for 1 call to frewind, which is aliased to
  fseek, which seems to be a system call*/
#include "mpi_info.h"
#include "timing.h"


#define INC_LIB
#define INC_SHELL
#include "npl.h"



/* externals */
LOCUS_INFO *locus;
PHENOTYPE_INFO *phenotype;
int num_markers, num_in_map_order, *map_order;
int num_phenotypes, num_covs; /*** new ***/
int num_loci; /*** new ***/ /* num_phenotypes + num_markers */
double *map_distance;
double affected_freq;
int num_liability_classes;
bool phenotype_data; /*phenotype data read from file, or not */ /*** new ***/
double penetrance[MAX_LIABILITY_CLASSES+1][6];
double apriori_disease[MAX_LIABILITY_CLASSES+1][6][6];

/* internals */
void read_linkage_marker_file(FILE*); /* arg: fp 
				         Loop over LINKAGE loci file */
void read_linkage_marker(FILE*,int);  /* args: fp, loci_read 
				         Read indiv LINKAGE marker entry */
void free_map_structs(void);          /* only called if load_markers
					 cannot completely load the 
					 file */

/* Associated procedures in cmds.c:
   void print_map_order(void) -- print out the current map
   int lookup_locus(char*) -- find the index of a locus in global locus array
   command set_use_map(void) -- input marker distances
*/

command load_markers(void)
{

  /* The upper level command.  Reads the number of markers
     in the file, determines the type of file and then
     passes control off to the appropriate file to actually handle
     the input. */

  char *filename;
  int num_fields,foo1,foo2,foo3;
  FILE *fp;



  /* Check that the locus file hasn't already been loaded */
  if (num_markers > 0) {
    sf(ps,"Genetic marker info is already loaded for %d markers.\n",
       num_markers); pr();
    print("This command will therefore be ignored.\n");
    return;
  }

  fp=NULL; locus=NULL;
  run {
    /* If no filename is given, just print the status */
    filename = get_temp_string();
    use_uncrunched_args();
    get_one_arg(stoken,"",filename);
    

    if (nullstr(filename)) {
      /* Print the status of the data */
      print("no data is currently loaded - use 'load markers <filename>'");
    }
    else {
#ifdef GC_TIME
      gct_pre=gct_RunTime();
#endif
      fp=open_file(filename,READ);
    
      /* Read the first line -  num_loci is all we use, risk
	 locus, sexlinked status, etc if present (in Linkage
	 style files) are discarded */
      fgetln(fp);
     num_fields = sscanf(ln,"%d %d %d %d",&num_loci,&foo1,&foo2,&foo3);
      if (num_fields == 0) {
	sf(ps,"missing num_loci on first line of '%s'",filename);
	error(ps);
      }
      /* allocate locus array now that we know how many there are,
	 this array will be filled in as we read the rest of the file */
      array(locus, num_loci, LOCUS_INFO);          /*** This is a little screwy, because each of these will hold only ***/
      array(phenotype, num_loci, PHENOTYPE_INFO);  /***	the marker data, or the phenotype data, not both. ***/
      
      /* Number of fields on the first line gives us the type of
	 file.  Our own internal style just has the number of
	 markers on the first line. */
      if (num_fields == 4) {
	/* Linkage style data file */
	num_loci--; /* Linkage files count the disease locus */
	print("Parsing Linkage marker data file...\n");
	if (mpi_interface.rank==0)
	  frewind(fp);
	read_linkage_marker_file(fp);
      }
      else {
	/* Parse our own internal format */
	error("Unrecognized marker file format");
      }
      close_file(fp);
    }
    /* Give the user some output info */
    sf(ps,"%d markers read (last one = %s)\n", num_markers,
       locus[num_markers-1].name); pr();
#ifdef GC_TIME
    gct_post=gct_RunTime();
    if (mpi_interface.rank == 0)
    printf("Proc %d runtime for reading markers: %d\n", mpi_interface.rank,
	   gct_post-gct_pre);
#endif
    
  } except {
    when ENDOFILE: 
       print("Unexpected end-of-file, no markers read\n");
       close_file(fp);
       free_map_structs();
       break;
    when CANTOPEN:
       sf(ps,"Can't open file '%s'\n",filename); 
       pr(); break;
    default:
       if (fp != NULL) close_file(fp);
       free_map_structs(); 
       relay_messages;
  }
}


void read_linkage_marker_file(FILE *fp)
{

  /* This method was ported from HOMOZ to read in the locus
     file in LINKAGE format.  Some of the infomation read in
     is not actually used but it is left here to check the format
     of the file and in case it is needed at a later time. */

  int i,num1,num2,loci_read=0,this_loc,*new_order,count, cM_dists;
  char *word,*word2,*strptr,*map_ord_str;
  double rnum1, rnum2, rnum3, dist;
  void init_disease_info(void);

  run {

    fgetln(fp);			/* header line, num_loci already read */
    fgetln(fp);			/* mutation line - skip*/
    fgetln(fp);                 /* map order */
    array(strptr,5000,char); strcpy(strptr,ln); map_ord_str=strptr; 
    fgetln(fp);			/* should be the start of affectation locus */

    /*** LINKAGE formatting checks - might want to take this out ***/
    /* is this an acceptable affectation locus? */
    if (sscanf(ln,"%d %d",&num1,&num2)!=2) {
      sf(ps,"bad affectation (4th) line '%s'",ln);
      error(ps);
    }
    fgetln(fp);			/* Read in the line with gene frequencies */
    if (sscanf(ln,"%lf %lf",&rnum1,&rnum2)!=2) {
      sf(ps,"bad disease gene frequency line (%s) - needs 2 numbers",ln);
      error(ps);
    }
    if (rnum1+rnum2 < 0.999 || rnum1+rnum2 > 1.001) {
      sf(ps,"disease allele frequencies (%.4lf, %.4lf) do not sum to 1.0",
	 rnum1,rnum2); error(ps);
    }
    affected_freq = rnum2;

    fgetln(fp);			/* liability class line */
    if (!itoken(&ln,iREQUIRED,&num1)) {
      sf(ps,"bad liability class line '%s'",ln); error(ps);
    }
    num_liability_classes=num1;
    if (num_liability_classes > MAX_LIABILITY_CLASSES) {
      sf(ps,"too many liability classes (%d) - edit npl.h",num_liability_classes);
      error(ps);
    }
    /* get and store a line of penetrance data for each liability class... */
    for (i=0; i<num_liability_classes; i++) {
      fgetln(fp);
      if (sscanf(ln,"%lf %lf %lf",&rnum1,&rnum2,&rnum3)!=3) {
	sf(ps,"bad liability class line (%s) - needs 3 numbers",ln);
	error(ps);
      }
      penetrance[i+1][HOM_UNAFF] = rnum1;
      penetrance[i+1][HET] = rnum2;
      penetrance[i+1][HOM_AFF] = rnum3;
    }
    /* store some disease probabilities */
    init_disease_info();

    /*** End of LINKAGE formatting check, time to actually read the
      marker information ***/

    /**** Read in marker and phenotype information ****/
    for (i=0; i<num_loci; i++) {
      read_linkage_marker(fp,i);
      loci_read++;
    }

    fgetln(fp); while(nullstr(ln)) fgetln(fp); /* gets sex diff. line */
    fgetln(fp); /* list of recombination distances */
    
    /* fill globals with linkage map info */

    num_in_map_order=0;

    array(map_order, num_markers+1, int);
    array(map_distance, num_markers+1, double);
    array(new_order, num_markers+1, int);

    if (num_markers == 1) {
        num_in_map_order=1;
	map_order[0]=0;
    } else {
        /* read in recombination distance from end of file */
        count=0;
        while (itoken(&map_ord_str,iREQUIRED,&this_loc)) {
	  new_order[count] = this_loc;
	  count++;
	}
	if (new_order[0] == 1) {
	  cM_dists=FALSE;
	  /* disease listed first, skip i=0, first distance */
	  if (!rtoken(&ln,rREQUIRED,&dist)) 
	    error("insufficient number of recombination distances");
	  for (i=1; i<count-1; i++) {
	    map_order[i-1] = new_order[i]-2;
	    if (!rtoken(&ln,rREQUIRED,&dist)) 
	        error("insufficient number of recombination distances");
	    map_distance[i-1] = dist;
	    if (dist >= 0.50) cM_dists=TRUE;
	  }
	  map_order[count-2] = new_order[count-1]-2;
	  num_in_map_order=count-1;

	  if (!cM_dists) {
	    for (i=0; i<count-2; i++) 
	      map_distance[i] = rec_to_dist(map_distance[i]);
	  }

	} else {

	  for (i=0; i<count; i++) {
	    if (new_order[i]==1) error("disease locus cannot be in map");
	    map_order[i]=new_order[i]-2;
	  }
	  cM_dists=FALSE;
	  for (i=0; i<count-1; i++) {
	    /* do a better job of conversion here */
	    if (!rtoken(&ln,rREQUIRED,&dist)) 
	      error("insufficient number of recombination distances");
	    map_distance[i] = dist;
	    if (dist >= 0.50) cM_dists=TRUE;
	  }
	  if (!cM_dists) {
	    for (i=0; i<count-1; i++) 
	      map_distance[i] = rec_to_dist(map_distance[i]);
	  }
	  num_in_map_order=count;
	}
    }
    unarray(new_order, int);
    unarray(strptr, char);
  } except {
      when ENDOFILE: 
         sf(ps,"Unexpected end-of-file, only %d of %d markers read\n",
         loci_read,num_loci); pr();
         free_map_structs();
         break;
      default:
         relay_messages;
  }
}


void read_linkage_marker(FILE *fp, int loci_read)
{
  int i, n, type, num1, num2;
  char *word1, *word2;
  double rnum, total_freq;

  run {
    /* Read in the line with marker type and num_alleles */
    fgetln(fp); 
    word1=get_temp_string();
    word2=get_temp_string(); 
    if ((n=sscanf(ln,"%d %d %s %s",&num1,&num2, word1, word2)) < 2) {
      sf(ps,"bad allele number line '%s'",ln); error(ps);
    }

    type = num1;
    if (type == 3) {            /* Marker info */
      
      /* Save marker name */
      if (word1[0] == '#' && n == 4) {
        strcpy(locus[loci_read].name,word2);
      } else {
        sf(word1,"loc%d",loci_read+1); 
        strcpy(locus[loci_read].name,word1);
      }      
      
      /* Read in the line with all the allele frequencies */
      fgetln(fp); 
      total_freq = 0.00;
      for (i=0; i<num2; i++) {
	if (!rtoken(&ln,rREQUIRED,&rnum)) {
	  sf(ps,"not enough allele frequencies for marker %d",loci_read+1);
	  error(ps);
	}
	locus[loci_read].allele_freq[i+1]=rnum;/* alleles are listed 1 to n */
	total_freq+=rnum;
      }

      /* Save other permanent locus info */
      locus[loci_read].allele_sum = total_freq;
      if (total_freq < .99999 || total_freq > 1.00001) {
	sf(ps,"WARNING: allele frequencies for marker %d sum to %.4lf instead of 1.0\n",loci_read+1,total_freq); pr();
      }

      num_markers++;
    }

    else if (type == 0) {     /* Phenotype info */

      /* Save trait name */
      if (word1[0] == '#' && n == 4) {
        strcpy(phenotype[loci_read-num_markers].name,word2);
      } else {
        sf(word1,"phen%d",loci_read-num_markers+1); 
        strcpy(phenotype[loci_read-num_markers].name,word1);
      }      

      fgetln(fp);  /* Skip the next five lines, which contain data for LINKAGE not needed here. */
      fgetln(fp);  /* It would be nice to accomodate files which lack these lines. */
      fgetln(fp);
      fgetln(fp);
      fgetln(fp);      

      num_phenotypes++;
      if (num_phenotypes > MAX_PHENOTYPES)
	error("number of phenotypes exceeds maximum. Try increasing MAX_PHENOTYPES in npl.h");
    }

    else if (type == 4) {    /* Covariate info */
      num_covs++; 
      if (num_covs > MAX_COVARIATES)
	error("number of covariates exceeds maximum. Try increasing MAX_COVARIATES in npl.h");
    }

    else
      error("all loci must have allele number = 0 (phenotypes), 3 (markers), or 4 (covariates)");


  } on_error {
    relay_messages;
  }
}


void free_map_structs(void)
{

  /* Free the structures allocated by load_markers, only
     called if load_markers cannot finish loading the file given */
  unarray(locus, LOCUS_INFO);
  num_markers = 0;

}


void init_disease_info(void) 
{
  /* create a-priori probabilities for originals' disease alleles */
  /* CALLED ONCE when locus information file loaded */
  double tot_aff, tot_unaff, pen_sum[3];
  int i;
  /* liability classes are 1 to N, create a dummy liability class 0
     which will represent unknowns and will have the average of the
     other penetrances */

  pen_sum[HOM_AFF] = pen_sum[HET] = pen_sum[HOM_UNAFF] = 0.0;
  for (i=1; i<=num_liability_classes; i++) {
    pen_sum[HOM_AFF] += penetrance[i][HOM_AFF];
    pen_sum[HET] += penetrance[i][HET];
    pen_sum[HOM_UNAFF] += penetrance[i][HOM_UNAFF];
  }
  penetrance[0][HOM_AFF] = pen_sum[HOM_AFF]/(double)num_liability_classes;
  penetrance[0][HET] = pen_sum[HET]/(double)num_liability_classes;
  penetrance[0][HOM_UNAFF] = pen_sum[HOM_UNAFF]/(double)num_liability_classes;

  for (i=0; i<=num_liability_classes; i++) {
    apriori_disease[i][AFFECTED][HOM_AFF] = 
      affected_freq*affected_freq*penetrance[i][HOM_AFF];
    apriori_disease[i][AFFECTED][HET] = 
      affected_freq*(1.0-affected_freq)*penetrance[i][HET];
    apriori_disease[i][AFFECTED][HOM_UNAFF] = 
      (1.0-affected_freq)*(1.0-affected_freq)*penetrance[i][HOM_UNAFF];

    apriori_disease[i][UNAFFECTED][HOM_AFF] =
      affected_freq*affected_freq*(1.0-penetrance[i][HOM_AFF]);
    apriori_disease[i][UNAFFECTED][HET] =
      affected_freq*(1.0-affected_freq)*(1.0-penetrance[i][HET]);
    apriori_disease[i][UNAFFECTED][HOM_UNAFF] = 
      (1.0-affected_freq)*(1.0-affected_freq)*(1.0-penetrance[i][HOM_UNAFF]);

    apriori_disease[i][UNKNOWN][HOM_AFF] =
      apriori_disease[i][AFFECTED][HOM_AFF]+apriori_disease[i][UNAFFECTED][HOM_AFF];
    apriori_disease[i][UNKNOWN][HET] =
      apriori_disease[i][AFFECTED][HET]+apriori_disease[i][UNAFFECTED][HET]; 
    apriori_disease[i][UNKNOWN][HOM_UNAFF] =
      apriori_disease[i][AFFECTED][HOM_UNAFF]+apriori_disease[i][UNAFFECTED][HOM_UNAFF];
    

    /* apriori_disease for affected and unaffected are not normalized */

    tot_aff = apriori_disease[i][AFFECTED][HOM_AFF]+
             (2.0*apriori_disease[i][AFFECTED][HET])+
	      apriori_disease[i][AFFECTED][HOM_UNAFF];
    if (tot_aff > 0.00000000000001) {
      apriori_disease[i][AFFECTED][HOM_AFF] /= tot_aff;
      apriori_disease[i][AFFECTED][HET] /= tot_aff;
      apriori_disease[i][AFFECTED][HOM_UNAFF] /= tot_aff;
    }

    tot_unaff = apriori_disease[i][UNAFFECTED][HOM_AFF]+
               (2.0*apriori_disease[i][UNAFFECTED][HET])+
		apriori_disease[i][UNAFFECTED][HOM_UNAFF];
    if (tot_unaff > 0.00000000000001) {
      apriori_disease[i][UNAFFECTED][HOM_AFF] /= tot_unaff;
      apriori_disease[i][UNAFFECTED][HET] /= tot_unaff;
      apriori_disease[i][UNAFFECTED][HOM_UNAFF] /= tot_unaff;
    }
  }
}
