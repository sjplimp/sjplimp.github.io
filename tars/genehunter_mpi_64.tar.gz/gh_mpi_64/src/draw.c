/* GENEHUNTER - Kruglyak, Daly, Reeve-Daly, and Lander
   Whitehead Institute for Biomedical Research, Copyright 1996 */
#define INC_LIB
#define INC_SHELL
#include "npl.h"

/*G. Conant added for c++ compile*/
#include <time.h>


typedef struct {
  int num_indiv;
  int indiv[MAX_INDIVIDUALS];
  double x_pos[MAX_INDIVIDUALS];
  bool partner_next[MAX_INDIVIDUALS];
  bool consang_next[MAX_INDIVIDUALS];
  bool same_fam[MAX_INDIVIDUALS]; /* Also TRUE if partner is next */
} GENERATION;

static GENERATION *gen_level;
static int num_levels;		/* Number of generations in the pedigree */
static int num_mom, num_dad;    /* Number of ancestors for mom and dad, used
				   in checking for inbred families */

#define MAX_GENERATIONS 6
#define MALE 1
#define FEMALE 2
#define MISSING -1
#define PATH_LEN 200

static char current_ped[100];
static int ped_size;
static int box_width;
static int center_pedigree;

void fill_generations(void);
void assign_block_size (void);
void assign_x_pos(void);
void draw_postscript_ped(int,int*,int**,int*,int*,int,int**,int,int**);
bool inbred_family (void);
void set_nuclear_families (void);
void mark_originals(void);
bool inbred_mating(int,int);

PED_MEMBER *famtree;

void draw_pedigree(int num_in_ped, int num_markers, int *markers, 
		   char *ped_name, int **alleles_to_draw, int *iv_idx, 
		   int *sorted_famtree, int num_non_orig, int **haplotype,
		   int num_orig, int **inferred)
{
  int i,j,indiv;

  ped_size = num_in_ped;
  strcpy(current_ped,ped_name);

  mark_originals();
  set_nuclear_families();

  array(gen_level,MAX_GENERATIONS,GENERATION);

  fill_generations();
  assign_block_size();
  assign_x_pos();
  draw_postscript_ped(num_markers,markers,alleles_to_draw,iv_idx,
		      sorted_famtree,num_non_orig,haplotype,num_orig,inferred);

  /* Print text debugging output for now */

/**********
  sf(ps,"pedigree '%s' number of generations: %d\n",
     current_ped,num_levels); pr();
  for (i=0; i<num_levels; i++) {
    for (j=0; j<gen_level[i].num_indiv; j++) {
      indiv = gen_level[i].indiv[j];
      sf(ps,"*%s(%d-%.1lf) samefam %d partnext %d consang %d\n*",
	 famtree[indiv].indiv_ID,
	 famtree[indiv].psblock,
	 gen_level[i].x_pos[j],
	 gen_level[i].same_fam[j],
	 gen_level[i].partner_next[j],
	 gen_level[i].consang_next[j]); pr();
    }
    print("\n\n");
  }
**********/

  unarray(gen_level,GENERATION);
}


void fill_generations(void)
{

  int i,j,k,g,m,p,gen;
  int indiv,kid;
  int start_count;
  int part, part1, part2;
  int num_kids;
  bool assigned[MAX_INDIVIDUALS];
  bool all_assigned,non_original_found;
  bool done,ok,inbred;

  for (i=0; i<ped_size; i++)	/* Mark everyone unassigned */
    assigned[i]=FALSE;
  for (i=0; i<MAX_GENERATIONS; i++) {/* Clear out the partner next, sibnext arrays */
    gen_level[i].num_indiv=0;
    for (j=0; j<MAX_INDIVIDUALS; j++) {
      gen_level[i].partner_next[j]=FALSE;
      gen_level[i].same_fam[j]=TRUE;
      gen_level[i].consang_next[j]=FALSE;
    }
  }

  /* Find the people at the top of the pedigree,
     these will be people for whom their parents are missing,
     as well as all their  partners' parents.
     Once we find one, put their partner(s) in as well,
     if the inidvidual has two partners center individual
     between them.  Code does not deal with drawing more than
     two partners for one individual (although strings of 
     marriages are handled).  Inbreeding should be impossible
     at the top level of the pedigree, so we won't check for
     it until we start assigning individuals to the lower 
     generations */

  for (i=0; i<ped_size; i++) {
    if (assigned[i]) continue;
    if (!famtree[i].original) continue;
    /* Individual might be at top level - check that partner(s) 
       are as well */
    if (famtree[i].num_partners == 1) {
      /* Keep the number of individuals at the start in
	 case we find a non-original in a string of partnerships
	 and need to backtrack */
      start_count = gen_level[0].num_indiv;
      part = famtree[i].partner[0];
      if (!famtree[part].original) continue;
      /* Assign individual and partner */
      gen_level[0].indiv[gen_level[0].num_indiv]=i;
      gen_level[0].partner_next[gen_level[0].num_indiv]=TRUE;
      assigned[i]=TRUE;
      gen_level[0].num_indiv++;
      gen_level[0].indiv[gen_level[0].num_indiv]=part;
      assigned[part]=TRUE;
      gen_level[0].num_indiv++;
      /* If the partner has another partner (and that
	 partner has another partner, etc) different
	 from individual i, then we will also take care
	 of that now. */
      done = FALSE;
      while (!done) {
	if (famtree[part].num_partners == 1) {
	  done = TRUE;
	} else if (famtree[part].num_partners > 2) {
	  sf(ps,"In pedigree %s can't draw indiv %s who has %d partners\n",
	     current_ped,famtree[i].indiv_ID,
	     famtree[i].num_partners); error(ps);
	} else if (famtree[part].num_partners == 2) {
	  if (famtree[part].partner[0] == i)
	    part2 = famtree[part].partner[1];
	  else
	    part2 = famtree[part].partner[0];
	  if (famtree[part2].original) {
	    gen_level[0].indiv[gen_level[0].num_indiv]=part2;
	    gen_level[0].partner_next[(gen_level[0].num_indiv)-1]=TRUE;
	    gen_level[0].num_indiv++;
	    assigned[part2]=TRUE;
	    part = part2;
	  } else {
	    /* Non-original found in a string of marriages */
	    gen_level[0].num_indiv = start_count;
	    done = TRUE;
	  }
	}
      }
    } else if (famtree[i].num_partners == 2) {
      /* Check that partners are also missing parents,
	 otherwise not at the top */
      part1 = famtree[i].partner[0];
      part2 = famtree[i].partner[1];
      if (!(famtree[part1].original &&
	    famtree[part2].original)) continue;
      if (famtree[part1].num_partners == 1 &&
	  famtree[part2].num_partners == 1) {
	/* Add one partner, then the individual, then 
	   the other partner */
	gen_level[0].indiv[gen_level[0].num_indiv]=part1;
	gen_level[0].partner_next[gen_level[0].num_indiv]=TRUE;
	assigned[part1]=TRUE;
	gen_level[0].num_indiv++;
	gen_level[0].indiv[gen_level[0].num_indiv]=i;
	gen_level[0].partner_next[gen_level[0].num_indiv]=TRUE;
	assigned[i]=TRUE;
	gen_level[0].num_indiv++;
	gen_level[0].indiv[gen_level[0].num_indiv]=part2;
	assigned[part2]=TRUE;
	gen_level[0].num_indiv++;
      } else if (famtree[part1].num_partners == 2 &&
		 famtree[part2].num_partners == 2) {
	/******* Need to take care of marriage strings here ********/
	/* Check that we haven't found a non-original along the way */
      } else {
	sf(ps,"In pedigree %s can't draw the matings around indiv %s\n",
	   current_ped,famtree[i].indiv_ID); error(ps);
      }
    } else if (famtree[i].num_partners > 2) {
      sf(ps,"In pedigree %s can't draw indiv %s who has %d partners\n",
	 current_ped,famtree[i].indiv_ID,
	 famtree[i].num_partners); error(ps);
    } else {
      /* Individual unlinked to anyone else in the pedigree, ignore */
      assigned[i]=TRUE;
    }
  }

  
  /* Check if the family is inbred.  If it is inbred, we will
     check each mating and mark the consanguinous mating */
  inbred = inbred_family();

  /* Assign the rest of the individuals in the family to
     a level of the pedigree.  Assign all children of the
     top level to the next level, and so on unless an inbred
     mating puts them on a lower level. */
  for (gen=0; gen<MAX_GENERATIONS; gen++) {
    all_assigned=TRUE;
    for (i=0; i<ped_size; i++)
      if (assigned[i] == FALSE) {
	all_assigned=FALSE;
	break;
      }
    if (all_assigned) {
      num_levels = gen+1;
      break;
    }
    for (i=0; i<gen_level[gen].num_indiv; i++) {
      indiv = gen_level[gen].indiv[i];
      /* Find a couple on the level above */
      if (gen_level[gen].indiv[i+1] == 
	  famtree[indiv].partner[0]) part=0;
      else if (gen_level[gen].indiv[i+1] == 
	       famtree[indiv].partner[1]) part=1;
      else continue; /* Singleton child */

      /* Look at all the kids the couple share */
      num_kids = famtree[indiv].nkids_in_nuc[part];
      for (k=0; k<num_kids; k++) {
	/* We can just add kids and their spouse(s), as long
	   as the spouse(s) is an original, if the spouse
	   is non-original then we have to deal with the
	   kid and spouse more carefully (uncle-niece 
	   marriages, kids leading to inbred matings need
	   to be put on the end, families with two branched, etc) */
	kid = famtree[indiv].nuc_family[part][k];
	if (assigned[kid]) continue;

	/*********** figure out how to deal with this section **********/
	ok=TRUE;
	non_original_found=FALSE;
	for (p=0; p<famtree[kid].num_partners; p++) {
	  if (!famtree[famtree[kid].partner[p]].original) {
#ifdef DEBUGGING_OUTPUT
	    sf(ps,"found a non-original spouse mating in pedigree %s\n",
	       current_ped); pr();
#endif
	    non_original_found=TRUE;
	    break;
	  }
	}
	if(non_original_found) {
	  /* If the parents are already assigned then it's OK,
	     otherwise continue */
	  ok=FALSE;
	  for (g=0; g<=gen; g++){
	    for (m=0; m<gen_level[g].num_indiv; m++)
	      if ((gen_level[g].indiv[m] ==
		   famtree[famtree[kid].partner[p]].mom_index) ||
		  (gen_level[g].indiv[m] ==
		   famtree[famtree[kid].partner[p]].dad_index)) {
		ok=TRUE; break;
	      }
	  }
	} 
	if(!ok)continue;
	/*****************************************************************/

	/* Add in kids and spouses in the same manner as above */
	if (famtree[kid].num_partners == 1) {
	  part1 = famtree[kid].partner[0];
	  if (inbred) /*See if this is the inbred mating in an inbred family */
	    if (inbred_mating(kid,part1))
	      gen_level[gen+1].consang_next[gen_level[gen+1].num_indiv]=TRUE;
	  gen_level[gen+1].indiv[gen_level[gen+1].num_indiv]=kid;
	  gen_level[gen+1].partner_next[gen_level[gen+1].num_indiv]=TRUE;
	  assigned[kid]=TRUE;
	  gen_level[gen+1].num_indiv++;
	  gen_level[gen+1].indiv[gen_level[gen+1].num_indiv]=part1;
	  assigned[part1]=TRUE;
	  gen_level[gen+1].num_indiv++;
	  /* If the partner has another partner (and that
	     partner has another partner, etc) different
	     from individual i, then we will also take care
	     of that now. */
	  done = FALSE;
	  while (!done) {
	    if (famtree[part1].num_partners == 1) {
	      done = TRUE;
	    } else if (famtree[part1].num_partners > 2) {
	      sf(ps,"In pedigree %s can't draw indiv %s who has %d partners\n",
		 current_ped,famtree[i].indiv_ID,
		 famtree[i].num_partners); error(ps);
	    } else if (famtree[part1].num_partners == 2) {
	      if (famtree[part1].partner[0] == i)
		part2 = famtree[part1].partner[1];
	      else
		part2 = famtree[part1].partner[0];
	      if (inbred)
		if (inbred_mating(part1,part2))
		  gen_level[gen+1].consang_next[(gen_level[gen+1].num_indiv)-1]=TRUE;
	      gen_level[gen+1].partner_next[(gen_level[gen+1].num_indiv)-1]=TRUE;
	      gen_level[gen+1].indiv[gen_level[gen+1].num_indiv]=part2;
	      gen_level[gen+1].num_indiv++;
	      assigned[part2]=TRUE;
	      part1 = part2;
	    }
	  }
	} else if (famtree[kid].num_partners == 2) {
	  part1 = famtree[kid].partner[0];
	  part2 = famtree[kid].partner[1];
	  gen_level[gen+1].indiv[gen_level[gen+1].num_indiv]=part1;
	  gen_level[gen+1].partner_next[gen_level[gen+1].num_indiv]=TRUE;
	  assigned[part1]=TRUE;
	  gen_level[gen+1].num_indiv++;
	  gen_level[gen+1].indiv[gen_level[gen+1].num_indiv]=kid;
	  gen_level[gen+1].partner_next[gen_level[gen+1].num_indiv]=TRUE;
	  assigned[kid]=TRUE;
	  gen_level[gen+1].num_indiv++;
	  gen_level[gen+1].indiv[gen_level[gen+1].num_indiv]=part2;
	  assigned[part2]=TRUE;
	  gen_level[gen+1].num_indiv++;
	  /*********Deal with strings of marriages here too */
	} else if (famtree[kid].num_partners > 2) {
	  sf(ps,"In pedigree %s can't draw indiv %s who has %d partners\n",
	     current_ped,famtree[kid].indiv_ID,
	     famtree[kid].num_partners); error(ps);
	} else {
	  /* Just put the kid in */
	  gen_level[gen+1].indiv[gen_level[gen+1].num_indiv]=kid;
	  assigned[kid]=TRUE;
	  gen_level[gen+1].num_indiv++;
	}
	if (k == num_kids-1) 
	  gen_level[gen+1].same_fam[gen_level[gen+1].num_indiv-1]=FALSE;
      }
    }
  }
}

void assign_block_size (void)
{
  /* Assign each non-original the block size below
     him/her necessary to accomodate all the ancestors.
     if the kid is a leaf then he will just have block
     size 1, if a kid is a leaf with a spouse he will
     have block size 2 (though this isn't a very useful
     non-original).  Otherwise the kid's block size will
     be the the number of kids if he/she has more than 1 kid,
     or block size 2 if there is 1 kid */

  int i,j,k,indiv,kid;
  int default_ps_block;
  int num_kids;

  for (i=(num_levels-1); i>=0; i--) {
    for (j=0; j<gen_level[i].num_indiv; j++) {
      indiv = gen_level[i].indiv[j];
      if (famtree[indiv].original && i!=0 && j!=0) continue;
      if(famtree[indiv].num_partners == 0) {
	/* Individual has no kids or partners */
	famtree[indiv].psblock = 1;
      } else if (famtree[indiv].num_partners == 1) {
	famtree[indiv].psblock = 0;
	default_ps_block = 2;
	num_kids = famtree[indiv].nkids;
	for (k=0; k<num_kids; k++) {
	  kid = famtree[indiv].nuc_family[0][k];
	  famtree[indiv].psblock += famtree[kid].psblock;
	}
	if (famtree[indiv].psblock < default_ps_block) 
	  famtree[indiv].psblock = default_ps_block;

      } else if (famtree[indiv].num_partners == 2) {
	famtree[indiv].psblock = 0;
	default_ps_block = 3;
	num_kids = famtree[indiv].nkids_in_nuc[0];
	for (k=0; k<num_kids; k++) {
	  kid = famtree[indiv].nuc_family[0][k];
	  famtree[indiv].psblock += famtree[kid].psblock;
	}
	num_kids = famtree[indiv].nkids_in_nuc[1];
	for (k=0; k<num_kids; k++) {
	  kid = famtree[indiv].nuc_family[1][k];
	  famtree[indiv].psblock += famtree[kid].psblock;
	}
	if (famtree[indiv].psblock < default_ps_block) 
	  famtree[indiv].psblock = default_ps_block;
      }
    }
  }

}


void assign_x_pos(void)
{
  /* Determine the x-axis (horizontal) position of each individual
     on the page.  The y-coordinate will be determined by what
     level of the pedigree the individual is at */

  int i,j,gen;
  bool check_parents;
  bool positioned[MAX_INDIVIDUALS];
  double x_pos,parent_x_pos,kid_x_pos[MAX_KIDS],tmp_dbl,middle_parents;
  double position_from_parent;
  int count,indiv,kid;

  /* Hand position the individuals at the top, we'll go
     back and center them over their kids later */
  x_pos = ((double)(famtree[0].psblock)*2.0-2.0)/2.0-1.0;
  gen_level[0].x_pos[0]=x_pos;
  /* Position the person's partner */
  x_pos += 2.0;
  gen_level[0].x_pos[1]=x_pos;
  if (gen_level[0].num_indiv == 3) {
    x_pos += 2.0;
      gen_level[0].x_pos[1]+=2.0;
    x_pos += 7.0;
    gen_level[0].x_pos[2]=x_pos;
  }
  if (gen_level[0].num_indiv == 4) {
    tmp_dbl = (famtree[0].psblock*2.0-2.0)/2.0-1.0;
    tmp_dbl += 2.0;
    tmp_dbl += (famtree[2].psblock*2.0-2.0)/2.0-1.0;
    x_pos += tmp_dbl;
    gen_level[0].x_pos[2]=x_pos;
    x_pos += 2.0;
    gen_level[0].x_pos[3]=x_pos;
  }
  for (gen=1; gen<num_levels; gen++) {
    x_pos = 0.0;
    for (i=0; i<ped_size; i++)
      positioned[i]=FALSE;
    check_parents=TRUE;

    for (i=0; i<gen_level[gen].num_indiv; i++) {
      if (positioned[i]) continue;
      indiv = gen_level[gen].indiv[i];

      /* Treat the first child of each sibship separately,
	 then offset all the others according to the first
	 sib */
     if (check_parents) {
	check_parents=FALSE; parent_x_pos=0.0;
	for (j=0; j<gen_level[gen-1].num_indiv; j++) {
	  if (gen_level[gen-1].indiv[j] ==
	      famtree[indiv].dad_index ||
	      gen_level[gen-1].indiv[j] ==
	      famtree[indiv].mom_index) {
	    parent_x_pos = gen_level[gen-1].x_pos[j];
	    break;
	  }
	}
	/* j is the parent */
	middle_parents = (gen_level[gen-1].x_pos[j+1]-gen_level[gen-1].x_pos[j])/2.0;
	middle_parents += parent_x_pos;
	position_from_parent = 
	  middle_parents-((famtree[gen_level[gen-1].indiv[j]].psblock*2.0-2.0)/2.0);

	if (famtree[gen_level[gen-1].indiv[j]].psblock == 1) {
	  gen_level[gen].x_pos[i]=parent_x_pos+1;
	  x_pos = gen_level[gen].x_pos[i];
	  positioned[i]=TRUE;
	}
	else if (famtree[gen_level[gen-1].indiv[j]].psblock == 2) {
	  if (!gen_level[gen].same_fam[i]) {
	    /* Only child */
	    gen_level[gen].x_pos[i]=parent_x_pos+1;
	    x_pos = gen_level[gen].x_pos[i];
	    positioned[i]=TRUE;
	  } else if (gen_level[gen].partner_next[i] 
		     && (!gen_level[gen].same_fam[i+1])) {
	    /* Married only child */
	    gen_level[gen].x_pos[i]=parent_x_pos+1;
	    x_pos = gen_level[gen].x_pos[i];
	    positioned[i]=TRUE;
	    if (!gen_level[gen].consang_next[i] &&
		famtree[gen_level[gen].indiv[i+1]].original) {
	      x_pos += 2;
	      gen_level[gen].x_pos[i+1]=x_pos;
	      positioned[i+1]=TRUE;
	    } else {
	      /* Inbred or non-original mating, spouse should
		 be positioned under own parents */
	      check_parents=TRUE;
	    }
	  } else if (famtree[indiv].psblock == 2) {
	    /* Child also has family, mark spouse */
	    gen_level[gen].x_pos[i]=parent_x_pos;
	    x_pos = parent_x_pos;
	    positioned[i]=TRUE;
	    /* Position the person's partner */
	    if (!gen_level[gen].consang_next[i] &&
		famtree[gen_level[gen].indiv[i+1]].original) {
	      x_pos += 2;
	      gen_level[gen].x_pos[i+1]=x_pos;
	      positioned[i+1]=TRUE;
	    } else {
	      /* Inbred or non-original mating, spouse should
		 be positioned under own parents */
	      check_parents=TRUE;
	    }
	  } else if (famtree[indiv].psblock >= 2) {
	    /* Child also has family, mark spouse and indent for own family*/
	    x_pos = parent_x_pos;
	    x_pos -= ((double)(famtree[indiv].psblock)*2.0-2.0)/2.0;
	    gen_level[gen].x_pos[i]=x_pos;
	    positioned[i]=TRUE;
	    /* Position the person's partner */
	    if (!gen_level[gen].consang_next[i] &&
		famtree[gen_level[gen].indiv[i+1]].original) {
	      x_pos += 2;
	      gen_level[gen].x_pos[i+1]=x_pos;
	      positioned[i+1]=TRUE;
	    } else {
	      /* Inbred or non-original mating, spouse should
		 be positioned under own parents */
	      check_parents=TRUE;
	    }
	  } else {
	    gen_level[gen].x_pos[i]=parent_x_pos;
	    x_pos = parent_x_pos;
	    positioned[i]=TRUE;
	  }
	} else {
	  /*
	  tmp_dbl = (double)(famtree[gen_level[gen-1].indiv[j]].psblock);
	  x_pos = parent_x_pos+1.0-((tmp_dbl*2.0-2.0)/2.0);
	  gen_level[gen].x_pos[i]=x_pos;
	  */
	  x_pos = position_from_parent;
	  gen_level[gen].x_pos[i]=x_pos;

	  positioned[i]=TRUE;
	  if (famtree[indiv].psblock >=2) {
	    if (famtree[indiv].psblock > 2) {
	      x_pos+=((double)(famtree[indiv].psblock)*2.0-2.0)/2.0;
	      gen_level[gen].x_pos[i]=x_pos;
	    }
	    if (!gen_level[gen].consang_next[i] &&
		famtree[gen_level[gen].indiv[i+1]].original) {
	      x_pos += 2;
	      gen_level[gen].x_pos[i+1]=x_pos;
	      positioned[i+1]=TRUE;
	    } else {
	      /* Inbred or non-original mating, spouse should
		 be positioned under own parents */
	      check_parents=TRUE;
	    }
	  }
	}
      } else if (famtree[indiv].psblock == 1 &&
		 famtree[gen_level[gen].indiv[i-1]].psblock == 1) {
	x_pos += 2.0;
	gen_level[gen].x_pos[i]=x_pos;
	positioned[i]=TRUE;
      } else if (famtree[indiv].psblock > 1 &&
		 famtree[gen_level[gen].indiv[i-1]].psblock == 1) {
	x_pos += 2;
	tmp_dbl = (double)(famtree[indiv].psblock);
	x_pos += (tmp_dbl*2.0-2.0)/2.0-1.0;
	gen_level[gen].x_pos[i]=x_pos;
	positioned[i]=TRUE;
	/* Position the person's partner */
	if (!gen_level[gen].consang_next[i] &&
	    famtree[gen_level[gen].indiv[i+1]].original) {
	  x_pos += 2;
	  gen_level[gen].x_pos[i+1]=x_pos;
	  positioned[i+1]=TRUE;
	} else {
	  /* Inbred or non-original mating, spouse should
	     be positioned under own parents */
	  check_parents=TRUE;
	}
      } else if (famtree[indiv].psblock == 1 &&
		 famtree[gen_level[gen].indiv[i-2]].psblock > 1) {
	x_pos +=2;
	tmp_dbl = (double)(famtree[gen_level[gen].indiv[i-2]].psblock);
	x_pos += (tmp_dbl*2.0-2.0)/2.0-1.0;
	gen_level[gen].x_pos[i]=x_pos;
	positioned[i]=TRUE;
      } else if (famtree[indiv].psblock > 1 &&
		 famtree[gen_level[gen].indiv[i-2]].psblock > 1) {
	tmp_dbl = (double)(famtree[gen_level[gen].indiv[i-2]].psblock);
	x_pos += (tmp_dbl*2.0-2.0)/2.0+1.0;
	x_pos += ((double)(famtree[indiv].psblock)*2.0-2.0)/2.0-1.0;
	gen_level[gen].x_pos[i]=x_pos;
	positioned[i]=TRUE;
	/* Position the person's partner */
	if (!gen_level[gen].consang_next[i] &&
	    famtree[gen_level[gen].indiv[i+1]].original) {
	  x_pos += 2;
	  gen_level[gen].x_pos[i+1]=x_pos;
	  positioned[i+1]=TRUE;
	} else {
	  /* Inbred or non-original mating, spouse should
	     be positioned under own parents */
	  check_parents=TRUE;
	}
      } else {
#ifdef DEBUGGING_OUTPUT
	sf(ps,"found a case not dealt with at indiv %s\n",
	   famtree[indiv].indiv_ID); pr();
#endif
      }
      if (!gen_level[gen].same_fam[i]) 
	check_parents=TRUE;

    }
  }  

  /* Re-center top level individuals */
  count = 0;
  indiv = gen_level[0].indiv[0];
  for (j=0; j<gen_level[1].num_indiv; j++) {
    kid = gen_level[1].indiv[j];
    if (famtree[kid].dad_index == indiv ||
	famtree[kid].mom_index == indiv) {
      kid_x_pos[count]=gen_level[1].x_pos[j];
      count++;
    }
  }
  if (count > 1) {
    gen_level[0].x_pos[0]=
      fabs((kid_x_pos[count-1]-kid_x_pos[0]))/2.0-1.0+kid_x_pos[0];
    gen_level[0].x_pos[1]=
      fabs((kid_x_pos[count-1]-kid_x_pos[0]))/2.0+1.0+kid_x_pos[0];
  }
  if (gen_level[0].num_indiv == 4) {
    count = 0;
    indiv = gen_level[0].indiv[2];
    for (j=0; j<gen_level[1].num_indiv; j++) {
      kid = gen_level[1].indiv[j];
      if (famtree[kid].dad_index == indiv ||
	  famtree[kid].mom_index == indiv) {
	kid_x_pos[count]=gen_level[1].x_pos[j];
	count++;
      }
    }
    if (count > 1) {
      gen_level[0].x_pos[2]=
	fabs((kid_x_pos[count-1]-kid_x_pos[0]))/2.0-1.0+kid_x_pos[0];
      gen_level[0].x_pos[3]=
	fabs((kid_x_pos[count-1]-kid_x_pos[0]))/2.0+1.0+kid_x_pos[0];
    }
  }
}



void draw_postscript_ped(int num_markers,int *markers,int **alleles_to_draw,
			 int *iv_idx, int *sorted_famtree, int num_non_orig,
			 int **haplotype, int num_orig, int **inferred)
{

  FILE *fp;
  int i,j,gen,indiv,kid;
  int box_size;
  double x_increment;
  int y_value;
  char *outfile,label[100],tmp_label[10];
  double fill;
  int count;
  double kid_x_pos[MAX_KIDS],y_increment;
  double tmp_dbl, geno_increment,geno_space;
  int marker;
  double min_x_pos, max_x_pos, roman_pos;
  int genos_drawn;
  int allele1,allele2;
  char trans_allele[MAX_INDIVIDUALS*2];
  bool crossL,crossR;
  int cross_bits;
  int Lbit,Rbit,sort_pos;
  time_t now;

  box_width = 15;
  center_pedigree = TRUE;

  /* Set up the translation between place holder allele
     indices and their letter equivalents */
  for (i=0; i<MAX_INDIVIDUALS*2; i++)
    if (i%2 == 0) trans_allele[i]= 'A'+(i/2);
    else          trans_allele[i]= 'a'+(i/2);


  /* Actually write the postscript to a file */
  array(outfile,PATH_LENGTH,char);
  count=0;
  strcpy(outfile,"");
  for (i=0; i<strlen(current_ped); i++)
    if (current_ped[i] != '/') {  /* REMOVED ALNUM CHECK - MJD 6/98 */
      outfile[count]=current_ped[i];
      count++;
    }
  strcat(outfile,".ps");
  fp = open_postscript_file(outfile, "pedigree");
  unarray(outfile,char);

  
  ps_file_start(fp);
  ps_page_start(fp,1);

  fprintf(fp,"%d %d translate\n",512,72);
  fprintf(fp,"90 rotate\n");
  fprintf(fp,"0 0 moveto\n");

  /* Print the header information in the upper lefthand corner */
  now = time((time_t *) 0);
  sf(label,"Date run: %s",ctime(&now));
  fprintf(fp,"GS -54 483 moveto /Times-Roman FF 9 SF F(%s)S GR\n",label);
  sf(label,"Filename: %s",current_filename);
  fprintf(fp,"GS -54 470 moveto /Times-Roman FF 9 SF F(%s)S GR\n",label);
  sf(label,"Pedigree: %s",current_ped);
  fprintf(fp,"GS -54 457 moveto /Times-Roman FF 9 SF F(%s)S GR\n",label);
  fprintf(fp,"GS -18 444 moveto /Times-Roman FF 9 SF F(Markers:)SR GR\n",label);
  for (i=0; i<num_markers; i++) {
    sf(tmp_label,"%d",markers[i]+1);
    fprintf(fp,"GS %.1lf 444 moveto /Times-Roman FF 9 SF F(%s)CS GR\n",
	    ((double)i*10.0)-8.5,tmp_label);
  }

  /* Print haplotypes (actual alleles defined by letters) */
  for (j=0; j<2*num_orig; j++) {
    fprintf(fp,"GS -18 %d moveto /Times-Roman FF 9 SF F(%c:)SR GR\n",
	    431-(j*12),trans_allele[j]);
    for (i=0; i<num_markers; i++) {
      if (haplotype[j][markers[i]] == 0) sf(tmp_label,"-");
      else sf(tmp_label,"%d",haplotype[j][markers[i]]);
      fprintf(fp,"GS %.1lf %d moveto /Times-Roman FF 9 SF F(%s)CS GR\n",
	      ((double)i*10.0)-8.5, 431-(j*12), tmp_label);
    }
  }
  /*****
  fprintf(fp,"GS -54 %d moveto /Times-Roman FF 9 SF F(haplo ratio = %.4lf)S GR\n",
	  457-(j*13), haplo_ratio);
  *****/
  /* Draw */
  box_size = (570*2)/(num_levels*(6+num_markers)); /* Scale the box by looking at
						      the number of levels and markers
						      in the y direction */
  
/*  sf(ps,"box size %d\n",box_size); pr(); */
  if (box_size > 20) box_size=20;
  x_increment = box_size+2;
  y_increment = box_size*3;
  geno_increment = 0.0;		/* Size to allow for the genotypes */
  geno_space = box_size/2.0;	/* White space around the genotypes */
  if (num_markers > 0) {
    /* make room for font for each genotype going
       vertically downward */
    geno_increment = (double)(num_markers)*geno_space;
  }

  min_x_pos = 999.0; max_x_pos = -999.0;
  for (gen=0; gen<num_levels; gen++) {
    for (i=0; i<gen_level[gen].num_indiv; i++) {
      if (gen_level[gen].x_pos[i] > max_x_pos) {
	max_x_pos = gen_level[gen].x_pos[i];
      } else if (gen_level[gen].x_pos[i] < min_x_pos) {
	min_x_pos = gen_level[gen].x_pos[i];
      }
    }
  }
  if (center_pedigree) {
    if (min_x_pos >= 0)
      fprintf(fp,"%.1lf 0 translate\n",
	      (648-(max_x_pos-min_x_pos)*x_increment)/2.0-min_x_pos*x_increment);
    else
      fprintf(fp,"%.1lf 0 translate\n",
	      (648-(max_x_pos+fabs(min_x_pos))*x_increment)/2.0+fabs(min_x_pos)*x_increment);
  } else {
    if (min_x_pos > 0)
      fprintf(fp,"%.1lf 0 translate\n",
	      (-min_x_pos)*x_increment);
    else if (min_x_pos < 0)
      fprintf(fp,"%.1lf 0 translate\n",
	      fabs(min_x_pos)*x_increment);
  }
  fprintf(fp,"0 0 moveto\n");
  roman_pos = min_x_pos*x_increment-54;


  y_value = 470;
  genos_drawn = 0;
  for (gen=0; gen<num_levels; gen++) {
    if (gen > 0)
      y_value -= y_increment;
    genos_drawn++;
    if (gen > 0)
      y_value -=geno_increment;
    geno_increment = (double)(num_markers)*geno_space;

    for (i=0; i<gen_level[gen].num_indiv; i++) {
      indiv = gen_level[gen].indiv[i];
      if (!famtree[indiv].original && !famtree[indiv].discard) {
	for (j=0; j<num_non_orig; j++) 
	  if (sorted_famtree[j] == indiv) {
	    sort_pos = j;
	    break;
	  }
	Lbit = 2*num_non_orig-1-(sort_pos*2);
	Rbit = 2*num_non_orig-2-(sort_pos*2);
      }
      if (num_markers > 0 && !famtree[indiv].discard) {
	for (j=0; j<num_markers; j++) {
	  marker = markers[j];
	  crossL = FALSE;
	  crossR = FALSE;
	  if (!famtree[indiv].original && j>0) {
	    cross_bits = iv_idx[j-1]^iv_idx[j];
	    crossL = (cross_bits>>Lbit)%2;
	    crossR = (cross_bits>>Rbit)%2;
	  }
	  /* Write out the persons genotypes */
	  allele1 = alleles_to_draw[indiv][j*2];	    
	  if (use_letters)
	    fprintf(fp,"GS %0.1lf %0.1lf moveto /Times-%s FF %d SF F(%c)S GR\n",
		    gen_level[gen].x_pos[i]*x_increment-geno_space,
		    y_value - (y_increment/2.0) - geno_space*j,
		    (inferred[indiv][j*2] ? "Italic" : "Bold"),
		    (int)(geno_space-1.0), trans_allele[allele1]);
	  else
	    fprintf(fp,"GS %0.1lf %0.1lf moveto /Times-%s FF %d SF F(%d)S GR\n",
		    gen_level[gen].x_pos[i]*x_increment-geno_space,
		    y_value - (y_increment/2.0) - geno_space*j,
		    (inferred[indiv][j*2] ? "Italic" : "Bold"),
		    (int)(geno_space-1.0), haplotype[allele1][markers[j]]);

	  if (crossL) {
	    fprintf(fp,"GS %0.1lf %0.1lf moveto /Times-Bold FF %d SF F(x)S GR\n",
		    gen_level[gen].x_pos[i]*x_increment-geno_space-(geno_space/2.0),
		    y_value - (y_increment/2.0) - geno_space*j + geno_space/2.0,
		    (int)(geno_space-2.0));
	  }

	  allele2 = alleles_to_draw[indiv][j*2+1];	
	  if (use_letters)
	    fprintf(fp,"GS %0.lf %0.1lf moveto /Times-%s FF %d SF F(%c)S GR\n",
		    gen_level[gen].x_pos[i]*x_increment+(geno_space/2.0),
		    y_value - (y_increment/2.0) - geno_space*j,
		    (inferred[indiv][j*2+1] ? "Italic" : "Bold"),
		    (int)(geno_space-1.0), trans_allele[allele2]);
	  else
	    fprintf(fp,"GS %0.lf %0.1lf moveto /Times-%s FF %d SF F(%d)S GR\n",
		    gen_level[gen].x_pos[i]*x_increment+(geno_space/2.0),
		    y_value - (y_increment/2.0) - geno_space*j,
		    (inferred[indiv][j*2+1] ? "Italic" : "Bold"),
		    (int)(geno_space-1.0), haplotype[allele2][markers[j]]);

	  if (crossR) {
	    fprintf(fp,"GS %0.lf %0.1lf moveto /Times-Bold FF %d SF F(x)S GR\n",
		    gen_level[gen].x_pos[i]*x_increment+(geno_space/2.0)*2,
		    y_value - (y_increment/2.0) - geno_space*j + geno_space/2.0,
		    (int)(geno_space-2.0));
	  }
	  /* if (famtree[indiv].original) break; */
	}
      }
      if (famtree[indiv].affectation_status == 0) 
	fill = GRAY;
      else if (famtree[indiv].affectation_status == 1) 
	fill = WHITE;
      else if (famtree[indiv].affectation_status == 2) 
	fill = BLACK;
      if (famtree[indiv].sex == MALE) {
	draw_centered_rect(fp,(gen_level[gen].x_pos[i]*x_increment),
			   (double)y_value, x_increment, x_increment, 
			   fill, 
			   famtree[indiv].indiv_ID,
			   (int)geno_space);
      } else {
	draw_circle(fp,(gen_level[gen].x_pos[i]*x_increment),
		    (double)y_value, x_increment,
		    fill,
		    famtree[indiv].indiv_ID,
		    (int)geno_space);
      }
      if (gen_level[gen].partner_next[i]) {
	/* Draw a horizontal line connecting partners (or two
	   horizontal lines for a consanguinous mating */
	fprintf(fp,"%.2lf %.2lf moveto\n",
		(gen_level[gen].x_pos[i]*x_increment)+(x_increment/2.0),
		(double)y_value);
	fprintf(fp,"GS 0.5 LW %.2lf %.2lf lineto stroke GR\n",
		(gen_level[gen].x_pos[i+1]*x_increment)-(x_increment/2.0),
		(double)y_value);
	if (gen_level[gen].consang_next[i]) {
	  fprintf(fp,"%.2lf %.2lf moveto\n",
		  (gen_level[gen].x_pos[i]*x_increment)+(x_increment/2.0),
		  (double)y_value+3.0);
	  fprintf(fp,"GS 0.5 LW %.2lf %.2lf lineto stroke GR\n",
		  (gen_level[gen].x_pos[i+1]*x_increment)-(x_increment/2.0),
		  (double)y_value+3.0);
	}
	/* Store the x_pos of each kid */
	count = 0;
	min_x_pos = 999.0; max_x_pos = -999.0;
	for (j=0; j<gen_level[gen+1].num_indiv; j++) {
	  kid = gen_level[gen+1].indiv[j];
	  if ((famtree[kid].dad_index==indiv 
	       && famtree[kid].mom_index == gen_level[gen].indiv[i+1]) ||
	      (famtree[kid].mom_index==indiv 
	       && famtree[kid].dad_index == gen_level[gen].indiv[i+1])) {
	    kid_x_pos[count]=gen_level[gen+1].x_pos[j];
	    if (kid_x_pos[count] > max_x_pos) 
	      max_x_pos = kid_x_pos[count];
	    if (kid_x_pos[count] < min_x_pos)
	      min_x_pos = kid_x_pos[count];
	    count++;
	  }
	}
	/* Draw the horizontal line over the kids */
	fprintf(fp,"%.2lf %.2lf moveto\n",
		(min_x_pos*x_increment),
		(double)y_value-(y_increment/2.0)-geno_increment);
	fprintf(fp,"GS 0.5 LW %.2lf %.2lf lineto stroke GR\n",
		(max_x_pos*x_increment),
		(double)y_value-(y_increment/2.0)-geno_increment);
	/* Draw the connecting vertical line */
	if (gen_level[gen].x_pos[i+1]-gen_level[gen].x_pos[i] > 2) {
	  tmp_dbl = (gen_level[gen].x_pos[i+1]-gen_level[gen].x_pos[i])/2.0;
	  tmp_dbl += gen_level[gen].x_pos[i];
	  tmp_dbl *= x_increment;
	} else {
	  tmp_dbl = gen_level[gen].x_pos[i]*x_increment+x_increment;
	}
	fprintf(fp,"%.2lf %.2lf moveto\n",tmp_dbl,(double)y_value);
	fprintf(fp,"GS 0.5 LW %.2lf %.2lf lineto stroke GR\n",
		tmp_dbl,(double)y_value-(y_increment/2.0)-geno_increment);
	/* For each kid, draw a vertical line from the sib-bar to the kid */
	for (j=0; j<count; j++) {
	  fprintf(fp,"%.2lf %.2lf moveto\n",
		  (kid_x_pos[j]*x_increment),
		  (double)y_value-(y_increment/2.0)-geno_increment);
	  fprintf(fp,"GS 0.5 LW %.2lf %.2lf lineto stroke GR\n",
		  (kid_x_pos[j]*x_increment),
		  (double)y_value-y_increment-geno_increment);
	}
      }
    }
  }
  
  ps_page_end(fp,1);
  ps_file_end(fp);
  close_file(fp);
}


bool inbred_family (void)
{
  /* Return TRUE if the pedigree is inbred */
  
  int i,j,k,num_in_ped;
  int mom,dad;
  int *mom_anc, *dad_anc;
  bool checked[MAX_INDIVIDUALS],inbred=FALSE;

  array(mom_anc,MAX_INDIVIDUALS,int);
  array(dad_anc,MAX_INDIVIDUALS,int);

  num_in_ped = ped_size;

  for (i=0; i<num_in_ped; i++)
    checked[i]=FALSE;

  /* If a person has > 0 kids make a list of the
     person's ancestors and the partner(s)'s ancestors
     and make sure they have none in common */
  for (i=0; i<num_in_ped; i++) {
    if (checked[i]) continue;
    if (famtree[i].nkids <= 0) continue;
    for (j=0; j<num_in_ped; j++){
      if (famtree[j].dad_index == i ||
	  famtree[j].mom_index == i)
	break;			/* Kid found */
    }
    mom = famtree[j].mom_index;
    dad = famtree[j].dad_index;
      
    /* Make a list of each parents ancestors */
    num_mom=0;
    num_dad=0;
    get_mat_ancestors(mom,mom_anc);
    get_pat_ancestors(dad,dad_anc);
    /* Compare the lists */
    for (k=0; k<num_mom; k++) {
      if (inbred) break;
      for (j=0; j<num_dad; j++) {
	if (mom_anc[k] == dad_anc[j]) {
	  inbred=TRUE;
	  break;
	}
      }
    }
  }

  unarray(mom_anc,int);
  unarray(dad_anc,int);
  
  return(inbred);
}
     

bool inbred_mating(int part1, int part2)
{
  
  int j,k;
  int *mom_anc, *dad_anc;
  int mom,dad;
  bool inbred;

  /* just assign mom and dad from the partners */
  mom = part1; dad = part2;

  array(mom_anc,MAX_INDIVIDUALS,int);
  array(dad_anc,MAX_INDIVIDUALS,int);

  /* Make a list of each parents ancestors */
  num_mom=0;
  num_dad=0;
  get_mat_ancestors(mom,mom_anc);
  get_pat_ancestors(dad,dad_anc);
  /* Compare the lists */
  inbred=FALSE;
  for (k=0; k<num_mom; k++) {
    if (inbred) break;
    for (j=0; j<num_dad; j++) {
      if (mom_anc[k] == dad_anc[j]) {
	inbred=TRUE;
	break;
      }
    }
  }
  unarray(mom_anc,int);
  unarray(dad_anc,int);
  
  return(inbred);
}


void mark_originals(void)
{
  /* Flag the original individuals in a pedigree */

  int i;
  for (i=0; i<ped_size; i++) {
    if (famtree[i].dad_index == MISSING &&
	famtree[i].mom_index == MISSING)
      famtree[i].original=TRUE;
    else
      famtree[i].original=FALSE;
  }

}

void set_nuclear_families (void)
{

  int i,j,k,*checked;
  int mom,dad;
  int nkids,new_nkids,kids[MAX_KIDS],num_kids;
  int mom_partners,dad_partners,mom_members,dad_members;

  array(checked,ped_size,int);
  /* Mark everyone in the pedigree unchecked at the start */
  for (i=0; i<ped_size; i++) {
    checked[i]=FALSE;		
  }

  for (i=0; i<ped_size; i++) {
    famtree[i].num_partners=0;
    for (j=0; j<MAX_PARTNERS; j++)
      famtree[i].nkids_in_nuc[j]=0;
  }

  for (i=0; i<ped_size; i++) {

    if (checked[i]) continue;

    nkids = famtree[i].nkids;

    if (nkids > 0) {
      /* Fill in the kid_index array */
      num_kids = 0;
      for (j=0; j<ped_size; j++) {
	if (num_kids == nkids) break;
	if (famtree[j].dad_index == i ||
	    famtree[j].mom_index == i) {
	  famtree[i].kid_index[num_kids]=j;
	  num_kids++;
	}
      }


      dad = famtree[famtree[i].kid_index[0]].dad_index;
      mom = famtree[famtree[i].kid_index[0]].mom_index;
      /* Count up the kids these two parents have in common and make a list */
      new_nkids=0;
      for (k=0; k<nkids; k++) {
	if ((dad == 
	     famtree[famtree[i].kid_index[k]].dad_index) &&
	    (mom == 
	     famtree[famtree[i].kid_index[k]].mom_index)) {
	  /* Only use the kids if they have the same parents, if half-sibs we'll
	     deal with each half separately */
	  if (new_nkids < MAX_KIDS) {
	    kids[new_nkids]=famtree[i].kid_index[k];
	    new_nkids++;
	  } else {
	    sf(ps,"Too many kids for mother %s and father %s\n",
	       famtree[mom].indiv_ID,
	       famtree[dad].indiv_ID); error(ps);
	  }
	}
      }

      /* Record these parents as checked */
      checked[dad]=TRUE; checked[mom]=TRUE;

      /* Record the kids in the nuclear family */

      /* Record the partners for Mom and Dad */
      mom_partners = famtree[mom].num_partners;
      if(mom_partners < MAX_PARTNERS) {
	famtree[mom].partner[mom_partners] = dad;
	for (k=0; k<new_nkids; k++) {
	  mom_members = famtree[mom].nkids_in_nuc[mom_partners];
	  famtree[mom].nuc_family[mom_partners][mom_members]=kids[k];
	  famtree[mom].nkids_in_nuc[mom_partners]++;
	}
	famtree[mom].num_partners++;
      } else {
	sf(ps,"mother %s has children with too many different fathers\n",
	   famtree[mom].indiv_ID); error(ps);
      }
      dad_partners = famtree[dad].num_partners;
      if(dad_partners < MAX_PARTNERS) {
	famtree[dad].partner[dad_partners] = mom;
	for (k=0; k<new_nkids; k++) {
	  dad_members = famtree[dad].nkids_in_nuc[dad_partners];
	  famtree[dad].nuc_family[dad_partners][dad_members]=kids[k];
	  famtree[dad].nkids_in_nuc[dad_partners]++;
	}
	famtree[dad].num_partners++;
      } else {
	sf(ps,"father %s has children with too many different mothers\n",
	   famtree[dad].indiv_ID); error(ps);
      }
    }

  }

  unarray(checked,int);
}


FILE* open_postscript_file(char *default_file, char *purpose)
{

  char *out_file,*tmp;
  bool valid;
  FILE *fp;

  array(out_file, PATH_LEN+1, char);

  valid = FALSE;
  while(!valid) {
    fp = NULL;
    tmp = get_temp_string();
    sf(ps,"file to store %s plot [%s]: ",purpose, default_file);
    input(ps,tmp,TEMP_STRING_LEN);
    if (!nullstr(tmp)) {
      run {
	nstrcpy(out_file,tmp,PATH_LEN);
	/* User has specified a file */
	fp = open_file(out_file,"r");
	sf(ps," file '%s' already exists, overwrite? y/n [n]: ",
	   out_file);
	close_file(fp);
	tmp = get_temp_string();
	input(ps,tmp,TEMP_STRING_LEN);
	if (tmp[0] == 'y' || tmp[0] == 'Y') {
	  run {
	    fp = open_file(out_file,"w");
	    valid = TRUE;
	  } except_when(CANTOPEN) {
	    print("can't write to that file, try again/n");
	  }
	}
      } except_when(CANTOPEN) {
	run {
	  fp = open_file(out_file,"w");
	  valid = TRUE;
	} except_when(CANTOPEN) {
	  sf(ps," can't open file %s, try again\n"); pr();
	}
      }
    } else {
      /* Use the default filename */
      run {
	fp = open_file(default_file,"r");
	sf(ps," file '%s' already exists, overwrite? y/n [n]: ",
	   default_file);
	close_file(fp);
	tmp = get_temp_string();
	input(ps,tmp,TEMP_STRING_LEN);
	if (tmp[0] == 'y' || tmp[0] == 'Y') {
	  run {
	    fp = open_file(default_file,"w");
	    valid = TRUE;
	  } except_when(CANTOPEN) {
	    print("can't write to that file, try again/n");
	  }
	}
      } except_when (CANTOPEN) {
	run {
	  fp = open_file(default_file,"w");
	  valid=TRUE;
	} except_when (CANTOPEN) {
	  sf(ps,
	     " can't open file '%s' (maybe permission problem?) try again\n",
	     default_file); pr();
	}
      }
    }
  }

  unarray(out_file, char);
  return(fp);
}

