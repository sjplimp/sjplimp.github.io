#include "system.h"

#define MAX_ALLELES 110
#define MAX_FAMILIES 500
#define MAX_LOCI 110
#define NAME_LEN 20
#define MAX_MEMBERS 50

#define MISSING -1

typedef struct {
    char indiv_ID[NAME_LEN];
    char dad_ID[NAME_LEN], mom_ID[NAME_LEN];
    int dad_index, mom_index;
    int sex;
    int nkids;
    
    int real_disease; /* the real disease allele status */
    int affectation_status;
    int genotype[MAX_LOCI][2];

    int disease_genotype[2]; /* for random family simulation */

    int discard;
    int is_pivot;
    int inh_vec_pos;
    double disease_prob[4];

} PED_MEMBER;

typedef struct {
  int dad, mom;
  int num_kids;
  int kid[MAX_MEMBERS];
  int pivot;
} NUC_FAMILY;


/* actual disease alleles */
#define HOM_UNAFF 0
#define HOM_AFF 1
#define HET 2
#define HET_UA 2
#define HET_AU 3
/* for X-linked disease loci in males */
#define HEMI_U 4
#define HEMI_A 5

/* affectation status */
#define UNAFFECTED  1
#define AFFECTED    2
#define UNKNOWN     0

/* globals, etc */
extern int num_markers, num_families;

extern double *map_position, **allele_prob;
extern int *num_alleles;

extern double penetrance[3], affected_freq, disease_position;
extern double disease_prob[3][3];

extern PED_MEMBER **family;
extern char **family_name;
extern int *num_members;

extern int pedigree_copies, simulate_X;
extern double error_rate;
extern double missing_rate;

extern int generating_method;
#define USE_PEELING 0
#define USE_RANDGEN 1

extern double heterogeneity_alpha;

extern int gen_phenos;

/* commands */
void enter_map(void);
void show_map(void);
void do_simulation(void);
void set_disease_info(void);
void set_X_simulation(void);
void set_error_rate(void);
void set_missing_rate(void);
void set_disease_generation(void);
void set_heterogeneity(void);
void set_gen_phenos(void);
