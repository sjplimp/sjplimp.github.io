/******************************************************************************

 #    #    ##       #    #    #           ####
 ##  ##   #  #      #    ##   #          #    #
 # ## #  #    #     #    # #  #          #
 #    #  ######     #    #  # #   ###    #
 #    #  #    #     #    #   ##   ###    #    #
 #    #  #    #     #    #    #   ###     ####

******************************************************************************/
/* pirated from MAPMAKER...call shell for simulator code */

#define INC_LIB
#define INC_SHELL
#include "gensim.h"

void setup_commands(void), init_variables(void);

/* extern char help_filename[];*/

main(int argc, char **argv)
{
    char *version, help_filename[PATH_LENGTH+1];
    FILE *fp;

    custom_lib_init();
    tty_hello();
    seedrand(RANDOM);

    strcpy(help_filename,"sim.help"); 
    shell_init("GENSIM - pedingree linkage data simulator",
	       "0.9","1995",help_filename);
    banner();

    photo_banner_hook= NULL;
    quit_save_hook= NULL;

    setup_commands();

    init_variables(); /* startup values for global variables - gensim.c */

    /* make_help_entries(); - uncomment when help available */

    /***** place any init calls here *****/
    /***** once in command loop, you will be in the shell *****/

    command_loop();

    exit_main();
}


void setup_commands(void)
{

    /*  command-name	             Abbrev	function	   	type  
	1234567890123456789012345    123	12345678901234...  	123
	------------------------- sp ---  tab   --------------	  tab   --- 
    mc("dietrichs unreadable gels", "dug",	blow_dead_bears,	CMD);*/

    mc("quit",                       "q",	quit,            	CMD);
    mc("photo",                      "",	do_photo,        	CMD);
    mc("system",                     "",	system_command,  	CMD);
    mc("change directory",           "cd",	cd_command,      	CMD);
    mc("run",                        "",	run_from_file,   	CMD);
    mc("time",                       "",	show_time,       	CMD);
    mc("help",                       "?",       help,                   CMD);

    /* put command calls here */
    mc("setup map",                  "",        enter_map,              CMD);
    mc("show map",                   "",        show_map,               CMD);
    mc("simulate",                   "",        do_simulation,          CMD);
    mc("set disease",                "",        set_disease_info,       CMD);
    mc("X simulation",               "x",       set_X_simulation,       CMD);
    mc("error rate",                 "",        set_error_rate,         CMD);
    mc("missing rate",               "",        set_missing_rate,       CMD);
    mc("gen method",                 "gm",      set_disease_generation, CMD);
    mc("heterogeneity",              "",        set_heterogeneity,      CMD);
    mc("phenotypes",                 "",        set_gen_phenos,         CMD);
}

