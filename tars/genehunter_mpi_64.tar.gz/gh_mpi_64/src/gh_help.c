/* MAPMAKER help code file - do not edit! */ 

#define INC_LIB 
#define INC_SHELL 
#include "system.h" 

void make_help_entries()
{
 mkhelp("load markers","",79l,EXACTLY,1,CMD,1,
        "Load marker-locus data",
        "<file name>",
        "");
 mkhelp("use","",1682l,UPTO,1,CMD,1,
        "Select the current map for analysis",
        "<genetic map>",
        "displays the current map selected");
 mkhelp("scan pedigrees","",2815l,EXACTLY,1,CMD,2,
        "Analyze pedigree data",
        "<file name>",
        "");
 mkhelp("total stat","",5617l,UPTO,2,CMD,2,
        "Show total scores from a scan of multiple pedigrees",
        "<'het'> <fixed-alpha>",
        "");
 mkhelp("single point","",6765l,UPTO,1,CMD,2,
        "activate/deactive single-point analysis",
        "<'on' or 'off'>",
        "displays the current setting");
 mkhelp("count recs","",7216l,UPTO,1,CMD,2,
        "turn recombination counting on",
        "<'on' or 'off'>",
        "displays the current setting");
 mkhelp("haplotype","",8076l,UPTO,1,CMD,2,
        "determine likely haplotypes for individuals",
        "<'on' or 'off'>",
        "displays the current setting");
 mkhelp("discard","",10504l,UPTO,1,CMD,2,
        "eliminate less informative individuals",
        "<'on' or 'off'>",
        "displays the current setting");
 mkhelp("max bits","mb",11286l,UPTO,1,CMD,2,
        "determine how large a pedigree may be analyzed",
        "<number of bits>",
        "displays the current setting");
 mkhelp("skip large","",12353l,UPTO,1,CMD,2,
        "determine how large pedigrees are dealt with",
        "<'on' or 'off'>",
        "displays the current setting");
 mkhelp("analysis","",13622l,UPTO,1,CMD,2,
        "select what type of linkage analysis to perform",
        "<'NPL', 'LOD', or 'BOTH'>",
        "displays the current setting");
 mkhelp("score","",14162l,UPTO,1,CMD,2,
        "select NPL scoring function",
        "<'pairs' or 'all'>",
        "displays the current setting");
 mkhelp("postscript output","ps",15121l,UPTO,1,CMD,2,
        "activate Postscript graphing capability",
        "<'on' or 'off'>",
        "displays the current setting");
 mkhelp("letters","",15672l,UPTO,1,CMD,2,
        "controls allele display in Postscript output",
        "<'on' or 'off'>",
        "displays the current setting");
 mkhelp("drawing scale","ds",16143l,EXACTLY,-1,CMD,2,
        "set scale of Postscript 'total' drawings",
        "",
        "");
 mkhelp("off end","",16788l,UPTO,1,CMD,2,
        "Select how far to compute scores beyond ends of map",
        "<distance>",
        "displays the current value");
 mkhelp("increment","",17490l,EXACTLY,2,CMD,2,
        "Choose the scan step size",
        "<'distance' or 'step'> <number>",
        "");
 mkhelp("map function","",18843l,UPTO,1,CMD,2,
        "Choose a cM <-> rec-frac conversion function",
        "<'haldane' or 'kosambi'>",
        "displays the current value");
 mkhelp("units","",19151l,UPTO,1,CMD,2,
        "Choose whether scan output is in cM or rec-frac",
        "<'cM' or 'rec-frac'>",
        "displays the current setting");
 mkhelp("display scores","",19526l,UPTO,1,CMD,2,
        "activate screen display of scores and haplotypes",
        "<'on' or 'off'>",
        "displays the current setting");
 mkhelp("compute sharing","cs",19597l,UPTO,1,CMD,2,
        "turn IBD matrix storage on/off",
        "<'on' or 'off'>",
        "displays the current setting");
 mkhelp("dump requirements","",20132l,UPTO,1,CMD,2,
        "estimate memory requirements instead of scanning the",
        "<'on' or 'off'>",
        "displays the current setting");
 mkhelp("haplotype method","",20751l,UPTO,1,CMD,2,
        "choose algorithm used for haplotyping",
        "<'Viterbi' or 'MaxProb'>",
        "displays the current setting");
 mkhelp("estimate","",21556l,EXACTLY,0,CMD,3,
        "maximum likelihood estimate of IBD sharing",
        "",
        "");
 mkhelp("exclude","",23129l,UPTO,9,CMD,3,
        "exclusion mapping ",
        "<relative risk ratio hypotheses>",
        "");
 mkhelp("haseman elston","",26130l,EXACTLY,0,CMD,4,
        "traditional & EM Haseman-Elston analysis",
        "",
        "");
 mkhelp("ml variance","",27440l,EXACTLY,0,CMD,4,
        "maximum likelihood QTL variance estimation",
        "",
        "");
 mkhelp("no dom var","",28340l,EXACTLY,0,CMD,4,
        "maxlike QTL variance est. under no-dominance assmp.",
        "",
        "");
 mkhelp("nonparametric","",29242l,EXACTLY,0,CMD,4,
        "non-parametric QTL analysis",
        "",
        "");
 mkhelp("pairs used","",29862l,EXACTLY,0,CMD,5,
        "select what pair combinations will be used",
        "",
        "");
 mkhelp("dump ibd","",31588l,EXACTLY,0,CMD,5,
        "dump the ibd distribution to a text file",
        "",
        "");
 mkhelp("variance components","",32161l,EXACTLY,0,CMD,6,
        "run variance components analysis",
        "",
        "");
 mkhelp("set starting values","",36154l,EXACTLY,0,CMD,6,
        "choose method for initial estimates of parameters",
        "",
        "");
 mkhelp("means by sex","",37391l,EXACTLY,0,CMD,6,
        "choose whether to estimate means by sex",
        "",
        "");
 mkhelp("tdt","",38305l,EXACTLY,1,CMD,7,
        "standard single locus TDT",
        "<file name>",
        "");
 mkhelp("tdt2","",40248l,UPTO,1,CMD,7,
        "two locus TDT",
        "<offset between markers to examine>",
        "analyze adjacent markers (offset=1)");
 mkhelp("tdt3","",41199l,EXACTLY,-1,CMD,7,
        "three locus TDT",
        "",
        "");
 mkhelp("tdt4","",41366l,EXACTLY,-1,CMD,7,
        "four locus TDT",
        "",
        "");
 mkhelp("perm1","",41533l,UPTO,1,CMD,7,
        "permutation test for determining TDT significance",
        "<number of simulations>",
        "");
 mkhelp("perm2","",43168l,UPTO,1,CMD,7,
        "permutation test for determining TDT significance",
        "<number of simulations>",
        "");
 mkhelp("dhskip","",43517l,UPTO,1,CMD,7,
        "treatment of cases in which parents are identically ",
        "<'on' or 'off'>",
        "displays the current setting");
 mkhelp("help","?",44572l,UPTO,1,CMD,8,
        "GENEHUNTER on-line help facility",
        "<command or topic>",
        "");
 mkhelp("photo","",45081l,UPTO,1,CMD,8,
        "record the output of a session in a file",
        "<file name>",
        "");
 mkhelp("run","",45689l,EXACTLY,1,CMD,8,
        "instruct GENEHUNTER to take input from a file",
        "<file name>",
        "");
 mkhelp("system","",46447l,UPTO,1,CMD,8,
        "execute a command under the operating system",
        "<system command>",
        "");
 mkhelp("change directory","cd",47049l,EXACTLY,1,CMD,8,
        "change the current directory",
        "<new directory>",
        "");
 mkhelp("time","",47223l,EXACTLY,0,CMD,8,
        "display the current time",
        "",
        "");
 mkhelp("quit","q",47278l,EXACTLY,0,CMD,8,
        "exit session",
        "",
        "");

 mktopic(1,"data preparation commands",TOP,65l);
 mktopic(2,"GENEHUNTER mapping commands",TOP,2794l);
 mktopic(3,"sibs qualitative trait mapping commands",TOP,21492l);
 mktopic(4,"sibs quantitative trait loci (qtl) mapping commands",TOP,26052l);
 mktopic(5,"other sibs commands ",TOP,29850l);
 mktopic(6,"variance components",TOP,32140l);
 mktopic(7,"TDT commands",TOP,38091l);
 mktopic(8,"additional commands ",TOP,44316l);
}
