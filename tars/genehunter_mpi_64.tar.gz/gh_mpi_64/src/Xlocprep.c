#define INC_LIB
#define INC_SHELL
#include "npl.h"

/* externals */
LOCUS_INFO *locus;
int num_markers, num_in_map_order, *map_order;
double *map_distance;
double affected_freq;
int num_liability_classes;
double penetrance[MAX_LIABILITY_CLASSES+1][6];
double apriori_disease[MAX_LIABILITY_CLASSES+1][6][6];

/* internals */
void read_linkage_marker_file(FILE*); /* arg: fp 
				         Loop over LINKAGE loci file */
void read_linkage_marker(FILE*,int);  /* args: fp, markers_read 
				         Read indiv LINKAGE marker entry */
void free_map_structs(void);          /* only called if load_markers
					 cannot completely load the 
					 file */

/* Associated procedures in cmds.c:
   void print_map_order(void) -- print out the current map
   int lookup_locus(char*) -- find the index of a locus in global locus array
   command set_use_map(void) -- input marker distances
*/

command load_markers(void)
{

  /* The upper level command.  Reads the number of markers
     in the file, determines the type of file and then
     passes control off to the appropriate file to actually handle
     the input. */

  char *filename;
  int num_fields,foo1,foo2,foo3;
  FILE *fp;


  /* Check that the locus file hasn't already been loaded */
  if (num_markers > 0) {
    sf(ps,"Genetic marker info is already loaded for %d markers.\n",
       num_markers); pr();
    print("This command will therefore be ignored.\n");
    return;
  }

  fp=NULL; locus=NULL;
  run {
    /* If no filename is given, just print the status */
    filename = get_temp_string();
    use_uncrunched_args();
    get_one_arg(stoken,"",filename);
    
    if (nullstr(filename)) {
      /* Print the status of the data */
      print("no data is currently loaded - use 'load markers <filename>'");
    }
    else {
      fp=open_file(filename,READ);
      
      /* Read the first line -  num_markers is all we use, risk
	 locus, sexlinked status, etc if present (in Linkage
	 style files) are discarded */
      fgetln(fp);
      num_fields = sscanf(ln,"%d %d %d %d",&num_markers,&foo1,&foo2,&foo3);
      if (num_fields == 0) {
	sf(ps,"missing num_markers on first line of '%s'",filename);
	error(ps);
      }
      /* allocate locus array now that we know how many there are,
	 this array will be filled in as we read the rest of the file */
      array(locus, num_markers, LOCUS_INFO);
      
      /* Number of fields on the first line gives us the type of
	 file.  Our own internal style just has the number of
	 markers on the first line. */
      if (num_fields == 4) {
	/* Linkage style data file */
	num_markers--; /* Linkage files count the disease locus */
	print("Parsing Linkage marker data file...\n");
	frewind(fp);
	read_linkage_marker_file(fp);
      }
      else {
	/* Parse our own internal format */
	error("Unrecognized marker file format");
      }
    }
    /* Give the user some output info */
    sf(ps,"%d markers read (last one = %s)\n",num_markers,
       locus[num_markers-1].name); pr();
  } except {
    when ENDOFILE: 
       print("Unexpected end-of-file, no markers read\n");
       close_file(fp);
       free_map_structs();
       break;
    when CANTOPEN:
       sf(ps,"Can't open file '%s'\n",filename); 
       pr(); break;
    default:
       if (fp != NULL) close_file(fp);
       free_map_structs(); 
       relay_messages;
  }
}


void read_linkage_marker_file(FILE *fp)
{

  /* This method was ported from HOMOZ to read in the locus
     file in LINKAGE format.  Some of the infomation read in
     is not actually used but it is left here to check the format
     of the file and in case it is needed at a later time. */

  int i,num1,num2,markers_read=0,this_loc,*new_order,count, cM_dists;
  char *word,*word2,*strptr,*map_ord_str;
  double rnum1, rnum2, rnum3, dist;
  void init_disease_info(void);

  run {

    fgetln(fp);			/* header line, num_markers already read */
    fgetln(fp);			/* mutation line - skip*/
    fgetln(fp);                 /* map order */
    array(strptr,1000,char); strcpy(strptr,ln); map_ord_str=strptr; 
    fgetln(fp);			/* should be the start of affectation locus */

    /*** LINKAGE formatting checks - might want to take this out ***/
    /* is this an acceptable affectation locus? */
    if (sscanf(ln,"%d %d",&num1,&num2)!=2) {
      sf(ps,"bad affectation (4th) line '%s'",ln);
      error(ps);
    }
    fgetln(fp);			/* Read in the line with gene frequencies */
    if (sscanf(ln,"%lf %lf",&rnum1,&rnum2)!=2) {
      sf(ps,"bad disease gene frequency line (%s) - needs 2 numbers",ln);
      error(ps);
    }
    if (rnum1+rnum2 < 0.999 || rnum1+rnum2 > 1.001) {
      sf(ps,"disease allele frequencies (%.4lf, %.4lf) do not sum to 1.0",
	 rnum1,rnum2); error(ps);
    }
    affected_freq = rnum2;

    fgetln(fp);			/* liability class line */
    if (!itoken(&ln,iREQUIRED,&num1)) {
      sf(ps,"bad liability class line '%s'",ln); error(ps);
    }
    num_liability_classes=num1;
    if (num_liability_classes > MAX_LIABILITY_CLASSES) {
      sf(ps,"too many liability classes (%d) - edit apm.h",num_liability_classes);
      error(ps);
    }
    /* get and store a line of penetrance data for each liability class... */
    for (i=0; i<num_liability_classes; i++) {
      fgetln(fp);
      if (sscanf(ln,"%lf %lf %lf",&rnum1,&rnum2,&rnum3)!=3) {
	sf(ps,"bad penetrance line (%s) - needs 3 numbers",ln);
	error(ps);
      }
      penetrance[i+1][HOM_UNAFF] = rnum1;
      penetrance[i+1][HET] = rnum2;
      penetrance[i+1][HOM_AFF] = rnum3;

      /* if X inheritance data */
      fgetln(fp);
      if (sscanf(ln,"%lf %lf",&rnum1,&rnum2)!=2) {
	sf(ps,"bad penetrance line (%s) - needs 2 numbers",ln);
	error(ps);
      }
      penetrance[i+1][UNAFF_NULL] = rnum1;
      penetrance[i+1][AFF_NULL] = rnum2;
    }
    /* store some disease probabilities */
    init_disease_info();

    /*** End of LINKAGE formatting check, time to actually read the
      marker information ***/

    /**** Read in marker information ****/
    for (i=0; i<num_markers; i++) {
      read_linkage_marker(fp,i);
      markers_read++;
    }

    fgetln(fp); while(nullstr(ln)) fgetln(fp); /* gets sex diff. line */
    fgetln(fp); /* list of recombination distances */
    
    /* fill globals with linkage map info */

    num_in_map_order=0;

    array(map_order, num_markers+1, int);
    array(map_distance, num_markers+1, double);
    array(new_order, num_markers+1, int);

    if (num_markers == 1) {
        num_in_map_order=1;
	map_order[0]=0;
    } else {
        /* read in recombination distance from end of file */
        count=0;
        while (itoken(&map_ord_str,iREQUIRED,&this_loc)) {
	  new_order[count] = this_loc;
	  count++;
	}
	if (new_order[0] == 1) {
	  cM_dists=FALSE;
	  /* disease listed first, skip i=0, first distance */
	  if (!rtoken(&ln,rREQUIRED,&dist)) 
	    error("insufficient number of recombination distances");
	  for (i=1; i<count-1; i++) {
	    map_order[i-1] = new_order[i]-2;
	    if (!rtoken(&ln,rREQUIRED,&dist)) 
	        error("insufficient number of recombination distances");
	    map_distance[i-1] = dist;
	    if (dist >= 0.50) cM_dists=TRUE;
	  }
	  map_order[count-2] = new_order[count-1]-2;
	  num_in_map_order=count-1;

	  if (!cM_dists) {
	    for (i=0; i<count-2; i++) 
	      map_distance[i] = rec_to_dist(map_distance[i]);
	  }

	} else {

	  for (i=0; i<count; i++) {
	    if (new_order[i]==1) error("disease locus cannot be in map");
	    map_order[i]=new_order[i]-2;
	  }
	  cM_dists=FALSE;
	  for (i=0; i<count-1; i++) {
	    /* do a better job of conversion here */
	    if (!rtoken(&ln,rREQUIRED,&dist)) 
	      error("insufficient number of recombination distances");
	    map_distance[i] = dist;
	    if (dist >= 0.50) cM_dists=TRUE;
	  }
	  if (!cM_dists) {
	    for (i=0; i<count-1; i++) 
	      map_distance[i] = rec_to_dist(map_distance[i]);
	  }
	  num_in_map_order=count;
	}
    }
    unarray(new_order, int);
    unarray(strptr, char);
  } except {
      when ENDOFILE: 
         sf(ps,"Unexpected end-of-file, only %d of %d markers read\n",
         markers_read,num_markers); pr();
         free_map_structs();
         break;
      default:
         relay_messages;
  }
}


void read_linkage_marker(FILE *fp, int markers_read)
{
  int i, num1, num2;
  char *word1, *word2;
  double rnum, total_freq;

  run {
    /* Read in the line with marker type and num_alleles */
    fgetln(fp); 
    word1=get_temp_string();
    word2=get_temp_string();
    if (sscanf(ln,"%d %d",&num1,&num2)!=2) {
      sf(ps,"bad allele number line '%s'",ln); error(ps);
    }
    if (num1 != 3) error("all marker loci must have allele number = 3");

    /*****
    if (word1[0]!='<' || word2[0]!='A') {
      sf(ps,"bad allele number line '%s'",ln); error(ps);
    }
    *****/

    /* Read in the line with all the allele frequencies */
    fgetln(fp); 
    total_freq = 0.00;
    for (i=0; i<num2; i++) {
      if (!rtoken(&ln,rREQUIRED,&rnum)) {
	sf(ps,"not enough allele frequencies for marker %d",markers_read+1);
	error(ps);
      }
      locus[markers_read].allele_freq[i+1]=rnum;/* alleles are listed 1 to n */
      total_freq+=rnum;
    }

    /* Save the name and other permanent locus info */
    sf(word1,"loc%d",markers_read+1); 
    strcpy(locus[markers_read].name,word1);
    locus[markers_read].allele_sum = total_freq;
    if (total_freq < .9999 || total_freq > 1.0001) {
      sf(ps,"WARNING: allele frequencies for marker %d sum to %.4lf instead of 1.0\n",markers_read+1,total_freq); pr();
    }
  } on_error {
    relay_messages;
  }
}


void free_map_structs(void)
{

  /* Free the structures allocated by load_markers, only
     called if load_markers cannot finish loading the file given */
  unarray(locus, LOCUS_INFO);
  num_markers = 0;

}


void init_disease_info(void) 
{
  /* create a-priori probabilities for originals' disease alleles */
  /* CALLED ONCE when locus information file loaded */
  double tot_aff, tot_unaff, pen_sum[10];
  int i;
  /* liability classes are 1 to N, create a dummy liability class 0
     which will represent unknowns and will have the average of the
     other penetrances */

  /* X inheritance -- for FEMALES we have normal classes for AA, AU, UU 
                      for MALES we have A- and U- */
                             
  pen_sum[HOM_AFF] = pen_sum[HET] = pen_sum[HOM_UNAFF] = 0.0;
  pen_sum[AFF_NULL] = pen_sum[UNAFF_NULL] = 0.0;

  for (i=1; i<=num_liability_classes; i++) {
    pen_sum[HOM_AFF] += penetrance[i][HOM_AFF];
    pen_sum[HET] += penetrance[i][HET];
    pen_sum[HOM_UNAFF] += penetrance[i][HOM_UNAFF];
    pen_sum[AFF_NULL] += penetrance[i][AFF_NULL];
    pen_sum[UNAFF_NULL] += penetrance[i][UNAFF_NULL];
  }

  /* 0 = liability class missing, average of all liability classes */
  penetrance[0][HOM_AFF] = pen_sum[HOM_AFF]/(double)num_liability_classes;
  penetrance[0][HET] = pen_sum[HET]/(double)num_liability_classes;
  penetrance[0][HOM_UNAFF] = pen_sum[HOM_UNAFF]/(double)num_liability_classes;
  penetrance[0][AFF_NULL]= pen_sum[AFF_NULL]/(double)num_liability_classes;
  penetrance[0][UNAFF_NULL]= pen_sum[UNAFF_NULL]/(double)num_liability_classes;

  for (i=0; i<=num_liability_classes; i++) {
    apriori_disease[i][AFFECTED][HOM_AFF] = 
      affected_freq*affected_freq*penetrance[i][HOM_AFF];
    apriori_disease[i][AFFECTED][HET] = 
      affected_freq*(1.0-affected_freq)*penetrance[i][HET];
    apriori_disease[i][AFFECTED][HOM_UNAFF] = 
      (1.0-affected_freq)*(1.0-affected_freq)*penetrance[i][HOM_UNAFF];
    apriori_disease[i][AFFECTED][AFF_NULL] =
      affected_freq*penetrance[i][AFF_NULL];
    apriori_disease[i][AFFECTED][UNAFF_NULL] =
      (1.0-affected_freq)*penetrance[i][UNAFF_NULL];


    apriori_disease[i][UNAFFECTED][HOM_AFF] =
      affected_freq*affected_freq*(1.0-penetrance[i][HOM_AFF]);
    apriori_disease[i][UNAFFECTED][HET] =
      affected_freq*(1.0-affected_freq)*(1.0-penetrance[i][HET]);
    apriori_disease[i][UNAFFECTED][HOM_UNAFF] = 
      (1.0-affected_freq)*(1.0-affected_freq)*(1.0-penetrance[i][HOM_UNAFF]);
    apriori_disease[i][UNAFFECTED][AFF_NULL] =
      affected_freq*(1.0-penetrance[i][AFF_NULL]);
    apriori_disease[i][UNAFFECTED][UNAFF_NULL] =
      (1.0-affected_freq)*(1.0-penetrance[i][UNAFF_NULL]);


    apriori_disease[i][UNKNOWN][HOM_AFF] =
      apriori_disease[i][AFFECTED][HOM_AFF]+apriori_disease[i][UNAFFECTED][HOM_AFF];
    apriori_disease[i][UNKNOWN][HET] =
      apriori_disease[i][AFFECTED][HET]+apriori_disease[i][UNAFFECTED][HET]; 
    apriori_disease[i][UNKNOWN][HOM_UNAFF] =
      apriori_disease[i][AFFECTED][HOM_UNAFF]+apriori_disease[i][UNAFFECTED][HOM_UNAFF];
    apriori_disease[i][UNKNOWN][AFF_NULL] =
      apriori_disease[i][AFFECTED][AFF_NULL]+apriori_disease[i][UNAFFECTED][AFF_NULL];
    apriori_disease[i][UNKNOWN][UNAFF_NULL] =
      apriori_disease[i][AFFECTED][UNAFF_NULL]+apriori_disease[i][UNAFFECTED][UNAFF_NULL];

    /* apriori_disease for affected and unaffected are not normalized */

    tot_aff = apriori_disease[i][AFFECTED][HOM_AFF]+
             (2.0*apriori_disease[i][AFFECTED][HET])+
	      apriori_disease[i][AFFECTED][HOM_UNAFF];
    if (tot_aff > 0.00000000000001) {
      apriori_disease[i][AFFECTED][HOM_AFF] /= tot_aff;
      apriori_disease[i][AFFECTED][HET] /= tot_aff;
      apriori_disease[i][AFFECTED][HOM_UNAFF] /= tot_aff;
    }

    tot_aff = apriori_disease[i][AFFECTED][AFF_NULL] +
              apriori_disease[i][AFFECTED][UNAFF_NULL];
    if (tot_aff > 0.00000000000001) {
      apriori_disease[i][AFFECTED][AFF_NULL] /= tot_aff;
      apriori_disease[i][AFFECTED][UNAFF_NULL] /= tot_aff;
    }

    tot_unaff = apriori_disease[i][UNAFFECTED][HOM_AFF]+
               (2.0*apriori_disease[i][UNAFFECTED][HET])+
		apriori_disease[i][UNAFFECTED][HOM_UNAFF];
    if (tot_unaff > 0.00000000000001) {
      apriori_disease[i][UNAFFECTED][HOM_AFF] /= tot_unaff;
      apriori_disease[i][UNAFFECTED][HET] /= tot_unaff;
      apriori_disease[i][UNAFFECTED][HOM_UNAFF] /= tot_unaff;
    }
    tot_unaff = apriori_disease[i][UNAFFECTED][AFF_NULL] +
                apriori_disease[i][UNAFFECTED][UNAFF_NULL];
    if (tot_unaff > 0.00000000000001) {
      apriori_disease[i][UNAFFECTED][AFF_NULL] /= tot_unaff;
      apriori_disease[i][UNAFFECTED][UNAFF_NULL] /= tot_unaff;
    }
  }
}
