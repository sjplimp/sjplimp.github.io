/* GENEHUNTER - Kruglyak, Daly, Reeve-Daly, and Lander
   Whitehead Institure for Biomedical Research, Copyright 1996 */

/*G. Conant added define for INC_MISC to fix time_string error
  in c++ compile*/
#define INC_MISC

#define INC_LIB
#define INC_SHELL
#include "npl.h"



/*Note: G. Conant removed defs of functions fabs, pow, and sqrt to prevent
  compile errors with g++ (Why were they there in the first place?)*/


/* Internal Methods */
void exclude(FILE *fp, FILE *fpps, double **zall, int num_points);
void estimate(FILE *fp, FILE *fpps, FILE *fpsh, bool nodom);
void haseman_elston(FILE *tradfp, FILE *emfp, FILE *fpps, double num_pheno_peds, 
		    double *pheno_diffs);
void ml_variance(void);
void write_session_settings (FILE *fp);
int sort(int *order, double *pheno, int number);


command exclude_switch(void) /*modified from sibs: cmds.c*/
{
  char *default_file,*tmp;
  FILE *fp, *fpps;
  int i, num_points;
  int old_num_in_map_order, old_map_order[MAXLOCI];
  double *lambda, **zall,tmp_dbl,temp;
  double LamO, LamS, LamMZ;
  double *ztype;
  bool valid;

  matrix(zall,3,MAX_EXCLUSION_POINTS,double);
  array(ztype,3,double);

  /**** Check for the correct starting conditions ****/
  if (!scan_done)
    error("no scan done for the current map, pair, and pedigree settings\n");
  if (total_num_aff_sib_pairs <= 0)
    error("no pedigrees are selected for analysis (with >= 2 affecteds with genotypes\n");
  set_weights(-1);

  /* Scan needs to be done to compute the ibd distribution
     which is stored in the warray.  The scan_done flag is
     set to false anytime map features change -- markers
     used, Kosambi vs. Haldane, scan steps, increments, pairs,
     active pedigrees, etc. */

  /* Open the files for text output and postscript output;
     The methods called provide the default, check for
     overwriting, etc. */
  array(default_file,MAX_FILE_NAME_LEN,char);
  nstrcpy(default_file,"exclude.out",MAX_FILE_NAME_LEN);
  fp = open_out_file(default_file, "exclusion mapping");
  unarray(default_file,char);

    /***************************/
    /* INPUT GATHERING SECTION */
    /***************************/

    nl();

    tmp = get_temp_string();
    input("calculate exclusion LODs under no dominance variance? y/n [y]: ",
	  tmp, TEMP_STRING_LEN);
    nl();
    if (tmp[0] == 'N' || tmp[0] == 'n') { /* DOMINANCE VARIANCE */
      tmp = get_temp_string();
      input("input Z values or relative-risk values? z/r [r]: ",
	    tmp,TEMP_STRING_LEN);
      nl();
      if (tmp[0] == 'z' || tmp[0] == 'Z') {
	tmp = get_temp_string();
	sf(ps,"how many sets of z values do you want to examine? (max of %d):",
	   MAX_EXCLUSION_POINTS);
	input(ps,tmp,TEMP_STRING_LEN);
	itoken(&tmp,0,&num_points);
	if (num_points < 1 || num_points > MAX_EXCLUSION_POINTS) 
	  error("invalid number of points for exclusion LOD calculation");
	for (i=0; i<num_points; i++) {
	  nl();
	  sf(ps,"Enter set %d:\n",i+1); pr();
	  tmp = get_temp_string();
	  input("input Z0: ",tmp,TEMP_STRING_LEN);
	  rtoken(&tmp,999.0,&tmp_dbl);
	  if (tmp_dbl >= 999.0) 
	    error("illegal value of Z0 entered\n");
	  zall[0][i]=tmp_dbl;
	  
	  tmp = get_temp_string();
	  input("input Z1: ",tmp,TEMP_STRING_LEN);
	  rtoken(&tmp,999.0,&tmp_dbl);
	  if (tmp_dbl >= 999.0) 
	    error("illegal value of Z1 entered\n");
	  zall[1][i]=tmp_dbl;

	  zall[2][i]= 1.0 - zall[0][i] - zall[1][i];
	}
      } else {
	tmp = get_temp_string();
	sf(ps,"how many sets of risk values do you want to examine? (max of %d): ",
	   MAX_EXCLUSION_POINTS);
	input(ps,tmp,TEMP_STRING_LEN);
	itoken(&tmp,0,&num_points);
	if (num_points < 1 || num_points > MAX_EXCLUSION_POINTS) 
	  error("invalid number of points for exclusion LOD calculation");
	print("\nNote: For single locus model or multi-locus additive model\n");
	print(" L-MZ = 4*L-S - 2*L-O - 1, where L-MZ is the relative risk to\n");
	print(" a MZ twin, L-S is the risk to a sib, and L-0 is the risk to offspring).\n");
	for (i=0; i<num_points; i++) {
	  nl();
	  sf(ps,"Enter set %d:\n",i+1); pr();

	  tmp = get_temp_string();
	  input("input relative risk to offspring: ",tmp,TEMP_STRING_LEN);
	  rtoken(&tmp,9999.0,&LamO);
	  if (LamO >= 9999.0 || LamO <= 1.0) 
	    error("illegal relative risk to offspring value entered\n");

	  tmp = get_temp_string();
	  input("input relative risk to sib: ",tmp,TEMP_STRING_LEN);
	  rtoken(&tmp,9999.0,&LamS);
	  if (LamS >= 9999.0 || LamS <= 1.0) 
	    error("illegal relative risk to sib value entered\n");

	  zall[0][i] = 0.25/LamS;
	  zall[1][i] = 0.5*LamO/LamS;
	  zall[2][i] = 1.0 - zall[0][i] - zall[1][i];

	}
      }
    } else {			/* NO DOMINANCE VARIANCE */
      tmp = get_temp_string();
      input("input Z2 value(s) or relative-risk to sib value(s)? z/r [r]: ",
	    tmp, TEMP_STRING_LEN);
      if (tmp[0] == 'Z' || tmp[0] == 'z') {
	tmp = get_temp_string();
	input("enter values of Z2 (0.25 <= Z < 0.5): ",tmp,TEMP_STRING_LEN);
	num_points=0;
	while (1) {
	  rtoken(&tmp,999.0,&tmp_dbl);
	  if (tmp_dbl >= 999.0 || num_points > MAX_EXCLUSION_POINTS)
	    break;
	  if (tmp_dbl > 0.5) {
	    error("value of Z2 must be >= .25 and < 0.5");
	  }
	  /* Store the z's */
	  zall[0][num_points]= 0.5 - tmp_dbl;
	  zall[1][num_points] = 0.5;
	  zall[2][num_points] = tmp_dbl;
	  num_points++;
	}
      } else {
	/* Enter and record lambda-risk-to-sib values */
	tmp = get_temp_string();
	input("enter relative risk to sib value(s): ",
	      tmp,TEMP_STRING_LEN);
	num_points=0;
	while(1) {
	  rtoken(&tmp,999.0,&tmp_dbl);
	  if (tmp_dbl >= 999.0 || num_points > MAX_EXCLUSION_POINTS) 
	    break;
	  if (tmp_dbl <= 1.0) {
	    sf(ps,
	       "risk values <= 1 are not valid -- see 'help exclude' for more details\n"); 
	    error(ps);
	  }
	  /* Convert to z's and store */
	  temp = (tmp_dbl-1)/tmp_dbl;
	  zall[0][num_points] = 0.25*(1-temp);
	  zall[1][num_points] = 0.5;
	  zall[2][num_points] = 0.25*(1+temp);
	  num_points++;
	}
      }
    }

    /**********************************/
    /* END OF INPUT GATHERING SECTION */
    /**********************************/

  run {
    if (single_point_mode) {
      fpps = NULL;		/* No postscript output in single-point mode */

      exclude(fp,fpps,zall,num_points);

    } else {

      array(default_file,MAX_FILE_NAME_LEN,char);
      if (num_in_map_order > 1 && postscript_output) {
	nstrcpy(default_file,"exclude.ps",MAX_FILE_NAME_LEN);
	fpps = open_postscript_file(default_file, "postscript");
      } 
      unarray(default_file,char);

      exclude(fp,fpps,zall,num_points);
      if (num_in_map_order > 1 && postscript_output) 
	close_file(fpps);
    }

  } on_exit {

    unmatrix(zall,3,double);
    unarray(ztype,double);

    /* Write out what pairs, map, pedigrees, etc were used */
    write_session_settings(fp);
    if (msg == SOFTABORT) {
      fprintf(fp,"!!!! ERROR occured during analysis !!!!\n");
      print("error occured while running 'exclude', results incomplete\n");
    } else {
      if (num_in_map_order > 1 && !single_point_mode && postscript_output) 
	print("\nanalysis complete\ntext and drawing output files successfully written\n");
      else 
	print("\nanalysis complete\ntext output file successfully written\n");
    }
    close_file(fp);
  }
}


void exclude(FILE *fp, FILE *fpps, double **zall, int num_points)
{
  /* compute likelihoods given risk lambda to a sib */

  int i, j, k, m, shared_poss;
  double z[3], a[3], temp, lambda;
  double sum1, sum2, **loglike;
  char *title, **lambda_str, y_title[10], *tmp;

  /* Set the Mendelian expectation */
  a[0] = a[2] = 0.25;
  a[1] = 0.5;
  shared_poss=3;


  if (single_point_mode)
    fprintf(fp,"marker\t");
  else
    fprintf(fp,"pos   \t");		/* Column heading in text file */

  for (m=0; m<num_points; m++) {  /* loop over risk values */
    lambda =  1/(4*zall[0][m]);
    if (lambda > 9.99) fprintf(fp,"rs=%.1lf\t\t",lambda);
    else fprintf(fp,"rs=%.2lf\t\t",lambda);
  }
  fprintf(fp,"\n\t");    

  matrix(loglike,num_points,num_w_pos,double);
  for (m=0; m<num_points; m++) { /* loop over risk values */

    /* Needs a column heading */
    fprintf(fp,"(z2=%.3lf)\t",zall[2][m]);

    for (k=0; k<shared_poss; ++k)
      z[k] = zall[k][m];

    run {
      for (i=0; i<num_w_pos; ++i) { /* loop over scan positions */
	loglike[m][i] = 0;
	for (j=0; j<total_num_sib_pairs; ++j) { /* loop over pairs */
	  if (both_affected[j]) {
	    sum1 = sum2 = 0;
	    for (k=0; k<shared_poss; ++k)
	      {
		sum1+=z[k]*warray[i][j][k];   
		sum2+=a[k]*warray[i][j][k];   
	      }
	    loglike[m][i] += weight[j]*log10(sum1/sum2);
	  }
	}
      }
    } on_error {
      sf(ps,"error calculating set %d\n",m+1); pr();
      unmatrix(loglike,num_points,double);
      relay;
    }
  }
  fprintf(fp,"\n");		/* This will finish off the column designations
				   in the text output file */


  /* Output text values as tabbed columns*/
  for (i=0; i<num_w_pos; ++i) {
    if (single_point_mode) 
      fprintf(fp,"%4d\t",i+1);
    else
      fprintf(fp,"%.3lf\t",wpos[i]);
    for (m=0; m<num_points; m++)
      fprintf(fp,"%f\t",loglike[m][i]);
    fprintf(fp,"\n");
  }

  /* Deal with the postscript output */
  if (num_in_map_order > 1 && postscript_output && !single_point_mode) {
    array(title,MAX_TITLE,char);
    strcpy(title,"Exclusion LOD Scores");
    matrix(lambda_str,num_points,20,char);
    for (i=0; i<num_points; i++) {
      lambda =  1/(4*zall[0][i]);
      sprintf(lambda_str[i],"rs=%2.0f (Z2=%.3lf)", lambda, zall[2][i]);
    }
    strcpy(y_title,"LOD");
    draw_mult_y_plots(fpps,wpos,loglike,num_w_pos,num_points,title,lambda_str,y_title);
    unmatrix(lambda_str,num_points,char);
    unarray(title,char);
  } 

  /* Close up remaining variables */
  unmatrix(loglike,num_points,double);
}


command estimate_switch (void) 
{

  char *default_file, *tmp;
  int i;
  int old_num_in_map_order, old_map_order[MAX_POSITIONS+1]; /** ? **/
  bool nodom;
  FILE *fp, *fpps, *fpsh;
    
  /**** Check for the correct starting conditions ****/
  /* Scan needs to be done to compute the ibd distribution
     which is stored in the warray.  The scan_done flag is
     set to false anytime map features change -- markers
     used, Kosambi vs. Haldane, scan steps, increments, pairs,
     active pedigrees, etc. */
  /* For single point mode scan is called by the loop
     after the markers are shifted around */
  if (!scan_done)
    error("no scan done for the current map, pair, and pedigree settings\n");
  if (total_num_aff_sib_pairs <= 0)
    error("no pedigrees are selected for analysis (none with > 2 affecteds)\n");
  set_weights(-1);
  
  nl();
  tmp = get_temp_string();
  nodom = FALSE;
  input("analyze under the assumption of no dominance variance? y/n [n]: ",
	tmp,TEMP_STRING_LEN);
  if (tmp[0] == 'y' || tmp[0] == 'Y') {
    nodom = TRUE;
  }


  /* Open the text file, with the method called checking
     for overwrites, etc.  The text file will be written regardless
     of sex-linked status or single-point mode setting */
  array(default_file,MAX_FILE_NAME_LEN,char);
  nstrcpy(default_file,"mls.out",MAX_FILE_NAME_LEN);
  fp = open_out_file(default_file, "ML estimation");
  unarray(default_file,char);

  /* Print the column headings in the text output file */
  if (single_point_mode) 
    fprintf(fp,"marker\t   z0   \t   z1   \t   z2   \tloglike\n");
  else
    fprintf(fp,"pos   \t   z0   \t   z1   \t   z2   \tloglike\n");
  
  run {
    if (single_point_mode) {

      fpsh = NULL;
      fpps = NULL;		/* No postscript output in single-point mode */

      /* Scan the new "map" */
      
      estimate(fp,fpps,fpsh,nodom);    

    } else {

      if (num_in_map_order > 1 && postscript_output) {
	array(default_file,MAX_FILE_NAME_LEN,char);

	nstrcpy(default_file,"share.ps",MAX_FILE_NAME_LEN);
	fpsh = open_postscript_file(default_file, "sharing");

	nstrcpy(default_file,"mls.ps",MAX_FILE_NAME_LEN);
	fpps = open_postscript_file(default_file, "LOD");

	unarray(default_file,char);
      }
      
      run {
	estimate(fp,fpps,fpsh,nodom);
      } on_exit {
	if (num_in_map_order > 1 && postscript_output) {
	  close_file(fpps);
	  close_file(fpsh);
	}
      }
    }

    /* Write out what pairs, map, pedigrees, etc were used */
    write_session_settings(fp);
    if (nodom) {
      fprintf(fp,"LOD scores computed under the assumption of no dominance variance\n");
    } else {
      fprintf(fp,"LOD scores computed using the possible triangle method\n");
      fprintf(fp," (no assumption made about mode of inheritance)\n");
    }      
    
  } on_exit {
    if (msg == SOFTABORT) {
      fprintf(fp,"!!!! ERROR occured during analysis !!!!\n");
      print("error occured while running 'estimate', results incomplete\n");
    } else {
      if (num_in_map_order > 1 && !single_point_mode && postscript_output) 
	print("\nanalysis complete\ntext and drawing output files successfully written\n");
      else 
	print("\nanalysis complete\ntext output file successfully written\n");
    }
    close_file(fp);
  }

}


void estimate(FILE *fp, FILE *fpps, FILE *fpsh, bool nodom)
{
  
  /* compute maximum likelihood, estimating z0, z1, z2 by EM a la Holmans */
  
  int i, j, k, m, stop, shared_poss;
  double z[3], a[3], oldz[3], e[3], temp;
  double sum1, sum2, *loglike, oldlike;
  double **maxz, sumwt;
  char **share_str, *title, *tmp;
  
  /* Set the Mendelian expectations and the number of types
     of sharing that can occur */
  a[0] = a[2] = 0.25;
  a[1] = 0.5;
  shared_poss=3;

  array(loglike,num_w_pos,double); /* Store the results for plotting */
  matrix(maxz,shared_poss,num_w_pos,double);
  
  run {
    if (nodom) {
      for (i=0; i<num_w_pos; ++i) { /* loop over scan points */

	/* maximize with z1 = 1/2 */
	loglike[i] = -100000.0;
	for (k=0; k<3; ++k) z[k] = a[k];
	oldz[1] = z[1];
	stop = 0;
  
	while (!stop) {		/* EM iterations */
	  oldlike = loglike[i];
	  loglike[i] = 0.0;
	  oldz[0] = z[0];
	  oldz[2] = z[2];
	  e[0] = 0.0;
	  e[2] = 0.0;
  
	  for (j=0; j<total_num_sib_pairs; ++j) { /* loop over pairs */
	    sum1 = sum2 = 0;
	    for (k=0; k<3; ++k)
	      sum1+=oldz[k]*warray[i][j][k];
	    if (sum1 <= 0.0 && weight[j] > 0.0) {
	      /*This should never happen, but we'll catch it
		in a useful fashion if it does. */
	      sf(ps,"division by zero, sum of oldz's at pos %.1lf, pair %s = 0\n",
		 wpos[i],pair_name[j]); error(ps);
	    } 
	      
	    if (weight[j] > 0.0) {
	      loglike[i] += weight[j]*log10(sum1);
	      e[0] += weight[j]*oldz[0]*warray[i][j][0]/sum1;
	      e[2] += weight[j]*oldz[2]*warray[i][j][2]/sum1;
	    }
	  }

	  temp = e[0]+e[2];
	  if (temp > CONVERGE) {
	    z[0] = 0.5*e[0]/temp;
	    z[2] = 0.5*e[2]/temp;
	  }
	  else {
	    z[0] = 0.25;
	    z[2] = 0.25;
	  }
	  if (loglike[i]-oldlike < CONVERGE) stop = 1;
	  if (oldlike > loglike[i]+CONVERGE)
	    error("likelihood decreased in EM");
	} /* end EM loop */
	if (z[1] < 2*z[0]) {
	  for (k=0; k<3; ++k) z[k] = a[k];
	  loglike[i] = 0.0;
	}

	if (single_point_mode) {
	  fprintf(fp,"%s\t%f\t%f\t%f\t%f\n",
		  locus[i].name,z[0],z[1],z[2],loglike[i]);
	} else {
	  fprintf(fp,"%.3lf\t%f\t%f\t%f\t%f\n",
		  wpos[i],z[0],z[1],z[2],loglike[i]);
	}

	for(m=0; m<shared_poss; m++) 
	  maxz[m][i]=z[m];
      }

    } else {			/* end z1 = 1/2 maximization */

      /* EM loop */
      for (i=0; i<num_w_pos; ++i) { /* loop over scan points */
	/* do unconstrained max likelihood */
	loglike[i] = -100000.0;
	for (k=0; k<shared_poss; ++k) z[k] = a[k];
      
	stop = 0;
      
	while (!stop){		/* EM iterations */
	  oldlike = loglike[i];
	  loglike[i] = 0.0;
	  for (k=0; k<shared_poss; ++k) oldz[k] = z[k];
	  for (k=0; k<shared_poss; ++k) z[k] = 0.0;

	  sumwt=0.0;
	  for (j=0; j<total_num_sib_pairs; ++j) { /* loop over pairs */
	    sum1 = sum2 = 0;
	    for (k=0; k<shared_poss; ++k)
	      sum1+=oldz[k]*warray[i][j][k];

	    
	    if (sum1 <= 0.0 && weight[j] > 0.0) {
	      /*This should never happen, but we'll catch it
		in a useful fashion if it does. */
	      sf(ps,"division by zero, sum of oldz's at pos %.1lf, pair %s = 0\n",
		 wpos[i],pair_name[j]); error(ps);
	    } 
	    
	    if (weight[j] > 0.0) {
	      loglike[i] += weight[j]*log10(sum1);
	      
	      for (k=0; k<shared_poss; ++k)
		z[k] += weight[j]*oldz[k]*warray[i][j][k]/sum1;
	    }
	    sumwt += weight[j];
	  }

	  for (k=0; k<shared_poss; ++k) z[k] /= sumwt;
	  if (loglike[i]-oldlike < CONVERGE) stop = 1;
	  if (oldlike > loglike[i]+CONVERGE)
	    error("likelihood decreased in EM");
	} /* end EM loop */

	/* now do Holmans */
	if (z[1] > 0.5) {
	  /* maximize with z1 = 1/2 */
	  loglike[i] = -100000.0;
	  for (k=0; k<3; ++k) z[k] = a[k];
	  oldz[1] = z[1];
	  stop = 0;
  
	  while (!stop) {	/* EM iterations */
	    oldlike = loglike[i];
	    loglike[i] = 0.0;
	    oldz[0] = z[0];
	    oldz[2] = z[2];
	    e[0] = 0.0;
	    e[2] = 0.0;
  
	    for (j=0; j<total_num_sib_pairs; ++j) { /* loop over pairs */
	      sum1 = sum2 = 0;
	      for (k=0; k<3; ++k)
		sum1+=oldz[k]*warray[i][j][k];
		
	      if (sum1 <= 0.0 && weight[j] > 0.0) {
		/*This should never happen, but we'll catch it
		  in a useful fashion if it does.*/
		sf(ps,"division by zero, sum of oldz's at pos %.1lf, pair %s = 0\n",
		   wpos[i],pair_name[j]); error(ps);
	      } 
	      if (weight[j] > 0.0) {
		loglike[i] += weight[j]*log10(sum1);
		e[0] += weight[j]*oldz[0]*warray[i][j][0]/sum1;
		e[2] += weight[j]*oldz[2]*warray[i][j][2]/sum1;
	      }
	    }

	    temp = e[0]+e[2];
	    if (temp > CONVERGE) {
	      z[0] = 0.5*e[0]/temp;
	      z[2] = 0.5*e[2]/temp;
	    }
	    else {
	      z[0] = 0.25;
	      z[2] = 0.25;
	    }
	    if (loglike[i]-oldlike < CONVERGE) stop = 1;
	    if (oldlike > loglike[i]+CONVERGE)
	      error("likelihood decreased in EM");
	  } /* end EM loop */
	  if (z[1] < 2*z[0])
	    for (k=0; k<3; ++k) z[k] = a[k];
	  /* end z1 = 1/2 maximization */
	} else if (z[1] < 2*z[0]) {
	  /* maximize w/ z1 = 2 z0 */
	  loglike[i] = -100000.0;
	  for (k=0; k<3; ++k) z[k] = a[k];
	  stop = 0;
	  
	  while (!stop) {	/* EM iterations */
	    oldlike = loglike[i];
	    loglike[i] = 0.0;
	    for (k=0; k<3; ++k) oldz[k] = z[k];
	    for (k=0; k<3; ++k) e[k] = 0;
  
	    for (j=0; j<total_num_sib_pairs; ++j) { /* loop over pairs */
	      sum1 = sum2 = 0;
	      for (k=0; k<3; ++k)
		sum1+=oldz[k]*warray[i][j][k];
	      if (sum1 <= 0.0 && weight[j] > 0.0) {
		/*This should never happen, but we'll catch it
		  in a useful fashion if it does.*/
		sf(ps,"division by zero, sum of oldz's at pos %.1lf, pair %s = 0\n",
		   wpos[i],pair_name[j]); error(ps);
	      } 
	      if (weight[j] > 0.0) {
		loglike[i] += weight[j]*log10(sum1);
		for (k=0; k<3; ++k)
		  e[k] += weight[j]*oldz[k]*warray[i][j][k]/sum1;
	      }
	    }
	    temp = e[0]+e[1]+e[2];
	    z[0] = (e[0]+e[1])/(3*temp);
	    z[1] = 2*(e[0]+e[1])/(3*temp);
	    z[2] = e[2]/temp;
	    if (loglike[i]-oldlike < CONVERGE) stop = 1;
	    if (oldlike > loglike[i]+CONVERGE)
	      error("likelihood decreased in EM");
	  } /* end EM loop */
	  if (z[0] > 0.25)
	    for (k=0; k<3; ++k) z[k] = a[k];
	} /* end z1 = 2 z0 maximization */

	/* finally, compute lodscore */
	loglike[i] = 0;
	for (j=0; j<total_num_sib_pairs; ++j) { /* loop over pairs */
	  if (weight[j] > 0.0) {
	    sum1 = sum2 = 0;
	    for (k=0; k<shared_poss; ++k) {
	      sum1+=z[k]*warray[i][j][k];
	      sum2+=a[k]*warray[i][j][k];
	    }
	    loglike[i] += weight[j]*log10(sum1/sum2);
	  }
	}

	if (single_point_mode) {
	  fprintf(fp,"%s\t%f\t%f\t%f\t%f\n",
		  locus[i].name,z[0],z[1],z[2],loglike[i]);
	} else {
	  fprintf(fp,"%.3lf\t%f\t%f\t%f\t%f\n",
		  wpos[i],z[0],z[1],z[2],loglike[i]);
	}
	for(m=0; m<shared_poss; m++) 
	  maxz[m][i]=z[m];
      } /* end loop over scan points */
    }
  } on_exit {
    if (num_in_map_order > 1 && postscript_output && !single_point_mode) {
      array(title,MAX_TITLE,char);
      strcpy(title,"Maximum Likelihood Sharing Proportions\n");
      matrix(share_str,shared_poss,5,char);
	nstrcpy(share_str[0],"z0",2);
	nstrcpy(share_str[1],"z1",2);
	nstrcpy(share_str[2],"z2",2);
      draw_mult_y_plots(fpsh,wpos,maxz,num_w_pos,shared_poss,title,share_str,"");
      unarray(title,char);
      unmatrix(share_str,shared_poss,char);
      draw_graph(fpps,wpos,loglike,num_w_pos,"Maximum Likelihood IBD","LOD");
      unarray(loglike,double);
      unmatrix(maxz,shared_poss,double);
    }
    relay;
  }

} /* end estimate */



/***************Functions that work off phenotypes *****************/

/* num_pheno_peds is now expected to be a double containing the sum   	*/
/* of pedigree weights, NOT an int containing the number of pedigrees 	*/
/* with phenotypes (only the weights for pairs with phenotypes are	*/
/* included in the sum)  LK 2/22/96					*/

command he_switch (void)
{

  char *default_file, *tmp;
  bool valid;
  FILE *tradfp, *emfp, *fpps;
  int i;
  int old_num_in_map_order, old_map_order[MAXLOCI];
  int pheno_index;
  double *pheno_diffs, num_pheno_peds;

  /**** Check for the correct starting conditions ****/
  if (num_phenotypes == 0)
    error("no phenotype data loaded for this session\n");
  if (!scan_done)
    error("no scan done for the current map, pair, and pedigree settings\n");
  if (total_num_sibships < 3)
    error("you must have more than 2 pedigrees to run this regression analysis\n");

  /* Find out which phenotype to look at */
  valid=FALSE;
  while (!valid) {
    if (num_phenotypes > 1) {
      sf(ps,"which phenotype do you want to analyze? (1-%d): ",
	 num_phenotypes);
      tmp = get_temp_string();
      input(ps,tmp,TEMP_STRING_LEN);
      itoken(&tmp,iREQUIRED,&pheno_index);
      if (pheno_index < 1 || pheno_index > num_phenotypes) {
	sf(ps,"phenotype '%d' does not exist",pheno_index);
	print(ps);
      } else {
	pheno_index--;
	valid=TRUE;
      }
    } else { pheno_index = 0; valid = TRUE; }
  }
  set_weights(pheno_index);
  

  num_pheno_peds=0;
  array(pheno_diffs, total_num_sib_pairs, double);
  for (i=0; i<total_num_sib_pairs; i++) {
      pheno_diffs[i]=pair_pheno[i][pheno_index];
      num_pheno_peds += weight[i];
    }
  
  array(default_file,MAX_FILE_NAME_LEN,char);
  nstrcpy(default_file,"trad-he.out",MAX_FILE_NAME_LEN);
  tradfp = open_out_file(default_file, "haseman-elston trad");
  nstrcpy(default_file,"em-he.out",MAX_FILE_NAME_LEN);
  emfp = open_out_file(default_file, "haseman-elston em");
  unarray(default_file,char);

  run {
    if (single_point_mode) {
      fpps = NULL;		/* No postscript output in single-point mode */

      haseman_elston(tradfp,emfp,fpps,num_pheno_peds, pheno_diffs);
    
    } else {
      if (num_in_map_order > 1 && postscript_output) {
	array(default_file,MAX_FILE_NAME_LEN,char);
	nstrcpy(default_file,"he.ps",MAX_FILE_NAME_LEN);
	fpps = open_postscript_file(default_file, "postscript");
	unarray(default_file,char);
      }
      haseman_elston(tradfp,emfp,fpps,num_pheno_peds, pheno_diffs);
      if (num_in_map_order > 1 && postscript_output) 
	close_file(fpps);
    }

  } on_exit {
    /* Write out what pairs, map, pedigrees, etc were used */
    write_session_settings(tradfp);
    fprintf(tradfp, "\n*Phenotype selected:  %d\n",pheno_index+1);
    write_session_settings(emfp);
    fprintf(emfp, "\n*Phenotype selected:  %d  Convergence limit: %.10lf\n",
	    pheno_index+1,CONVERGE);
    if (msg == SOFTABORT) {
      fprintf(tradfp,"!!!! ERROR occured during analysis !!!!\n");
      fprintf(emfp,"!!!! ERROR occured during analysis !!!!\n");
      print("error occured while running 'haseman-eslton', results incomplete\n");
    } else {
      if (num_in_map_order > 1 && !single_point_mode && postscript_output) 
	print("\nanalysis complete\ntext and drawing output files successfully written\n");
      else 
	print("\nanalysis complete\ntext output file successfully written\n");
    }
    unarray(pheno_diffs, double);
    close_file(tradfp);
    close_file(emfp);
  }
}


void haseman_elston(FILE *tradfp, FILE *emfp, FILE *fpps, double num_pheno_peds, 
		    double *temp)
{

  /* read in phenotypic differences, do Haseman-Elston QTL mapping */


  int i, j, k, stop;
  double sum, xsum, xsqsum, vsum, vsqsum, xvsum, xvar;
  double alpha, beta, sigsq, x, *xhat;
  double alpha0, beta0, sigsq0;
  double a[3], z[3], p[3];
  double loglike, oldlike, loglike0;
  double t;
  double *v,tmp_dbl;
  double **lod;
  char **key_str;
  int shared_poss;


  /* Set the Mendelian expectations */
  a[0]=a[2]=0.25;
  a[1]=0.5;
  shared_poss=3;

  array(v,total_num_sib_pairs,double);
  array(xhat,total_num_sib_pairs,double);
  matrix(lod,2,num_w_pos,double);

  vsum = vsqsum = 0;
  for (j=0; j<total_num_sib_pairs; ++j) {
    if (temp[j] != MISSING_PHENO) {
      v[j] = temp[j]*temp[j];
      vsum += weight[j]*v[j];
      vsqsum += weight[j]*v[j]*v[j];
    } else {
      v[j]=MISSING_PHENO;
    }
  }

  beta0 = 0.0;
  alpha0 = vsum/num_pheno_peds;
  sigsq0 = (vsqsum - alpha0*alpha0*num_pheno_peds)/num_pheno_peds;

  if (single_point_mode) {
    fprintf(tradfp,"marker\t beta    \t LOD     \tt-score\n");
    fprintf(emfp,  "pos   \t beta    \t LOD     \tt-score\n");
  } else {
    fprintf(tradfp,"marker\t beta    \t LOD     \tt-score\n");
    fprintf(emfp,  "pos   \t beta    \t LOD     \tt-score\n");
  }

  run {
    /* do true Haseman-Elston */
    for (i=0; i<num_w_pos; ++i) {
      xsum = xsqsum = xvsum = 0;
      for (j=0; j<total_num_sib_pairs; ++j) {
	if (v[j] == MISSING_PHENO || weight[j] < 0.00001) continue;
	sum = 0;
	for (k=0; k<shared_poss; ++k)
	  sum += warray[i][j][k]*a[k];
	if (sum <= 0.0) {
	  /* This should never happen, but we'll catch it
	     in a useful fashion if it does. (Not anymore) */;
							   }
	
	for (k=0; k<shared_poss; ++k)
	  z[k] = warray[i][j][k]*a[k]/sum;
	
	x = 0.5*z[1] + z[2];
	
	xhat[j] = x;
	xsum += weight[j]*x;
	xsqsum += weight[j]*x*x;
	xvsum += weight[j]*x*v[j];
      }
      
      xvar = num_pheno_peds*xsqsum - xsum*xsum;
      if (xvar == 0.0)
	error("in traditional H-E xvar = 0\n");
      alpha = (vsum*xsqsum - xvsum*xsum)/xvar;
      beta = (num_pheno_peds*xvsum - xsum*vsum)/xvar;
      sigsq = (vsqsum + alpha*alpha*num_pheno_peds + beta*beta*xsqsum - 
	       2*alpha*vsum - 2*beta*xvsum + 2*alpha*beta*xsum)/num_pheno_peds;
      if (sigsq == 0.0) 
	error("in traditional H-E sigsq = 0\n");
      t = fabs(beta)/sqrt(num_pheno_peds*sigsq/xvar);
      loglike0 = 0.0;
      if (sigsq0 == 0.0)
	error("in traditional H-E sigsq0 = 0\n");
      for (j=0; j<total_num_sib_pairs; j++) {
	if (v[j] != MISSING_PHENO && weight[j] > 0.0) {
	  tmp_dbl = v[j] - alpha0;
	  loglike0 += weight[j]*(-LOG10E*tmp_dbl*tmp_dbl/(2*sigsq0) - 0.5*log10(sigsq0));
	}
      }
      loglike = 0.0;
      for (j=0; j<total_num_sib_pairs; j++) {
	if (v[j] != MISSING_PHENO && weight[j] > 0.0) {
	  tmp_dbl = v[j] - alpha - beta*xhat[j];
	  loglike += weight[j]*(-LOG10E*tmp_dbl*tmp_dbl/(2*sigsq) - 0.5*log10(sigsq));
	}
      }
      if (beta > 0) loglike = loglike0;
/*      if (debug) {
	sf(ps,"H-E: a = %f b = %f sigsq = %f xvar = %f t = %f\n",alpha,beta,sigsq,xvar,t);
	pr();
      } */
      if (single_point_mode)
	fprintf(tradfp,"%3d\t%f\t%f\t%f\n",i+1,beta,loglike-loglike0,t);
      else
	fprintf(tradfp,"%.3lf\t%f\t%f\t%f\n",wpos[i],beta,loglike-loglike0,t);
      lod[0][i]=loglike-loglike0;
      
    } /* end H-E */

  } on_error {
    print("error detected running traditional haseman-elston algorithm\n");
    unarray(v,double);
    unarray(xhat,double);
    unmatrix(lod,2,double);
    relay;
  }

  /* Now to EM Haseman Elston */
  
  fprintf(emfp,"\n");
  
/*  if (debug) {
    sf(ps,"vsum: %.2lf\t vsqsum: %.2lf\t alpha0: %.2lf beta0: %.2lf sigsq0: %.2lf\n",
       vsum,vsqsum,alpha0,beta0,sigsq0); pr();
  }*/
  
  run {
    for (i=0; i<num_w_pos; ++i) { /* loop over scan positions */
      /* initialize EM */
      loglike = -10000.0;
      alpha = alpha0;
      beta = beta0;
      sigsq = sigsq0;

      stop = 0;

      while (!stop) {		/* do EM iterations */
	oldlike = loglike;
	loglike = 0;
	xsum = xsqsum = xvsum = 0;

	/**** E step: recompute probabilities of sharing 0,1,2 ****/
	for (j=0; j<total_num_sib_pairs; ++j) { /* loop over pairs */
	  if (v[j] == MISSING_PHENO || weight[j] < 0.00001) continue;

	  /* Convert the warray values back to z[i] */
	  sum = 0;
	  for (k=0; k<shared_poss; ++k)
	    sum += warray[i][j][k]*a[k];
	  if (sum == 0.0)
	    error("sum of z's = 0.0 detected in EM H-E algorithm\n");
	  for (k=0; k<shared_poss; ++k)
	    z[k] = warray[i][j][k]*a[k]/sum;
	  
	  
	  /* Estimate new z[] */
	  sum = 0;
	  for (k=0; k<shared_poss; ++k) {
	    tmp_dbl = v[j] - alpha - beta*k/2.0;
	    p[k] = exp(-tmp_dbl*tmp_dbl/(2*sigsq));
	    sum += p[k]*z[k];
	  }
	  for (k=0; k<shared_poss; ++k)
	    z[k] = p[k]*z[k]/sum;
	  
	  x = 0.5*z[1] + z[2];
	  xsqsum += weight[j]*(0.25*z[1] + z[2]);
	  
	  xsum += weight[j]*x;
	  xvsum += weight[j]*x*v[j];
	  
	  loglike += weight[j]*(log10(sum) - 0.5*log10(sigsq));
	}
 	
	/**** M step: estimate a,b,sigma ****/
	xvar = num_pheno_peds*xsqsum - xsum*xsum; /* Denominator for alpha&beta */
	if (xvar == 0.0)
	  error("xvar = 0.0 in EM H-E\n");
	alpha = (vsum*xsqsum - xvsum*xsum)/xvar;

	beta = (num_pheno_peds*xvsum - xsum*vsum)/xvar;
	sigsq = (vsqsum + alpha*alpha*num_pheno_peds + beta*beta*xsqsum - 
		 2*alpha*vsum - 2*beta*xvsum + 2*alpha*beta*xsum)/num_pheno_peds;
	if (sigsq == 0.0)
	  error("sigsq = 0.0 in EM H-E\n");

/*	if (debug) {
	  fprintf(emfp,"%f\t%f\n",oldlike,loglike);
	  fprintf(emfp,"%.3lf\txvar %f\txsum %f\txvsum %f\txsqsum %f\n",
		  wpos[i],xvar,xsum,xvsum,xsqsum);
	  fprintf(emfp,"%.3lf\talpha %f\tbeta %f\tsiqsq %f\tLOD %f\n",
		  wpos[i],alpha,beta,
		  sigsq,loglike-loglike0);
	}*/
	if (loglike-oldlike < CONVERGE) stop = 1;

	if (oldlike > loglike+CONVERGE)
	  error("likelihood decreased in EM");

      } /* end EM loop */
      
      /* compute lod score */
      loglike0 = 0.0;
      for (j=0; j<total_num_sib_pairs; ++j) {
	if (v[j] != MISSING_PHENO && weight[j] > 0.0) {
	  tmp_dbl = v[j] - alpha0;
	  loglike0 += weight[j]*(-LOG10E*tmp_dbl*tmp_dbl/(2*sigsq0) - 0.5*log10(sigsq0));
	}
      }
      t = fabs(beta)/sqrt(num_pheno_peds*sigsq/xvar);
      if (beta > 0) loglike = loglike0;
   /*   if (debug) {
	sf(ps,"%.3lf\txvar %f\txsum %f\txvsum %f\txsqsum %f\n",
	   wpos[i],xvar,xsum,xvsum,xsqsum); pr();
	sf(ps,"%.3lf\talpha %f\tbeta %f\tsigsq %f\tlod%f\n",wpos[i],alpha,beta,
	   sigsq,loglike-loglike0); pr();
      }*/
      if (single_point_mode)
	fprintf(emfp,"%3d\t%f\t%f\t%f\n",i+1,beta,loglike-loglike0,t);
      else
	fprintf(emfp,"%.3lf\t%f\t%f\t%f\n",wpos[i],beta,loglike-loglike0,t);
      lod[1][i] = loglike-loglike0;
    } /* end loop over scan points */
  } on_error {
    print("Error detected running EM H-E\n");
    unarray(v,double);
    unarray(xhat,double);
    unmatrix(lod,2,double);
    relay;
  }

  if (num_in_map_order > 1 && postscript_output && !single_point_mode) {
    matrix(key_str,2,20,char);
    strcpy(key_str[0],"trad H-E");
    strcpy(key_str[1],"EM H-E");
    draw_mult_y_plots(fpps,wpos,lod,num_w_pos,2,"Haseman-Elston",key_str,"LOD");
    unmatrix(key_str,2,char);
  }

  unarray(v,double);
  unarray(xhat,double);
  unmatrix(lod,2,double);

} /* end haseman_elston */


void ml_variance(void)
{

  /* estimate phenotypic difference variances by maximum likelihood */

  FILE *output,*fpps;
  int i, j, k, stop, pheno_index;
  double sum, xsum, xsqsum, vsum, vsqsum, xvsum, xvar, temp;
  double alpha, beta, sigsq[3], sigsq_null;
  double a[3], z[3], p[3], x[3], n[3];
  double loglike, oldlike, loglike0, *lod;
  double t;
  double *pheno_diffs;
  char *tmp,*default_file;
  bool valid;
  int shared_poss;
  double num_pheno_peds;

  /**** Check for the correct starting conditions ****/

  if (num_phenotypes == 0)
    error("no phenotype data loaded for this session\n");
  

  /* Scan needs to be done to compute the ibd distribution
     which is stored in the warray.  The scan_done flag is
     set to false anytime map features change -- markers
     used, Kosambi vs. Haldane, scan steps, increments, pairs,
     active pedigrees, etc. */

  if (!scan_done)
    error("no scan done for the current map, pair, and pedigree settings\n");

  valid=FALSE;
  while (!valid) {
    if (num_phenotypes > 1) {
      sf(ps,"which phenotype do you want to analyze? (1-%d): ",
	 num_phenotypes);
      tmp = get_temp_string();
      input(ps,tmp,TEMP_STRING_LEN);
      itoken(&tmp,iREQUIRED,&pheno_index);
      if (pheno_index < 1 || pheno_index > num_phenotypes) {
	sf(ps,"phenotype '%d' does not exist",pheno_index);
	print(ps);
      } else {
	pheno_index--;
	valid=TRUE;
      }
    } else { pheno_index = 0; valid = TRUE; }
  }
  set_weights(pheno_index);

  /* Set Mendelian expectation */
  a[0] = a[2] = 0.25;
  a[1] = 0.5;
  shared_poss=3;

  num_pheno_peds=0;
  array(pheno_diffs, total_num_sib_pairs, double);
  for (i=0; i<total_num_sib_pairs; i++) {
    pheno_diffs[i]=pair_pheno[i][pheno_index];
    num_pheno_peds += weight[i];
  }
  vsum = vsqsum = 0;
  for (j=0; j<total_num_sib_pairs; ++j) {
    if (pheno_diffs[j] != MISSING_PHENO && weight[j] > 0.0) {
      vsum += weight[j]*pheno_diffs[j];
      vsqsum += weight[j]*pheno_diffs[j]*pheno_diffs[j];
    }
  }

  if (num_pheno_peds < 0.000001) {
    unarray(pheno_diffs,double);
    error("no pedigrees with phenotypes selected\n");
  }

  array(default_file,MAX_FILE_NAME_LEN,char);
  nstrcpy(default_file,"ml.out",MAX_FILE_NAME_LEN);
  output = open_out_file(default_file, "ML variance");

  if (num_in_map_order > 1 && postscript_output && !single_point_mode) {
    nstrcpy(default_file,"ml.ps",MAX_FILE_NAME_LEN);
    fpps = open_postscript_file(default_file, "postscript");
  }

  unarray(default_file,char);

  if (single_point_mode)
    fprintf(output,"marker\t  LOD   \tsigsq0  \tsigsq1  \tsigsq2\n");
  else
    fprintf(output,"pos   \t  LOD   \tsigsq0  \tsigsq1  \tsigsq2\n");


/*  if (debug) {
    sf(ps,"mean = %f, mean-sq = %f\n",vsum/num_pheno_peds,vsqsum/num_pheno_peds);
    pr();
  }*/

  array(lod,num_w_pos,double);

  run {
    for (i=0; i<num_w_pos; ++i) { /* loop over scan positions */
      /* initialize EM */
      loglike = -10000.0;
      sigsq_null = vsqsum/num_pheno_peds;
      sigsq[0] = sigsq[1] = sigsq[2] = sigsq_null;

      stop = 0;

      while (!stop)	{	/* do EM iterations */
	oldlike = loglike;
	loglike = 0;
	for (k=0; k<shared_poss; ++k)
	  x[k] = n[k] = 0;
	/* E step: recompute probabilities of sharing 0,1,2 */
	for (j=0; j<total_num_sib_pairs; ++j) { /* loop over pairs */

	  if (pheno_diffs[j] == MISSING_PHENO || weight[j] < .00001) continue;
	  sum = 0;
	  
	  for (k=0; k<shared_poss; ++k)
	    sum += warray[i][j][k]*a[k];
	  
	  if (sum == 0.0) {
	    /* This should never happen, but we'll handle it in case it does */
	    error("Sum of z's = 0.0 in maximum likelihood QTL variance algorithm\n");
	  }
	  
	  for (k=0; k<shared_poss; ++k)
	    z[k] = warray[i][j][k]*a[k]/sum;
	  
	  sum = 0;
	  for (k=0; k<shared_poss; ++k) {
	    p[k] = exp(-pheno_diffs[j]*pheno_diffs[j]/(2*sigsq[k]))/sqrt(sigsq[k]);
	    sum += p[k]*z[k];
	  }
	  
	  for (k=0; k<shared_poss; ++k)
	    z[k] = p[k]*z[k]/sum;
	  
	  for (k=0; k<shared_poss; ++k) {
	    x[k] += weight[j]*pheno_diffs[j]*pheno_diffs[j]*z[k];
	    n[k] += weight[j]*z[k];
	  }
	  loglike += weight[j]*log10(sum);
	}
	
	/* M step: re-estimate variances */
	for (k=0; k<shared_poss; ++k)
	  sigsq[k] = x[k]/n[k];

	if (sigsq[0] <= 0.0) break;

	if (loglike-oldlike < CONVERGE) stop = 1;
	if (oldlike > loglike+CONVERGE)
	  error("likelihood decreased in EM");
/*	if (debug) {
	  fprintf(output,"%.3lf %.3lf %.3lf %.3lf %.3lf \n",
		  wpos[i],loglike,sigsq[0],sigsq[1],sigsq[2]);
	}*/
      } /* end EM loop */

      if (sigsq[0] < sigsq[1]) {
	loglike = -10000.0;
	sigsq_null = vsqsum/num_pheno_peds;
	sigsq[0] = sigsq[1] = sigsq[2] = sigsq_null;

	stop = 0;

	while (!stop) {	/* do EM iterations */
	  oldlike = loglike;

	  loglike = 0;
	  for (k=0; k<3; ++k)
	    x[k] = n[k] = 0;
	  /* E step: recompute probabilities of sharing 0,1,2 */
	  for (j=0; j<total_num_sib_pairs; ++j) { /* loop over pairs */
	    if (pheno_diffs[j] == MISSING_PHENO || weight[j] < 0.00001) continue;

	    sum = 0;

	    for (k=0; k<3; ++k)
	      sum += warray[i][j][k]*a[k];
	    
	    if (sum == 0.0) {
	      /* This should never happen, but we'll handle it in case it does */
	      error("Sum of z's = 0.0 in maximum likelihood QTL variance algorithm\n");
	    }
	    
	    for (k=0; k<3; ++k)
	      z[k] = warray[i][j][k]*a[k]/sum;
	    
	    sum = 0;
	    for (k=0; k<3; ++k) {
	      p[k] = exp(-pheno_diffs[j]*pheno_diffs[j]/(2*sigsq[k]))/sqrt(sigsq[k]);
	      sum += p[k]*z[k];
	    }
	    
	    for (k=0; k<3; ++k)
	      z[k] = p[k]*z[k]/sum;
	    
	    for (k=0; k<3; ++k){
	      x[k] += weight[j]*pheno_diffs[j]*pheno_diffs[j]*z[k];
	      n[k] += weight[j]*z[k];
	    }
	    loglike += weight[j]*log10(sum);
	  }

	  /* M step: re-estimate variances */
	  sigsq[2] = x[2]/n[2];
	  sigsq[1] = sigsq[0] = (x[0]+x[1])/(n[0]+n[1]);
	  
	  if (loglike-oldlike < CONVERGE) stop = 1;
	  if (oldlike > loglike+CONVERGE)
	    error("likelihood decreased in EM");
	  
	} /* end EM loop */
      }

      else if (sigsq[1] < sigsq[2]) {
	loglike = -10000.0;
	sigsq_null = vsqsum/num_pheno_peds;
	sigsq[0] = sigsq[1] = sigsq[2] = sigsq_null;
	
	stop = 0;

	while (!stop) {	/* do EM iterations */
	  oldlike = loglike;
	  
	  loglike = 0;
	  for (k=0; k<3; ++k)
	    x[k] = n[k] = 0;
	  /* E step: recompute probabilities of sharing 0,1,2 */
	  for (j=0; j<total_num_sib_pairs; ++j) { /* loop over pairs */
	    if (pheno_diffs[j] == MISSING_PHENO || weight[j] < 0.00001) continue;
	    sum = 0;
	    
	    for (k=0; k<3; ++k)
	      sum += warray[i][j][k]*a[k];
	    
	    if (sum == 0.0) {
	      /* This should never happen, but we'll handle it in case it does */
	      error("Sum of z's = 0.0 in maximum likelihood QTL variance algorithm\n");
	    }
	    
	    
	    for (k=0; k<3; ++k)
	      z[k] = warray[i][j][k]*a[k]/sum;
	    
	    sum = 0;
	    for (k=0; k<3; ++k) {
	      p[k] = exp(-pheno_diffs[j]*pheno_diffs[j]/(2*sigsq[k]))/sqrt(sigsq[k]);
	      sum += p[k]*z[k];
	    }
	    
	    for (k=0; k<3; ++k)
	      z[k] = p[k]*z[k]/sum;
	    
	    for (k=0; k<3; ++k) {
	      x[k] += weight[j]*pheno_diffs[j]*pheno_diffs[j]*z[k];
	      n[k] += weight[j]*z[k];
	    }
	    loglike += weight[j]*log10(sum);
	  }
	  
	  /* M step: re-estimate variances */
	  sigsq[0] = x[0]/n[0];
	  sigsq[1] = sigsq[2] = (x[2]+x[1])/(n[2]+n[1]);
	  
	  if (loglike-oldlike < CONVERGE) stop = 1;
	  if (oldlike > loglike+CONVERGE)
	    error("likelihood decreased in EM");
	} /* end EM loop */
      }
      

      /* compute lod score */
      loglike0 = 0.0;
      for (j=0; j<total_num_sib_pairs; ++j) {
	if (pheno_diffs[j] != MISSING_PHENO && weight[j] > 0.0) 
	  loglike0 += weight[j]*(-LOG10E*pheno_diffs[j]*pheno_diffs[j]/(2*sigsq_null) - 0.5*log10(sigsq_null));
      }
      if (sigsq[0] < sigsq[1] || sigsq[1] < sigsq[2]) {
	sigsq[0] = sigsq[1] = sigsq[2] = sigsq_null;
	loglike = loglike0;
      }
  

      if (single_point_mode) 
	fprintf(output,"%3d\t%f\t%f\t%f\t%f\n",
		i+1,loglike-loglike0,sigsq[0],sigsq[1],sigsq[2]);
      else
	fprintf(output,"%.3lf\t%f\t%f\t%f\t%f\n",
		wpos[i],loglike-loglike0,sigsq[0],sigsq[1],sigsq[2]);

      lod[i] = loglike-loglike0;
    }

  } on_error {
    print("Error detected in maximum likelihood QTL variance algorithm\n");
    unarray(pheno_diffs,double);
    unarray(lod,double);
    close_file(output);
    if (num_in_map_order > 1 && postscript_output && !single_point_mode) {
      close_file(fpps);
    }
    return;
  }

  write_session_settings(output);
  fprintf(output, "\n*Phenotype se lected:  %d  Convergence limit: %.10lf\n",
	  pheno_index+1,CONVERGE);

  if (num_in_map_order > 1 && postscript_output && !single_point_mode) {
    draw_graph(fpps,wpos,lod,num_w_pos,"Maximum likelihood variance estimation","LOD");
  }

  if (num_in_map_order > 1 && postscript_output && !single_point_mode) 
    print("\nanalysis complete\ntext and drawing output files successfully written\n");
  else 
    print("\nanalysis complete\ntext output file successfully written\n");

  unarray(pheno_diffs,double);
  unarray(lod,double);
  close_file(output);

}


void no_dom_var(void)
{

  /* estimate phenotypic difference variances by maximum likelihood
     under the assumption of no dominance variance: 
     var0 = a, var1 = a(1+z), var2 = a(1+2z) */ 

  FILE *output, *fpps;
  int i, j, k, stop, pheno_index;
  double sum, xsum, xsqsum, vsum, vsqsum, xvsum, xvar, temp;
  double alpha, beta, sigsq[3], sigsq_null;
  double a[3], z[3], p[3], x[3], n[3];
  double loglike, oldlike, loglike0;
  double t;
  double *pheno_diffs;
  double solve_cubic(double, double, double, double, double, double, double *);
  double z_est, a_est;
  double *lod;
  char *tmp, *default_file;
  bool valid;
  double num_pheno_peds;

  /**** Check for the correct starting conditions ****/

  if (num_phenotypes == 0) 
    error("no phenotype data loaded for this session\n");
  
  /* Scan needs to be done to compute the ibd distribution
     which is stored in the warray.  The scan_done flag is
     set to false anytime map features change -- markers
     used, Kosambi vs. Haldane, scan steps, increments, pairs,
     active pedigrees, etc. */

  if (!scan_done)
    error("no scan done for the current map, pair, and pedigree settings\n");

  valid=FALSE;
  while (!valid) {
    if (num_phenotypes > 1) {
      sf(ps,"which phenotype do you want to analyze? (1-%d): ",
	 num_phenotypes);
      tmp = get_temp_string();
      input(ps,tmp,TEMP_STRING_LEN);
      itoken(&tmp,iREQUIRED,&pheno_index);
      if (pheno_index < 1 || pheno_index > num_phenotypes) {
	sf(ps,"phenotype '%d' does not exist",pheno_index);
	print(ps);
      } else {
	pheno_index--;
	valid=TRUE;
      }
    } else { pheno_index = 0; valid = TRUE;}
  }
  set_weights(pheno_index);

  /* Set Mendelian expectation */
  a[0] = a[2] = 0.25;
  a[1] = 0.5;

  num_pheno_peds=0;
  array(pheno_diffs, total_num_sib_pairs, double);
  for (i=0; i<total_num_sib_pairs; i++) {
    pheno_diffs[i]=pair_pheno[i][pheno_index];
    num_pheno_peds += weight[i];
  }
  vsum = vsqsum = 0;
  for (j=0; j<total_num_sib_pairs; ++j) {
    if (pheno_diffs[j] != MISSING_PHENO && weight[j] > 0.0) {
      vsum += weight[j]*pheno_diffs[j];
      vsqsum += weight[j]*pheno_diffs[j]*pheno_diffs[j];
    }
  }

  if (num_pheno_peds < 0.00001) {
    unarray(pheno_diffs,double);
    error("no pedigrees with phenotype data selected\n");
  }

  array(default_file,MAX_FILE_NAME_LEN,char);
  nstrcpy(default_file,"ml_ndv.out",MAX_FILE_NAME_LEN);
  output = open_out_file(default_file, "no dominance variance");

  if (num_in_map_order > 1 && postscript_output && !single_point_mode) {
    nstrcpy(default_file,"ml_ndv.ps",MAX_FILE_NAME_LEN);
    fpps = open_postscript_file(default_file, "postscript");
  }

  unarray(default_file,char);

  if (single_point_mode)
    fprintf(output,"marker\t  LOD    \tsigsq0  \tsigsq1 \tsigsq2\n");
  else
    fprintf(output,"pos   \t  LOD    \tsigsq0  \tsigsq1 \tsigsq2\n");

/*  if (debug) {
    sf(ps,"mean = %f, mean-sq = %f\n",vsum/num_pheno_peds,vsqsum/num_pheno_peds);
    pr();
  }*/

  array(lod,num_w_pos,double);

  run {
    for (i=0; i<num_w_pos; ++i) { /* loop over scan positions */
      /* initialize EM */
      loglike = -10000.0;
      sigsq_null = vsqsum/num_pheno_peds;
      sigsq[0] = sigsq[1] = sigsq[2] = sigsq_null;

      stop = 0;

      while (!stop) {		/* do EM iterations */

	oldlike = loglike;

	loglike = 0;
	for (k=0; k<3; ++k)
	  x[k] = n[k] = 0;
	/* E step: recompute probabilities of sharing 0,1,2 */
	for (j=0; j<total_num_sib_pairs; ++j) { /* loop over pairs */

	  if (pheno_diffs[j] == MISSING_PHENO || weight[j] < 0.00001) continue;
	  sum = 0;
	  
	  for (k=0; k<3; ++k)
	    sum += warray[i][j][k]*a[k];
	  
	  for (k=0; k<3; ++k)
	    z[k] = warray[i][j][k]*a[k]/sum;
	  
	  sum = 0;
	  
	  for (k=0; k<3; ++k) {
	    p[k] = exp(-pheno_diffs[j]*pheno_diffs[j]/(2*sigsq[k]))/sqrt(sigsq[k]);
	    sum += p[k]*z[k];
	  }
	  
	  for (k=0; k<3; ++k)
	    z[k] = p[k]*z[k]/sum;
	  
	  for (k=0; k<3; ++k) {
	    x[k] += weight[j]*pheno_diffs[j]*pheno_diffs[j]*z[k];
	    n[k] += weight[j]*z[k];
	  }
	  loglike += weight[j]*log10(sum);
	}
	
	/* M step: re-estimate variances */
	z_est = solve_cubic(x[0],x[1],x[2],n[0],n[1],n[2],&a_est);
	sigsq[0] = a_est;
	sigsq[1] = a_est*(1+z_est);
	sigsq[2] = a_est*(1+2*z_est);

	if (loglike-oldlike < CONVERGE) stop = 1;
	if (oldlike > loglike+CONVERGE)
	  error("likelihood decreased in EM");
      } /* end EM loop */

      /* compute lod score */
      loglike0 = 0.0;
      for (j=0; j<total_num_sib_pairs; ++j){
	if (pheno_diffs[j] != MISSING_PHENO && weight[j] > 0.0)
	  loglike0 += weight[j]*(-LOG10E*pheno_diffs[j]*pheno_diffs[j]/(2*sigsq_null) - 0.5*log10(sigsq_null));
      }
      if (sigsq[0] < sigsq[1] || sigsq[1] < sigsq[2]) {
	sigsq[0] = sigsq[1] = sigsq[2] = sigsq_null;
	loglike = loglike0;
      }
      if (single_point_mode)
	fprintf(output,"%3d\t%f\t%f\t%f\t%f\n",
		i+1,loglike-loglike0,sigsq[0],sigsq[1],sigsq[2]);
      else	
	fprintf(output,"%.3lf\t%f\t%f\t%f\t%f\n",
		wpos[i],loglike-loglike0,sigsq[0],sigsq[1],sigsq[2]);
      lod[i]=loglike-loglike0;
    }
  } on_error {
    print("error detected in no-dominance maximum likelihood variance estimation\n");
    close_file(output);
    if (num_in_map_order > 1 && postscript_output && !single_point_mode) {
      close_file(fpps);
    }
    unarray(lod,double);
    unarray(pheno_diffs,double);
    return;
  }

  write_session_settings(output);
  fprintf(output, "\n*Phenotype selected:  %d  Convergence limit: %.10lf\n",
	  pheno_index+1,CONVERGE);
  if (num_in_map_order > 1 && postscript_output && !single_point_mode) {
    draw_graph(fpps,wpos,lod,num_w_pos,"ML var estimate-no dominance var","LOD");
  }

  if (num_in_map_order > 1 && postscript_output && !single_point_mode) 
    print("\nanalysis complete\ntext and drawing output files successfully written\n");
  else 
    print("\nanalysis complete\ntext output file successfully written\n");

  close_file(output);

  unarray(lod,double);
  unarray(pheno_diffs,double);
}


double solve_cubic(double x0, double x1, double x2, double n0, double n1, double n2, double *a)
{
  double z;
  z = 
-(8*n1*x0 + 10*n2*x0 - 4*n0*x1 - 2*n0*x2)/(12*(n1 + n2)*x0) - 
   (-4*pow(4*n1*x0 + 5*n2*x0 - 2*n0*x1 - n0*x2,2.) + 
      12*(n1 + n2)*x0*(5*n1*x0 + 8*n2*x0 - 4*n0*x1 + 2*n2*x1 - 4*n0*x2 - 
         n1*x2))/
    (6*pow(2.,2./3.)*(n1 + n2)*x0*
      pow(-16*pow(4*n1*x0 + 5*n2*x0 - 2*n0*x1 - n0*x2,3.) + 
        72*(n1 + n2)*x0*(4*n1*x0 + 5*n2*x0 - 2*n0*x1 - n0*x2)*
         (5*n1*x0 + 8*n2*x0 - 4*n0*x1 + 2*n2*x1 - 4*n0*x2 - n1*x2) - 
        432*pow(n1 + n2,2.)*pow(x0,2.)*
         (n1*x0 + 2*n2*x0 - n0*x1 + n2*x1 - 2*n0*x2 - n1*x2) + 
        sqrt(4*pow(-4*pow(4*n1*x0 + 5*n2*x0 - 2*n0*x1 - n0*x2,2.) + 
             12*(n1 + n2)*x0*(5*n1*x0 + 8*n2*x0 - 4*n0*x1 + 2*n2*x1 - 
                4*n0*x2 - n1*x2),3.) + 
          pow(-16*pow(4*n1*x0 + 5*n2*x0 - 2*n0*x1 - n0*x2,3.) + 
            72*(n1 + n2)*x0*(4*n1*x0 + 5*n2*x0 - 2*n0*x1 - n0*x2)*
             (5*n1*x0 + 8*n2*x0 - 4*n0*x1 + 2*n2*x1 - 4*n0*x2 - n1*x2) - 
            432*pow(n1 + n2,2.)*pow(x0,2.)*
             (n1*x0 + 2*n2*x0 - n0*x1 + n2*x1 - 2*n0*x2 - n1*x2),2.)),1./3.)) + 
   pow(-16*pow(4*n1*x0 + 5*n2*x0 - 2*n0*x1 - n0*x2,3.) + 
      72*(n1 + n2)*x0*(4*n1*x0 + 5*n2*x0 - 2*n0*x1 - n0*x2)*
       (5*n1*x0 + 8*n2*x0 - 4*n0*x1 + 2*n2*x1 - 4*n0*x2 - n1*x2) - 
      432*pow(n1 + n2,2.)*pow(x0,2.)*
       (n1*x0 + 2*n2*x0 - n0*x1 + n2*x1 - 2*n0*x2 - n1*x2) + 
      sqrt(4*pow(-4*pow(4*n1*x0 + 5*n2*x0 - 2*n0*x1 - n0*x2,2.) + 
           12*(n1 + n2)*x0*(5*n1*x0 + 8*n2*x0 - 4*n0*x1 + 2*n2*x1 - 4*n0*x2 - 
              n1*x2),3.) + pow(-16*
           pow(4*n1*x0 + 5*n2*x0 - 2*n0*x1 - n0*x2,3.) + 
          72*(n1 + n2)*x0*(4*n1*x0 + 5*n2*x0 - 2*n0*x1 - n0*x2)*
           (5*n1*x0 + 8*n2*x0 - 4*n0*x1 + 2*n2*x1 - 4*n0*x2 - n1*x2) - 
          432*pow(n1 + n2,2.)*pow(x0,2.)*
           (n1*x0 + 2*n2*x0 - n0*x1 + n2*x1 - 2*n0*x2 - n1*x2),2.)),1./3.)/
    (12*pow(2.,1./3.)*(n1 + n2)*x0);

    *a = (x0+x1/(1+z)+x2/(1+2*z))/(n0+n1+n2);
    return z;
}


void nonparametric(void)
{

  /* compute nonparametric statistic*/

  FILE *output, *fpps;
  int i, j, k, pheno_index;
  int *order, *rank, *weighting, *weightsq, *pheno_to_w;
  double *pheno_diffs, y, var, *zstat, temp, *pheno;
  double a[3], z[3];
  double sum, expect;
  char *tmp,*default_file;
  bool valid;
  int shared_poss;
  int tmp_count;
  double num_pheno_peds;

  /**** Check for the correct starting conditions ****/

  if (num_phenotypes == 0)
    error("no phenotype data loaded for this session\n");
  
  /* Scan needs to be done to compute the ibd distribution
     which is stored in the warray.  The scan_done flag is
     set to false anytime map features change -- markers
     used, Kosambi vs. Haldane, scan steps, increments, pairs,
     active pedigrees, etc. */

  if (!scan_done)
    error("no scan done for the current map, pair, and pedigree settings\n");
  

  valid=FALSE;
  while (!valid) {
    if (num_phenotypes > 1) {
      sf(ps,"which phenotype do you want to analyze? (1-%d): ",
	 num_phenotypes);
      tmp = get_temp_string();
      input(ps,tmp,TEMP_STRING_LEN);
      itoken(&tmp,iREQUIRED,&pheno_index);
      if (pheno_index < 1 || pheno_index > num_phenotypes) {
	sf(ps,"phenotype '%d' does not exist",pheno_index);
	print(ps);
      } else {
	pheno_index--;
	valid=TRUE;
      }
    } else { pheno_index = 0; valid = TRUE;}
  }
  set_weights(pheno_index);

  num_pheno_peds=0;
  array(pheno_diffs, total_num_sib_pairs, double);
  for (i=0; i<total_num_sib_pairs; i++) {
    pheno_diffs[i]=pair_pheno[i][pheno_index];
    num_pheno_peds += weight[i];
  }

  if (num_pheno_peds <= 0.0) {
    unarray(pheno_diffs,double);
    error("no pedigrees with phenotypes selected\n");
  }

  array(pheno,total_num_sib_pairs,double);
  array(pheno_to_w,total_num_sib_pairs,int);
  array(order,total_num_sib_pairs,int);
  array(rank,total_num_sib_pairs,int);
  array(weighting,total_num_sib_pairs,int);
  array(weightsq,total_num_sib_pairs,int);
  array(zstat,num_w_pos,double);

  tmp_count = 0;
  for (j=0; j<total_num_sib_pairs; j++) {
    if (pheno_diffs[j] != MISSING_PHENO && weight[j] > .000001) {
      pheno_to_w[tmp_count]=j;
      pheno[tmp_count]=pheno_diffs[j];
      tmp_count++;
    }
  }

  array(default_file,MAX_FILE_NAME_LEN,char);
  nstrcpy(default_file,"np.out",MAX_FILE_NAME_LEN);
  output = open_out_file(default_file, "nonparametric");
  if (num_in_map_order > 1 && postscript_output && !single_point_mode) {
    nstrcpy(default_file,"np.ps",MAX_FILE_NAME_LEN);
    fpps = open_postscript_file(default_file, "postscript");
  }
  unarray(default_file,char);

  if (single_point_mode)
    fprintf(output,"marker\tZ-score\n");
  else
    fprintf(output,"pos   \tZ-score\n");

  a[1] = 0.5;
  a[0] = a[2] = 0.25;
  shared_poss=3;

  for (j=0; j<tmp_count; ++j) order[j] = j;
  sort(order,pheno,tmp_count);
  for (j=0; j<tmp_count; ++j) rank[order[j]] = j+1;
  for (j=0; j<tmp_count; ++j) {
    weighting[j] = num_pheno_peds+1-2*rank[j];
    weightsq[j] = weighting[j]*weighting[j];
  }
  
  run {
    for (i=0; i<num_w_pos; ++i) { /* loop over scan positions */
      y = 0;
      var = 0;
      for (j=0; j<tmp_count; ++j) {
	sum = 0;

	for (k=0; k<shared_poss; ++k)
	  sum += warray[i][pheno_to_w[j]][k]*a[k];

	if (sum <= 0.0)
	  error("sum of z's = 0.0 in nonparametric method\n");

	for (k=0; k<shared_poss; ++k)
	  z[k] = warray[i][pheno_to_w[j]][k]*a[k]/sum;

	expect = z[0] - z[2];
	temp = expect*expect;

	y += weight[pheno_to_w[j]]*weighting[j] * expect;
	var += weight[pheno_to_w[j]]*weightsq[j] * temp;
      }

      if (var == 0.0)
	error("var = 0.0 in nonparametric algorithm\n");
	  
      if (y<CONVERGE && var <CONVERGE)
	zstat[i] = 0;
      else
	zstat[i] = y/sqrt(var);
      /*
      fprintf(output,"%.3lf\t%f\t%f\n",wpos[i],zstat[i],
	      3*var/(num_pheno_peds*num_pheno_peds*num_pheno_peds-num_pheno_peds));
	      */
      if (single_point_mode) 
	fprintf(output,"%3d\t%f\n",i+1,zstat[i]);
      else
	fprintf(output,"%.3lf\t%f\n",wpos[i],zstat[i]);
    }
  } on_error {
    print("error detected in nonparametric algorithm\n");
    unarray(pheno_diffs,double);
    unarray(pheno,double);
    unarray(pheno_to_w,int);
    unarray(order,int);
    unarray(rank,int);
    unarray(weighting,int);
    unarray(weightsq,int);
    unarray(zstat,double);
    close_file(output);
    if (num_in_map_order > 1 && postscript_output && !single_point_mode) {
      close_file(fpps);
    }
    return;
  }
  

  write_session_settings(output);
  fprintf(output, "\n*Phenotype selected:  %d  Convergence limit: %.10lf\n",
	  pheno_index+1,CONVERGE);
  
  if (num_in_map_order > 1 && postscript_output && !single_point_mode) {
    draw_graph(fpps,wpos,zstat,num_w_pos,"Nonparametric Z-scores","Z");
  }

  if (num_in_map_order > 1 && postscript_output && !single_point_mode) 
    print("\nanalysis complete\ntext and drawing output files successfully written\n");
  else 
    print("\nanalysis complete\ntext output file successfully written\n");


  unarray(pheno_diffs,double);
  unarray(pheno,double);
  unarray(pheno_to_w,int);
  unarray(order,int);
  unarray(rank,int);
  unarray(weighting,int);
  unarray(weightsq,int);
  unarray(zstat,double);
  close_file(output);

}


void write_session_settings (FILE *fp)
{

  int i;

  /* Print a summary of the current session settings to
     the screen */
  fprintf(fp,"\n=======================================================\n");
  fprintf(fp,"*Time finished: %s\n\n",time_string());

  fprintf(fp,"*Pedigree file: %s\n",current_filename); 
  
  fprintf(fp,"*Pairs: ");
  if (pair_setting == FIRST_PAIR)
    fprintf(fp,"first pair from each sibship");
  else if (pair_setting == INDEPEND_PAIRS) 
    fprintf(fp,"all independent pairs");
  else if (pair_setting == ALL_PAIRS)
    fprintf(fp,"all pairs");
  else if (pair_setting == ALL_UNWEIGHTED)
    fprintf(fp, "all pairs, unweighted");
  fprintf(fp, "\n");

  if (single_point_mode) {
    fprintf(fp,"data for %d markers was analyzed in *single-point* mode\n",
	    num_markers);
  }
  else {
    fprintf(fp,"map (%d markers):\n",num_in_map_order);
    for (i=0; i<num_in_map_order-1; i++) {
      fprintf(fp,"%s %.1lf ",locus[map_order[i]].name,map_distance[i]);
    }
    fprintf(fp,"%s\n",locus[map_order[i]].name);
  

    fprintf(fp,"\tmap function: ");
    if (map_function == HALDANE) fprintf(fp,"haldane\n");
    else fprintf(fp,"kosambi\n");
    fprintf(fp,"\tunits: ");
    if (units == RECFRACS) fprintf(fp,"recfracs\n");
    else fprintf(fp,"centimorgans\n");
    fprintf(fp,"\toff end distance: %.1lf\n",off_end_dist); 
    if (scan_steps > 0) {
      fprintf(fp,"\t%d scan steps between markers\n",scan_steps); 
    } else {
      fprintf(fp,"\tscans done at constant increments of %.1lf cM\n",
	      scan_increment); 
    }
  }
}


int sort(int *order, double *pheno, int number)
{

  /* places into _order_ a list of pairs sorted by 
     decreasing abs phenotypic diff */

  int i, j, max, t;
 
  for (i=0; i<number-1; ++i)
    {
      max = i;
      for (j=i+1; j<number; ++j)
	if (fabs(pheno[order[j]]) > fabs(pheno[order[max]])) max = j;
      t = order[max];
      order[max] = order[i];
      order[i] = t;
    }
}


