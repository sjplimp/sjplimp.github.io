/* GENEHUNTER - Kruglyak, Daly, Reeve-Daly, and Lander
   Whitehead Institute for Biomedical Research, Copyright 1996 */
#define INC_LIB
#define INC_SHELL
#include "npl.h"

#define MISSING (-1) /* Value to set uncalculated fields to */

#define NOT_DONE

/* globals */
int **transmitted, **untransmitted, **double_het;
int TDTcount;
int one_parent_TDT, missing_TDT;
int dhskip;
/* QTDT globals */
int **qgenotype, **qparental;
double **qphenotype;
int num_qkids;
int qtdt_on;

/* locals */
int total_affecteds;
int which_allele[MAXLOCI][MAX_ALLELE_SIZE], allele_size[MAXLOCI][30], num_alleles[MAXLOCI];
int tdt2_diff, aff_relative_only;
FILE *fpt, *fpu;
int count_paternal,count_maternal;
int lowest_allele[MAXLOCI];
char *dadstr, *momstr, *dustr, *mustr;


command tdt_prep(void)
{

  /* Determine the type of pedigree we are dealing with (LINKAGE
     or our own internal format and call the appropriate method) */

  char *filename,s1[100],*hfilename;
  FILE *fpin, *ldfp;
  void tdt_linkage_pedigree(char*, int), tdt_stanford_pedigree(char*);
  int i,j,k,n,a,b,c,d,e,count,tmp_sum;
  double aa,bb,cc,dd,pval;
  double theta, chisq, diff, sum, chisq_prob(double,double), total_total;
  int temp_ser, temp_hap, temp_num_in_map_order, temp_map[MAXLOCI], **tmp_array, tmp_diff, tmp_gender;
  char *sig_string(double,double);

  if (num_markers == 0) {
    print("Please load marker information using 'load markers' first.\n");
    return;
  }

  total_affecteds=0;

  run {
    array(filename, TEMP_STRING_LEN, char);
    use_uncrunched_args();
    get_arg(stoken,"",filename);
	  
    if (nullstr(filename)) print("need filename as argument\n");

    count_paternal=count_maternal=1;

    get_arg(itoken, 0, &tmp_gender);
    if (tmp_gender==1) { count_maternal=0; }
    if (tmp_gender==2) { count_paternal=0; }

    fpin = open_file(filename,"r");
    fgetln(fpin);
    while(nullstr(ln)) fgetln(fpin);

    n = sscanf(ln,"%s %d %d %d %d %d",s1,&a,&b,&c,&d,&e);
    close_file(fpin); fpin=NULL;

    if (n > 0) {

      get_arg(itoken, 1, &tmp_diff);
      if (tmp_diff < 1) tmp_diff=1;
      tdt2_diff = tmp_diff;

      get_arg(itoken, 0, &tmp_diff);
      if (tmp_diff < 0 || tmp_diff > 2) { tmp_diff=0; }
      aff_relative_only = tmp_diff;

      /* TDT storage initialization */
      for (i=0; i<num_markers; i++) {
	for (j=0; j<MAX_ALLELE_SIZE; j++) {
	  locus[i].allele_count[j][0]=0; /* TRANSMITTED */
	  locus[i].allele_count[j][1]=0; /* UNTRANSMITTED */
	  locus[i].allele_count[j][2]=0; /* OBSERVED ANYWHERE */
	}
      }
      

      /* the 1 means 1st pass - single marker TDT 
         these will be stored in transmitted and untransmitted matrices */

      TDTcount=0;
      matrix(transmitted, num_markers+1, 10000, int);
      matrix(untransmitted, num_markers+1, 10000, int);
      matrix(double_het, num_markers+1, 10000, int);

      if (qtdt_on) {
	matrix(qgenotype, num_markers+1, 10000, int);
	matrix(qparental, num_markers+1, 10000, int);
	matrix(qphenotype, num_phenotypes+1, 10000, double);
      }
      num_qkids=0;
      /* define lowest_allele for QTDT storage */
      for (i=0; i<num_markers; i++) {
	for (j=1; j<MAX_ALLELE_SIZE; j++) {
	  if (locus[i].allele_freq[j] > 0.00) {
	    lowest_allele[i]=j; break;
	  }
	}
      }

      fpt = open_file("trans.out","w");
      fpu = open_file("untrans.out","w");

      tdt_linkage_pedigree(filename, 1); 

      close_file(fpt);
      close_file(fpu);

      /* TDT-results */

      sf(ps,"TDT Summary - (%d non-original affecteds):\n",total_affecteds); pr();

      for (i=0; i<num_in_map_order; i++) {
	sf(ps,"Marker %-12s    trans untrans  Chi2  p-val\n",locus[map_order[i]].name,map_order[i]+1); pr();
	for (j=0; j<MAX_ALLELE_SIZE; j++) {
	  if (locus[map_order[i]].allele_count[j][0] > 0 ||
	      locus[map_order[i]].allele_count[j][1] > 0) {
	    diff = (double) (locus[map_order[i]].allele_count[j][0] -
			     locus[map_order[i]].allele_count[j][1]);
	    sum = (double)  (locus[map_order[i]].allele_count[j][0] +
			     locus[map_order[i]].allele_count[j][1]);
	    chisq = diff*diff/sum;
	    pval = chisq_prob(1.0, chisq);
	    sf(ps,"%-10s- Allele %-3d  %4d  %4d   %6.2lf  %.6lf  %s\n",
	       locus[map_order[i]].name, j,
	       locus[map_order[i]].allele_count[j][TRANSMITTED],
	       locus[map_order[i]].allele_count[j][UNTRANSMITTED],
	       chisq, pval, sig_string(pval, diff)); pr();
	  }
	}
      }

      /*****
      num_in_map_order= temp_num_in_map_order;
      for (i=0; i<num_in_map_order; i++) {
	map_order[i] = temp_map[i];
      }
      *****/

    } else { 
      sf(ps,"error: can't recognize first line of pedigree file (%s)\n",ln);
      pr();
    }

  } on_error {
    if (msg == CANTOPEN) {
      sf(ps,"Can't open file '%s'\n",filename); pr();
    } else {
      relay_messages;
    }
  }
}


void tdt_stanford_pedigree(char *filename)
{

  /* eliminated to save space */
  error("old pedigree format - not supported");
}

/*********************************/
/* LINKAGE PEDIGREE READING CODE */
/*********************************/



typedef struct {
  int dad;
  int mom;
  int num_kids;
  int kid[MAX_KIDS];
  int pivot;
  bool inbred;        

  /* the following vars are for inbred families (or families in their loop)*/
  int num_common_anc; /* Number of ancestors in common between the mom&dad of this
			 nuclear family, for half-sibs it would be 1, in most other
			 cases it will be 2. */
  int dad_to_common;  /* Number of pedigree levels to the common ancestor.  For */
  int mom_to_common;  /* sibs marrying each other 0 levels, 1st cousins 1, etc */

  bool in_loop;
  int loop_indiv;

} NUC_FAMILY;

static NUC_FAMILY nuc_fam[MAX_INDIVIDUALS];
static int num_nuc_fam;
static int num_nuc_fams_to_peel;
/*G. Conant made int for c++ compile*/
static int order_assigned[MAX_INDIVIDUALS];


#define MALE 1
#define FEMALE 2
static char current_ped[MAX_NAME_SIZE];
int allele_data[MAX_INDIVIDUALS][MAXLOCI*2];
int num_allele_data[MAX_INDIVIDUALS];
int allele_offset;
int tdt_num_pedigrees;

/* Linkage pedigree auxiliary methods */
void set_mom_index(int,int);
void set_dad_index(int,int);
void check_for_unlinked(int);
void check_for_loop(int,int,int,int,int);
void sort_pedigree(int);
void place_indiv(int);
void fill_nuc_families(int);
int inbred_matings(void);
int mark_pivots(int);
void order_inbred_family(void);

int list_index;
char **pedigree_data;

void tdt_linkage_pedigree(char *filename, int pass)
{

  FILE *fpin;
  char ped_name[MAX_NAME_SIZE];
  char indiv_ID[MAX_NAME_SIZE];
  char father_ID[MAX_NAME_SIZE], mother_ID[MAX_NAME_SIZE];
  int sex, j, datum, pedigrees_loaded, num_data;
  void tdt_analyze_family(int);
  char *temp_data;
  double rdatum;
  /* Open the input file with the LINKAGE format pedigrees, and
     the output file where the inheritance vectors will be written */

  tdt_num_pedigrees=0;

  run {

    fpin = NULL; 
    fpin = open_file(filename,"r");
    strcpy(current_filename, filename);

  } except_when(CANTOPEN) {
    sf(ps,"Can't open file: %s\n",filename); pr();
    return;
  }

  array(famtree,MAX_INDIVIDUALS+5,PED_MEMBER);
  matrix(pedigree_data, MAXLOCI*2+MAX_PHENOTYPES, 256, char);

  array(dadstr,MAXLOCI*5,char);
  array(momstr,MAXLOCI*5,char);
  array(dustr,MAXLOCI*5,char);
  array(mustr,MAXLOCI*5,char);

  run {
    list_index=0;
    strcpy(current_ped,"");
    while(1) {

      fgetln(fpin);
      if (!maxstoken(&ln,sREQUIRED,ped_name,MAX_NAME_SIZE)) {
	/* blank line, read the next line */
      }
      else {
	/* actual line of data */
	if (nullstr(current_ped)) {
	  /* Record the new pedigree information for the first pedigree */
	  strcpy(current_ped,ped_name);
	  tdt_num_pedigrees++;
	} else if (strcasecmp(current_ped,ped_name) != 0) {
	  /* This line is the start of a new pedigree,
	     dump out the old one and reset the list index to 0 */

	  if (pass == 1) tdt_analyze_family(list_index); /* scans the family */
	  /* else tdt2_analyze_family(list_index); */

	  strcpy(current_ped,ped_name);
	  list_index=0;
	  tdt_num_pedigrees++;
	}
	
	/* Read the individual's index within the pedigree */
	if (!maxstoken(&ln,sREQUIRED,indiv_ID,MAX_NAME_SIZE)) {
	  sf(ps,"bad input line - no indivdual ID"); error(ps);
	}
	/* Read the parents' indices in the pedigree */
	if (!maxstoken(&ln,sREQUIRED,father_ID,MAX_NAME_SIZE)) {
	  sf(ps,"bad input line - no paternal ID for indiv %s",
	     indiv_ID); error(ps);
	}
	if (!maxstoken(&ln,sREQUIRED,mother_ID,MAX_NAME_SIZE)) {
	  sf(ps,"bad input line - no maternal ID for indiv %s",
	     indiv_ID); error(ps);
	}
	/* Read the sex of the individual */
	if (!itoken(&ln,iREQUIRED,&sex)) {
	  sf(ps,"bad input line - no sex for individual %s",indiv_ID);
	  error(ps);
	}
	
	/* Record the information in the family tree struct */
	strcpy(famtree[list_index].indiv_ID,indiv_ID);
	strcpy(famtree[list_index].dad,father_ID);
	strcpy(famtree[list_index].mom,mother_ID);
	famtree[list_index].sex=sex;
	/* Initialize values to be filled in later */
	famtree[list_index].nkids=0;
	famtree[list_index].dad_index=MISSING;
	famtree[list_index].mom_index=MISSING;
	for (j=0; j<MAX_PHENOTYPES; j++)
          famtree[list_index].phenotype[j]=MISSING_PHENO;
        for (j=0; j<MAX_COVARIATES; j++)
          famtree[list_index].covariate[j]=0.0;

	/* Check that this isn't a duplicate indiv_ID */
	for (j=0; j<list_index; j++)
	  if (!strcasecmp(famtree[j].indiv_ID,
			  famtree[list_index].indiv_ID)) {
	    sf(ps,"indiv %s appears more than once in pedigree %s",
	       famtree[list_index].indiv_ID,current_ped); error(ps);
	  }
	
	/* Read in the genotype and phenotype data */
        j=0;
        while (stoken(&ln,sREQUIRED,pedigree_data[j]))
          j++;

        num_data=j;
        if (num_data == 2*num_markers + num_phenotypes + num_covs + 1)
          allele_offset = 1;
        else if (num_data == 2*num_markers + num_phenotypes + num_covs + 2)
          allele_offset = 2;
        else {
          sf(ps,"number of loci and phenotypes in pedigree file different from number in\n locus file - ped %s\n",
             current_ped); 
          error(ps);
        }

        /* Store the genotype data in static structs */
        temp_data = get_temp_string();
        for (j=0; j<(num_data-(num_phenotypes+num_covs)); j++) {
          strcpy(temp_data, pedigree_data[j]);
          itoken(&temp_data, iREQUIRED, &datum);
          allele_data[list_index][j]=datum;
        }
        num_allele_data[list_index]=j;

        /* Store the phenotype data in static structs */
        for (j=0; j<num_phenotypes; j++) {
          strcpy(temp_data, pedigree_data[j+2*num_markers+allele_offset]);
          if (strcasecmp(temp_data, "-")) {
            rtoken(&temp_data, rREQUIRED, &rdatum);
            famtree[list_index].phenotype[j]=rdatum;
          }
        }

	/* Store the covariate data in static structs */
        for (j=0; j<num_covs; j++) {
          strcpy(temp_data, pedigree_data[j+2*num_markers+num_phenotypes+allele_offset])
;
          if (strcasecmp(temp_data, "-")) {
            rtoken(&temp_data, rREQUIRED, &rdatum);
            famtree[list_index].covariate[j] = rdatum;
          }
        }

	/****** Original: Read in the genotype data -store in static structs 
	j=0;
	while (itoken(&ln,iREQUIRED,&datum)) {
	  allele_data[list_index][j]=datum;
	  j++;
	}
	num_allele_data[list_index]=j;
	********************/

	list_index++;
      }
    }	
    close_file(fpin);
    pedigrees_loaded=TRUE;
    unarray(famtree,PED_MEMBER);
  } except {
      when SOFTABORT: 
          pedigrees_loaded=FALSE;
          tdt_num_pedigrees=0;
          close_file(fpin); fpin=NULL;
          unarray(famtree,PED_MEMBER);
          relay;
      when ENDOFILE:
          if (list_index > 0) {
	    pedigrees_loaded=TRUE;
	    run { 
	      if (pass == 1) tdt_analyze_family(list_index); 
	      /* else tdt2_analyze_family(list_index); */
	    } on_error {
	      pedigrees_loaded=FALSE;
	    }
	  }
          close_file(fpin); fpin=NULL;
          unarray(famtree,PED_MEMBER);
          break;
      default:
          close_file(fpin); fpin=NULL;
          unarray(famtree,PED_MEMBER);
          relay;
  }
}


void tdt_analyze_family(int num_in_ped)
{
  int i,j,kid0,kid1,dad0,dad1,mom0,mom1,num;
  int dad_het, mom_het, num_loci, dad_affected, mom_affected;
  char *tempstr;
  int good_for_qcount;

  run {

    if (num_allele_data[0]%2==1) 
      allele_offset = 1;
    else 
      allele_offset = 2;

    for (i=0; i<num_in_ped; i++) {
      set_dad_index(i,num_in_ped);
      set_mom_index(i,num_in_ped);
    }

    num_loci = (num_allele_data[0]-allele_offset)/2; 
    if (num_loci != num_markers) {
      sf(ps,
"num_loci in pedigree file (%d) != num_markers in locus file (%d) - ped %s\n",
         num_loci,num_markers,current_ped); error(ps);
    }

    /* fill in affectation_status in PED_MEMBERs */
    for (i=0; i<num_in_ped; i++) {
      famtree[i].affectation_status = allele_data[i][0];
    }

    for (i=0; i<num_in_ped; i++) {
      if ((famtree[i].affectation_status == 2 || qtdt_on) && 
	  famtree[i].dad_index!=MISSING && famtree[i].mom_index!=MISSING) {

	/* eligible for TDT count */
	good_for_qcount=0;
        strcpy(dadstr,"");
	strcpy(momstr,"");
	strcpy(dustr,"");
	strcpy(mustr,"");
	tempstr = get_temp_string(); strcpy(tempstr,"");

	if (famtree[famtree[i].dad_index].affectation_status == 2) dad_affected=1;
	else dad_affected=0;
	if (famtree[famtree[i].mom_index].affectation_status == 2) mom_affected=1;
	else mom_affected=0;

	for (j=0; j<num_loci; j++) {
	  num = allele_offset+(j*2);
	  dad0 = allele_data[famtree[i].dad_index][num];
	  dad1 = allele_data[famtree[i].dad_index][num+1];
	  mom0 = allele_data[famtree[i].mom_index][num];
	  mom1 = allele_data[famtree[i].mom_index][num+1];
	  kid0 = allele_data[i][num];
	  kid1 = allele_data[i][num+1];
	  if (qtdt_on) {
	    qgenotype[j][num_qkids]=MISSING;
	    qparental[j][num_qkids]=MISSING;
	  }
	  /* total alleles observed */
	  if (kid0 > 0) locus[j].allele_count[kid0][2]++;
	  if (kid1 > 0) locus[j].allele_count[kid1][2]++;

	  double_het[j][TDTcount]=FALSE;
	  double_het[j][TDTcount+1]=FALSE;

	  if (kid0 == 0 || kid1 == 0) {

	      if (dad0==dad1 && dad0 != 0) {
		sf(tempstr,"%3d ",dad0); 
		strcat(dadstr,tempstr);
		strcat(dustr,tempstr);
		transmitted[j][TDTcount]=MISSING;/* dad0; */
		untransmitted[j][TDTcount]=MISSING; /* dad1; */
	      } else {
		strcat(dadstr," 0  ");
		strcat(dustr," 0  ");
		transmitted[j][TDTcount]=MISSING;
		untransmitted[j][TDTcount]=MISSING;	      
	      }
	      if (mom0==mom1 && mom0 != 0) {
		sf(tempstr,"%3d ",mom0); 
		strcat(momstr,tempstr);
		strcat(mustr,tempstr);
		transmitted[j][TDTcount+1]=MISSING; /* mom0; */
		untransmitted[j][TDTcount+1]=MISSING; /* mom1; */
	      } else {
		strcat(momstr," 0  ");
		strcat(mustr," 0  ");
		transmitted[j][TDTcount+1]=MISSING;
		untransmitted[j][TDTcount+1]=MISSING;
	      }
	      continue;
	  }

	  /* if dhskip is set, ignore all cases where dad=AB and mom=AB */
	  if ((dad0==mom0 && dad1==mom1 && dad0!=dad1 && dhskip) ||
	      (dad0==mom1 && dad1==mom0 && dad0!=dad1 && dhskip)) {
	    double_het[j][TDTcount]=TRUE;
	    double_het[j][TDTcount+1]=TRUE;
	    strcat(dadstr," 0  ");
	    strcat(dustr," 0  ");
	    transmitted[j][TDTcount]=MISSING;
	    untransmitted[j][TDTcount]=MISSING;	      
	    strcat(momstr," 0  ");
	    strcat(mustr," 0  ");
	    transmitted[j][TDTcount+1]=MISSING;
	    untransmitted[j][TDTcount+1]=MISSING;
	    continue;
	  }

	  /* in the following: by het we mean the ambiguous parent: AB, kid: AB */
	  dad_het = mom_het = 0;
	  if (dad0==kid0 && dad1==kid1 && dad0!=dad1) dad_het=TRUE;
	  if (dad0==kid1 && dad1==kid0 && dad0!=dad1) dad_het=TRUE;
	  if (mom0==kid0 && mom1==kid1 && mom0!=mom1) mom_het=TRUE;
	  if (mom0==kid1 && mom1==kid0 && mom0!=mom1) mom_het=TRUE;

	  if (dad_het && mom_het) {
	    /* dreaded double het */
	    /* add 1 trans, 1 untrans to each */
	    if (!aff_relative_only || (dad_affected && mom_affected)) {
	      if (count_paternal && count_maternal) {
		locus[j].allele_count[kid0][TRANSMITTED]++;
		locus[j].allele_count[kid0][UNTRANSMITTED]++;
		locus[j].allele_count[kid1][TRANSMITTED]++;
		locus[j].allele_count[kid1][UNTRANSMITTED]++;
	      }
	      double_het[j][TDTcount]=TRUE;
	      double_het[j][TDTcount+1]=TRUE;
	      transmitted[j][TDTcount]=kid0;
	      untransmitted[j][TDTcount]=kid1;
	      transmitted[j][TDTcount+1]=kid1;
	      untransmitted[j][TDTcount+1]=kid0;
	      strcat(dadstr," h  ");
	      strcat(momstr," h  ");
	      strcat(dustr," h  ");
	      strcat(mustr," h  ");
	      if (qtdt_on) {
		qgenotype[j][num_qkids]=1; /* 1 copy of allele 2 */
		qparental[j][num_qkids]=2; /* ab x ab */
		good_for_qcount=TRUE;
	      }
	    }

	  } else { 

	    /* If dad is the ambiguous double het, use mom to resolve dad and vice-versa */

	    if (dad_het) {
	      if (mom0==0 || mom1==0) { 
		/* dad dbl-het, mom missing - SKIP */
		transmitted[j][TDTcount]=MISSING;
		untransmitted[j][TDTcount]=MISSING;
		transmitted[j][TDTcount+1]=MISSING;
		untransmitted[j][TDTcount+1]=MISSING; 
		strcat(dadstr," 0  ");
		strcat(momstr," 0  ");
		strcat(dustr," 0  ");
		strcat(mustr," 0  ");
	      }
	      else {
		if (mom0 == kid0 || mom0 == kid1) {
		  if (mom0 != mom1) {
		    if (count_maternal) {
		      locus[j].allele_count[mom0][TRANSMITTED]++;
		      locus[j].allele_count[mom1][UNTRANSMITTED]++;
		    }
		  }
		  /* store all (even homozygotes) for multipoint analysis */
		  transmitted[j][TDTcount+1]=mom0;
		  untransmitted[j][TDTcount+1]=mom1;
		  sf(tempstr,"%3d ",mom0); strcat(momstr,tempstr);
		  sf(tempstr,"%3d ",mom1); strcat(mustr,tempstr);

		  if (dad0 == mom0) {
		    /* then dad1 must be transmitted */
		    if (count_paternal) {
		      locus[j].allele_count[dad1][TRANSMITTED]++;
		      locus[j].allele_count[dad0][UNTRANSMITTED]++;
		    }
		    transmitted[j][TDTcount]=dad1;
		    untransmitted[j][TDTcount]=dad0;
		    sf(tempstr,"%3d ",dad1); strcat(dadstr,tempstr);
		    sf(tempstr,"%3d ",dad0); strcat(dustr,tempstr);
		  } else {
		    /* dad0 must be transmitted */
		    if (count_paternal) {
		      locus[j].allele_count[dad0][TRANSMITTED]++;
		      locus[j].allele_count[dad1][UNTRANSMITTED]++;
		    }
		    transmitted[j][TDTcount]=dad0;
		    untransmitted[j][TDTcount]=dad1;
		    sf(tempstr,"%3d ",dad0); strcat(dadstr,tempstr);
		    sf(tempstr,"%3d ",dad1); strcat(dustr,tempstr);
		  }
		} else {
		  if (mom0 != mom1) {
		    if (count_maternal) {
		      locus[j].allele_count[mom1][TRANSMITTED]++;
		      locus[j].allele_count[mom0][UNTRANSMITTED]++;
		    }
		  }
		  transmitted[j][TDTcount+1]=mom1;
		  untransmitted[j][TDTcount+1]=mom0;
		  sf(tempstr,"%3d ",mom1); strcat(momstr,tempstr);
		  sf(tempstr,"%3d ",mom0); strcat(mustr,tempstr);

		  if (dad0 == mom1) {
		    /* then dad1 must be transmitted */
		    if (count_paternal) {
		      locus[j].allele_count[dad1][TRANSMITTED]++;
		      locus[j].allele_count[dad0][UNTRANSMITTED]++;
		    }
		    transmitted[j][TDTcount]=dad1;
		    untransmitted[j][TDTcount]=dad0;
		    sf(tempstr,"%3d ",dad1); strcat(dadstr,tempstr);
		    sf(tempstr,"%3d ",dad0); strcat(dustr,tempstr);
		  } else {
		    /* dad0 must be transmitted */
		    if (count_paternal) {
		      locus[j].allele_count[dad0][TRANSMITTED]++;
		      locus[j].allele_count[dad1][UNTRANSMITTED]++;
		    }
		    transmitted[j][TDTcount]=dad0;
		    untransmitted[j][TDTcount]=dad1;
		    sf(tempstr,"%3d ",dad0); strcat(dadstr,tempstr);
		    sf(tempstr,"%3d ",dad1); strcat(dustr,tempstr);
		  }
		}
	      }
	      /* dad and kid are het */
	      if (qtdt_on && mom0==mom1 && mom0 != 0) {
		if (mom0==lowest_allele[j]) {
		  qgenotype[j][num_qkids]=1; /* 1 copy of allele 2 */
		  qparental[j][num_qkids]=1; /* aa x ab */
		  good_for_qcount=TRUE;
		} else {
		  qgenotype[j][num_qkids]=1; /* 1 copy of allele 2 */
		  qparental[j][num_qkids]=3; /* bb x ab */
		  good_for_qcount=TRUE;
		}
	      }

	    } else if (mom_het) {
	      if (dad0==0 || dad1==0) { 
		/* mom dbl-het, dad missing - SKIP */ 
		transmitted[j][TDTcount]=MISSING;
		untransmitted[j][TDTcount]=MISSING;
		transmitted[j][TDTcount+1]=MISSING;
		untransmitted[j][TDTcount+1]=MISSING; 
		strcat(dadstr," 0  ");
		strcat(momstr," 0  ");
		strcat(dustr," 0  ");
		strcat(mustr," 0  ");
	      } else {
		if (dad0 == kid0 || dad0 == kid1) {
		  if (dad0 != dad1) {
		    if (count_paternal) {
		      locus[j].allele_count[dad0][TRANSMITTED]++;
		      locus[j].allele_count[dad1][UNTRANSMITTED]++;
		    }
		  }
		  transmitted[j][TDTcount]=dad0;
		  untransmitted[j][TDTcount]=dad1;
		  sf(tempstr,"%3d ",dad0); strcat(dadstr,tempstr);
		  sf(tempstr,"%3d ",dad1); strcat(dustr,tempstr);

		  if (mom0 == dad0) {
		    /* then mom1 must be transmitted */
		    if (count_maternal) {
		      locus[j].allele_count[mom1][TRANSMITTED]++;
		      locus[j].allele_count[mom0][UNTRANSMITTED]++;
		    }
		    transmitted[j][TDTcount+1]=mom1;
		    untransmitted[j][TDTcount+1]=mom0;
		    sf(tempstr,"%3d ",mom1); strcat(momstr,tempstr);
		    sf(tempstr,"%3d ",mom0); strcat(mustr,tempstr);
		  } else {
		    /* mom0 must be transmitted */
		    if (count_maternal) {
		      locus[j].allele_count[mom0][TRANSMITTED]++;
		      locus[j].allele_count[mom1][UNTRANSMITTED]++;
		    }
		    transmitted[j][TDTcount+1]=mom0;
		    untransmitted[j][TDTcount+1]=mom1;
		    sf(tempstr,"%3d ",mom0); strcat(momstr,tempstr);
		    sf(tempstr,"%3d ",mom1); strcat(mustr,tempstr);
		  } 
		} else {
		  if (dad0 != dad1) {
		    if (count_paternal) {
		      locus[j].allele_count[dad1][TRANSMITTED]++;
		      locus[j].allele_count[dad0][UNTRANSMITTED]++;
		    }
		  }
		  transmitted[j][TDTcount]=dad1;
		  untransmitted[j][TDTcount]=dad0;
		  sf(tempstr,"%3d ",dad1); strcat(dadstr,tempstr);
		  sf(tempstr,"%3d ",dad0); strcat(dustr,tempstr);

		  if (mom0 == dad1) {
		    /* then mom1 must be transmitted */
		    if (count_maternal) {
		      locus[j].allele_count[mom1][TRANSMITTED]++;
		      locus[j].allele_count[mom0][UNTRANSMITTED]++;
		    }
		    transmitted[j][TDTcount+1]=mom1;
		    untransmitted[j][TDTcount+1]=mom0;
		    sf(tempstr,"%3d ",mom1); strcat(momstr,tempstr);
		    sf(tempstr,"%3d ",mom0); strcat(mustr,tempstr);
		  } else {
		    /* mom0 must be transmitted */
		    if (count_maternal) {
		      locus[j].allele_count[mom0][TRANSMITTED]++;
		      locus[j].allele_count[mom1][UNTRANSMITTED]++;
		    }
		    transmitted[j][TDTcount+1]=mom0;
		    untransmitted[j][TDTcount+1]=mom1;
		    sf(tempstr,"%3d ",mom0); strcat(momstr,tempstr);
		    sf(tempstr,"%3d ",mom1); strcat(mustr,tempstr);
		  } 
		}
	      }
	      /* mom and kid are het */
	      if (qtdt_on && dad0==dad1 && dad0 != 0) {
		if (dad0==lowest_allele[j]) {
		  qgenotype[j][num_qkids]=1; /* 1 copy of allele 2 */
		  qparental[j][num_qkids]=1; /* aa x ab */
		  good_for_qcount=TRUE;
		} else {
		  qgenotype[j][num_qkids]=1; /* 1 copy of allele 2 */
		  qparental[j][num_qkids]=3; /* bb x ab */
		  good_for_qcount=TRUE;
		}
	      }

	    } else {
	      /* just normal old TDT - each parent contains only 1 of
		 the childs alleles so this part is trivial */

	      if (kid0==kid1 && (dad0==0 || dad1==0 || mom0==0 || mom1==0) && !one_parent_TDT) {
		transmitted[j][TDTcount]=MISSING;
		untransmitted[j][TDTcount]=MISSING;
		transmitted[j][TDTcount+1]=MISSING;
		untransmitted[j][TDTcount+1]=MISSING;
		strcat(dadstr," 0  "); strcat(dustr," 0  ");
		strcat(momstr," 0  "); strcat(mustr," 0  ");
	      } else {

		if (dad0 == 0 || dad1 == 0) { 
		  transmitted[j][TDTcount]=MISSING;
		  untransmitted[j][TDTcount]=MISSING;
		  strcat(dadstr," 0  "); strcat(dustr," 0  ");
		} else if (dad0 == dad1) { 
		  transmitted[j][TDTcount]=dad1;
		  untransmitted[j][TDTcount]=dad0;
		  sf(tempstr,"%3d ",dad1); strcat(dadstr,tempstr);
		  sf(tempstr,"%3d ",dad0); strcat(dustr,tempstr);
		} else if (dad0 == kid0 || dad0 == kid1) {
		  if (count_paternal) {
		    locus[j].allele_count[dad0][TRANSMITTED]++;
		    locus[j].allele_count[dad1][UNTRANSMITTED]++;
		  }
		  transmitted[j][TDTcount]=dad0;
		  untransmitted[j][TDTcount]=dad1;
		  sf(tempstr,"%3d ",dad0); strcat(dadstr,tempstr);
		  sf(tempstr,"%3d ",dad1); strcat(dustr,tempstr);
		} else {
		  if (count_paternal) {
		    locus[j].allele_count[dad1][TRANSMITTED]++;
		    locus[j].allele_count[dad0][UNTRANSMITTED]++;
		  }
		  transmitted[j][TDTcount]=dad1;
		  untransmitted[j][TDTcount]=dad0;
		  sf(tempstr,"%3d ",dad1); strcat(dadstr,tempstr);
		  sf(tempstr,"%3d ",dad0); strcat(dustr,tempstr);
		}

		if (mom0 == 0 || mom1 == 0) { 
		  transmitted[j][TDTcount+1]=MISSING;
		  untransmitted[j][TDTcount+1]=MISSING;
		  strcat(momstr," 0  "); strcat(mustr," 0  ");
		} else if (mom0 == mom1) { 
		  transmitted[j][TDTcount+1]=mom0;
		  untransmitted[j][TDTcount+1]=mom1;
		  sf(tempstr,"%3d ",mom0); strcat(momstr,tempstr);
		  sf(tempstr,"%3d ",mom1); strcat(mustr,tempstr);
		} else if (mom0 == kid0 || mom0 == kid1) {
		  if (count_maternal) {
		    locus[j].allele_count[mom0][TRANSMITTED]++;
		    locus[j].allele_count[mom1][UNTRANSMITTED]++;
		  }
		  transmitted[j][TDTcount+1]=mom0;
		  untransmitted[j][TDTcount+1]=mom1;
		  sf(tempstr,"%3d ",mom0); strcat(momstr,tempstr);
		  sf(tempstr,"%3d ",mom1); strcat(mustr,tempstr);
		} else {
		  if (count_maternal) {
		    locus[j].allele_count[mom1][TRANSMITTED]++;
		    locus[j].allele_count[mom0][UNTRANSMITTED]++;
		  }
		  transmitted[j][TDTcount+1]=mom1;
		  untransmitted[j][TDTcount+1]=mom0;
		  sf(tempstr,"%3d ",mom1); strcat(momstr,tempstr);
		  sf(tempstr,"%3d ",mom0); strcat(mustr,tempstr);
		}
	      }
	    }
	    /* either kid is het and both parents hom - SKIP
	       or kid is hom */
	    if (qtdt_on && kid0==kid1 && dad0 != 0 && dad1 != 0
		&& mom0 != 0 && mom1 != 0) {
	      if (dad0==dad1) {
		if (mom0==mom1) { /* skip */ }
		else {
		  if (dad0==lowest_allele[j]) {
		    if (kid0==dad0) {
		      qgenotype[j][num_qkids]=0; /* 0 copies of allele 2 */
		      qparental[j][num_qkids]=1; /* aa x ab */
		      good_for_qcount=TRUE;
		    } /* else Mendel error */
		  } else {
		    if (kid0==dad0) {
		      qgenotype[j][num_qkids]=2; /* 2 copies of allele 2 */
		      qparental[j][num_qkids]=3; /* bb x ab */
		      good_for_qcount=TRUE;
		    } /* else Mendel error */
		  }
		}
	      } else { /* dad het, kid hom */
		if (mom0==mom1) {
		  if (mom0==lowest_allele[j]) {
		    if (kid0==mom0) {
		      qgenotype[j][num_qkids]=0; /* 1 copy of allele 2 */
		      qparental[j][num_qkids]=1; /* aa x ab */
		      good_for_qcount=TRUE;
		    } /* else Mendel error */
		  } else {
		    if (kid0==mom0) {
		      qgenotype[j][num_qkids]=2; /* 2 copies of allele 2 */
		      qparental[j][num_qkids]=3; /* bb x ab */
		      good_for_qcount=TRUE;
		    } /* else Mendel error */
		  }
		} else {
		  /* both parents het, kid hom */
		  if (kid0==lowest_allele[j]) {
		    qgenotype[j][num_qkids]=0; /* aa */
		    qparental[j][num_qkids]=2; /* ab x ab */
		    good_for_qcount=TRUE;
		  } else {
		    qgenotype[j][num_qkids]=2; /* bb */
		    qparental[j][num_qkids]=2; /* ab x ab */
		    good_for_qcount=TRUE;
		  }
		}
	      }
	    }
	  }

	} /* for loci */

	TDTcount += 2;

	sf(ps,"%s\t%s\t%s\n",current_ped,famtree[i].indiv_ID,dadstr); fpr(fpt);
	sf(ps,"%s\t%s\t%s\n",current_ped,famtree[i].indiv_ID,dustr); fpr(fpu);

	sf(ps,"%s\t%s\t%s\n",current_ped,famtree[i].indiv_ID,momstr); fpr(fpt);
	sf(ps,"%s\t%s\t%s\n",current_ped,famtree[i].indiv_ID,mustr); fpr(fpu);

	if (good_for_qcount && qtdt_on) {
	  /* fill in qphenotype here */
	  for (j=0; j<num_phenotypes; j++) {
	    qphenotype[j][num_qkids] = famtree[i].phenotype[j];
	  }
	  num_qkids++;
	}

      }
    }
  } on_error {
    relay_messages;
  }
}



char *sig_string(double pval, double diff)
{
    char *tmpstr;
    tmpstr = get_temp_string();

    if (pval < .000001) {
      if (diff < 0.0) sprintf(tmpstr,"------");
      else sprintf(tmpstr,"++++++");
    } else if (pval < .00001) {
      if (diff < 0.0) sprintf(tmpstr,"-----");
      else sprintf(tmpstr,"+++++");
    } else if (pval < .0001) {
      if (diff < 0.0) sprintf(tmpstr,"----");
      else sprintf(tmpstr,"++++");
    } else if (pval < .001) {
      if (diff < 0.0) sprintf(tmpstr,"---");
      else sprintf(tmpstr,"+++");
    } else if (pval < .01) {
      if (diff < 0.0) sprintf(tmpstr,"--");
      else sprintf(tmpstr,"++");
    } else if (pval < .05) {
      if (diff < 0.0) sprintf(tmpstr,"-");
      else sprintf(tmpstr,"+");
    } else {
      sprintf(tmpstr,"");
    }
    return(tmpstr);
}




command tdt2(void)   /* Two dimensional TDT / LD test */
{
    int i, j, k, count, tmp_diff, t1, t2, u1, u2;
    int **trans2, **untrans2, **count2;
    double chisq, pval, diff, sum, chisq_prob(double,double), aa,bb,cc,dd;
    int tmp_sum, *jsum, *ksum, **tmp_array, largest_count, tmp_gender;
    int count_pat=1, count_mat=1;
    FILE *ldfp;


    if (TDTcount == 0) { /* exit */
      print("error: tdt command must be run before using the tdt2 command\n");
      return;
    }
      
    get_arg(itoken, 1, &tmp_diff);
    if (tmp_diff < 1) tmp_diff=1;
    tdt2_diff = tmp_diff;

    get_arg(itoken, 0, &tmp_gender);
    if (tmp_gender == 1) count_mat=0;
    else if (tmp_gender == 2) count_pat=0;

    /* First shrink the list of alleles we're looking at to only the 
       existent ones (rather than the 1 to MAX_ALLELE_SIZE used above */

    largest_count=0;
    for (i=0; i<num_in_map_order; i++) {
	count=0;
	for (j=0; j<MAX_ALLELE_SIZE; j++) {
	  if (locus[map_order[i]].allele_count[j][2] > 0 ||
	      locus[map_order[i]].allele_count[j][1] > 0) {
	    which_allele[map_order[i]][j] = count;
	    allele_size[map_order[i]][count] = j;
	    count++;
	  } else {
	    which_allele[map_order[i]][j] = MISSING;
	  }
	  num_alleles[map_order[i]] = count;
	}
	if (count > largest_count) { largest_count=count; }
    }
    largest_count++;
    matrix(trans2, largest_count, largest_count, int);
    matrix(untrans2, largest_count, largest_count, int);
    matrix(count2, largest_count, largest_count, int);

    matrix(tmp_array, 50, 50, int);
    array(jsum, largest_count, int);
    array(ksum, largest_count, int);

    ldfp = open_file("ld.out","w");

    for (i=0; i<num_in_map_order-tdt2_diff; i++) {

        for (j=0; j<largest_count; j++) {
	  for (k=0; k<largest_count; k++) {
	    trans2[j][k] = untrans2[j][k] = 0;
	    count2[j][k] = 0;
	  }
	}

	sf(ps,"Markers %d and %d       trans untrans  Chi2  p-val (%s - %s)\n",
	   map_order[i]+1, map_order[i+tdt2_diff]+1, locus[map_order[i]].name, 
	   locus[map_order[i+tdt2_diff]].name); pr();

	sf(ps,"Markers %d and %d  (%s - %s):\n",map_order[i]+1,map_order[i+tdt2_diff]+1,
	   locus[map_order[i]].name, locus[map_order[i+tdt2_diff]].name); fpr(ldfp);
	fprint(ldfp,"    ");
	for (k=0; k<num_alleles[map_order[i+tdt2_diff]]; k++) {
	  sf(ps," %3d",allele_size[map_order[i+tdt2_diff]][k]); fpr(ldfp);
	}
	fnl(ldfp);

	tmp_sum = 0;

	for (j=0; j<TDTcount; j++) {
	  if (!count_pat && j%2==0) continue;
	  if (!count_mat && j%2==1) continue;

	  t1 = transmitted[map_order[i]][j];  t2 = transmitted[map_order[i+tdt2_diff]][j];
	  u1 = untransmitted[map_order[i]][j];  u2 = untransmitted[map_order[i+tdt2_diff]][j];

	  if (t1==MISSING || t2==MISSING || double_het[map_order[i]][j] || double_het[map_order[i+tdt2_diff]][j]) continue;


	  if (t1==u1 && t2==u2) {
	    count2[which_allele[map_order[i]][t1]][which_allele[map_order[i+tdt2_diff]][t2]] += 2;
	    continue;
	  }

	  trans2[which_allele[map_order[i]][t1]][which_allele[map_order[i+tdt2_diff]][t2]]++;
	  count2[which_allele[map_order[i]][t1]][which_allele[map_order[i+tdt2_diff]][t2]]++;
	  untrans2[which_allele[map_order[i]][u1]][which_allele[map_order[i+tdt2_diff]][u2]]++;
	  count2[which_allele[map_order[i]][u1]][which_allele[map_order[i+tdt2_diff]][u2]]++;
	}


	for (j=0; j<num_alleles[map_order[i]]; j++) {

	  sf(ps,"%3d ",allele_size[map_order[i]][j]); fpr(ldfp);
	  for (k=0; k<num_alleles[map_order[i+tdt2_diff]]; k++) {
	    if (trans2[j][k] > 0 || untrans2[j][k] > 0) {
	      diff = (double) (trans2[j][k] - untrans2[j][k]);
	      sum =  (double) (trans2[j][k] + untrans2[j][k]);
	      chisq = diff*diff/sum;
	      pval = chisq_prob(1.0, chisq);
	      sf(ps,"Haplotype: %-3d %-3d     %4d  %4d   %6.2lf  %.6lf  %s\n",
		 allele_size[map_order[i]][j], allele_size[map_order[i+tdt2_diff]][k],
		 trans2[j][k], untrans2[j][k], chisq, pval, sig_string(pval,diff)); pr();
	    }
	    tmp_array[j][k] = count2[j][k];
	    tmp_sum += count2[j][k];
	    sf(ps," %3d",count2[j][k]); fpr(ldfp);
	  }
	  fnl(ldfp);
	}

	if (num_alleles[map_order[i]] > 1 && num_alleles[map_order[i+tdt2_diff]] > 1) {

	  /* filter out row alleles with just one observation */
	  for (j=0; j<largest_count; j++) { jsum[j]=ksum[j]=0; }

	  for (j=0; j<num_alleles[map_order[i]]; j++) {
	    for (k=0; k<num_alleles[map_order[i+tdt2_diff]]; k++) {
	      jsum[j] += tmp_array[j][k];
	      ksum[k] += tmp_array[j][k];
	    }
	  }

	  for (j=0; j<num_alleles[map_order[i]]; j++) {
	    for (k=0; k<num_alleles[map_order[i+tdt2_diff]]; k++) {
	      if ((jsum[j]==1 || ksum[k]==1) && tmp_array[j][k]==1) {
		tmp_array[j][k]=0; tmp_sum--;
		sf(ps,"filtered out pos %d,%d\n",j,k); fpr(ldfp);
	      }
	    }
	  }

	  if (tmp_sum > 1) {
	    cntab1(tmp_array,num_alleles[map_order[i]],num_alleles[map_order[i+tdt2_diff]],&chisq,&aa,&bb,&cc,&dd);
	    sf(ps,"Chi-sq = %.4lf   p-value = %.6g   (df = %d)\n",chisq,bb,(int)aa);
	    fpr(ldfp);
	  }
	}
	fnl(ldfp);
    }

    close_file(ldfp);
    unmatrix(trans2, largest_count, int);
    unmatrix(untrans2, largest_count, int);
    unmatrix(count2, largest_count, int);
}


command tdt3(void)
{
    int i, j, k, l, count, tmp_diff, t1, t2, t3, u1, u2, u3, jj;
    double ***trans3, ***untrans3, ***count3;
    double chisq, pval, diff, sum, chisq_prob(double,double), aa, bb, cc, dd;
    int tmp_sum, **tmp_array, largest_count;
    FILE *ldfp;


    if (TDTcount == 0) { /* exit */
      print("error: tdt command must be run before using the tdt3 command\n");
      return;
    }
      
    /* First shrink the list of alleles we're looking at to only the 
       existent ones (rather than the 1 to MAX_ALLELE_SIZE used above */

    largest_count=0;
    for (i=0; i<num_in_map_order; i++) {
	count=0;
	for (j=0; j<MAX_ALLELE_SIZE; j++) {
	  if (locus[map_order[i]].allele_count[j][2] > 0 ||
	      locus[map_order[i]].allele_count[j][1] > 0) {
	    which_allele[map_order[i]][j] = count;
	    allele_size[map_order[i]][count] = j;
	    count++;
	  } else {
	    which_allele[map_order[i]][j] = MISSING;
	  }
	  num_alleles[map_order[i]] = count;
	}
	if (count > largest_count) { largest_count=count; }
    }

    largest_count++;

    array(trans3, largest_count, double**);
    array(untrans3, largest_count, double**);
    array(count3, largest_count, double**);
    for (i=0; i<largest_count; i++) {
      matrix(trans3[i], largest_count, largest_count, double);
      matrix(untrans3[i], largest_count, largest_count, double);
      matrix(count3[i], largest_count, largest_count, double);
    }

    for (i=0; i<num_in_map_order-2; i++) {

        for (j=0; j<largest_count; j++) {
	  for (k=0; k<largest_count; k++) {
	    for (l=0; l<largest_count; l++) {
	      trans3[j][k][l] = untrans3[j][k][l] = count3[j][k][l] = 0;
	    }
	  }
	}

	sf(ps,"Markers %d and %d and %d      trans untrans  Chi2  p-val (%s - %s - %s)\n",
	   map_order[i]+1, map_order[i+1]+1, map_order[i+2]+1, locus[map_order[i]].name, 
	   locus[map_order[i+1]].name, locus[map_order[i+2]].name);  pr();

	tmp_sum = 0;

	for (j=0; j<TDTcount; j++) {
	  t1 = transmitted[map_order[i]][j];  
	  t2 = transmitted[map_order[i+1]][j];
	  t3 = transmitted[map_order[i+2]][j];

	  u1 = untransmitted[map_order[i]][j];  
	  u2 = untransmitted[map_order[i+1]][j];
	  u3 = untransmitted[map_order[i+2]][j];


	  if (t1==MISSING || t2==MISSING || t3==MISSING) continue;
	  if (t1==u1 && t2==u2 && t3==u3) {
	    count3 [which_allele[map_order[i]][t1]] [which_allele[map_order[i+1]][t2]] [which_allele[map_order[i+2]][t3]] += 2.0;
	    continue;
	  }
	  if (double_het[map_order[i]][j] || double_het[map_order[i+1]][j] || double_het[map_order[i+2]][j]) continue;

	  trans3[which_allele[map_order[i]][t1]] [which_allele[map_order[i+1]][t2]] [which_allele[map_order[i+2]][t3]] += 1.0;
	  untrans3[which_allele[map_order[i]][u1]] [which_allele[map_order[i+1]][u2]] [which_allele[map_order[i+2]][u3]] += 1.0;

	  count3 [which_allele[map_order[i]][t1]] [which_allele[map_order[i+1]][t2]] [which_allele[map_order[i+2]][t3]] += 1.0;
	  count3 [which_allele[map_order[i]][u1]] [which_allele[map_order[i+1]][u2]] [which_allele[map_order[i+2]][u3]] += 1.0;
	}

	if (missing_TDT) {
	  /* If one of the three markers is missing - probabilistically assign the
	     transmitted and untransmitted alleles */

	  for (jj=0; jj<TDTcount; jj++) {
	    t1 = transmitted[map_order[i]][jj];  
	    t2 = transmitted[map_order[i+1]][jj];
	    t3 = transmitted[map_order[i+2]][jj];

	    u1 = untransmitted[map_order[i]][jj];  
	    u2 = untransmitted[map_order[i+1]][jj];
	    u3 = untransmitted[map_order[i+2]][jj];

	    if (t1==MISSING && t2!=MISSING && t3!=MISSING) {
	      /* first marker missing */

	      sum=0.0;
	      for (j=0; j<num_alleles[map_order[i]]; j++) {
		sum += count3 [j] [which_allele[map_order[i+1]][t2]] [which_allele[map_order[i+2]][t3]];
	      }
	      for (j=0; j<num_alleles[map_order[i]]; j++) {
		if (sum < 0.5) {
		  trans3 [j] [which_allele[map_order[i+1]][t2]] [which_allele[map_order[i+2]][t3]] += 
		    locus[map_order[i]].allele_freq[allele_size[map_order[i]][j]];
		} else {
		  trans3 [j] [which_allele[map_order[i+1]][t2]] [which_allele[map_order[i+2]][t3]] += 
		    count3 [j] [which_allele[map_order[i+1]][t2]] [which_allele[map_order[i+2]][t3]] / sum;
		}
	      }

	      sum=0.0;
	      for (j=0; j<num_alleles[map_order[i]]; j++) {
		sum += count3 [j] [which_allele[map_order[i+1]][u2]] [which_allele[map_order[i+2]][u3]];
	      }
	      for (j=0; j<num_alleles[map_order[i]]; j++) {
		if (sum < 0.5) {
		  untrans3 [j] [which_allele[map_order[i+1]][u2]] [which_allele[map_order[i+2]][u3]] += 
		    locus[map_order[i]].allele_freq[allele_size[map_order[i]][j]];
		} else {
		  untrans3 [j] [which_allele[map_order[i+1]][u2]] [which_allele[map_order[i+2]][u3]] += 
		    count3 [j] [which_allele[map_order[i+1]][u2]] [which_allele[map_order[i+2]][u3]] / sum;
		}
	      }

	    } else if (t1!=MISSING && t2==MISSING && t3!=MISSING) {
	      /* second marker missing */

	      sum=0.0;
	      for (k=0; k<num_alleles[map_order[i+1]]; k++) {
		sum += count3 [which_allele[map_order[i]][t1]] [k] [which_allele[map_order[i+2]][t3]];
	      }
	      for (k=0; k<num_alleles[map_order[i+1]]; k++) {
		if (sum < 0.5) {
		  trans3 [which_allele[map_order[i]][t1]] [k] [which_allele[map_order[i+2]][t3]] += 
		    locus[map_order[i+1]].allele_freq[allele_size[map_order[i+1]][k]];
		} else {
		  trans3 [which_allele[map_order[i]][t1]] [k] [which_allele[map_order[i+2]][t3]] += 
		    count3 [which_allele[map_order[i]][t1]] [k] [which_allele[map_order[i+2]][t3]] / sum;
		}
	      }

	      sum=0.0;
	      for (k=0; k<num_alleles[map_order[i+1]]; k++) {
		sum += count3 [which_allele[map_order[i]][u1]] [k] [which_allele[map_order[i+2]][u3]];
	      }
	      for (k=0; k<num_alleles[map_order[i+1]]; k++) {
		if (sum < 0.5) {
		  untrans3 [which_allele[map_order[i]][u1]] [k] [which_allele[map_order[i+2]][u3]] += 
		    locus[map_order[i+1]].allele_freq[allele_size[map_order[i+1]][k]];
		} else {
		  untrans3 [which_allele[map_order[i]][u1]] [k] [which_allele[map_order[i+2]][u3]] += 
		    count3 [which_allele[map_order[i]][u1]] [k] [which_allele[map_order[i+2]][u3]] / sum;
		}
	      }

	    } else if (t1!=MISSING && t2!=MISSING && t3==MISSING) {
	      /* third marker missing */
	      sum=0.0;
	      for (l=0; l<num_alleles[map_order[i+2]]; l++) {
		sum += count3 [which_allele[map_order[i]][t1]] [which_allele[map_order[i+1]][t2]] [l];
	      }
	      for (l=0; l<num_alleles[map_order[i+2]]; l++) {
		if (sum < 0.5) {
		  trans3 [which_allele[map_order[i]][t1]] [which_allele[map_order[i+1]][t2]] [l] +=
		    locus[map_order[i+2]].allele_freq[allele_size[map_order[i+2]][l]];
		} else {
		  trans3 [which_allele[map_order[i]][t1]] [which_allele[map_order[i+1]][t2]] [l] +=
		    count3 [which_allele[map_order[i]][t1]] [which_allele[map_order[i+1]][t2]] [l] / sum;
		}
	      }

	      sum=0.0;
	      for (l=0; l<num_alleles[map_order[i+2]]; l++) {
		sum += count3 [which_allele[map_order[i]][u1]] [which_allele[map_order[i+1]][u2]] [l];
	      }
	      for (l=0; l<num_alleles[map_order[i+2]]; l++) {
		if (sum < 0.5) {
		  untrans3 [which_allele[map_order[i]][u1]] [which_allele[map_order[i+1]][u2]] [l] +=
		    locus[map_order[i+2]].allele_freq[allele_size[map_order[i+2]][l]];
		} else {
		  untrans3 [which_allele[map_order[i]][u1]] [which_allele[map_order[i+1]][u2]] [l] +=
		    count3 [which_allele[map_order[i]][u1]] [which_allele[map_order[i+1]][u2]] [l] / sum;
		}
	      }
	    }
	  }
	}

	  


	for (j=0; j<num_alleles[map_order[i]]; j++) {
	  for (k=0; k<num_alleles[map_order[i+1]]; k++) {
	    for (l=0; l<num_alleles[map_order[i+2]]; l++) {
	      if (trans3[j][k][l] > 0.0 || untrans3[j][k][l] > 0.0) {

		diff = (trans3[j][k][l] - untrans3[j][k][l]);
		sum =  (trans3[j][k][l] + untrans3[j][k][l]);
		chisq = diff*diff/sum;
		pval = chisq_prob(1.0, chisq);
		if (!missing_TDT) {
		  sf(ps,"Haplotype: %-3d %-3d %-3d     %4d  %4d   %6.2lf  %.6lf  %s\n",
		     allele_size[map_order[i]][j], allele_size[map_order[i+1]][k],
		     allele_size[map_order[i+2]][l], (int) trans3[j][k][l], (int) untrans3[j][k][l],
		     chisq, pval, sig_string(pval,diff)); pr();
		} else {
		  sf(ps,"Haplotype: %-3d %-3d %-3d    %5.1lf  %5.1lf  %6.2lf  %.6lf  %s\n",
		     allele_size[map_order[i]][j], allele_size[map_order[i+1]][k],
		     allele_size[map_order[i+2]][l], trans3[j][k][l], untrans3[j][k][l],
		     chisq, pval, sig_string(pval,diff)); pr();
		}
	      }
	    }
	  }
	}

    }

    for (i=largest_count-1; i>0; i--) {
      unmatrix(count3[i], largest_count, double);
      unmatrix(untrans3[i], largest_count, double);
      unmatrix(trans3[i], largest_count, double);
    }
    unarray(count3, double**);
    unarray(untrans3, double**);
    unarray(trans3, double**);


}


command tdt4(void)
{
    int i, j, k, l, m, count, tmp_diff, t1, t2, t3, t4, u1, u2, u3, u4, jj;
    double ****trans4, ****untrans4, ****count4;
    double chisq, pval, diff, sum, chisq_prob(double,double), aa, bb, cc, dd;
    int tmp_sum, **tmp_array, largest_count;
    FILE *ldfp;


    if (TDTcount == 0) { /* exit */
      print("error: tdt command must be run before using the tdt4 command\n");
      return;
    }
      
    get_arg(itoken, 1, &tmp_diff);
    if (tmp_diff < 1) tmp_diff=1;
    tdt2_diff = tmp_diff;


    /* First shrink the list of alleles we're looking at to only the 
       existent ones (rather than the 1 to MAX_ALLELE_SIZE used above */

    largest_count=0;
    for (i=0; i<num_in_map_order; i++) {
	count=0;
	for (j=0; j<MAX_ALLELE_SIZE; j++) {
	  if (locus[map_order[i]].allele_count[j][2] > 0 ||
	      locus[map_order[i]].allele_count[j][1] > 0) {
	    which_allele[map_order[i]][j] = count;
	    allele_size[map_order[i]][count] = j;
	    count++;
	  } else {
	    which_allele[map_order[i]][j] = MISSING;
	  }
	  num_alleles[map_order[i]] = count;
	}
	if (count > largest_count) { largest_count=count; }
    }

    largest_count++;

    matrix(trans4, largest_count, largest_count, double**);
    matrix(untrans4, largest_count, largest_count, double**);
    matrix(count4, largest_count, largest_count, double**);
    for (i=0; i<largest_count; i++) {
      for (j=0; j<largest_count; j++) {
	matrix(trans4[i][j], largest_count, largest_count, double);
	matrix(untrans4[i][j], largest_count, largest_count, double);
	matrix(count4[i][j], largest_count, largest_count, double);
      }
    }
  
    for (i=0; i<num_in_map_order-3; i++) {

        for (j=0; j<largest_count; j++) {
	  for (k=0; k<largest_count; k++) {
	    for (l=0; l<largest_count; l++) {
	      for (m=0; m<largest_count; m++) {
		trans4[j][k][l][m] = untrans4[j][k][l][m] = count4[j][k][l][m] = 0;
	      }
	    }
	  }
	}

	sf(ps,"Markers %d - %d - %d - %d     trans untrans  Chi2  p-val (%s - %s - %s - %s)\n",
	   map_order[i]+1, map_order[i+1]+1, map_order[i+2]+1, map_order[i+3]+1,
	   locus[map_order[i]].name, locus[map_order[i+1]].name, 
	   locus[map_order[i+2]].name, locus[map_order[i+3]].name);  pr();

	tmp_sum = 0;

	for (j=0; j<TDTcount; j++) {
	  t1 = transmitted[map_order[i]][j];  
	  t2 = transmitted[map_order[i+1]][j];
	  t3 = transmitted[map_order[i+2]][j];
	  t4 = transmitted[map_order[i+3]][j];

	  u1 = untransmitted[map_order[i]][j];  
	  u2 = untransmitted[map_order[i+1]][j];
	  u3 = untransmitted[map_order[i+2]][j];
	  u4 = untransmitted[map_order[i+3]][j];


	  if (t1==MISSING || t2==MISSING || t3==MISSING || t4==MISSING) continue;

	  if (t1==u1 && t2==u2 && t3==u3 && t4==u4) {
	    count4 [which_allele[map_order[i]][t1]] [which_allele[map_order[i+1]][t2]] [which_allele[map_order[i+2]][t3]] [which_allele[map_order[i+3]][t4]] += 2.0;
	    continue;
	  }

	  if (double_het[map_order[i]][j] || double_het[map_order[i+1]][j] || 
	      double_het[map_order[i+2]][j] || double_het[map_order[i+3]][j]) continue;

	  trans4[which_allele[map_order[i]][t1]] [which_allele[map_order[i+1]][t2]] [which_allele[map_order[i+2]][t3]] [which_allele[map_order[i+3]][t4]] += 1.0;
	  untrans4[which_allele[map_order[i]][u1]] [which_allele[map_order[i+1]][u2]] [which_allele[map_order[i+2]][u3]] [which_allele[map_order[i+3]][u4]] += 1.0;

	  count4 [which_allele[map_order[i]][t1]] [which_allele[map_order[i+1]][t2]] [which_allele[map_order[i+2]][t3]] [which_allele[map_order[i+3]][t4]] += 1.0;
	  count4 [which_allele[map_order[i]][u1]] [which_allele[map_order[i+1]][u2]] [which_allele[map_order[i+2]][u3]] [which_allele[map_order[i+3]][u4]] += 1.0;
	}

	if (missing_TDT) {
	  /* If one of the three markers is missing - probabilistically assign the
	     transmitted and untransmitted alleles */

	  for (jj=0; jj<TDTcount; jj++) {
	    t1 = transmitted[map_order[i]][jj];  
	    t2 = transmitted[map_order[i+1]][jj];
	    t3 = transmitted[map_order[i+2]][jj];
	    t4 = transmitted[map_order[i+3]][jj];

	    u1 = untransmitted[map_order[i]][jj];  
	    u2 = untransmitted[map_order[i+1]][jj];
	    u3 = untransmitted[map_order[i+2]][jj];
	    u4 = untransmitted[map_order[i+3]][jj];

	    if (t1==MISSING && t2!=MISSING && t3!=MISSING && t4!=MISSING) {
	      /* first marker missing */

	      sum=0.0;
	      for (j=0; j<num_alleles[map_order[i]]; j++) {
		sum += count4 [j] [which_allele[map_order[i+1]][t2]] [which_allele[map_order[i+2]][t3]] [which_allele[map_order[i+3]][t4]];
	      }
	      for (j=0; j<num_alleles[map_order[i]]; j++) {
		if (sum < 0.5) {
		  trans4 [j] [which_allele[map_order[i+1]][t2]] [which_allele[map_order[i+2]][t3]] [which_allele[map_order[i+3]][t4]] += 
		    locus[map_order[i]].allele_freq[allele_size[map_order[i]][j]];
		} else {
		  trans4 [j] [which_allele[map_order[i+1]][t2]] [which_allele[map_order[i+2]][t3]] [which_allele[map_order[i+3]][t4]] += 
		    count4 [j] [which_allele[map_order[i+1]][t2]] [which_allele[map_order[i+2]][t3]] [which_allele[map_order[i+3]][t4]] / sum;
		}
	      }

	      sum=0.0;
	      for (j=0; j<num_alleles[map_order[i]]; j++) {
		sum += count4 [j] [which_allele[map_order[i+1]][u2]] [which_allele[map_order[i+2]][u3]] [which_allele[map_order[i+3]][u4]];
	      }
	      for (j=0; j<num_alleles[map_order[i]]; j++) {
		if (sum < 0.5) {
		  untrans4 [j] [which_allele[map_order[i+1]][u2]] [which_allele[map_order[i+2]][u3]] [which_allele[map_order[i+3]][u4]] += 
		    locus[map_order[i]].allele_freq[allele_size[map_order[i]][j]];
		} else {
		  untrans4 [j] [which_allele[map_order[i+1]][u2]] [which_allele[map_order[i+2]][u3]] [which_allele[map_order[i+3]][u4]] += 
		    count4 [j] [which_allele[map_order[i+1]][u2]] [which_allele[map_order[i+2]][u3]] [which_allele[map_order[i+3]][u4]] / sum;
		}
	      }

	    } else if (t1!=MISSING && t2==MISSING && t3!=MISSING && t4!=MISSING) {
	      /* second marker missing */

	      sum=0.0;
	      for (k=0; k<num_alleles[map_order[i+1]]; k++) {
		sum += count4 [which_allele[map_order[i]][t1]] [k] [which_allele[map_order[i+2]][t3]] [which_allele[map_order[i+3]][t4]];
	      }
	      for (k=0; k<num_alleles[map_order[i+1]]; k++) {
		if (sum < 0.5) {
		  trans4 [which_allele[map_order[i]][t1]] [k] [which_allele[map_order[i+2]][t3]] [which_allele[map_order[i+3]][t4]] += 
		    locus[map_order[i+1]].allele_freq[allele_size[map_order[i+1]][k]];
		} else {
		  trans4 [which_allele[map_order[i]][t1]] [k] [which_allele[map_order[i+2]][t3]] [which_allele[map_order[i+3]][t4]] += 
		    count4 [which_allele[map_order[i]][t1]] [k] [which_allele[map_order[i+2]][t3]] [which_allele[map_order[i+3]][t4]] / sum;
		}
	      }

	      sum=0.0;
	      for (k=0; k<num_alleles[map_order[i+1]]; k++) {
		sum += count4 [which_allele[map_order[i]][u1]] [k] [which_allele[map_order[i+2]][u3]] [which_allele[map_order[i+3]][u4]];
	      }
	      for (k=0; k<num_alleles[map_order[i+1]]; k++) {
		if (sum < 0.5) {
		  untrans4 [which_allele[map_order[i]][u1]] [k] [which_allele[map_order[i+2]][u3]] [which_allele[map_order[i+3]][u4]] += 
		    locus[map_order[i+1]].allele_freq[allele_size[map_order[i+1]][k]];
		} else {
		  untrans4 [which_allele[map_order[i]][u1]] [k] [which_allele[map_order[i+2]][u3]] [which_allele[map_order[i+3]][u4]] += 
		    count4 [which_allele[map_order[i]][u1]] [k] [which_allele[map_order[i+2]][u3]] [which_allele[map_order[i+3]][u4]] / sum;
		}
	      }

	    } else if (t1!=MISSING && t2!=MISSING && t3==MISSING && t4!=MISSING) {
	      /* third marker missing */
	      sum=0.0;
	      for (l=0; l<num_alleles[map_order[i+2]]; l++) {
		sum += count4 [which_allele[map_order[i]][t1]] [which_allele[map_order[i+1]][t2]] [l] [which_allele[map_order[i+3]][t4]];
	      }
	      for (l=0; l<num_alleles[map_order[i+2]]; l++) {
		if (sum < 0.5) {
		  trans4 [which_allele[map_order[i]][t1]] [which_allele[map_order[i+1]][t2]] [l] [which_allele[map_order[i+3]][t4]] +=
		    locus[map_order[i+2]].allele_freq[allele_size[map_order[i+2]][l]];
		} else {
		  trans4 [which_allele[map_order[i]][t1]] [which_allele[map_order[i+1]][t2]] [l] [which_allele[map_order[i+3]][t4]] +=
		    count4 [which_allele[map_order[i]][t1]] [which_allele[map_order[i+1]][t2]] [l] [which_allele[map_order[i+3]][t4]] / sum;
		}
	      }

	      sum=0.0;
	      for (l=0; l<num_alleles[map_order[i+2]]; l++) {
		sum += count4 [which_allele[map_order[i]][u1]] [which_allele[map_order[i+1]][u2]] [l] [which_allele[map_order[i+3]][u4]];
	      }
	      for (l=0; l<num_alleles[map_order[i+2]]; l++) {
		if (sum < 0.5) {
		  untrans4 [which_allele[map_order[i]][u1]] [which_allele[map_order[i+1]][u2]] [l] [which_allele[map_order[i+3]][u4]] +=
		    locus[map_order[i+2]].allele_freq[allele_size[map_order[i+2]][l]];
		} else {
		  untrans4 [which_allele[map_order[i]][u1]] [which_allele[map_order[i+1]][u2]] [l] [which_allele[map_order[i+3]][u4]] +=
		    count4 [which_allele[map_order[i]][u1]] [which_allele[map_order[i+1]][u2]] [l] [which_allele[map_order[i+3]][u4]] / sum;
		}
	      }

	    } else if (t1!=MISSING && t2!=MISSING && t3!=MISSING && t4==MISSING) {
	      /* fourth marker missing */

	      sum=0.0;
	      for (m=0; m<num_alleles[map_order[i+3]]; m++) {
		sum += count4 [which_allele[map_order[i]][t1]] [which_allele[map_order[i+1]][t2]] [which_allele[map_order[i+2]][t3]] [m];
	      }
	      for (m=0; m<num_alleles[map_order[i+3]]; m++) {
		if (sum < 0.5) {
		  trans4 [which_allele[map_order[i]][t1]] [which_allele[map_order[i+1]][t2]] [which_allele[map_order[i+2]][t3]] [m] +=
		    locus[map_order[i+3]].allele_freq[allele_size[map_order[i+3]][m]];
		} else {
		  trans4 [which_allele[map_order[i]][t1]] [which_allele[map_order[i+1]][t2]] [which_allele[map_order[i+2]][t3]] [m] +=
		    count4 [which_allele[map_order[i]][t1]] [which_allele[map_order[i+1]][t2]] [which_allele[map_order[i+2]][t3]] [m] / sum;
		}
	      }

	      sum=0.0;
	      for (m=0; m<num_alleles[map_order[i+3]]; m++) {
		sum += count4 [which_allele[map_order[i]][u1]] [which_allele[map_order[i+1]][u2]] [which_allele[map_order[i+2]][u3]] [m];
	      }
	      for (m=0; m<num_alleles[map_order[i+3]]; m++) {
		if (sum < 0.5) {
		  untrans4 [which_allele[map_order[i]][u1]] [which_allele[map_order[i+1]][u2]] [which_allele[map_order[i+2]][u3]] [m] +=
		    locus[map_order[i+3]].allele_freq[allele_size[map_order[i+3]][m]];
		} else {
		  untrans4 [which_allele[map_order[i]][u1]] [which_allele[map_order[i+1]][u2]] [which_allele[map_order[i+2]][u3]] [m] +=
		    count4 [which_allele[map_order[i]][u1]] [which_allele[map_order[i+1]][u2]] [which_allele[map_order[i+2]][u3]] [m] / sum;
		}
	      }	      

	    }

	  }
	}

	  


	for (j=0; j<num_alleles[map_order[i]]; j++) {
	  for (k=0; k<num_alleles[map_order[i+1]]; k++) {
	    for (l=0; l<num_alleles[map_order[i+2]]; l++) {
	      for (m=0; m<num_alleles[map_order[i+3]]; m++) {
		if (trans4[j][k][l][m] > 0.1 || untrans4[j][k][l][m] > 0.1) {

		  diff = (trans4[j][k][l][m] - untrans4[j][k][l][m]);
		  sum =  (trans4[j][k][l][m] + untrans4[j][k][l][m]);
		  chisq = diff*diff/sum;
		  pval = chisq_prob(1.0, chisq);
		  if (!missing_TDT) {
		    sf(ps,"Haplotype: %-3d %-3d %-3d %-3d    %4d  %4d   %6.2lf  %.6lf  %s\n",
		       allele_size[map_order[i]][j], allele_size[map_order[i+1]][k],
		       allele_size[map_order[i+2]][l], allele_size[map_order[i+3]][m],
		       (int) trans4[j][k][l][m], (int) untrans4[j][k][l][m],
		       chisq, pval, sig_string(pval,diff)); pr();
		  } else {
		    sf(ps,"Haplotype: %-3d %-3d %-3d %-3d   %5.1lf  %5.1lf  %6.2lf  %.6lf  %s\n",
		       allele_size[map_order[i]][j], allele_size[map_order[i+1]][k],
		       allele_size[map_order[i+2]][l], allele_size[map_order[i+3]][m],
		       trans4[j][k][l][m], untrans4[j][k][l][m],
		       chisq, pval, sig_string(pval,diff)); pr();
		  }
		}
	      }
	    }
	  }
	}

    }

    for (i=0; i<largest_count; i++) {
      for (j=0; j<largest_count; j++) {
	unmatrix(trans4[i][j], largest_count, double);
	unmatrix(untrans4[i][j], largest_count, double);
	unmatrix(count4[i][j], largest_count, double);
      }
    }

    unmatrix(trans4, largest_count, double**);
    unmatrix(untrans4, largest_count, double**);
    unmatrix(count4, largest_count, double**);

}

#ifdef NOT_DONE

command tdt5(void)
{
    int i, j, k, l, m, n, count, tmp_diff, t1, t2, t3, t4, t5, u1, u2, u3, u4, u5, jj;
    double *****trans5, *****untrans5, *****count5;
    double chisq, pval, diff, sum, chisq_prob(double,double), aa, bb, cc, dd, ee;
    int tmp_sum, **tmp_array, largest_count;
    FILE *ldfp;


    if (TDTcount == 0) { /* exit */
      print("error: tdt command must be run before using the tdt5 command\n");
      return;
    }
      
    get_arg(itoken, 1, &tmp_diff);
    if (tmp_diff < 1) tmp_diff=1;
    tdt2_diff = tmp_diff;


    /* First shrink the list of alleles we're looking at to only the 
       existent ones (rather than the 1 to MAX_ALLELE_SIZE used above */

    largest_count=0;
    for (i=0; i<num_in_map_order; i++) {
	count=0;
	for (j=0; j<MAX_ALLELE_SIZE; j++) {
	  if (locus[map_order[i]].allele_count[j][2] > 0 ||
	      locus[map_order[i]].allele_count[j][1] > 0) {
	    which_allele[map_order[i]][j] = count;
	    allele_size[map_order[i]][count] = j;
	    count++;
	  } else {
	    which_allele[map_order[i]][j] = MISSING;
	  }
	  num_alleles[map_order[i]] = count;
	}
	if (count > largest_count) { largest_count=count; }
    }

    largest_count++;


    array(trans5, largest_count, double****);
    array(untrans5, largest_count, double****);
    array(count5, largest_count, double****);
    for (i=0; i<largest_count; i++) {
      matrix(trans5[i], largest_count, largest_count, double**);
      matrix(untrans5[i], largest_count, largest_count, double**);
      matrix(count5[i], largest_count, largest_count, double**);
    }
    for (i=0; i<largest_count; i++) {
      for (j=0; j<largest_count; j++) {
	for (k=0; k<largest_count; k++) {
	  matrix(trans5[i][j][k], largest_count, largest_count, double);
	  matrix(untrans5[i][j][k], largest_count, largest_count, double);
	  matrix(count5[i][j][k], largest_count, largest_count, double);
	}
      }
    }

    matrix(tmp_array, 50, 50, int);

    for (i=0; i<num_in_map_order-4; i++) {

        for (j=0; j<largest_count; j++) {
	  for (k=0; k<largest_count; k++) {
	    for (l=0; l<largest_count; l++) {
	      for (m=0; m<largest_count; m++) {
		for (n=0; n<largest_count; n++) {
		  trans5[j][k][l][m][n] = untrans5[j][k][l][m][n] = 0;
		  count5[j][k][l][m][n] = 0;
		}
	      }
	    }
	  }
	}

	sf(ps,"Markers %d-%d-%d-%d-%d trans untrans  Chi2  p-val (%s-%s-%s-%s-%s)\n",
	   map_order[i]+1, map_order[i+1]+1, map_order[i+2]+1, 
	   map_order[i+3]+1, map_order[i+4]+1,
	   locus[map_order[i]].name, locus[map_order[i+1]].name, 
	   locus[map_order[i+2]].name, locus[map_order[i+3]].name,
	   locus[map_order[i+4]].name);  pr();

	tmp_sum = 0;

	for (j=0; j<TDTcount; j++) {
	  t1 = transmitted[map_order[i]][j];  
	  t2 = transmitted[map_order[i+1]][j];
	  t3 = transmitted[map_order[i+2]][j];
	  t4 = transmitted[map_order[i+3]][j];
	  t5 = transmitted[map_order[i+4]][j];

	  u1 = untransmitted[map_order[i]][j];  
	  u2 = untransmitted[map_order[i+1]][j];
	  u3 = untransmitted[map_order[i+2]][j];
	  u4 = untransmitted[map_order[i+3]][j];
	  u5 = untransmitted[map_order[i+4]][j];

	  if (t1==u1 && t2==u2 && t3==u3 && t4==u4 && t5==u5) {
	    continue;
	  }

	  if (t1==MISSING || t2==MISSING || t3==MISSING || t4==MISSING || t5==MISSING) continue;
	  if (double_het[map_order[i]][j] || double_het[map_order[i+1]][j] || 
	      double_het[map_order[i+2]][j] || double_het[map_order[i+3]][j] ||
	      double_het[map_order[i+4]][j]) continue;

	  trans5[which_allele[map_order[i]][t1]] [which_allele[map_order[i+1]][t2]] [which_allele[map_order[i+2]][t3]] [which_allele[map_order[i+3]][t4]] [which_allele[map_order[i+4]][t5]] += 1.0;
	  untrans5[which_allele[map_order[i]][u1]] [which_allele[map_order[i+1]][u2]] [which_allele[map_order[i+2]][u3]] [which_allele[map_order[i+3]][u4]] [which_allele[map_order[i+4]][u5]] += 1.0;

	  count5 [which_allele[map_order[i]][t1]] [which_allele[map_order[i+1]][t2]] [which_allele[map_order[i+2]][t3]] [which_allele[map_order[i+3]][t4]] [which_allele[map_order[i+4]][t5]] += 1.0;
	  count5 [which_allele[map_order[i]][u1]] [which_allele[map_order[i+1]][u2]] [which_allele[map_order[i+2]][u3]] [which_allele[map_order[i+3]][u4]][which_allele[map_order[i+4]][u5]] += 1.0;
	}
      

	for (j=0; j<num_alleles[map_order[i]]; j++) {
	  for (k=0; k<num_alleles[map_order[i+1]]; k++) {
	    for (l=0; l<num_alleles[map_order[i+2]]; l++) {
	      for (m=0; m<num_alleles[map_order[i+3]]; m++) {
		for (n=0; n<num_alleles[map_order[i+4]]; n++) {
		  if (trans5[j][k][l][m][n] > 0.1 || untrans5[j][k][l][m][n] > 0.1) {

		    diff = (trans5[j][k][l][m][n] - untrans5[j][k][l][m][n]);
		    sum =  (trans5[j][k][l][m][n] + untrans5[j][k][l][m][n]);
		    chisq = diff*diff/sum;
		    pval = chisq_prob(1.0, chisq);
		    if (!missing_TDT) {
		      sf(ps,"Haplotype: %-3d %-3d %-3d %-3d %-3d   %4d  %4d   %6.2lf  %.6lf  %s\n",
			 allele_size[map_order[i]][j], allele_size[map_order[i+1]][k],
			 allele_size[map_order[i+2]][l], allele_size[map_order[i+3]][m],
			 allele_size[map_order[i+4]][n],
		       (int) trans5[j][k][l][m][n], (int) untrans5[j][k][l][m][n],
		       chisq, pval, sig_string(pval,diff)); pr();
		    } else {
		      sf(ps,"Haplotype: %-3d %-3d %-3d %-3d %-3d  %5.1lf  %5.1lf  %6.2lf  %.6lf  %s\n",
			 allele_size[map_order[i]][j], allele_size[map_order[i+1]][k],
			 allele_size[map_order[i+2]][l], allele_size[map_order[i+3]][m],
			 allele_size[map_order[i+4]][n],
			 trans5[j][k][l][m][n], untrans5[j][k][l][m][n],
			 chisq, pval, sig_string(pval,diff)); pr();
		    }
		  }
		}
	      }
	    }
	  }
	}

    }


    for (i=0; i<largest_count; i++) {
      for (j=0; j<largest_count; j++) {
	for (k=0; k<largest_count; k++) {
	  unmatrix(trans5[i][j][k], largest_count, double);
	  unmatrix(untrans5[i][j][k], largest_count, double);
	  unmatrix(count5[i][j][k], largest_count, double);
	}
      }
    }

    for (i=0; i<largest_count; i++) {
      unmatrix(trans5[i], largest_count, double**);
      unmatrix(untrans5[i], largest_count, double**);
      unmatrix(count5[i], largest_count, double**);
    }
    unarray(trans5, double****);
    unarray(untrans5, double****);
    unarray(count5, double****);
}


#endif



command set_one_parent_TDT(void)
{
    char type[TOKLEN+1];
    get_one_arg(stoken,"",type);

    if (nullstr(type)) {
        if (one_parent_TDT) {
	  sf(ps,"Current setting = ON (Full single parent TDT is now active - use with caution)\n"); pr();
	} else {
	  sf(ps,"Current setting = OFF (Single parent TDTs have homozygous children discarded)\n"); pr();
	}
    } else {
        if (matches(type,"on")) one_parent_TDT=TRUE;
	else if(matches(type,"off")) one_parent_TDT=FALSE;
	else usage_error(1);
      
        if (one_parent_TDT) {
	  sf(ps,"Current setting = ON (Full single parent TDT is now active - use with caution)\n"); pr();
	} else {
	  sf(ps,"Current setting = OFF (Single parent TDTs have homozygous children discarded)\n"); pr();
	}
    }
}


command set_missing_TDT(void)
{
    char type[TOKLEN+1];
    get_one_arg(stoken,"",type);

    if (nullstr(type)) {
        if (missing_TDT) {
	  sf(ps,"Current setting = ON (Missing data is probabilistically assigned in 3 and 4 pt TDT)\n"); pr();
	} else {
	  sf(ps,"Current setting = OFF (Missing data is unused in all TDTs)\n"); pr();
	}
    } else {
        if (matches(type,"on")) missing_TDT=TRUE;
	else if(matches(type,"off")) missing_TDT=FALSE;
	else usage_error(1);
      
        if (missing_TDT) {
	  sf(ps,"Current setting = ON (Missing data is probabilistically assigned in 3 and 4 pt TDT)\n"); pr();
	} else {
	  sf(ps,"Current setting = OFF (Missing data is unused in all TDTs)\n"); pr();
	}
    }
}


command set_dhskip(void)
{
    int orig_setting;
    char type[TOKLEN+1];
    get_one_arg(stoken,"",type);

    orig_setting=dhskip;

    if (nullstr(type)) {
        if (dhskip) {
	  sf(ps,"Current setting = ON (cases of identically heterozygous parents skipped in TDTs)\n"); pr();
	} else {
	  sf(ps,"Current setting = OFF (cases of identically heterozygous parents used when possible in all TDTs)\n"); pr();
	}
    } else {
        if (matches(type,"on")) dhskip=TRUE;
	else if(matches(type,"off")) dhskip=FALSE;
	else usage_error(1);
      
        if (dhskip) {
	  sf(ps,"Current setting = ON (cases of identically heterozygous parents skipped in TDTs)\n"); pr();
	} else {
	  sf(ps,"Current setting = OFF (cases of identically heterozygous parents used used when possible in all TDTs)\n"); pr();
	}
	
	if (dhskip != orig_setting) {
	  sf(ps,"TDTs must be recomputed (using 'tdt') for this to take effect!\n");
	  pr();
	}
    }
}


command set_qtdt(void)
{
    char type[TOKLEN+1];
    get_one_arg(stoken,"",type);

    if (nullstr(type)) {
        if (qtdt_on) {
	  sf(ps,"Current setting = ON (all offspring counted in TDT)\n"); pr();
	} else {
	  sf(ps,"Current setting = OFF (only affecteds counted in TDT)\n"); pr();
	}
    } else {
        if (matches(type,"on")) qtdt_on=TRUE;
	else if(matches(type,"off")) qtdt_on=FALSE;
	else usage_error(1);
      
        if (qtdt_on) {
	  sf(ps,"Current setting = ON (all offspring counted in TDT)\n"); pr();
	} else {
	  sf(ps,"Current setting = OFF (only affecteds counted in TDT)\n"); pr();
	}
    }
}


command perm1(void)
{
    int i, j, k, t1, u1, count, p, num_permutations, tmp_diff;
    int *tmpt, *tmpu, num_hits, num_hits2, num_hits3, tempnh, tempnh2, tempnh3;
    long tmp_diff2;
    double diff, sum, chisq, csqlist[200], largest, tmp_largest;
    int sims_max, sims_nh1, sims_nh2, sims_nh3, largest_count;

    if (TDTcount == 0) { /* exit */
      print("error: tdt command must be run before using the perm1 command\n");
      return;
    }

    get_arg(ltoken, 10, &tmp_diff2);
    tmp_diff = (int)tmp_diff2;
    if (tmp_diff < 1) tmp_diff=10;
    num_permutations = tmp_diff;

    largest_count=0;
    for (i=0; i<num_in_map_order; i++) {
	count=0;
	for (j=0; j<MAX_ALLELE_SIZE; j++) {
	  if (locus[map_order[i]].allele_count[j][2] > 0 ||
	      locus[map_order[i]].allele_count[j][1] > 0) {
	    which_allele[map_order[i]][j] = count;
	    allele_size[map_order[i]][count] = j;
	    count++;
	  } else {
	    which_allele[map_order[i]][j] = MISSING;
	  }
	  num_alleles[map_order[i]] = count;
	}
	if (count > largest_count) largest_count=count;
    }
    largest_count++;
    array(tmpt, largest_count, int);
    array(tmpu, largest_count, int);

    sims_max=sims_nh1=sims_nh2=sims_nh3=0;

    /* First do the acual data as the reference */

    num_hits=num_hits2=num_hits3=0; largest=0.0;
    for (i=0; i<num_in_map_order; i++) {

        for (k=0; k<largest_count; k++) { tmpt[k] = tmpu[k] = 0; }

	for (j=0; j<TDTcount; j++) {
	  t1 = transmitted[map_order[i]][j];
	  u1 = untransmitted[map_order[i]][j];

	  if (t1==u1) continue; 
	  if (t1==MISSING || u1==MISSING) continue;

	  tmpt[which_allele[map_order[i]][t1]]++;
	  tmpu[which_allele[map_order[i]][u1]]++;
	}

	for (k=0; k<num_alleles[map_order[i]]; k++) {
	  if (tmpt[k] > tmpu[k]) {
	    diff = (double)(tmpt[k]-tmpu[k]);
	    sum = (double)(tmpt[k]+tmpu[k]);
	    chisq = diff*diff/sum;
	    if (chisq > largest) largest=chisq;
	    if (chisq > 5.41) { 
	      csqlist[num_hits] = chisq;
	      num_hits++;
	    }
	    if (chisq > 9.55) num_hits2++;
	    if (chisq > 13.83) num_hits3++;
	  }
	}
    }

    sf(ps,"%3d %3d %3d =",num_hits,num_hits2,num_hits3); pr();
    for (i=0; i<num_hits; i++) { sf(ps," %5.2lf",csqlist[i]); pr(); }
    nl();

    /* Now perform permutations! */

    for (p=0; p<num_permutations; p++) {

      tempnh=tempnh2=tempnh3=0; tmp_largest=0.0;

      for (i=0; i<num_in_map_order; i++) {

        for (k=0; k<largest_count; k++) { tmpt[k] = tmpu[k] = 0; }

	for (j=0; j<TDTcount; j++) {
	  if (coin_flip()) {
	    u1 = transmitted[map_order[i]][j];
	    t1 = untransmitted[map_order[i]][j];
	  } else {
	    t1 = transmitted[map_order[i]][j];
	    u1 = untransmitted[map_order[i]][j];
	  }

	  if (t1==u1) continue; 
	  if (t1==MISSING || u1==MISSING) continue;

	  tmpt[which_allele[map_order[i]][t1]]++;
	  tmpu[which_allele[map_order[i]][u1]]++;
	}

	for (k=0; k<num_alleles[map_order[i]]; k++) {
	  if (tmpt[k] > tmpu[k]) {
	    diff = (double)(tmpt[k]-tmpu[k]);
	    sum = (double)(tmpt[k]+tmpu[k]);
	    chisq = diff*diff/sum;
	    if (chisq > tmp_largest) tmp_largest=chisq;
	    if (chisq > 5.41) { 
	      csqlist[tempnh] = chisq;
	      tempnh++;
	    }
	    if (chisq > 9.55) tempnh2++;
	    if (chisq > 13.83) tempnh3++;
	  }
	}
      }

      sf(ps,"%3d %3d %3d %c",tempnh,tempnh2,tempnh3,(tmp_largest>largest)?'*':'-'); pr();
      for (i=0; i<tempnh; i++) { sf(ps," %5.2lf",csqlist[i]); pr(); }
      nl();
      if (tmp_largest > largest) sims_max++;
      if (tempnh >= num_hits) sims_nh1++;
      if (tempnh2 >= num_hits2) sims_nh2++;
      if (tempnh3 >= num_hits3) sims_nh3++;
    }    

    print("PERMUTATION SUMMARY:\n");
    sf(ps,"%d of %d had a larger maximum value than the real best (%.2lf)\n",sims_max,num_permutations,largest);  pr();
    sf(ps,"%d of %d had as many tests (%d) exceeding p=.01\n",sims_nh1,num_permutations,num_hits);  pr();
    sf(ps,"%d of %d had as many tests (%d) exceeding p=.001\n",sims_nh2,num_permutations,num_hits2);  pr();
    sf(ps,"%d of %d had as many tests (%d) exceeding p=.0001\n",sims_nh3,num_permutations,num_hits3);  pr();

}


command perm2(void)
{  
    int i, j, k, t1, u1, t2, u2, count, p, num_permutations, tmp_diff, tdt2_diff;
    int **tmpt, **tmpu, num_hits, num_hits2, num_hits3, tempnh, tempnh2, tempnh3;
    double diff, sum, chisq, csqlist[200], largest, tmp_largest;
    int sims_max, sims_nh1, sims_nh2, sims_nh3, largest_count;
    long tmp_diff2;

    sims_max=sims_nh1=sims_nh2=sims_nh3=0;

    if (TDTcount == 0) { /* exit */
      print("error: tdt command must be run before using the perm2 command\n");
      return;
    }

    /* get_arg(itoken, 10, &tmp_diff); */
    get_arg(ltoken, 10, &tmp_diff2);
    tmp_diff = (int)tmp_diff2;
    if (tmp_diff < 1) tmp_diff=10;
    num_permutations = tmp_diff;

    largest_count=0;
    for (i=0; i<num_in_map_order; i++) {
	count=0;
	for (j=0; j<MAX_ALLELE_SIZE; j++) {
	  if (locus[map_order[i]].allele_count[j][2] > 0 ||
	      locus[map_order[i]].allele_count[j][1] > 0) {
	    which_allele[map_order[i]][j] = count;
	    allele_size[map_order[i]][count] = j;
	    count++;
	  } else {
	    which_allele[map_order[i]][j] = MISSING;
	  }
	  num_alleles[map_order[i]] = count;
	}
	if (count > largest_count) largest_count=count;
    }
    largest_count++;
    matrix(tmpt, largest_count, largest_count, int);
    matrix(tmpu, largest_count, largest_count, int);

    /* First do the actual data as the reference */

    num_hits=num_hits2=num_hits3=0; largest=0.0;

    tdt2_diff=1;

    for (i=0; i<num_in_map_order-tdt2_diff; i++) {

        for (j=0; j<largest_count; j++) {
	  for (k=0; k<largest_count; k++) {
	    tmpt[j][k] = tmpu[j][k] = 0;
	  }
	}

	for (j=0; j<TDTcount; j++) {
	  t1 = transmitted[map_order[i]][j];  t2 = transmitted[map_order[i+tdt2_diff]][j];
	  u1 = untransmitted[map_order[i]][j];  u2 = untransmitted[map_order[i+tdt2_diff]][j];

	  if (t1==u1 && t2==u2) continue;
	  if (t1==MISSING || t2==MISSING || double_het[map_order[i]][j] || double_het[map_order[i+tdt2_diff]][j]) continue;

	  tmpt[which_allele[map_order[i]][t1]][which_allele[map_order[i+tdt2_diff]][t2]]++;
	  tmpu[which_allele[map_order[i]][u1]][which_allele[map_order[i+tdt2_diff]][u2]]++;
	}

	for (j=0; j<num_alleles[map_order[i]]; j++) {
	  for (k=0; k<num_alleles[map_order[i+tdt2_diff]]; k++) {
	    if (tmpt[j][k] > tmpu[j][k]) {
	      diff = (double)(tmpt[j][k]-tmpu[j][k]);
	      sum = (double)(tmpt[j][k]+tmpu[j][k]);
	      chisq = diff*diff/sum;
	      if (chisq > largest) largest=chisq;
	      if (chisq > 5.41) { 
		csqlist[num_hits] = chisq;
		num_hits++;
	      }
	      if (chisq > 9.55) num_hits2++;
	      if (chisq > 13.83) num_hits3++;
	    }
	  }
	}
    }

    /* Now do all the pairs of markers that are separated by a marker */
    tdt2_diff=2;

    for (i=0; i<num_in_map_order-tdt2_diff; i++) {

        for (j=0; j<largest_count; j++) {
	  for (k=0; k<largest_count; k++) {
	    tmpt[j][k] = tmpu[j][k] = 0;
	  }
	}

	for (j=0; j<TDTcount; j++) {
	  t1 = transmitted[map_order[i]][j];  t2 = transmitted[map_order[i+tdt2_diff]][j];
	  u1 = untransmitted[map_order[i]][j];  u2 = untransmitted[map_order[i+tdt2_diff]][j];

	  if (t1==u1 && t2==u2) continue;
	  if (t1==MISSING || t2==MISSING || double_het[map_order[i]][j] || double_het[map_order[i+tdt2_diff]][j]) continue;

	  tmpt[which_allele[map_order[i]][t1]][which_allele[map_order[i+tdt2_diff]][t2]]++;
	  tmpu[which_allele[map_order[i]][u1]][which_allele[map_order[i+tdt2_diff]][u2]]++;
	}

	for (j=0; j<num_alleles[map_order[i]]; j++) {
	  for (k=0; k<num_alleles[map_order[i+tdt2_diff]]; k++) {
	    if (tmpt[j][k] > tmpu[j][k]) {
	      diff = (double)(tmpt[j][k]-tmpu[j][k]);
	      sum = (double)(tmpt[j][k]+tmpu[j][k]);
	      chisq = diff*diff/sum;
	      if (chisq > largest) largest=chisq;
	      if (chisq > 5.41) { 
		csqlist[num_hits] = chisq;
		num_hits++;
	      }
	      if (chisq > 9.55) num_hits2++;
	      if (chisq > 13.83) num_hits3++;
	    }
	  }
	}
    }

    sf(ps,"%3d %3d %3d =",num_hits,num_hits2,num_hits3); pr();
    for (i=0; i<num_hits; i++) { sf(ps," %5.2lf",csqlist[i]); pr(); }
    nl();

    for (p=0; p<num_permutations; p++) {

      tempnh=tempnh2=tempnh3=0; tmp_largest=0.0;

      tdt2_diff=1;

      for (i=0; i<num_in_map_order-tdt2_diff; i++) {

        for (j=0; j<largest_count; j++) {
	  for (k=0; k<largest_count; k++) {
	    tmpt[j][k] = tmpu[j][k] = 0;
	  }
	}

	for (j=0; j<TDTcount; j++) {
	  if (coin_flip()) {
	    t1 = transmitted[map_order[i]][j];  t2 = transmitted[map_order[i+tdt2_diff]][j];
	    u1 = untransmitted[map_order[i]][j];  u2 = untransmitted[map_order[i+tdt2_diff]][j];
	  } else {
	    u1 = transmitted[map_order[i]][j];  u2 = transmitted[map_order[i+tdt2_diff]][j];
	    t1 = untransmitted[map_order[i]][j];  t2 = untransmitted[map_order[i+tdt2_diff]][j];
	  }

	  if (t1==u1 && t2==u2) continue;
	  if (t1==MISSING || t2==MISSING || double_het[map_order[i]][j] || double_het[map_order[i+tdt2_diff]][j]) continue;

	  tmpt[which_allele[map_order[i]][t1]][which_allele[map_order[i+tdt2_diff]][t2]]++;
	  tmpu[which_allele[map_order[i]][u1]][which_allele[map_order[i+tdt2_diff]][u2]]++;
	}

	for (j=0; j<num_alleles[map_order[i]]; j++) {
	  for (k=0; k<num_alleles[map_order[i+tdt2_diff]]; k++) {
	    if (tmpt[j][k] > tmpu[j][k]) {
	      diff = (double)(tmpt[j][k]-tmpu[j][k]);
	      sum = (double)(tmpt[j][k]+tmpu[j][k]);
	      chisq = diff*diff/sum;
	      if (chisq > tmp_largest) tmp_largest=chisq;
	      if (chisq > 5.41) { 
		csqlist[tempnh] = chisq;
		tempnh++;
	      }
	      if (chisq > 9.55) tempnh2++;
	      if (chisq > 13.83) tempnh3++;
	    }
	  }
	}
      }

      tdt2_diff=2;

      for (i=0; i<num_in_map_order-tdt2_diff; i++) {

        for (j=0; j<largest_count; j++) {
	  for (k=0; k<largest_count; k++) {
	    tmpt[j][k] = tmpu[j][k] = 0;
	  }
	}

	for (j=0; j<TDTcount; j++) {
	  if (coin_flip()) {
	    t1 = transmitted[map_order[i]][j];  t2 = transmitted[map_order[i+tdt2_diff]][j];
	    u1 = untransmitted[map_order[i]][j];  u2 = untransmitted[map_order[i+tdt2_diff]][j];
	  } else {
	    u1 = transmitted[map_order[i]][j];  u2 = transmitted[map_order[i+tdt2_diff]][j];
	    t1 = untransmitted[map_order[i]][j];  t2 = untransmitted[map_order[i+tdt2_diff]][j];
	  }

	  if (t1==u1 && t2==u2) continue;
	  if (t1==MISSING || t2==MISSING || double_het[map_order[i]][j] || double_het[map_order[i+tdt2_diff]][j]) continue;

	  tmpt[which_allele[map_order[i]][t1]][which_allele[map_order[i+tdt2_diff]][t2]]++;
	  tmpu[which_allele[map_order[i]][u1]][which_allele[map_order[i+tdt2_diff]][u2]]++;
	}

	for (j=0; j<num_alleles[map_order[i]]; j++) {
	  for (k=0; k<num_alleles[map_order[i+tdt2_diff]]; k++) {
	    if (tmpt[j][k] > tmpu[j][k]) {
	      diff = (double)(tmpt[j][k]-tmpu[j][k]);
	      sum = (double)(tmpt[j][k]+tmpu[j][k]);
	      chisq = diff*diff/sum;
	      if (chisq > tmp_largest) tmp_largest=chisq;
	      if (chisq > 5.41) { 
		csqlist[tempnh] = chisq;
		tempnh++;
	      }
	      if (chisq > 9.55) tempnh2++;
	      if (chisq > 13.83) tempnh3++;
	    }
	  }
	}
      }

      sf(ps,"%3d %3d %3d %c",tempnh,tempnh2,tempnh3,(tmp_largest>largest)?'*':'-'); pr();
      for (i=0; i<tempnh; i++) { sf(ps," %5.2lf",csqlist[i]); pr(); }
      nl();
      if (tmp_largest > largest) sims_max++;
      if (tempnh >= num_hits) sims_nh1++;
      if (tempnh2 >= num_hits2) sims_nh2++;
      if (tempnh3 >= num_hits3) sims_nh3++;
    }

    print("PERMUTATION SUMMARY:\n");
    sf(ps,"%d of %d had a larger maximum value than the real best (%.2lf)\n",sims_max,num_permutations,largest);  pr();
    sf(ps,"%d of %d had as many tests (%d) exceeding p=.01\n",sims_nh1,num_permutations,num_hits);  pr();
    sf(ps,"%d of %d had as many tests (%d) exceeding p=.001\n",sims_nh2,num_permutations,num_hits2);  pr();
    sf(ps,"%d of %d had as many tests (%d) exceeding p=.0001\n",sims_nh3,num_permutations,num_hits3); pr();

    unmatrix(tmpt, largest_count, int);
    unmatrix(tmpu, largest_count, int);
}


/* P-excess computation using TDT results */
command pexcess1(void)
{
    int i, j, k, count, tmp_diff, t1, t2, u1, u2;
    int *affcount, *normcount, total_count, num_stars;
    int tmp_sum, *jsum, *ksum, **tmp_array, largest_count;
    double diff1, diff2, p_excess;


    if (TDTcount == 0) { /* exit */
      print("error: tdt command must be run before using the pexcess1 command\n");
      return;
    }
      

    /* First shrink the list of alleles we're looking at to only the 
       existent ones (rather than the 1 to MAX_ALLELE_SIZE used above */

    largest_count=0;
    for (i=0; i<num_in_map_order; i++) {
	count=0;
	for (j=0; j<MAX_ALLELE_SIZE; j++) {
	  if (locus[map_order[i]].allele_count[j][2] > 0 ||
	      locus[map_order[i]].allele_count[j][1] > 0) {
	    which_allele[map_order[i]][j] = count;
	    allele_size[map_order[i]][count] = j;
	    count++;
	  } else {
	    which_allele[map_order[i]][j] = MISSING;
	  }
	  num_alleles[map_order[i]] = count;
	}
	if (count > largest_count) { largest_count=count; }
    }
    largest_count++;
    array(affcount, largest_count, int);
    array(normcount, largest_count, int);


    for (i=0; i<num_in_map_order; i++) {

        for (j=0; j<largest_count; j++) {
	    affcount[j] = normcount[j] = 0;
	}
	total_count=0;

	sf(ps,"Marker %d (%s)\t Transmitted  Untransmitted        p_excess\n",
	   map_order[i]+1, locus[map_order[i]].name); pr();

	
	for (j=0; j<TDTcount; j++) {
	  t1 = transmitted[map_order[i]][j];
	  u1 = untransmitted[map_order[i]][j];

	  if (t1==MISSING || u1==MISSING) continue;

	  affcount[which_allele[map_order[i]][t1]]++;
	  normcount[which_allele[map_order[i]][u1]]++;
	  total_count++;
	}


	for (j=0; j<num_alleles[map_order[i]]; j++) {

	    if (affcount[j] > 0 || normcount[j] > 0) {
	      diff1 = (double) (affcount[j] - normcount[j]);
	      diff2 = (double) (total_count - normcount[j]);
	      if (diff2 < 0.05) p_excess=1.0;
	      else p_excess = diff1/diff2;

	      sf(ps,"%-3d\t\t\t%4d (%.3lf)    %4d (%.3lf)        %.4lf ",
		 allele_size[map_order[i]][j], affcount[j],
		 (double)affcount[j]/(double)total_count, normcount[j],
		 (double)normcount[j]/(double)total_count, 
		 (p_excess > 0.00) ? p_excess : 0.00); pr();
	      if (p_excess > 0.0) {
		num_stars = (int) (p_excess*10.0);
		for (k=0; k<num_stars; k++) { print("*"); }
	      }
	      nl();
	    }
	}
    }

    unarray(affcount, int);
    unarray(normcount, int);
}


command pexcess2(void)   /* Two locus p-excess calculation */
{
    int i, j, k, l, count, tmp_diff, t1, t2, u1, u2;
    int **affcount, **normcount, total_count;
    double diff1, diff2, p_excess, num_stars;
    int tmp_sum, *jsum, *ksum, **tmp_array, largest_count;


    if (TDTcount == 0) { /* exit */
      print("error: tdt command must be run before using the pexcess2 command\n");
      return;
    }
      
    get_arg(itoken, 1, &tmp_diff);
    if (tmp_diff < 1) tmp_diff=1;
    tdt2_diff = tmp_diff;


    /* First shrink the list of alleles we're looking at to only the 
       existent ones (rather than the 1 to MAX_ALLELE_SIZE used above */

    largest_count=0;
    for (i=0; i<num_in_map_order; i++) {
	count=0;
	for (j=0; j<MAX_ALLELE_SIZE; j++) {
	  if (locus[map_order[i]].allele_count[j][2] > 0 ||
	      locus[map_order[i]].allele_count[j][1] > 0) {
	    which_allele[map_order[i]][j] = count;
	    allele_size[map_order[i]][count] = j;
	    count++;
	  } else {
	    which_allele[map_order[i]][j] = MISSING;
	  }
	  num_alleles[map_order[i]] = count;
	}
	if (count > largest_count) { largest_count=count; }
    }
    largest_count++;
    matrix(affcount, largest_count, largest_count, int);
    matrix(normcount, largest_count, largest_count, int);


    for (i=0; i<num_in_map_order-tdt2_diff; i++) {

        for (j=0; j<largest_count; j++) {
	  for (k=0; k<largest_count; k++) {
	    affcount[j][k] = normcount[j][k] = 0;
	  }
	}
	total_count=0;

	sf(ps,"Markers %d and %d     Transmitted Untransmitted  p-excess   (%s - %s)\n",
	   map_order[i]+1, map_order[i+tdt2_diff]+1, locus[map_order[i]].name, 
	   locus[map_order[i+tdt2_diff]].name); pr();

	tmp_sum = 0;

	for (j=0; j<TDTcount; j++) {
	  t1 = transmitted[map_order[i]][j];  t2 = transmitted[map_order[i+tdt2_diff]][j];
	  u1 = untransmitted[map_order[i]][j];  u2 = untransmitted[map_order[i+tdt2_diff]][j];

	  if (t1==MISSING || t2==MISSING || double_het[map_order[i]][j] || double_het[map_order[i+tdt2_diff]][j]) continue;

	  affcount[which_allele[map_order[i]][t1]][which_allele[map_order[i+tdt2_diff]][t2]]++;
	  normcount[which_allele[map_order[i]][u1]][which_allele[map_order[i+tdt2_diff]][u2]]++;
	  total_count++;
	}


	for (j=0; j<num_alleles[map_order[i]]; j++) {

	  for (k=0; k<num_alleles[map_order[i+tdt2_diff]]; k++) {
	    if (affcount[j][k] > 0 || normcount[j][k] > 0) {
	      diff1 = (double) (affcount[j][k] - normcount[j][k]);
	      diff2 =  (double) (total_count - normcount[j][k]);
	      if (diff2 < 0.05) p_excess=0.00;
	      else p_excess = diff1 / diff2;

	      sf(ps,"Haplotype: %-3d %-3d     %4d (%.3lf)  %4d (%.3lf)    %.3lf ",
		 allele_size[map_order[i]][j], allele_size[map_order[i+tdt2_diff]][k],
		 affcount[j][k], (double)affcount[j][k]/(double)total_count,
		 normcount[j][k], (double)normcount[j][k]/(double)total_count,
		 (p_excess > 0.0) ? p_excess : 0.0); pr();
	      if (p_excess > 0.0) {
		num_stars = (int) (p_excess*10.0);
		for (l=0; l<num_stars; l++) { print("*"); }
	      }
	      nl();
	    }
	  }
	}

    }

    unmatrix(affcount, largest_count, int);
    unmatrix(normcount, largest_count, int);
}


command pexcess3(void)   /* Two locus p-excess calculation */
{
    int i, j, k, l, x, count, tmp_diff, t1, t2, t3, u1, u2, u3;
    int ***affcount, ***normcount, total_count;
    double diff1, diff2, p_excess, num_stars;
    int tmp_sum, *jsum, *ksum, **tmp_array, largest_count;


    if (TDTcount == 0) { /* exit */
      print("error: tdt command must be run before using the pexcess3 command\n");
      return;
    }
      
    /* First shrink the list of alleles we're looking at to only the 
       existent ones (rather than the 1 to MAX_ALLELE_SIZE used above */

    largest_count=0;
    for (i=0; i<num_in_map_order; i++) {
	count=0;
	for (j=0; j<MAX_ALLELE_SIZE; j++) {
	  if (locus[map_order[i]].allele_count[j][2] > 0 ||
	      locus[map_order[i]].allele_count[j][1] > 0) {
	    which_allele[map_order[i]][j] = count;
	    allele_size[map_order[i]][count] = j;
	    count++;
	  } else {
	    which_allele[map_order[i]][j] = MISSING;
	  }
	  num_alleles[map_order[i]] = count;
	}
	if (count > largest_count) { largest_count=count; }
    }
    largest_count++;

    array(affcount, largest_count, int**);
    array(normcount, largest_count, int**);
    for (i=0; i<largest_count; i++) {
      matrix(affcount[i], largest_count, largest_count, int);
      matrix(normcount[i], largest_count, largest_count, int);
    }

    for (i=0; i<num_in_map_order-2; i++) {

        for (j=0; j<largest_count; j++) {
	  for (k=0; k<largest_count; k++) {
	    for (l=0; l<largest_count; l++) {
	      affcount[j][k][l] = normcount[j][k][l] = 0;
	    }
	  }
	}
	total_count=0;

	sf(ps,"Markers %d and %d and %d    Trans  Untrans  p-excess   (%s - %s - %s)\n",
	   map_order[i]+1, map_order[i+1]+1, map_order[i+2]+1,
	   locus[map_order[i]].name, locus[map_order[i+1]].name,
	   locus[map_order[i+2]].name); pr();

	tmp_sum = 0;

	for (j=0; j<TDTcount; j++) {
	  t1 = transmitted[map_order[i]][j];  
	  t2 = transmitted[map_order[i+1]][j];
	  t3 = transmitted[map_order[i+2]][j];

	  u1 = untransmitted[map_order[i]][j];  
	  u2 = untransmitted[map_order[i+1]][j];
	  u3 = untransmitted[map_order[i+2]][j];


	  if (t1==MISSING || t2==MISSING || t3==MISSING) continue;

	  if (double_het[map_order[i]][j] || double_het[map_order[i+1]][j] ||
	      double_het[map_order[i+2]][j]) continue;

	  affcount[which_allele[map_order[i]][t1]][which_allele[map_order[i+1]][t2]][which_allele[map_order[i+2]][t3]]++;
	  normcount[which_allele[map_order[i]][u1]][which_allele[map_order[i+1]][u2]][which_allele[map_order[i+2]][u3]]++;
	  total_count++;
	}
    

	for (j=0; j<num_alleles[map_order[i]]; j++) {
	  for (k=0; k<num_alleles[map_order[i+1]]; k++) {
	    for (l=0; l<num_alleles[map_order[i+2]]; l++) {
	      if (affcount[j][k][l] > 0 || normcount[j][k][l] > 0) {

		diff1 = (double) (affcount[j][k][l] - normcount[j][k][l]);
		diff2 =  (double) (total_count - normcount[j][k][l]);
		if (diff2 < 0.05) p_excess=0.00;
		else p_excess = diff1 / diff2;

		sf(ps,"Haplotype: %-3d %-3d %-3d   %4d (%.3lf)  %4d (%.3lf)    %.3lf ",
		   allele_size[map_order[i]][j], allele_size[map_order[i+1]][k],
		   allele_size[map_order[i+2]][l],
		   affcount[j][k][l], (double)affcount[j][k][l]/(double)total_count,
		   normcount[j][k][l], (double)normcount[j][k][l]/(double)total_count,
		   (p_excess > 0.0) ? p_excess : 0.0); pr();
		if (p_excess > 0.0) {
		  num_stars = (int) (p_excess*10.0);
		  for (x=0; x<num_stars; x++) { print("*"); }
		}
		nl();

	      }
	    }
	  }
	}

    }

    for (i=largest_count-1; i>0; i--) {
      unmatrix(normcount[i], largest_count, double);
      unmatrix(affcount[i], largest_count, double);
    }
    unarray(normcount, double**);
    unarray(affcount, double**);
}


command qtdt_test(void)
{
  int i, j;
  char kidstr[4][10]={"11","12","22",""};
  char parstr[4][10]={"","11x12","12x12","12x22"};

  

  if (num_qkids==0) { error("must have run TDT with 'qtdt on' before this command can be used"); }

  sf(ps,"QTDT input: %d kids, %d phenotypes\n",num_qkids,num_phenotypes);
  pr();

  print("locus 1\n");
  print("kid\tparents\n");
  for (i=0; i<num_qkids; i++) {
    if (qgenotype[0][i] == MISSING || qparental[0][i] == MISSING) continue;
    sf(ps,"%s\t%s\n",kidstr[qgenotype[0][i]],parstr[qparental[0][i]]);
    pr();
  }
}
