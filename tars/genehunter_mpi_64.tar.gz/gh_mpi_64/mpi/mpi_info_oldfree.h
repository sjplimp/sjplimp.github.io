
#ifndef ___MPI_INFO_H___
#define ___MPI_INFO_H___

#include <mpi.h>
#define MPI_ASSUME_LN_SIZE 50000
#define CRASH_MEM

#ifdef CRASH_MEM
void crash_mem();
#endif

/*Holds general information about the distribution of memory on the processors*/
typedef struct {
  
  int rank, 
    num_procs, 
    log2procs,                    /*Log base 2 of the number of processors*/
    vecs_per_proc,                /*Disease vectors per processor--should be less than 2^32*/
    log2_vecs_per_proc,           /*Log base 2 of above*/
    num_markers, prev_markers,  
    real_markers,  
    *marker_bits,                 /*Number of bits of the marker on this processor*/
    *do_marker_in_parallel,       /*For small markers ==0 because parallel overhead is too high*/ 
    *local_score_count,
    num_local_scores,  
    pednum, npl_error,
    *marker_memory_offset;          /*Replaces nz_pointer in parallel--tells where each marker starts in
				    pvct, lvct, rvct*/
  

  long long int vec_offset,                   /*1st disease vector on this processor*/
    vec_end,                                  /*Last disease vector on this processor*/  
    calc_apm_score_offset,                   /*Used to initialize static elements of Get_apm_score*/
    calc_apm_score_end,                      /*Determines size of apm score array*/

    *marker_full_vec_end, 
    *marker_full_vec_start,       /*Where to start in the marker vectors given our division of the disease
				    vector--Note, not the same as marker_vec_start*/  
    *marker_vec_start,            /*Where in each marker this processor's storage starts*/
    *marker_vec_end;              /*Where in each marker this processor's storage ends*/ 
   
  
    double *local_scores;
  
} Message_pass_interface;

Message_pass_interface mpi_interface;


/*A linked list for the reduction of the p_score arrays*/
struct k_score_l {
  int index;
  struct k_score_l *next;
}; 

typedef struct k_score_l save_score_list;



/*Holds data for the communication in steps 2 and 3*/
typedef struct {
  int orig_local,                        /*Did we alloc memory in the process of comm? 0 = YES*/
    free_needed_0,                       /*Is the 1st founder sim block memory to free*/
    did_founder_comm,                    
    num_live_procs,
    num_blocks,                  
    blocks_per_liveproc,
    log2_block_size,
    my_block,
    my_block_rank,
    *proc_blocks,
    **proc_block_ranks,
    founder_sim_groups,                  /*The number of distinct blocks of p-vals to represent all fs cases*/
    *did_fs_block,
    *founder_sim_blocks;                 /*Which of the FS blocks is needed for each FS case (of which there are 2^nffs*/
  
  long long int  maskshift[64][2], maskshift2[64][2], maskshift3[64][2], maskshift4[64][2], 
    *new_founder_sim_mask1,
    founder_sim_mask_fullrep[64],   new_p_mask_v_bits,
    target_mask_sourcerep,
    source_mask_targetrep,
    *target_fixed_vals_sourcerep, *foundersim_targetrep,
    target_proc_mask, source_proc_mask;
  
  double *local_block, **needed_blocks;
  
} PBvct_blocks;

void mpi_distribution_setup(int *, long long int *, long *, int,
			    long long int **, long long int, int *, long long int, int, long long int *);
double mpi_calculate_entropy(int,  long long int *, int, double ***, double *, double *, long long int);
void mpi_choose_last_prior_dist (int, double *, double *, double **, int);
void setup_prob_blocks(PBvct_blocks *);
void mpi_redistribute_marker(int, int, long long int, long long int, int, long long int *, PBvct_blocks *);
void mpi_redistribution_for_on_marker(int, long long int, long long int, long long int *, double **);
void mpi_redistribution_for_on_marker3(int, long long int, long long int, long long int *,  double **,  double **, double **);
void mpi_distrib_founder_sim_markers (int, int, long long int, long long int *, long long int *, PBvct_blocks *);
void mpi_partial_gather(int, int **, int, int, long long int *, int, int *, double *,  double **);
void mpi_reduce_sharing_arrays(double ****, int);
void mpi_cleanup();


void mpi_redistribute_step2_marker_bothparallel(int, long long int, int, long long int,
						long long int, int, int, long long int *,
						double *, PBvct_blocks *);
void mpi_redistribute_step2_marker_nonparallel_target(int, long long int, int, int, long long int, long long int, int,  long long int *, double *, PBvct_blocks *);

void compact_prob_vct(int, long long int, long long int, int, long long int *, double *, PBvct_blocks *);
void setup_maskshift(long long int, int, long long int *, long long int maskshift[64][2]);
void cleanup_PBvct_struct(PBvct_blocks *);
#endif

