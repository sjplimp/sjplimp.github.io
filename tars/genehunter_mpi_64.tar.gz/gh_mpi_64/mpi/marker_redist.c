void mpi_redistribute_marker(int marker, int marker_bits, int mask, int full_bits, int *pow2, double *score_pvect,
								double **converted_pvect)
{
	int i, j, k, proc_mask, proc_fixed_bits=0, num_blocks, my_block, my_block_rank, *proc_blocks, 
		**proc_block_ranks, *block_cnts, maskshift[64][2], my_block_owner, local_block, 
		local_block_rank, free_local=0;
	double *correct_block_piece;
	MPIStatus status;

	proc_mask=mask>>mpi_interface.log2_vecs_per_proc;

	if (proc_mask != 0)
	{
		for (i=0; i<mpi_interface.log2procs; i++)
			if (pow2[i]	& proc_mask)		
				proc_fixed_bits++;
		num_blocks=pow2[proc_fixed_bits];

		if (proc_mask & 1) {
			maskshift[0][0]=0;
			maskshift[0][1]=1;
		}
		else {
			maskshift[0][0]=1;
			maskshift[0][1]=0;
		}

		for (i=1; i<mpi_interface.log2procs; i++)  {
			if (pow2[i] & proc_mask) {
				maskshift[i][0]=0;
				maskshift[i][1]=maskshift[i-1][1]+1;
			}
			else {
				maskshift[i][0]=pow2[i];
				maskshift[i][1]-maskshift[i-1];
			}
		}

		proc_blocks=(int*)malloc(sizeof(int)*mpi_interface.num_procs);
		proc_block_ranks=(int**)malloc(sizeof(int*)*num_blocks);
		block_cnts=(int*)malloc(sizeof(int)*num_blocks);

		for (i=0; i<num_blocks; i++) {
			block_cnts[i]=0;
			proc_block_ranks[i]=(int*)malloc(sizeof(int)*mpi_inteface.num_procs/num_blocks);
		}

		for (i=0; i<mpi_interface.num_procs; i++)
		{
			k=0;
			for (j=0; j<log2procs; j++)
				k |= (i  & maskshift[j][0])>>maskshift[j][1];
			proc_blocks[i] = k;
		}

		my_block = proc_blocks[mpi_interface.rank];

		for (i=0; i<mpi_interface.num_procs; i++) {
			proc_block_ranks[proc_blocks[i]][block_cnts[proc_blocks[i]]=i;
			
			if (i == mpi_interface.rank)
				my_block_rank = block_cnts[proc_ranks[i]];

			block_cnts[proc_blocks[i]]++;	
		}

		my_block_owner=my_block*(mpi_interface.num_procs/num_blocks) +
			my_block_rank;
		

		local_block=mpi_interface.rank*(num_blocks/mpi_interface.num_procs);
		local_block_rank=mpi_interface.rank%(mpi_interface.num_procs/num_blocks);

		if (my_block_owner != mpi_interface.rank) {
			correct_block_piece=(double*)malloc(sizeof(double)*pow2[marker_bits]);
			free_local=1;
			MPI_IRecv(correct_block_piece, pow2[marker_bits], my_block_owner, my_block, MPI_COMM_WORLD);
			MPI_ISend(score_pvect, pow2[marker_bits], proc_block_ranks[local_block][local_block_rank],
					local_block, MPI_COMM_WORLD);
			MPI_Wait(my_block);
			MPI_Wait(local_block);
		}
		else
			correct_block_piece = score_pvect;
	}


	mpi_partial_gather(proc_fixed_bits, proc_block_ranks, my_block_rank, my_block, pow2,
			pow2[marker_bits], free_local, correct_block_piece, converted_pvect);


}



void mpi_partial_gather(int log2comm_size, int **proc_block_ranks, int my_rank, int my_block, 
							int *pow2, int block_piece_size, int free_local, double *block_piece,  double **converted_pvect)
{
	int i, j, comm_partner, local_size;
	double *local_vect, *remote_vect, *net_vect;
	
	local_size=block_piece_size;
	local_vect=block_piece;


	for (i=0; i<log2comm_size; i++) {
		if (!(my_rank & pow2[i]))
			comm_partner = my_rank + pow2[i];
		else 
			comm_partner = my_rank - pow2[i];
		remote_vect=(double*)malloc(sizeof(double)*local_size);

		MPI_SendRecv(local_vect, local_size, 0, comm_partner, remote_vect, local_size , 0, MPI_COMM_WORLD);

		net_vect=(double*)malloc(sizeof(double)*2*local_size);
		if (!(my_rank & pow2[i]))  {
			for (j=0; j<local_size; j++)
				net_vect[i]=local_vect[i];
			for (j=0; j<local_size; j++)
				net_vect[i+local_size]=remote_vect[i];
		}
		else {
			for (j=0; j<local_size; j++)
				net_vect[i]=remote_vect[i];
			for (j=0; j<local_size; j++)
				net_vect[i+local_size]=local_vect[i];
		}

		free(remote_vect);
		if (!(i == 0 && free_local == 0))
			free(local_vect);

		local_vect=net_vect;
		local_size*=2;
	}

	(*converted_pvect)=net_vect;
}