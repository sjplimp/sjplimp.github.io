#include "mpi_info.h"
#include "BST.h"

/*#define MPI_SERIAL_LIMIT 6+mpi_interface.log2procs*/
#define MPI_SERIAL_LIMIT 6
/*Note that these routinues require processors to scale in multiples of 2*/

extern BinarySearchTree *global_score_tree, *score_tree;

/*GCCHECK*/
int Get_apm_offset_mpi(long long int, long long int);

#ifdef CRASH_MEM
void crash_mem()
{
  int i,j, size=500;
  double **dum;

  dum=(double**)malloc(sizeof(double*)*size);
  for(i=0; i<size; i++)
    dum[i]=(double*)malloc(sizeof(double)*size);
  for(i=0; i<size; i++)
    for(j=0; j<size; j++)
      dum[i][j]=0.0;
  
  if (mpi_interface.rank == 0)
    printf("Proc %d malloced big\n", mpi_interface.rank);
   for(i=0; i<size; i++)
     free(dum[i]);
   free(dum);

}
#endif

void mpi_distribution_setup(int *nz_bits, long long int *nz_pointer, long *amount_to_alloc, int f_num_in_map_order,
			    long long int **maskTest, long long int score_mask_rdc, 
			    int *f_uninformative, long long int real_num_vecs,
			    int analysis_type, long long int *score_alloc)
{
  int i,j,k;
  long long int ii, kk;

  /*Calculates the log base of the number of processors--Assumes we 
    have a power of 2 for num_procs*/
  mpi_interface.log2procs=0;
  while ((int)pow2[mpi_interface.log2procs]!=mpi_interface.num_procs)
    mpi_interface.log2procs++;

 
  *amount_to_alloc=0;
  
 
  /*Calculates the distribution of the markers for the parallel fft*/
  array(mpi_interface.do_marker_in_parallel, f_num_in_map_order, int);
  array(mpi_interface.marker_vec_start, f_num_in_map_order,long long int);
  array(mpi_interface.marker_vec_end, f_num_in_map_order, long long int);
  array(mpi_interface.marker_bits, f_num_in_map_order, int);
  array(mpi_interface.marker_memory_offset, f_num_in_map_order+1, int);
 
  for(i=0; i<f_num_in_map_order; i++){ 
    mpi_interface.marker_memory_offset[i]=(int)*amount_to_alloc;

    
    if (nz_bits[i]>=MPI_SERIAL_LIMIT)
      mpi_interface.do_marker_in_parallel[i]=1;
    else
      mpi_interface.do_marker_in_parallel[i]=0;
    if (mpi_interface.do_marker_in_parallel[i]==1){
      mpi_interface.marker_vec_start[i]=pow2[nz_bits[i]-mpi_interface.log2procs]*(long long int)mpi_interface.rank;
      mpi_interface.marker_vec_end[i]=pow2[nz_bits[i]-mpi_interface.log2procs]*((long long int)mpi_interface.rank+1)-1;
      
      mpi_interface.marker_bits[i]=nz_bits[i]-mpi_interface.log2procs;
      *amount_to_alloc+=(long)pow2[mpi_interface.marker_bits[i]];
      
    }
    else {
      mpi_interface.marker_vec_start[i]=mpi_interface.marker_vec_end[i]=-1;
      mpi_interface.marker_bits[i]=nz_bits[i];
      *amount_to_alloc+=(long)pow2[nz_bits[i]];
    }
    /*printf("Proc %d marker %d: bits: %d, unifor: %d size: %d  Offset %d\n", mpi_interface.rank, i, nz_bits[i], 
      f_uninformative[i], pow2[nz_bits[i]], mpi_interface.marker_memory_offset[i] );*/
    


  }


  mpi_interface.marker_memory_offset[f_num_in_map_order]=(int)*amount_to_alloc;

#ifdef _SHOW_MPI_DIST
  for(i=0; i<f_num_in_map_order; i++)
    printf("Proc %d marker %d: bits: %d, uninformative: %d Array locs (Start %d, end %d), Parallel: %d\n",
	   mpi_interface.rank, i, nz_bits[i], f_uninformative[i], mpi_interface.marker_memory_offset[i],
	   mpi_interface.marker_memory_offset[i+1], mpi_interface.do_marker_in_parallel[i]);
#endif

  
 
  /*Distributes disease vector among processors*/
  
  
  mpi_interface.vecs_per_proc=(int)(real_num_vecs/mpi_interface.num_procs);
  
  /*vec_offset is the starting location of this processor's vector in the
    "real" vector*/
  mpi_interface.vec_offset=(long long int)mpi_interface.rank*(long long int)mpi_interface.vecs_per_proc;
  
  /*vec_end is the last element of the full vector stored on this processor--G. Conant*/
  mpi_interface.vec_end=mpi_interface.vec_offset+ (long long int)(mpi_interface.vecs_per_proc-1);
  
  
  /*Determines the log2 of the number of "full" inher. vectors on each processor*/
  mpi_interface.log2_vecs_per_proc=0;
  i=mpi_interface.vecs_per_proc;
  while (!(i & 1))
    {
      i=i>>1;
      mpi_interface.log2_vecs_per_proc++;
    }
  if (i!=1) {
    printf("Error on processor %d: number of vectors on processor (%d) is not a power of two\n",
	   mpi_interface.rank, mpi_interface.vecs_per_proc);
    MPI_Abort(MPI_COMM_WORLD, 1);
  }
  
  /*We want to distribute the marker vectors onto processors as well.  To
    do this, we need to know the overall size of each marker's allow inher.
    vector space--G. Conant*/
  array(mpi_interface.marker_full_vec_end,      f_num_in_map_order  , long long int);
  array(mpi_interface.marker_full_vec_start, f_num_in_map_order, long long int);
  for (i=0; i<f_num_in_map_order; i++)
    {
      
      /*We now look for the full vector index that corrisponds to the first index
	of the reduced vector that is on this processor--G. Conant */
      j=kk=0;
      while (kk<mpi_interface.vec_offset ){
	if((kk & maskTest[i][0]) == maskTest[i][1]) j++;
	kk++;
      }
      
      mpi_interface.marker_full_vec_start[i]=j;
      while (kk<mpi_interface.vec_end ){
	if((kk & maskTest[i][0]) == maskTest[i][1]) j++;
	kk++;
      }		
      mpi_interface.marker_full_vec_end[i]=j;
      
    }
  
  /*We now calculate the apm score offsets so that this processor can
    calculate npl scores for its vectors only--these are used again in the
    TRANSBETWEENANDDOT routinue in newcombo.c--G. Conant*/
  for(ii=0; ii<=mpi_interface.vec_end; ii++)
    {
      j=Get_apm_offset_mpi(ii,score_mask_rdc);
      if (ii==mpi_interface.vec_offset)
	mpi_interface.calc_apm_score_offset=j;
      if (ii==mpi_interface.vec_end)
	mpi_interface.calc_apm_score_end=j;
    }
  *score_alloc= mpi_interface.calc_apm_score_end-
    mpi_interface.calc_apm_score_offset;
  
  
}  /*End  mpi_distribution_setup*/


void setup_prob_blocks(PBvct_blocks *prob_blocks)
{
  prob_blocks->orig_local=1;
  prob_blocks->proc_blocks=0; 
  prob_blocks->local_block=0;
  prob_blocks->proc_block_ranks=0;
  prob_blocks->new_founder_sim_mask1=0;
  prob_blocks->needed_blocks=0;
  prob_blocks->did_founder_comm=0;
  prob_blocks->founder_sim_blocks=0;
  prob_blocks->target_fixed_vals_sourcerep=0;
  prob_blocks->did_fs_block=0;
  prob_blocks->free_needed_0=0;
  prob_blocks->foundersim_targetrep=0;
}




void mpi_reduce_score_arrays(int num_scores,  long long int *pow2)
{
  int i, j, k, comm_partner, local_size, remote_size, *temp_count_local, *temp_count_remote, 
    *reduced_count, reduced_size;
  double *temp_scores_remote, *temp_scores_local, *reduced_scores;
  MPI_Status status;
  BinarySearchTree *search_tree;
 
  /*printf("Proc %d entering reduce_score_arrays: num %d\n", mpi_interface.rank, num_scores);*/
  /*Setup for 1st iteration*/ 
  if (mpi_interface.num_procs > 1) {
    temp_scores_local= (double*)malloc(sizeof(double)*num_scores);   
    temp_count_local= (int*)malloc(sizeof(int)*num_scores);
   
    if ((temp_scores_local == NULL) || (temp_count_local == NULL))
      {
	printf("Error on processor %d: Insufficient memory for mpi_reduce_score_arrays\n", mpi_interface.rank);
	MPI_Abort(MPI_COMM_WORLD, 1);
      }
    
    for(i=0; i<num_scores; i++)
      {
	temp_scores_local[i]=mpi_interface.local_scores[i];
	temp_count_local[i]=mpi_interface.local_score_count[i];
      }
  }  
  local_size=num_scores;
  
  
  for(i=0; i<mpi_interface.log2procs; i++)  {

      search_tree=(BinarySearchTree*)malloc(sizeof(BinarySearchTree));
      initialize_tree(search_tree);

   
      if ((mpi_interface.rank & (int)pow2[i])==0)
	comm_partner=mpi_interface.rank+(int)pow2[i];
      else
	comm_partner=mpi_interface.rank-(int)pow2[i];
      
      MPI_Sendrecv(&local_size, 1,MPI_INT,comm_partner,0,
                 &remote_size,1,MPI_INT,comm_partner,0,
                 MPI_COMM_WORLD,&status);
      
     
      temp_scores_remote=(double*)malloc(sizeof(double)*remote_size);
      temp_count_remote=(int*)malloc(sizeof(int)*remote_size);
     
      if ((temp_scores_remote ==0) || (temp_count_remote == 0))
      {
	printf("Error on processor %d: Insufficient memory for mpi_reduce_score_arrays: remote\n", mpi_interface.rank);
	MPI_Abort(MPI_COMM_WORLD, 1);
      }

      reduced_size=0;

      MPI_Sendrecv(temp_scores_local, local_size, MPI_DOUBLE, comm_partner,0,
                 temp_scores_remote, remote_size, MPI_DOUBLE, comm_partner,0,
                 MPI_COMM_WORLD,&status);
      
      MPI_Sendrecv(temp_count_local, local_size, MPI_INT, comm_partner,0,
                 temp_count_remote, remote_size, MPI_INT, comm_partner,0,
                 MPI_COMM_WORLD,&status);

    
      /*If we're the lower rank of the two, start with local. Otherwise start with remote
	(this makes sure that both processors have identical BSTs and arrays)*/
      if (mpi_interface.rank < comm_partner) {

	for(j=0; j<local_size; j++)
	  {
	    Insert(search_tree, temp_scores_local[j], reduced_size);
	    reduced_size++;
	  }

	for(j=0; j<remote_size; j++)
	  {
	    k=Retrieve(search_tree, temp_scores_remote[j]);
	    if (k == -1) {
	      Insert(search_tree, temp_scores_remote[j], reduced_size);
	      reduced_size++;
	    }
	  }
	
      }
      else { /*We're bigger than comm_partner*/
	for(j=0; j<remote_size; j++)
	  {
	    Insert(search_tree, temp_scores_remote[j], reduced_size);
	    reduced_size++;
	  }
	
	for(j=0; j<local_size; j++)
	  {
	    k=Retrieve(search_tree, temp_scores_local[j]);
	    if (k == -1) {
	      Insert(search_tree, temp_scores_local[j], reduced_size);
	      reduced_size++;
	    }
	  }
	
      }

     
      reduced_scores=(double*)malloc(sizeof(double)*reduced_size);
      reduced_count=(int*)malloc(sizeof(int)*reduced_size);

      if ((reduced_scores ==0) || (reduced_count == 0))
      {
	printf("Error on processor %d: Insufficient memory for mpi_reduce_score_arrays: reduced\n", mpi_interface.rank);
	MPI_Abort(MPI_COMM_WORLD, 1);
      }


      for(j=0; j<reduced_size; j++)
	reduced_count[j]=0;
 
      /*If we're the lower rank of the two, start with local. Otherwise start with remote
	(this makes sure that both processors have identical BSTs and arrays)*/
      if (mpi_interface.rank < comm_partner) {

	for(j=0; j<local_size; j++)
	  {
	    k=Retrieve(search_tree, temp_scores_local[j]);
	    reduced_scores[k]=
	      temp_scores_local[j];
	    reduced_count[k]+=
	      temp_count_local[j];
	  }
	  

	for(j=0; j<remote_size; j++)
	  {
	    k=Retrieve(search_tree, temp_scores_remote[j]);
	    reduced_scores[k]=
	      temp_scores_remote[j];
	    reduced_count[k]+=
	      temp_count_remote[j];
	  }
      }
      else { /*We're bigger than comm_partner*/
	for(j=0; j<remote_size; j++)
	  {
	    k=Retrieve(search_tree, temp_scores_remote[j]);
	    reduced_scores[k]=
	      temp_scores_remote[j];
	    reduced_count[k]+=
	      temp_count_remote[j];
	  }

	for(j=0; j<local_size; j++)
	  {
	    k=Retrieve(search_tree, temp_scores_local[j]); 
	    reduced_scores[k]=
	      temp_scores_local[j];
	    reduced_count[k]+=
	      temp_count_local[j];
	  }
      }
     
      free(temp_scores_remote);
      free(temp_count_remote);
      if (i != (mpi_interface.log2procs-1))  
	  delete_tree(search_tree);
     
      free(temp_scores_local);
      free(temp_count_local);

      temp_scores_local=reduced_scores;
      temp_count_local=reduced_count;
      local_size=reduced_size;    
  }
 

  /*We built the full search tree in the last iteration--let's use it*/
  if (mpi_interface.num_procs > 1) {
     /*After the last iteration everyone has the same arrays--copy them to the right place and 
    continue*/
    mpi_interface.num_net_scores=local_size;
    mpi_interface.net_score_count=temp_count_local;
    mpi_interface.net_scores=temp_scores_local;
   
    global_score_tree=search_tree;
  }
  else {
    mpi_interface.num_net_scores=num_scores;
    mpi_interface.net_score_count=mpi_interface.local_score_count;
    mpi_interface.net_scores=mpi_interface.local_scores; 
    global_score_tree=score_tree;
  } 
 
  }  /*End mpi_reduce_score_arrays*/



void mpi_calculate_entropy(int num_w_pos, double **p_score, int num_scores, double *like_r, double *entropy,
			   double *un_normalized_entropy_r)
     /*Standard MPI_Allreduce blew out, so I had to write my own version*/
{
  int pos, i, j, k,  cnt, comm_partner, local_size, remote_size, net_size, lower, upper, dec, mem_fail=0;
  double *temp=0, *temp_r=0, *scores_l, *scores_r, *net_scores, *net_temp, *entropy_r;
  MPI_Status status;


 

 for (pos=0; pos<num_w_pos; pos++) {
   
   local_size=num_scores;
   temp=(double*)malloc(sizeof(double)*local_size);
   scores_l=(double*)malloc(sizeof(double)*local_size);


   if ((temp == 0) || (scores_l == 0)) {
       printf("ERROR: Insufficient memory for entropy calculation--entropy will be wrong--Continuing\n");
       mem_fail=1;
   }
   else {
     for(i=0; i<local_size; i++) {
       temp[i]=p_score[pos][i]; 
       scores_l[i]=mpi_interface.local_scores[i];
     }
     
     lower=0;
     upper=mpi_interface.num_net_scores;
    
     for(i=0; i<mpi_interface.log2procs; i++) {
       if ((mpi_interface.rank & (int)pow2[mpi_interface.log2procs-i-1]) == 0) {
	 comm_partner=mpi_interface.rank+(int)pow2[mpi_interface.log2procs-i-1];
	 if (((upper-lower) & 1) == 1) dec=1;
	 else dec=0;
	   
	 upper-=(upper-lower)/2;

	 upper-=dec;
       }
       else {
	 comm_partner=mpi_interface.rank-(int)pow2[mpi_interface.log2procs-i-1];
	 lower += (upper-lower)/2;
       }
      
       MPI_Sendrecv(&local_size, 1, MPI_INT, comm_partner,0,
		    &remote_size, 1, MPI_INT, comm_partner,0,
		    MPI_COMM_WORLD,&status); 
       temp_r=(double*)malloc(sizeof(double)*remote_size);
       scores_r=(double*)malloc(sizeof(double)*remote_size);
       if ((temp_r == 0) || (scores_r == 0)) {
	 printf("ERROR: insufficient memory for entropy calculations--entropy will be wrong--Continuing\n");  
	 mem_fail=1;
       }
       else {
	 MPI_Sendrecv(scores_l, local_size,  MPI_DOUBLE, comm_partner,0,
		      scores_r, remote_size,  MPI_DOUBLE, comm_partner,0,
		      MPI_COMM_WORLD,&status);      
	 
	 MPI_Sendrecv(temp, local_size,  MPI_DOUBLE, comm_partner,0,
		      temp_r, remote_size,  MPI_DOUBLE, comm_partner,0,
		      MPI_COMM_WORLD,&status); 
	 
	 net_size=0;

	 for(j=0; j<local_size; j++) {
	   k=Retrieve_Global_ST(scores_l[j]);
	   if ((k<upper) && (k>=lower)) net_size++;
	 }
	  for(j=0; j<remote_size; j++) {
	   k=Retrieve_Global_ST(scores_r[j]);
	   if ((k<upper) && (k>=lower)) net_size++;
	 }
	  
	  net_scores=(double*)malloc(sizeof(double)*net_size);
	  net_temp=(double*)malloc(sizeof(double)*net_size);

	  if ((net_scores ==0) ||( net_temp == 0)) {
	    printf("ERROR: insufficient memory for entropy calculations--entropy will be wrong--Contiuning\n");
	    mem_fail=1;
	  }
	  else {
	    cnt=0;

	    for(j=0; j<local_size; j++) {
	      k=Retrieve_Global_ST(scores_l[j]);
	      if ((k<upper) && (k>=lower))  {
		net_scores[cnt]=scores_l[j];
		net_temp[cnt++]=temp[j];
	      }
	    }
	    for(j=0; j<remote_size; j++) {
	      k=Retrieve_Global_ST(scores_r[j]);
	      if ((k<upper) && (k>=lower)) {
		net_scores[cnt]=scores_r[j];
		net_temp[cnt++]=temp_r[j];
	      }
	    }


	    free(temp_r);
	    free(temp);
	    free(scores_l);
	    free(scores_r);
	    scores_l=net_scores;
	    temp=net_temp;
	    local_size=net_size;

	  }

       }
       
     }

     if (mem_fail == 0) {
       if (like_r[pos] < 1e-280) 
	 entropy[pos]=0;
       else {
	 for (i=0; i<net_size; i++) temp[i]/=like_r[pos];
	 
	 entropy[pos]=0.0;
	 
	 for (i=0; i<local_size; i++) {
	   if (temp[i]!=0.0)
	     entropy[pos] += (-1.0)*temp[i]*log(temp[i]);
	 }
       }
     }
     
   }
 }

 entropy_r=(double*)malloc(sizeof(double)*num_w_pos);

 MPI_Allreduce(entropy, entropy_r, num_w_pos, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);

 for(pos=0; pos<num_w_pos; pos++)
   entropy[pos]=entropy_r[pos];
 
 free(entropy_r);
 if (scores_l != 0)
   free(scores_l);
 if (temp != 0)
   free(temp);

 delete_tree(global_score_tree);

}




void mpi_redistribute_marker(int marker, int marker_bits, long long int mask, long long int p_mask_v_bits, int full_bits,
			     long long int *pow2, PBvct_blocks *prob_blocks)
     /*For use in step 3, this function calculates which pieces of the left/right vectors each processor
       will need in TransBetweenAndDot and does appropriate communication*/

{
  int i, j, k, proc_fixed_bits=0, *block_cnts, 
    my_block_owner, local_block, local_block_size, 
    local_block_rank;
  long long int ii, kk, mask_proc_bits;
  double *correct_block_piece;
  MPI_Status status;
  MPI_Request receive_request;
  
  

  
  /*Locate any fixed bits "above the processor boundary*/
  prob_blocks->source_proc_mask=mask>>mpi_interface.log2_vecs_per_proc;
  
  for (i=0; i<mpi_interface.log2procs; i++)
    if (pow2[i]	& prob_blocks->source_proc_mask)		
      proc_fixed_bits++;

 
  /* printf("Proc %d begining communication analysis of marker %d, mask: %d, proc mask: %d, fixed bits: %d\n", mpi_interface.rank, marker, mask, prob_blocks->source_proc_mask, proc_fixed_bits);*/
  
  prob_blocks->orig_local=1;
  prob_blocks->needed_blocks=0;
  prob_blocks->free_needed_0=0;
  
  mask_proc_bits=pow2[marker_bits-mpi_interface.log2procs+proc_fixed_bits]-1;
  
  if (p_mask_v_bits != 0) {
    prob_blocks->new_p_mask_v_bits = (p_mask_v_bits & mask_proc_bits);
    
    prob_blocks->log2_block_size=marker_bits-mpi_interface.log2procs+proc_fixed_bits;
  }
  

  if (prob_blocks->source_proc_mask != 0)
    {
      local_block_size=(int)pow2[marker_bits-mpi_interface.log2procs];      
      
      prob_blocks->num_blocks=(int)pow2[mpi_interface.log2procs-proc_fixed_bits];
	 
      setup_maskshift(prob_blocks->source_proc_mask, mpi_interface.log2procs, pow2, prob_blocks->maskshift);
      
      prob_blocks->proc_blocks=(int*)malloc(sizeof(int)*mpi_interface.num_procs);
      prob_blocks->proc_block_ranks=(int**)malloc(sizeof(int*)*prob_blocks->num_blocks);
      block_cnts=(int*)malloc(sizeof(int)*prob_blocks->num_blocks);
      
      for (i=0; i<prob_blocks->num_blocks; i++) {
	block_cnts[i]=0;
	prob_blocks->proc_block_ranks[i]=(int*)malloc(sizeof(int)*(mpi_interface.num_procs/
						      prob_blocks->num_blocks));
      }
      
      for (i=0; i<mpi_interface.num_procs; i++)
	{
	  ii=(long long int)i;
	  kk=0;
	  for (j=0; j<mpi_interface.log2procs; j++)
	    if (pow2[j] & prob_blocks->maskshift[j][0])
	      kk |= (ii  & prob_blocks->maskshift[j][0])>>prob_blocks->maskshift[j][1];
	  prob_blocks->proc_blocks[i] = (int)kk;
	}
      
      prob_blocks->my_block = prob_blocks->proc_blocks[mpi_interface.rank];
      
      for (i=0; i<mpi_interface.num_procs; i++) {
	prob_blocks->proc_block_ranks[prob_blocks->proc_blocks[i]][block_cnts[prob_blocks->proc_blocks[i]]]=i;
	
	if (i == mpi_interface.rank)
	  prob_blocks->my_block_rank = block_cnts[prob_blocks->proc_blocks[i]];
	
	block_cnts[prob_blocks->proc_blocks[i]]++;	
      }
      
      my_block_owner=prob_blocks->my_block*(mpi_interface.num_procs/
					    prob_blocks->num_blocks) +prob_blocks->my_block_rank;
      
      
      local_block=(int)mpi_interface.rank*(1.0*prob_blocks->num_blocks/mpi_interface.num_procs);
      local_block_rank=mpi_interface.rank%(mpi_interface.num_procs/prob_blocks->num_blocks);
      
      if (my_block_owner != mpi_interface.rank) {
	/*printf("Proc %d doing async send/receive: getting from: %d sending to %d: blocks %d, my_block: %d, my_block_rank: %d, local block: %d, local_block_rank: %d\n",
	       mpi_interface.rank, my_block_owner, prob_blocks->proc_block_ranks[local_block][local_block_rank],
	       prob_blocks->num_blocks, prob_blocks->my_block, prob_blocks->my_block_rank, local_block, local_block_rank);*/

	correct_block_piece=0;
	correct_block_piece=(double*)malloc(sizeof(double)*local_block_size);
	
	if (correct_block_piece == NULL) {
	  printf("ERROR: Insufficient memory for block exchange: mpi_redistribute_marker\n");
	  MPI_Abort(MPI_COMM_WORLD,1);
	}

	/*We will need to free the memory we just malloc-ed--flag that with orig_local == 0*/
	prob_blocks->orig_local=0;
	
	MPI_Irecv(correct_block_piece, local_block_size, MPI_DOUBLE, my_block_owner, 0, 
		  MPI_COMM_WORLD, &receive_request);
	
	MPI_Send(prob_blocks->local_block, local_block_size, MPI_DOUBLE,  
		 prob_blocks->proc_block_ranks[local_block][local_block_rank],
		 0, MPI_COMM_WORLD);
	
	MPI_Wait(&receive_request, &status);
	
      }
      else
	correct_block_piece = prob_blocks->local_block;
      
	
      mpi_partial_gather(proc_fixed_bits, prob_blocks->proc_block_ranks, prob_blocks->my_block_rank, 
			 prob_blocks->my_block, pow2,
			 local_block_size, &prob_blocks->orig_local, correct_block_piece, &prob_blocks->local_block);

      if (my_block_owner != mpi_interface.rank) 
	free(correct_block_piece);

      free(block_cnts);
    }
  else
    { 

    
    /*Even if there are no high order fixed bits, we need to set these values
	in case there are high order founder-sim bits*/
      prob_blocks->num_blocks=mpi_interface.num_procs;
      prob_blocks->proc_blocks=(int*)malloc(sizeof(int)*mpi_interface.num_procs);
      prob_blocks->proc_block_ranks=(int**)malloc(sizeof(int*)*mpi_interface.num_procs);
      for(j=0; j<mpi_interface.num_procs; j++) {
	prob_blocks->proc_blocks[j]=j;
	prob_blocks->proc_block_ranks[j]=(int*)malloc(sizeof(int));
	prob_blocks->proc_block_ranks[j][0]=j;
      }
      prob_blocks->my_block=mpi_interface.rank;
      prob_blocks->my_block_rank=0;
      for(j=0; j<mpi_interface.log2procs; j++)
	{
	  prob_blocks->maskshift[j][0]=pow2[j];
	  prob_blocks->maskshift[j][1]=0;
	}
    }
  
}  /*End mpi_redistribute_markers*/



void mpi_distrib_founder_sim_markers (int founder_sibs_w_fixed, int full_bits, long long int mask_fixed, 
				      long long int *ordered_masks,
				      int var_bits, long long int *pow2, PBvct_blocks *prob_blocks)
{
  int i, j, k, comm_partner,  new_block;
  long long int kk, proc_bit_masks[64], mask_proc_bits, net_fs_mask;
  MPI_Status status;


  prob_blocks->founder_sim_groups=0;
  prob_blocks->did_founder_comm=0;
  prob_blocks->free_needed_0=0;

  prob_blocks->foundersim_targetrep=(long long int*)malloc(sizeof(long long int)*(int)pow2[founder_sibs_w_fixed]);
  prob_blocks->founder_sim_blocks=(int*)malloc(sizeof(int)*(int)pow2[founder_sibs_w_fixed]);

 
  for (i=0; i<founder_sibs_w_fixed; i++) 
    prob_blocks->founder_sim_mask_fullrep[i] ^=  (prob_blocks->founder_sim_mask_fullrep[i] & mask_fixed);

 
 
  for (i=0; i<(int)pow2[founder_sibs_w_fixed]; i++) {
    net_fs_mask=0;
    for(j=0; j<founder_sibs_w_fixed; j++)
      if ((int)pow2[j] & i)
	net_fs_mask |= (prob_blocks->founder_sim_mask_fullrep[j]>>mpi_interface.log2_vecs_per_proc);


   
    kk=0;
    for (j=0; j<mpi_interface.log2procs; j++)
      if (pow2[j] & prob_blocks->maskshift[j][0])
	kk |= (net_fs_mask & prob_blocks->maskshift[j][0]) >> prob_blocks->maskshift[j][1];
   
   
    prob_blocks->foundersim_targetrep[i]=kk;  
 
  
    /*Determines if this is the first founder sim combination with this block number*/
    j=0;
    while ((j<i) && 
	   (prob_blocks->foundersim_targetrep[j]
	    != prob_blocks->foundersim_targetrep[i])) 
      j++;
  
    if (j<i) 
      prob_blocks->founder_sim_blocks[i]=prob_blocks->founder_sim_blocks[j];
    else {
      prob_blocks->founder_sim_blocks[i]=prob_blocks->founder_sim_groups;
      prob_blocks->founder_sim_groups++;
    } 
    
  }

  /* MPI_Barrier(MPI_COMM_WORLD);
  if (mpi_interface.rank == 0)
    printf("Proc %d: for this marker:  %d var bit val and the mask is %d, fs phases: %d, groups %d\n", mpi_interface.rank,
    var_bits, prob_blocks->founder_sim_mask_fullrep[0], founder_sibs_w_fixed, prob_blocks->founder_sim_groups);*/
  

  if ( prob_blocks->founder_sim_groups > 1) {
    prob_blocks->needed_blocks=(double**)malloc(sizeof(double*)*prob_blocks->founder_sim_groups);
    prob_blocks->needed_blocks[0]=prob_blocks->local_block;
    prob_blocks->new_founder_sim_mask1=(long long int*)malloc(sizeof(long long int)*(int)pow2[founder_sibs_w_fixed]);
    prob_blocks->did_fs_block=(int*)malloc(sizeof(int)*prob_blocks->founder_sim_groups);
    prob_blocks->did_fs_block[0]=1;
    for(i=1; i<prob_blocks->founder_sim_groups; i++)
      prob_blocks->did_fs_block[i]=0;

    prob_blocks->did_founder_comm=1;

    mask_proc_bits=pow2[full_bits]-1;
    
    for (i=prob_blocks->log2_block_size; i<full_bits; i++)
      mask_proc_bits ^= pow2[i];

  
    for (i=0; i<(int)pow2[founder_sibs_w_fixed]; i++)
	prob_blocks->new_founder_sim_mask1[i] = (ordered_masks[i] & mask_proc_bits);
	
    for (i=1; i<prob_blocks->founder_sim_groups; i++) {
      prob_blocks->needed_blocks[i]=0;
      prob_blocks->needed_blocks[i]=(double*)malloc(sizeof(double)*(int)pow2[prob_blocks->log2_block_size]);

      if (prob_blocks->needed_blocks[i] == 0) {
	printf("ERROR: Insufficient memory for needed_blocks %d: mpi_distrib_founder_sim_markers\n", i);
	MPI_Abort(MPI_COMM_WORLD,1);
      }
    }

    for (i=0; i<(int)pow2[founder_sibs_w_fixed]; i++) {
      if(prob_blocks->did_fs_block[prob_blocks->founder_sim_blocks[i]] == 0) {
	prob_blocks->did_fs_block[prob_blocks->founder_sim_blocks[i]]=1;

	new_block=(int)(prob_blocks->foundersim_targetrep[i] ^ (long long int)prob_blocks->my_block);

	/*printf("Proc %d wants block %d on this iteration (%d)\n", mpi_interface.rank, new_block, i);*/

	comm_partner=prob_blocks->proc_block_ranks[new_block][prob_blocks->my_block_rank];
	MPI_Sendrecv(prob_blocks->local_block, (int)pow2[prob_blocks->log2_block_size], MPI_DOUBLE, comm_partner, 0, 
		     prob_blocks->needed_blocks[prob_blocks->founder_sim_blocks[i]], (int)pow2[prob_blocks->log2_block_size], 
		     MPI_DOUBLE, comm_partner, 0, MPI_COMM_WORLD, &status);
	
      }
    }
  }
  else {
     prob_blocks->needed_blocks=(double**)malloc(sizeof(double*));
     prob_blocks->needed_blocks[0]=prob_blocks->local_block;
   
     prob_blocks->new_founder_sim_mask1=ordered_masks;

  }

 
}




void mpi_partial_gather(int log2comm_size, int **proc_block_ranks, int my_rank, int my_block, 
			long long int *pow2, int block_piece_size, int *free_local, 
			double *block_piece,  double **converted_pvect)
{
  int i, j, comm_partner, local_size;
  double *correct_block_piece, *local_vect, *remote_vect, *net_vect;
  MPI_Status status;


  local_size=block_piece_size;
  local_vect=block_piece;
  
  
  for (i=0; i<log2comm_size; i++) {
    if (!(my_rank & (int)pow2[i]))
      comm_partner = my_rank + (int)pow2[i];
    else 
      comm_partner = my_rank - (int)pow2[i];
  
    remote_vect=(double*)malloc(sizeof(double)*local_size);

    if (remote_vect==NULL) {
       printf("ERROR: Insufficient buffer memory for mpi_partial_gather\n");
       MPI_Abort(MPI_COMM_WORLD,1);
    }
    
    MPI_Sendrecv(local_vect, local_size, MPI_DOUBLE, proc_block_ranks[my_block][comm_partner], 0, remote_vect, local_size,
		 MPI_DOUBLE, proc_block_ranks[my_block][comm_partner], 0, MPI_COMM_WORLD, &status);
    
    net_vect=(double*)malloc(sizeof(double)*(2*local_size));

    if (net_vect==NULL) {
      printf("ERROR: Insufficient buffer memory for mpi_partial_gather\n");
      MPI_Abort(MPI_COMM_WORLD,1);
    }

    if (!(my_rank & (int)pow2[i]))  {
      for (j=0; j<local_size; j++)
	net_vect[j]=local_vect[j];
      for (j=0; j<local_size; j++)
	net_vect[j+local_size]=remote_vect[j];
    }
    else {
      for (j=0; j<local_size; j++)
	net_vect[j]=remote_vect[j];
      for (j=0; j<local_size; j++)
	net_vect[j+local_size]=local_vect[j];
    }
    
    free(remote_vect);
    if (!((i == 0) && (*free_local == 1)))
      free(local_vect);
    
    local_vect=net_vect;
    local_size*=2;
  }
 
  (*converted_pvect)=net_vect;
  *free_local=0;
}


void mpi_redistribute_step2_marker_bothparallel(int source_bits, long long int source_mask, int target_bits, 
						long long int target_mask,
						long long int target_fixed_vals, int full_bits, int foundersim_families,
						long long int *pow2,
						double *source_vct, PBvct_blocks *prob_blocks)
     /*Uses 4 maskshift systems:
       maskshift:  removes fixed bits in source
       maskshift2: removes fixed bits in target
       maskshift3: removes fixed bits in target above proc. boundry
       maskshift4: removes fixed bits in source above proc. boundry */
{
  int i, j, k, match_fs, free_local_block=1,
    local_block_id, comm_partner,
    *local_block_starts=0, *local_block_ends=0, *local_block_ranks=0, my_block_owner, comm_steps, comm_start;
  long long int ii, kk, sourceproc_fixedbits, targetproc_fixedbits, fs_proc_flip, net_fixed_vals,
    mask_proc_bits, local_target_mask, local_target_fixed_vals, net_foundersim_mask;
  double  *local_block, *local_vect, *remote_vect, *net_vect;
  MPI_Status status;
  MPI_Request receive_request;

  /*if (mpi_interface.rank == 0)
    printf("Proc 0 entering mpi_redistribute_step2_marker_bothparallel\n");*/

 
  prob_blocks->free_needed_0=1;
  prob_blocks->did_founder_comm=1;

  /*Finds location of bits fixed in source but not target*/
  setup_maskshift(target_mask, full_bits, pow2, prob_blocks->maskshift2);
  
  prob_blocks->source_mask_targetrep=0;
  for (i=0; i<full_bits; i++)
    if (prob_blocks->maskshift2[i][0]  == pow2[i])
      prob_blocks->source_mask_targetrep |= (source_mask & prob_blocks->maskshift2[i][0])>>
	prob_blocks->maskshift2[i][1];
  
 
  for (i=0; i<full_bits; i++)
  /*Finds location of bits fixed in target but not source*/
  setup_maskshift(source_mask, full_bits, pow2, prob_blocks->maskshift);
  
  prob_blocks->target_mask_sourcerep=0;
  for(i=0; i<full_bits; i++) {
    if (prob_blocks->maskshift[i][0] == pow2[i])
	prob_blocks->target_mask_sourcerep |= (target_mask & prob_blocks->maskshift[i][0])>>
	  prob_blocks->maskshift[i][1];
  }

  
  /*Identifies how many different patterns of founder symmetry occur in the fixed bits of the source*/
  prob_blocks->founder_sim_groups=0;
  prob_blocks->new_founder_sim_mask1=(long long int*)malloc(sizeof(long long int)*(int)pow2[foundersim_families]);
  prob_blocks->founder_sim_blocks=(int*)malloc(sizeof(int)*(int)pow2[foundersim_families]);
  prob_blocks->target_fixed_vals_sourcerep=(long long int*)malloc(sizeof(long long int)*(int)pow2[foundersim_families]);
  prob_blocks->foundersim_targetrep=(long long int*)malloc(sizeof(long long int)*(int)pow2[foundersim_families]);
 
  mask_proc_bits=(pow2[mpi_interface.log2procs]-1)<<(target_bits-mpi_interface.log2procs);
  
  setup_maskshift(prob_blocks->source_mask_targetrep | mask_proc_bits , full_bits, pow2, prob_blocks->maskshift3);
 
 
  for (j=0; j<(int)pow2[foundersim_families]; j++) {
    prob_blocks->target_fixed_vals_sourcerep[j]=0;
    net_foundersim_mask=0;
  
    for (i=0; i<foundersim_families; i++)
      if ((int)pow2[i] & j)
	net_foundersim_mask |= prob_blocks->founder_sim_mask_fullrep[i];
	

    net_fixed_vals = target_fixed_vals ^ (net_foundersim_mask & target_mask);
    kk=0;
    for (i=0; i<full_bits; i++) 
      if (prob_blocks->maskshift[i][0] & pow2[i]) 
	kk |=  (net_fixed_vals & prob_blocks->maskshift[i][0])>>prob_blocks->maskshift[i][1];   
    
    prob_blocks->target_fixed_vals_sourcerep[j] = kk;
    
    kk=0;
    for (i=0; i<full_bits; i++) 
      if (prob_blocks->maskshift2[i][0] & pow2[i]) 
	kk |=  (net_foundersim_mask & prob_blocks->maskshift2[i][0])>>prob_blocks->maskshift2[i][1];   
    
    prob_blocks->foundersim_targetrep[j] = kk;
 
    prob_blocks->foundersim_targetrep[j] ^=  (prob_blocks->foundersim_targetrep[j] & prob_blocks->source_mask_targetrep);

    prob_blocks->new_founder_sim_mask1[j]=kk;

    kk=0;
    for (i=0; i<full_bits; i++)
      if (pow2[i] & prob_blocks->maskshift3[i][0])
	kk |= (prob_blocks->new_founder_sim_mask1[j] & prob_blocks->maskshift3[i][0]) >> prob_blocks->maskshift3[i][1];
    
    prob_blocks->new_founder_sim_mask1[j]=kk;  
   
  
    /*Determines if this is the first founder sim combination with this block number*/
    i=0;
    while ((i<j) && 
	   (prob_blocks->target_fixed_vals_sourcerep[j]
	    != prob_blocks->target_fixed_vals_sourcerep[i])) 
      i++;
  
    if (i<j) {
      match_fs=-1;

      /*We need a case where the fixed bits AND the processor bits match*/
      for(k=0; k<j; k++)
	  if ((prob_blocks->target_fixed_vals_sourcerep[j]
	    == prob_blocks->target_fixed_vals_sourcerep[k]) 
	      && ((prob_blocks->foundersim_targetrep[j]>>(target_bits-mpi_interface.log2procs)) ==
		  (prob_blocks->foundersim_targetrep[k]>>(target_bits-mpi_interface.log2procs))))
	    match_fs=k;

      if (match_fs != -1)
	prob_blocks->founder_sim_blocks[j]=prob_blocks->founder_sim_blocks[match_fs];
      else {
	prob_blocks->founder_sim_blocks[j]=prob_blocks->founder_sim_groups;
	prob_blocks->founder_sim_groups++;
      }
    }
    else {
      prob_blocks->founder_sim_blocks[j]=prob_blocks->founder_sim_groups;
      prob_blocks->founder_sim_groups++;
    } 
  
  }

  sourceproc_fixedbits=0;
  targetproc_fixedbits=0;  
  prob_blocks->target_proc_mask=prob_blocks->target_mask_sourcerep>>(source_bits-mpi_interface.log2procs);
  prob_blocks->source_proc_mask=prob_blocks->source_mask_targetrep>>(target_bits-mpi_interface.log2procs);

 
  for (i=0; i<mpi_interface.log2procs; i++) {
    if (pow2[i] & prob_blocks->target_proc_mask)
      targetproc_fixedbits++;
    if (pow2[i] & prob_blocks->source_proc_mask)
      sourceproc_fixedbits++;
  } 

 

  prob_blocks->num_blocks=(int)pow2[mpi_interface.log2procs-sourceproc_fixedbits];
  prob_blocks->num_live_procs=(int)pow2[mpi_interface.log2procs-targetproc_fixedbits];
 
  /*Note that if sourceproc_fixedbits>targetproc_fixedbits, then each "live" processor holds only 
    part of a block and blocks_per_live_proc==0*/
  prob_blocks->blocks_per_liveproc=prob_blocks->num_blocks/prob_blocks->num_live_procs;
 
  mask_proc_bits=pow2[source_bits-mpi_interface.log2procs]-1;
  local_target_mask=mask_proc_bits & prob_blocks->target_mask_sourcerep;
	
 
  prob_blocks->needed_blocks=(double**)malloc(sizeof(double*)*prob_blocks->founder_sim_groups);

  prob_blocks->did_fs_block=(int*)malloc(sizeof(int)*prob_blocks->founder_sim_groups);
  for(i=0; i<prob_blocks->founder_sim_groups; i++)
    prob_blocks->did_fs_block[i]=0;

 
  setup_maskshift(prob_blocks->target_proc_mask, mpi_interface.log2procs, pow2, prob_blocks->maskshift3);
  setup_maskshift(prob_blocks->source_proc_mask, mpi_interface.log2procs, pow2, prob_blocks->maskshift4);
  
  prob_blocks->proc_blocks=(int*)malloc(sizeof(int)*mpi_interface.num_procs);
  prob_blocks->proc_block_ranks=(int**)malloc(sizeof(int*)*prob_blocks->num_blocks);
  for(i=0; i<prob_blocks->num_blocks; i++) 
    prob_blocks->proc_block_ranks[i]=(int*)malloc(sizeof(int)*(mpi_interface.num_procs/prob_blocks->num_blocks));

  prob_blocks->orig_local=0;	
  
  local_block_starts=(int*)malloc(sizeof(int)*mpi_interface.num_procs);
  local_block_ends=(int*)malloc(sizeof(int)*mpi_interface.num_procs);
  local_block_ranks=(int*)malloc(sizeof(int)*mpi_interface.num_procs);

  /*We loop over all combos of founder sim, creating blocks for the first instance of each unique one*/
  for (k=0; k<(int)pow2[foundersim_families]; k++) {
    
    /*Have we already created a block for this fixed-bit pattern of founder symmetry?*/
    if (prob_blocks->did_fs_block[prob_blocks->founder_sim_blocks[k]] == 0)
      {
	prob_blocks->did_fs_block[prob_blocks->founder_sim_blocks[k]]=1;

	if (prob_blocks->target_proc_mask != 0) {
	  if ((prob_blocks->target_proc_mask & (long long int)mpi_interface.rank) == 
	      ((prob_blocks->target_fixed_vals_sourcerep[k]) >>(source_bits-mpi_interface.log2procs)))
	    prob_blocks->my_block_rank=0;
	  else
	    prob_blocks->my_block_rank=-1;
	}
	else
	  prob_blocks->my_block_rank=0;
	
	
	local_target_fixed_vals = mask_proc_bits & prob_blocks->target_fixed_vals_sourcerep[k];
	
	
	compact_prob_vct(source_bits, local_target_mask, local_target_fixed_vals, prob_blocks->founder_sim_blocks[k],
			 pow2, source_vct, prob_blocks);

	if (prob_blocks->my_block_rank != -1)
	  local_block=prob_blocks->needed_blocks[prob_blocks->founder_sim_blocks[k]];
	else
	  local_block=0;
	
	if (prob_blocks->blocks_per_liveproc>1)
	  prob_blocks->log2_block_size=prob_blocks->log2_block_size-(targetproc_fixedbits-sourceproc_fixedbits);
	
  
	/*We initialize all ranks to -1 so that we can assign correct ranks to processors with local data*/
	for(i=0; i<prob_blocks->num_blocks; i++) {
	  for (j=0; j<mpi_interface.num_procs/prob_blocks->num_blocks; j++)
	    prob_blocks->proc_block_ranks[i][j]=-1;
	}
	
	/*if (mpi_interface.rank == 0)
	printf("Proc %d: sourcemask(t): %d (F: %d) target_mask(s): %d (F: %d), target vals: %d source_bits: %d, target_bits: %d num blocks: %d target proc mask: %d source proc maks: %d, liveprocs: %d\n", mpi_interface.rank, prob_blocks->source_mask_targetrep, source_mask,
	       prob_blocks->target_mask_sourcerep, target_mask, prob_blocks->target_fixed_vals_sourcerep[k],  source_bits, target_bits,
	       prob_blocks->num_blocks, prob_blocks->target_proc_mask, prob_blocks->source_proc_mask, prob_blocks->num_live_procs);*/

	
	
	for (ii=0; ii<(long long int)mpi_interface.num_procs; ii++) {
	  i = (int)ii;
	  local_block_id=0;
	  for (j=0; j<mpi_interface.log2procs; j++)
	    if (prob_blocks->maskshift3[j][0] == pow2[j])
	      local_block_id |= (int)((ii & prob_blocks->maskshift3[j][0]) >> prob_blocks->maskshift3[j][1]);
	  
	
	  prob_blocks->proc_blocks[i]=0;
	
	  fs_proc_flip=ii ^ (prob_blocks->foundersim_targetrep[k]>>(target_bits-mpi_interface.log2procs));
	  for (j=0; j<mpi_interface.log2procs; j++)
	    if (prob_blocks->maskshift4[j][0] == pow2[j])
	      prob_blocks->proc_blocks[i] |= (fs_proc_flip & prob_blocks->maskshift4[j][0]) >> prob_blocks->maskshift4[j][1];
	  
	  /*Is i a "live" processor?*/
	  if ((prob_blocks->target_proc_mask & ii) == 
	      (prob_blocks->target_fixed_vals_sourcerep[k] >>(source_bits-mpi_interface.log2procs))) {
	    
	    
	    if (prob_blocks->blocks_per_liveproc == 0) {
	      local_block_starts[i]=local_block_ends[i]=local_block_id/(prob_blocks->num_live_procs/prob_blocks->num_blocks);
	      local_block_ranks[i]=local_block_id%(prob_blocks->num_live_procs/prob_blocks->num_blocks);
	      
	      /*This processor will eventually need the block it currently has a part of*/
	      if (prob_blocks->proc_blocks[i] == local_block_starts[i])
		prob_blocks->proc_block_ranks[prob_blocks->proc_blocks[i]][local_block_ranks[i]]=i;	
	    }
	    else {
	      
	      local_block_starts[i]=local_block_id*prob_blocks->blocks_per_liveproc;
	      local_block_ends[i]=((local_block_id+1)*prob_blocks->blocks_per_liveproc)-1;
	      local_block_ranks[i]=0; 
	      
	      
	      if ((prob_blocks->proc_blocks[i]>=local_block_starts[i]) && 
		  (prob_blocks->proc_blocks[i]<=local_block_ends[i])) 
		prob_blocks->proc_block_ranks[prob_blocks->proc_blocks[i]][0]=i;
	    }
	  }
	  else 
	    local_block_starts[i]=local_block_ends[i]=local_block_ranks[i]=-1;
	}
	
	
	for (i=0; i<mpi_interface.num_procs; i++) { 
	  if (!((prob_blocks->proc_blocks[i] >= local_block_starts[i]) && 
		(prob_blocks->proc_blocks[i] <= local_block_ends[i]))) {
	    j=0;
	    while (prob_blocks->proc_block_ranks[prob_blocks->proc_blocks[i]][j] != -1) j++; 
	    if (prob_blocks->proc_block_ranks[prob_blocks->proc_blocks[i]][j] != i )
	      prob_blocks->proc_block_ranks[prob_blocks->proc_blocks[i]][j]=i;
	  }
	}
	
	prob_blocks->my_block=prob_blocks->proc_blocks[mpi_interface.rank];
	j=0;
	while (prob_blocks->proc_block_ranks[prob_blocks->my_block][j] != mpi_interface.rank) j++;
	prob_blocks->my_block_rank=j;
	
	if (sourceproc_fixedbits > targetproc_fixedbits) {
	  i=0;
	  if (prob_blocks->my_block_rank <(prob_blocks->num_live_procs/prob_blocks->num_blocks)) {
	    while (!((local_block_starts[i] == prob_blocks->my_block) && (local_block_ranks[i] == prob_blocks->my_block_rank))) i++;
	    my_block_owner=i;
	  }
	  else
	    my_block_owner=mpi_interface.num_procs;
	}
	else {
	  i=0;
	  while (!((local_block_starts[i] <= prob_blocks->my_block) && (local_block_ends[i] >= prob_blocks->my_block))) i++;  
	  my_block_owner=i;
	}
	
	if (prob_blocks->blocks_per_liveproc >=1)
	  comm_steps=prob_blocks->blocks_per_liveproc;
	else
	  comm_steps=1;
	
	
	/*printf("Proc %d wants block %d, rank %d, owner: %d, commsteps: %d targetproc mask: %d sourceproc mask: %d source mask: %d targetmask: %d, fixedvals: %d\n", 
		 mpi_interface.rank, prob_blocks->my_block, prob_blocks->my_block_rank,
		 my_block_owner, comm_steps, prob_blocks->target_proc_mask, prob_blocks->source_proc_mask, source_mask, target_mask, target_fixed_vals);*/
	
	
	/*Exchange the current blocks such that the pieces lie in rank order on the processors that
	  need each block (i.e. block 1 rank 0 has the first piece of block 1 etc)*/
	
	for(i=0; i<comm_steps; i++) { 
	  if ((prob_blocks->my_block_rank <(prob_blocks->num_live_procs/prob_blocks->num_blocks)) || 
	      ((prob_blocks->num_live_procs<prob_blocks->num_blocks) && (prob_blocks->my_block_rank==0) ))
	    if (((prob_blocks->blocks_per_liveproc<=1) || (local_block_starts[my_block_owner]+i == prob_blocks->my_block))
		&& (my_block_owner != mpi_interface.rank)) {  
	      /*printf("Proc %d receiving correct block piece from %d\n", mpi_interface.rank, my_block_owner);*/
	 
	      prob_blocks->needed_blocks[prob_blocks->founder_sim_blocks[k]]=(double*)malloc(sizeof(double)*(int)pow2[prob_blocks->log2_block_size]);
	      if (prob_blocks->needed_blocks[prob_blocks->founder_sim_blocks[k]] == NULL) {
		printf("ERROR: Insufficient memory for Irecv: mpi_redistribute_step2_marker_bothparallel\n");
		MPI_Abort(MPI_COMM_WORLD,1);
	      }
	    

	      MPI_Irecv(prob_blocks->needed_blocks[prob_blocks->founder_sim_blocks[k]], (int)pow2[prob_blocks->log2_block_size], MPI_DOUBLE, my_block_owner, 0, 
			MPI_COMM_WORLD, &receive_request);
	    }
    
	  if ((local_block_starts[mpi_interface.rank] != -1)  && (local_block_starts[mpi_interface.rank]+i != prob_blocks->my_block)) {	
	    /* printf("Proc %d sending block %d to %d (ele 0: %6.5e, 1: %6.5e)\n", mpi_interface.rank, local_block_starts[mpi_interface.rank]+i, 
	      prob_blocks->proc_block_ranks[local_block_starts[mpi_interface.rank]+i][local_block_ranks[mpi_interface.rank]],
	      local_block[0], local_block[1]);*/
	    MPI_Send(&local_block[(int)pow2[prob_blocks->log2_block_size]*i], (int)pow2[prob_blocks->log2_block_size], 
		     MPI_DOUBLE, prob_blocks->proc_block_ranks[local_block_starts[mpi_interface.rank]+i][local_block_ranks[mpi_interface.rank]],
		     0, MPI_COMM_WORLD);
	  }
	  else if ((local_block_starts[mpi_interface.rank] != -1)  && (local_block_starts[mpi_interface.rank]+i == prob_blocks->my_block)) { 
	    if (prob_blocks->blocks_per_liveproc > 1)
	      {
		prob_blocks->needed_blocks[prob_blocks->founder_sim_blocks[k]]=(double*)malloc(sizeof(double)*(int)pow2[prob_blocks->log2_block_size]);
		if (prob_blocks->needed_blocks[prob_blocks->founder_sim_blocks[k]] == NULL) {
		  printf("ERROR: Insufficient memory for Irecv: mpi_redistribute_step2_marker_bothparallel\n");
		  MPI_Abort(MPI_COMM_WORLD,1);
		}
		

		for(j=0; j<(int)pow2[prob_blocks->log2_block_size]; j++)
		  prob_blocks->needed_blocks[prob_blocks->founder_sim_blocks[k]][j]=local_block[j+((int)pow2[prob_blocks->log2_block_size]*i)];
	      }
	    else
	      free_local_block=0;
	  }
	  if ((prob_blocks->my_block_rank <(prob_blocks->num_live_procs/prob_blocks->num_blocks)) || 
	      ((prob_blocks->num_live_procs<prob_blocks->num_blocks) && (prob_blocks->my_block_rank==0) ))
	    if (((prob_blocks->blocks_per_liveproc<=1) || (local_block_starts[my_block_owner]+i == prob_blocks->my_block)) 
		&& (my_block_owner != mpi_interface.rank)) 
	      MPI_Wait(&receive_request, &status);	/*Receive*/
	  
	}
	
	if ((local_block != 0) && (free_local_block == 1) && (prob_blocks->orig_local == 0))
	  free(local_block);
	
	
	
	if (sourceproc_fixedbits>targetproc_fixedbits) {
	  net_vect=0;
	  local_vect=prob_blocks->needed_blocks[prob_blocks->founder_sim_blocks[k]];
	  
	  /*printf("Proc %d doing initial compaction: local vct: %d,(ele 0: %6.5e, ele 1: %6.5e) sf: %d, tf: %d, block rank: %d, block_size: %d\n", mpi_interface.rank, local_vect, local_vect[0], local_vect[1],
	    sourceproc_fixedbits, targetproc_fixedbits, prob_blocks->my_block_rank, prob_blocks->log2_block_size);*/

	  /*Each block is divided among processors*/
	  for (i=0; i<sourceproc_fixedbits-targetproc_fixedbits; i++) {
      
	    if (prob_blocks->my_block_rank<(int)pow2[sourceproc_fixedbits-targetproc_fixedbits]) {
	      if (!(prob_blocks->my_block_rank & (int)pow2[i]))
		comm_partner = prob_blocks->proc_block_ranks[prob_blocks->my_block][prob_blocks->my_block_rank + (int)pow2[i]];
	      else 
		comm_partner = prob_blocks->proc_block_ranks[prob_blocks->my_block][prob_blocks->my_block_rank - (int)pow2[i]];
	      
	      remote_vect=(double*)malloc(sizeof(double)*(int)pow2[prob_blocks->log2_block_size]);
	      if (remote_vect == NULL) {
		printf("ERROR: Insufficient remote_vect buffer memory:  mpi_redistribute_step2_marker_bothparallel\n");
		MPI_Abort(MPI_COMM_WORLD,1);
	      }
	      /*printf("Proc %d compacting block with proc %d\n", mpi_interface.rank, comm_partner);*/
	      
	      MPI_Sendrecv(local_vect, (int)pow2[prob_blocks->log2_block_size], MPI_DOUBLE, comm_partner, 0, remote_vect, (int)pow2[prob_blocks->log2_block_size],
			   MPI_DOUBLE, comm_partner, 0, MPI_COMM_WORLD, &status);
	      
	      net_vect=(double*)malloc(sizeof(double)*(int)pow2[prob_blocks->log2_block_size+1]);
	      if (net_vect == NULL) {
		printf("ERROR: Insufficient net_vect buffer memory:  mpi_redistribute_step2_marker_bothparallel\n");
		MPI_Abort(MPI_COMM_WORLD,1);
	      }

	      if (!(prob_blocks->my_block_rank & (int)pow2[i]))  {
		for (j=0; j<(int)pow2[prob_blocks->log2_block_size]; j++)
		  net_vect[j]=local_vect[j];
		for (j=0; j<(int)pow2[prob_blocks->log2_block_size]; j++)
		  net_vect[j+(int)pow2[prob_blocks->log2_block_size]]=remote_vect[j];
	      }
	      else {
		for (j=0; j<(int)pow2[prob_blocks->log2_block_size]; j++)
		  net_vect[j]=remote_vect[j];
		for (j=0; j<(int)pow2[prob_blocks->log2_block_size]; j++)
		  net_vect[j+(int)pow2[prob_blocks->log2_block_size]]=local_vect[j];
	      }
	      
	      free(remote_vect);
	      if (!((i == 0) && (prob_blocks->orig_local == 1) && (prob_blocks->founder_sim_blocks[k]==0)))
		free(local_vect);
	      
	      local_vect=net_vect;
	    }
	    prob_blocks->log2_block_size++;
	  }
	  comm_start=sourceproc_fixedbits-targetproc_fixedbits;
	  if (net_vect != 0)
	    prob_blocks->needed_blocks[prob_blocks->founder_sim_blocks[k]]=net_vect;
	}
	else 
	  comm_start=0;
  
	
	for (i=comm_start; i<sourceproc_fixedbits; i++) {
	  if (prob_blocks->my_block_rank < (int)pow2[i]) {
	    comm_partner=prob_blocks->proc_block_ranks[prob_blocks->my_block][prob_blocks->my_block_rank+(int)pow2[i]];
	    /*printf("Proc %d Final comm: sending block to %d\n", mpi_interface.rank, comm_partner);*/
	    
	    MPI_Send(prob_blocks->needed_blocks[prob_blocks->founder_sim_blocks[k]],
		     (int)pow2[prob_blocks->log2_block_size], MPI_DOUBLE, comm_partner, 
		     0, MPI_COMM_WORLD);
	  }
	  else if (prob_blocks->my_block_rank < (int)pow2[i+1]) { 
	    comm_partner=prob_blocks->proc_block_ranks[prob_blocks->my_block][prob_blocks->my_block_rank-(int)pow2[i]];
	    /*printf("Proc %d Final comm: receiving block from %d\n", mpi_interface.rank, comm_partner);*/
	    
	    prob_blocks->needed_blocks[prob_blocks->founder_sim_blocks[k]]=
	      (double*)malloc(sizeof(double)*(int)pow2[prob_blocks->log2_block_size]);
	    if (prob_blocks->needed_blocks[prob_blocks->founder_sim_blocks[k]] == NULL) {
	      printf("ERROR: Insufficient needed_blocks buffer memory:  mpi_redistribute_step2_marker_bothparallel\n");
	      MPI_Abort(MPI_COMM_WORLD,1);
	    }

	    MPI_Recv(prob_blocks->needed_blocks[prob_blocks->founder_sim_blocks[k]], 
		     (int)pow2[prob_blocks->log2_block_size], MPI_DOUBLE, comm_partner, 
	       0, MPI_COMM_WORLD, &status);
	  }
	}  
      }
  }
 
  mask_proc_bits=(pow2[mpi_interface.log2procs]-1)<<(target_bits-mpi_interface.log2procs);
  
  
  setup_maskshift(prob_blocks->source_mask_targetrep | mask_proc_bits , full_bits, pow2, prob_blocks->maskshift);

 
  if (local_block_starts != 0)
    free(local_block_starts);
  if (local_block_ends != 0)
    free(local_block_ends);
  if (local_block_ranks != 0)
    free(local_block_ranks); 

 
}  /*End  mpi_redistribute_step2_marker_bothparallel*/




void mpi_redistribute_step2_marker_nonparallel_target(int source_bits, long long int source_mask, long long int target_bits, int full_bits, long long int target_mask, 
						      long long int target_fixed_vals, int foundersim_families,  long long int *pow2, double *source_vct, 
						      PBvct_blocks *prob_blocks)
     /*maskshift: removes source fixed bits*/
     /*maskshift3: removes target variable bits*/
{
  int i, j, k,  target_fixedproc_bits=0, comm_partner, *block_cnts, new_num_blocks, **new_block_ranks, 
    my_new_rank, my_new_block, *new_blocks;
  long long int  ii, jj, mask_proc_bits, net_foundersim_mask, local_target_mask, local_target_fixed_vals;
 MPI_Status status;


 /*if (mpi_interface.rank == 0)
   printf("Proc 0 entering mpi_redistribute_step2_marker_nonparallel_target\n");*/


  prob_blocks->free_needed_0=1;
  prob_blocks->did_founder_comm=1;

  /*First we assemble a mask of the target fixed bits in source representation*/
  setup_maskshift(source_mask, full_bits, pow2, prob_blocks->maskshift);
 
  /*Makes the marker fixed bit mask in source rep*/
  prob_blocks->target_mask_sourcerep=0; 
  for (i=0; i<full_bits; i++)
    if (prob_blocks->maskshift[i][0] & pow2[i]) 
      prob_blocks->target_mask_sourcerep |= (target_mask & prob_blocks->maskshift[i][0])>>prob_blocks->maskshift[i][1];


  /*Sets up a new maskshift system that contains on fixed bits of the target.  This is used to
    determine, for each founder_sim combination, which stored block to use*/
 
  /*For each founder sim group, find the source rep. for the values of the fixed bits*/ 
  prob_blocks->founder_sim_groups=0;
  prob_blocks->new_founder_sim_mask1=(long long int*)malloc(sizeof(long long int)*(int)pow2[foundersim_families]);
  prob_blocks->founder_sim_blocks=(int*)malloc(sizeof(int)*(int)pow2[foundersim_families]);
  prob_blocks->target_fixed_vals_sourcerep=(long long int*)malloc(sizeof(long long int)*(int)pow2[foundersim_families]);
 
  for (j=0; j<(int)pow2[foundersim_families]; j++) {
    prob_blocks->target_fixed_vals_sourcerep[j]=0;
    net_foundersim_mask=target_fixed_vals;
    for (i=0; i<foundersim_families; i++)
      if ((int)pow2[i] & j)
	net_foundersim_mask ^= prob_blocks->founder_sim_mask_fullrep[i];
    
    for (i=0; i<full_bits; i++) 
      if (prob_blocks->maskshift[i][0] & pow2[i]) 
	prob_blocks->target_fixed_vals_sourcerep[j] |= 
	  (net_foundersim_mask & prob_blocks->maskshift[i][0])>>prob_blocks->maskshift[i][1];   

    prob_blocks->target_fixed_vals_sourcerep[j] &=  prob_blocks->target_mask_sourcerep;
    
    /*Determines if this is the first founder sim combination with this block number*/
    i=0;
    while ((i<j) && 
	   (prob_blocks->target_fixed_vals_sourcerep[j] != prob_blocks->target_fixed_vals_sourcerep[i]))
      i++;
 
    if (i == j) {
      prob_blocks->founder_sim_blocks[j]=prob_blocks->founder_sim_groups;
      prob_blocks->founder_sim_groups++;
    }
    else
      prob_blocks->founder_sim_blocks[j]=prob_blocks->founder_sim_blocks[i];
     
  }


  prob_blocks->target_proc_mask=prob_blocks->target_mask_sourcerep>>(source_bits-mpi_interface.log2procs);

  target_fixedproc_bits=0;
  for(i=0; i<mpi_interface.log2procs; i++)
    if (pow2[i] &  prob_blocks->target_proc_mask)
      target_fixedproc_bits++;

  /*Now we need a maskshift system that gives us unique block numbers for each processor*/
  setup_maskshift(prob_blocks->target_proc_mask, mpi_interface.log2procs, pow2, prob_blocks->maskshift2);
  
 
  prob_blocks->num_blocks=(int)pow2[mpi_interface.log2procs-target_fixedproc_bits];
  prob_blocks->proc_blocks=(int*)malloc(sizeof(int)*mpi_interface.num_procs);
  prob_blocks->proc_block_ranks=(int**)malloc(sizeof(int*)*prob_blocks->num_blocks);
  block_cnts=(int*)malloc(sizeof(int)*prob_blocks->num_blocks);
	
  for(i=0; i<prob_blocks->num_blocks; i++)
    prob_blocks->proc_block_ranks[i]=(int*)malloc(sizeof(int)*(mpi_interface.num_procs/prob_blocks->num_blocks));
     	
  new_num_blocks=(int)pow2[target_fixedproc_bits];
	
  new_blocks=(int*)malloc(sizeof(int)*mpi_interface.num_procs);
  new_block_ranks=(int**)malloc(sizeof(int*)*new_num_blocks);
	
  for (i=0; i<new_num_blocks; i++)
    new_block_ranks[i]=(int*)malloc(sizeof(int)*(mpi_interface.num_procs/new_num_blocks));
	

  prob_blocks->needed_blocks=(double**)malloc(sizeof(double*)*prob_blocks->founder_sim_groups);
  prob_blocks->did_fs_block=(int*)malloc(sizeof(int)*prob_blocks->founder_sim_groups);
  for(i=0; i<prob_blocks->founder_sim_groups; i++)
    prob_blocks->did_fs_block[i]=0;

  /*printf("Proc %d about to enter comm loop: fs blocks: %d, sourcemasks tr: %d (o: %d), target_mask sr: %d (o: %d)\n", mpi_interface.rank,
    prob_blocks->founder_sim_groups, prob_blocks->source_mask_targetrep, source_mask, prob_blocks->target_mask_sourcerep, target_mask);*/
  /*We loop over all combos of founder sim, creating blocks for the first instance of each unique one*/
  for (k=0; k<(int)pow2[foundersim_families]; k++) {
    
    /*Have we already created a block for this fixed-bit pattern of founder symmetry?*/
    if (prob_blocks->did_fs_block[prob_blocks->founder_sim_blocks[k]] == 0)
      {
	prob_blocks->did_fs_block[prob_blocks->founder_sim_blocks[k]]=1;
	if (prob_blocks->target_proc_mask != 0) {
	  for (i=0; i<mpi_interface.num_procs; i++) {
	    ii=(long long int)i;
	    prob_blocks->proc_blocks[i]=0;
	    for (j=0; j<mpi_interface.log2procs; j++)
	      {
		if (prob_blocks->maskshift2[j][0] & pow2[j]) {
		  prob_blocks->proc_blocks[i] |= (ii & prob_blocks->maskshift2[j][0])
		    >>prob_blocks->maskshift2[j][1];
		}
	      }
	  }
	}
	else
	  for (i=0; i<mpi_interface.num_procs; i++) 
	    prob_blocks->proc_blocks[i]=i;
	
	prob_blocks->my_block=prob_blocks->proc_blocks[mpi_interface.rank];
	
	
	
	if (prob_blocks->target_proc_mask != 0) {
	  if ((prob_blocks->target_proc_mask & (long long int)mpi_interface.rank) == 
	      (prob_blocks->target_fixed_vals_sourcerep[k] >>(source_bits-mpi_interface.log2procs)))
	    prob_blocks->my_block_rank=0;
	  else
	    prob_blocks->my_block_rank=-1;
	}
	else
	  prob_blocks->my_block_rank=0;
	
	mask_proc_bits=pow2[source_bits-mpi_interface.log2procs]-1;
	
	
	local_target_mask=mask_proc_bits & prob_blocks->target_mask_sourcerep;
	local_target_fixed_vals = mask_proc_bits & prob_blocks->target_fixed_vals_sourcerep[k];
	
	prob_blocks->orig_local=0;	
	
	/*printf("Proc %d compacting vector\n", mpi_interface.rank);*/
	compact_prob_vct(source_bits, local_target_mask, local_target_fixed_vals, prob_blocks->founder_sim_blocks[k],
			 pow2, source_vct, prob_blocks);
		
	
	for( i=0; i<prob_blocks->num_blocks; i++)
	  block_cnts[i]=1;
	
	if (prob_blocks->target_proc_mask != 0) {
	  for(i=0; i<mpi_interface.num_procs; i++) {
	    ii=(long long int)i;
	    if ((prob_blocks->target_proc_mask & ii) != 
		(prob_blocks->target_fixed_vals_sourcerep[k] >>(source_bits-mpi_interface.log2procs))){ 
	      prob_blocks->proc_block_ranks[prob_blocks->proc_blocks[i]][block_cnts[prob_blocks->proc_blocks[i]]]=i;
	      
	      if (i == mpi_interface.rank)
		prob_blocks->my_block_rank = block_cnts[prob_blocks->proc_blocks[i]];
	      
	      block_cnts[prob_blocks->proc_blocks[i]]++;
	    }
	    else
	      prob_blocks->proc_block_ranks[prob_blocks->proc_blocks[i]][0]=i;
	    
	  }
	}
	else
	  for(i=0; i<mpi_interface.num_procs; i++)
	    prob_blocks->proc_block_ranks[prob_blocks->proc_blocks[i]][0]=i;
	
	for (i=0; i<target_fixedproc_bits; i++) {
	  if (prob_blocks->my_block_rank < (int)pow2[i]) {
	    comm_partner=prob_blocks->proc_block_ranks[prob_blocks->my_block][prob_blocks->my_block_rank+(int)pow2[i]];
	    /*printf("Proc %d sending block to proc %d\n", mpi_interface.rank, comm_partner);*/
	    MPI_Send(prob_blocks->needed_blocks[prob_blocks->founder_sim_blocks[k]], 
		     (int)pow2[prob_blocks->log2_block_size], MPI_DOUBLE, comm_partner, 
		     0, MPI_COMM_WORLD);
	  }
	  else if (prob_blocks->my_block_rank < (int)pow2[i+1]) { 
	    comm_partner=prob_blocks->proc_block_ranks[prob_blocks->my_block][prob_blocks->my_block_rank-(int)pow2[i]];
	    /*printf("Proc %d receiving block from proc %d\n", mpi_interface.rank, comm_partner);*/
	    prob_blocks->needed_blocks[prob_blocks->founder_sim_blocks[k]]=
	      (double*)malloc(sizeof(double)*(int)pow2[prob_blocks->log2_block_size]);
	    if ( prob_blocks->needed_blocks[prob_blocks->founder_sim_blocks[k]] == NULL) {
	      printf("ERROR: Insufficient needed_blocks buffer memory: mpi_redistribute_step2_marker_nonparallel_target\n");
	      MPI_Abort(MPI_COMM_WORLD,1);
	    }

	    MPI_Recv(prob_blocks->needed_blocks[prob_blocks->founder_sim_blocks[k]], (int)pow2[prob_blocks->log2_block_size], 
		     MPI_DOUBLE, comm_partner, 
		     0, MPI_COMM_WORLD, &status);
	  }
	}
    
	
	/*Now each block has the data it needs, so we "recreate" blocks to to gather*/    
	for (i=0; i<mpi_interface.num_procs; i++) {
	  j=0;
	  while (prob_blocks->proc_block_ranks[prob_blocks->proc_blocks[i]][j] != i) j++;
	  new_blocks[i]=j;
	} 
	my_new_block=new_blocks[mpi_interface.rank];
    
    
	for (i=0; i<mpi_interface.num_procs; i++) 	
	    new_block_ranks[new_blocks[i]][prob_blocks->proc_blocks[i]]=i;
	  
	my_new_rank=prob_blocks->my_block;
	
	/*printf("Proc %d doing gather\n", mpi_interface.rank);*/
	if (mpi_interface.log2procs-target_fixedproc_bits>0) 
	  mpi_partial_gather(mpi_interface.log2procs-target_fixedproc_bits, new_block_ranks, my_new_rank, my_new_block, 
			     pow2, (int)pow2[prob_blocks->log2_block_size], &prob_blocks->orig_local,
			     prob_blocks->needed_blocks[prob_blocks->founder_sim_blocks[k]],
			     &prob_blocks->needed_blocks[prob_blocks->founder_sim_blocks[k]]);
      }
  }
  
  /*Contains bits fixed in source but not target*/ 
  setup_maskshift(target_mask, full_bits, pow2, prob_blocks->maskshift2);
 
  jj=0;
  for (i=0; i<full_bits; i++)
    if (pow2[i] & prob_blocks->maskshift2[i][0])
      jj |= (source_mask & prob_blocks->maskshift2[i][0]) >> prob_blocks->maskshift2[i][1];

  prob_blocks->source_mask_targetrep=jj;

  setup_maskshift(prob_blocks->source_mask_targetrep, full_bits, pow2, prob_blocks->maskshift);
 
 
  /*Remove target fixed bits in fs mask*/
  for(k=0; k<(int)pow2[foundersim_families]; k++) { 
    net_foundersim_mask=0;
    for (i=0; i<foundersim_families; i++)
      if ((int)pow2[i] & k)
	net_foundersim_mask |= prob_blocks->founder_sim_mask_fullrep[i];
    
    jj=0;
    for (i=0; i<full_bits; i++)
      jj |= (net_foundersim_mask & prob_blocks->maskshift2[i][0]) >> prob_blocks->maskshift2[i][1];
    prob_blocks->new_founder_sim_mask1[k]=jj;

    jj=0;
    for (i=0; i<full_bits; i++)
      jj |= (prob_blocks->new_founder_sim_mask1[k] & prob_blocks->maskshift[i][0]) >> prob_blocks->maskshift[i][1];
    prob_blocks->new_founder_sim_mask1[k]=jj;
  }

  free(block_cnts);
  for (i=0; i<new_num_blocks; i++)
    free(new_block_ranks[i]);
  free(new_block_ranks);
  free(new_blocks);
}




/*Assumes target mask has bits only in "processor" area*/
void compact_prob_vct(int source_bits, long long int target_mask, long long int target_fixed_vals, int fs_block_id, 
		      long long int *pow2, double *source_vct, PBvct_blocks *prob_blocks)
{
  int i, local_bits, will_be_fixed_bits=0, reduced_vct_loc=0;
  long long int ii;

  local_bits=source_bits-mpi_interface.log2procs;

  for (i=0; i<local_bits; i++)
    if (pow2[i] & target_mask)
      will_be_fixed_bits++;
  prob_blocks->log2_block_size=local_bits-will_be_fixed_bits;


  if (prob_blocks->my_block_rank == 0) { 
    if (will_be_fixed_bits>0){
    
      prob_blocks->needed_blocks[fs_block_id]=(double*)malloc(sizeof(double)*(int)pow2[prob_blocks->log2_block_size]);

      if ( prob_blocks->needed_blocks[fs_block_id] == 0)
	{
	  printf ("Proc %d: Error in compact_prob_vct: Insufficient memory\n", mpi_interface.rank);
	  MPI_Abort(MPI_COMM_WORLD, 1);
	}

      for (ii=0; ii<pow2[local_bits]; ii++)
	if ((ii & target_mask) == target_fixed_vals)
	  prob_blocks->needed_blocks[fs_block_id][reduced_vct_loc++]=source_vct[(int)ii];  
    }
 
    else {
      prob_blocks->needed_blocks[fs_block_id]=source_vct;
      if (fs_block_id == 0)
	prob_blocks->orig_local=1; 
    }
  }
}  /*End compact_prob_vct*/



void setup_maskshift(long long int mask, int bits, long long int *pow2, long long int maskshift[64][2])
{
  int i;
 
  if (mask & 1) {
    maskshift[0][0]=0;
    maskshift[0][1]=1;
  }
  else {
    maskshift[0][0]=1;
    maskshift[0][1]=0;
  }

  for (i=1; i<bits; i++)
    {
      if (pow2[i] & mask) {
	maskshift[i][0]=0;
	maskshift[i][1]=maskshift[i-1][1]+1;
      }
      else {
	maskshift[i][0]=pow2[i];
	maskshift[i][1]=maskshift[i-1][1];
      }
    }
}



void cleanup_PBvct_struct(PBvct_blocks *prob_blocks)
{ 
  int i;
 

  if (prob_blocks->proc_blocks != 0)
    free(prob_blocks->proc_blocks);

  
  if (prob_blocks->proc_block_ranks != 0)
    {
      for (i=0; i<prob_blocks->num_blocks; i++)
	free(prob_blocks->proc_block_ranks[i]);
      free(prob_blocks->proc_block_ranks);
    }
  
 
  prob_blocks->proc_blocks=0;
  prob_blocks->proc_block_ranks=0;
 
 

  if ((prob_blocks->orig_local == 0) &&  (prob_blocks->local_block != 0))  
    free(prob_blocks->local_block);
  
  prob_blocks->local_block=0;

  
  if (prob_blocks->needed_blocks != 0) {
    if ((prob_blocks->free_needed_0 == 1) && (prob_blocks->orig_local == 0))
      free(prob_blocks->needed_blocks[0]);

 
    for (i=1; i<prob_blocks->founder_sim_groups; i++)
      free(prob_blocks->needed_blocks[i]);

  free(prob_blocks->needed_blocks);
  prob_blocks->needed_blocks=0;
  }


  if (prob_blocks->did_founder_comm == 1)
    free(prob_blocks->new_founder_sim_mask1);
  prob_blocks->new_founder_sim_mask1=0;

  if (prob_blocks->founder_sim_blocks != 0)
    free(prob_blocks->founder_sim_blocks);
  prob_blocks->founder_sim_blocks=0;

  if (prob_blocks->foundersim_targetrep != 0)
    free(prob_blocks->foundersim_targetrep);
  prob_blocks->foundersim_targetrep=0;

  if (prob_blocks->did_fs_block !=0)
    free(prob_blocks->did_fs_block);
  prob_blocks->did_fs_block=0;
  
 

  if (prob_blocks->target_fixed_vals_sourcerep != 0)
    free(prob_blocks->target_fixed_vals_sourcerep);
  prob_blocks->target_fixed_vals_sourcerep=0;

 
  prob_blocks->orig_local=1;
  prob_blocks->free_needed_0=0;
  prob_blocks->did_founder_comm=0;

 


}


void mpi_reduce_sharing_arrays(double ****wmatrix, int num_w_pos)
     /*This function reduces the individual processor's sharing arrays onto all processors.
       To do this, the 4-dim array wmatrix (5-d total, 4-d per pedigree) is copied
       into a 1-d array and then re-extracted*/
{
  int i, j, pos,count, num_members, triangle_size=0, array_size; 
  double *send_array, *receive_array;

  num_members=pedigree_size[num_pedigrees-1];
  for (i=1; i<num_members; i++) 
    for (j=0; j<i; j++) triangle_size++;

  array_size=num_w_pos*triangle_size*3;
  send_array=(double*)malloc(sizeof(double)*array_size);
  receive_array=(double*)malloc(sizeof(double)*array_size);

  count=0;
  for(pos=0; pos<num_w_pos; pos++)
    for (i=1; i<num_members; i++) 
      for (j=0; j<i; j++) { 
	receive_array[count]=0;
	send_array[count++]=wmatrix[pos][i][j][0];
	receive_array[count]=0;
	send_array[count++]=wmatrix[pos][i][j][1];
	receive_array[count]=0;
	send_array[count++]=wmatrix[pos][i][j][2];
      }
   MPI_Allreduce(send_array, receive_array, array_size, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
   
   count=0;
   for(pos=0; pos<num_w_pos; pos++)
    for (i=1; i<num_members; i++) 
      for (j=0; j<i; j++) { 
	wmatrix[pos][i][j][0]=receive_array[count++];
	wmatrix[pos][i][j][1]=receive_array[count++];
	wmatrix[pos][i][j][2]=receive_array[count++];
      }
} 


void mpi_cleanup ()
{
  unarray(mpi_interface.marker_full_vec_end, int);
  unarray(mpi_interface.marker_full_vec_start, int);
  unarray(mpi_interface.marker_vec_start, int);
  unarray(mpi_interface.marker_vec_end, int);
  unarray(mpi_interface.marker_bits, int);
  unarray(mpi_interface.do_marker_in_parallel, int);
 
  if (mpi_interface.num_procs > 1) {
    unarray(mpi_interface.net_score_count, int);
    unarray(mpi_interface.net_scores, double);
  }
}

